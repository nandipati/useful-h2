package io.hmheng.reporting.aggregator.core.service.assignments.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.Activity;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObject;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import io.hmheng.reporting.aggregator.web.domain.assignment.StudentAssignment;
import io.hmheng.reporting.aggregator.web.domain.event.Message;
import io.hmheng.reporting.aggregator.web.domain.event.StudentUpdatedEvent;
import org.joda.time.DateTime;
import org.junit.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

/**
 * Created by Dare Famuyiwa on 27/06/2016.
 */
public class StudentAssignmentsBatchConverterTest {

	@Test
	public void toStudentAssignmentBatchFromStudentUpdatedEventTest(){
		StudentUpdatedEvent studentUpdatedEvent = new StudentUpdatedEvent();

		Message message1 = new Message();
		message1.setDistrictRefUUID(UUID.fromString("52957381-f08b-4021-8d4d-e705a0d9f96d"));
		message1.setSchoolRefUUID(UUID.fromString("00b33268-d785-423e-85e4-c5ec687c3127"));
		message1.setStudentRefUUID(UUID.fromString("376f3382-c7cd-457f-b6bb-00bf83d72e38"));
		studentUpdatedEvent.add(message1);

		Message message2 = new Message();
		message2.setDistrictRefUUID(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"));
		message2.setSchoolRefUUID(UUID.fromString("10b33268-d785-423e-85e4-c5ec687c312f"));
		message2.setStudentRefUUID(UUID.fromString("476f3382-c7cd-457f-b6bb-00bf83d72e39"));
		studentUpdatedEvent.add(message2);

		StudentAssignmentsBatch studentAssignmentsBatch = StudentAssignmentsBatchConverter.toStudentAssignmentBatch(studentUpdatedEvent);
		List<StudentAssignmentReport> studentAssignmentReports = studentAssignmentsBatch.getStudentAssignmentReports();
		assertEquals(studentAssignmentReports.size(), studentUpdatedEvent.size());
		for(int i=0; i<studentAssignmentReports.size(); i++){
			Message message;
			if(i==0){
				message = message1;
			}else{
				message = message2;
			}
			assertEquals(studentAssignmentReports.get(i).getSchoolRefId(), message.getSchoolRefUUID());
			assertEquals(studentAssignmentReports.get(i).getLeaRefId(), message.getDistrictRefUUID());
			assertEquals(studentAssignmentReports.get(i).getStudentPersonalRefId(), message.getStudentRefUUID());
		}
	}

	@Test
	public void toStudentAssignmentBatchFromStudentAssignmentEventTest(){
		StudentAssignment studentAssignment = new StudentAssignment();

		Set<Activity> activities = new HashSet<>();
		Activity activity1 = new Activity();
		activity1.setRefId(UUID.fromString("52957381-f08b-4021-8d4d-e705a0d9f96d"));
		activity1.setStudentAssignmentRefId(UUID.fromString("00b33268-d785-423e-85e4-c5ec687c3127"));
		activity1.setTeacherReviewRefId(UUID.fromString("376f3382-c7cd-457f-b6bb-00bf83d72e38"));
		activity1.setGrade("10");
		activity1.setLevel("1");
		activity1.setSourceObject(new SourceObject("Test", "isbn", SourceObjectType.ACTIVITY,
				UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"), "name", "subjectCode", true, "correlationId:\"12121\""));

		activities.add(activity1);

		Activity activity2 = new Activity();
		activity2.setRefId(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f961"));
		activity2.setStudentAssignmentRefId(UUID.fromString("00b33268-d785-423e-85e4-c5ec687c3127"));
		activity2.setTeacherReviewRefId(UUID.fromString("376f3382-c7cd-457f-b6bb-00bf83d72e38"));
		activity2.setGrade("10");
		activity2.setLevel("1");
		activity2.setSourceObject(new SourceObject("Test", "isbn", SourceObjectType.ACTIVITY,
				UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"), "name", "subjectCode", true, "correlationId:\"12121\""));
		activities.add(activity2);

		studentAssignment.setActivities(activities);
		studentAssignment.setAttributes("Some attributes");
		studentAssignment.setAvailableDate(new DateTime());
		studentAssignment.setCustomClientData("Some custom client data");
		studentAssignment.setDueDate(new DateTime());
		studentAssignment.setMessageAttributes("some message attributes");
		studentAssignment.setPreamble("Some preamble");
		studentAssignment.setRefId(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"));
		studentAssignment.setSchoolRefId(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"));
		studentAssignment.setSectionId(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"));
		studentAssignment.setStaffPersonalRefId(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"));
		studentAssignment.setTeacherAssignmentRefId(UUID.fromString("62957381-f08b-4021-8d4d-e705a0d9f96e"));
		studentAssignment.setSubmitDate(new DateTime());

		StudentAssignmentsBatch studentAssignmentsBatch = StudentAssignmentsBatchConverter.toStudentAssignmentBatch(studentAssignment);
		List<StudentAssignmentReport> studentAssignmentReports = studentAssignmentsBatch.getStudentAssignmentReports();
		assertEquals(studentAssignmentReports.size(), activities.size());

		int size = studentAssignmentReports.size();
		if(size == 2) {
			assertEquals(studentAssignmentReports.get(size - 2).getStudentPersonalRefId(), studentAssignment.getStudentPersonalRefId());
			assertEquals(studentAssignmentReports.get(size - 2).getStartDate(), activity1.getStartDate());
			assertEquals(studentAssignmentReports.get(size - 1).getStudentPersonalRefId(), studentAssignment.getStudentPersonalRefId());
			assertEquals(studentAssignmentReports.get(size - 1).getStartDate(), activity2.getStartDate());
		}
	}

}
