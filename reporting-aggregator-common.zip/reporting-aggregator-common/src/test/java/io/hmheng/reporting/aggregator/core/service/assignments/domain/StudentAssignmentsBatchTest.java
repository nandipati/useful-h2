package io.hmheng.reporting.aggregator.core.service.assignments.domain;

import io.hmheng.reporting.aggregator.core.service.utils.GenericBeanCoverage;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by Dare Famuyiwa on 27/06/2016.
 */
public class StudentAssignmentsBatchTest {
	@Test
	public void testGettersAndSetters() throws InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		GenericBeanCoverage.doBeanCodeCoverage(StudentAssignmentsBatch.class);
	}
}
