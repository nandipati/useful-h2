package io.hmheng.reporting.aggregator.web.domain.assignment;

public enum SourceTopicName {

    student_updated,
    teacher_assignment_create,
    teacher_assignment_update,
    teacher_assignment_delete,
    testing_event_closed;

    public static SourceTopicName fromString(String value) {
        return valueOf(value.trim());
    }

    public static boolean isStudentUpdated(String sourceTopicName){
        return student_updated.name().equals(sourceTopicName);
    }

    public static boolean isTestingEventClosed(String sourceTopicName){
        return testing_event_closed.name().equals(sourceTopicName);
    }
}
