package io.hmheng.reporting.aggregator.web.domain.event;

import java.util.ArrayList;

public class StudentUpdatedEvent extends ArrayList<Message>{}
