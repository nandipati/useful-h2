package io.hmheng.reporting.aggregator.utils;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.cloud.sleuth.Span;
import org.springframework.util.StringUtils;

import java.security.SecureRandom;
import java.util.Map;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils;

import static io.hmheng.reporting.aggregator.Constants.CONTEXT_ID;
import static io.hmheng.reporting.aggregator.Constants.PLATFORM_ID;

public class ProcessorUtils {

    private static final Logger logger = LoggerFactory.getLogger(ProcessorUtils.class);

    private static final SecureRandom idGenerator = new SecureRandom();

    /**
     * Set HMH headers based on the exchange body
     * @param exchange
     */

    public static void setHmhHeaders(Exchange exchange){
      String body = ExchangeUtils.getBody(exchange);
      Map<String, Object> headers = exchange.getIn().getHeaders();

      String correlationId = CommonMessageUtils.getCorrelationId(body, headers);

      if (StringUtils.isEmpty(correlationId)) {
        correlationId = Span.idToHex(idGenerator.nextLong());
      }
      exchange.getIn().setHeader(Constants.CORRELATION_ID, correlationId);
      MDC.put(Constants.CORRELATION_ID, correlationId);

      String spanId = CommonMessageUtils.getMessageAttribute(Constants.SPAN_ID, body, headers);
      if (StringUtils.isEmpty(spanId)) {
        spanId = Span.idToHex(idGenerator.nextLong());
      }

      exchange.getIn().setHeader(Constants.SPAN_ID, spanId);
      MDC.put(Constants.SPAN_ID, spanId);

      String contextId = CommonMessageUtils.getMessageAttribute(CONTEXT_ID, body, headers);
      if (CommonMessageUtils.isContextIdValid(contextId)) {
          exchange.getIn().setHeader(Constants.CONTEXT_ID, contextId);
          MDC.put(Constants.CONTEXT_ID, contextId);
      } else {
         logger.warn("Missing contextId from message {}", correlationId);
      }

      String platformId = CommonMessageUtils.getMessageAttribute(PLATFORM_ID, body, headers);
      if (CommonMessageUtils.isPlatformIdValid(platformId)) {
        exchange.getIn().setHeader(Constants.PLATFORM_ID, platformId);
        MDC.put(Constants.PLATFORM_ID, platformId);
      } else {
        logger.warn("Missing Platform ID from message {}", correlationId);
      }
    }

    public static void clearMdc() {
      MDC.remove(Constants.CORRELATION_ID);
      MDC.remove(Constants.SPAN_ID);
      MDC.remove(Constants.CONTEXT_ID);
      MDC.remove(Constants.PLATFORM_ID);
    }
}
