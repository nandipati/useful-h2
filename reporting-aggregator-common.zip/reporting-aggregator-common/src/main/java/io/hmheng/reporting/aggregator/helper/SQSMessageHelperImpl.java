package io.hmheng.reporting.aggregator.helper;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.GetQueueUrlRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.google.common.collect.Lists;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

import io.hmheng.reporting.aggregator.config.SQSConfig;

/**
 * A helper class to work with SQS.
 */
@Component
public class SQSMessageHelperImpl implements SQSMessageHelper {

    private static Logger logger = LoggerFactory.getLogger(SQSMessageHelperImpl.class);
    
    @Override
    public List<Message> readMessages(AWSCredentials credentials, SQSConfig config) {
        // Setup SQS Client
        AmazonSQSClient client = new AmazonSQSClient(credentials);
        client.setRegion(Region.getRegion(Regions.fromName(config.getRegion())));
        client.setEndpoint(config.getEndpoint());
        
        logger.info("SQS Endpoint URL --> {}", config.getEndpoint());
        
        GetQueueUrlRequest queueUrlRequest = new GetQueueUrlRequest(config.getQueue());
        String queueUrl = client.getQueueUrl(queueUrlRequest).getQueueUrl();
        
        ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(queueUrl);
        receiveMessageRequest.withMaxNumberOfMessages(config.getMaxMessages());
        receiveMessageRequest.setWaitTimeSeconds(config.getDelaySeconds());
        receiveMessageRequest.setMaxNumberOfMessages(config.getMaxMessages());
        receiveMessageRequest.setVisibilityTimeout(config.getVisibilityTimeout());
        
        return client.receiveMessage(receiveMessageRequest).getMessages();
    }
    
    @Override
    public void deleteMessage(AWSCredentials credentials, String receiptHandle, SQSConfig config) {
        deleteMessages(credentials, Lists.newArrayList(receiptHandle), config);
    }

    @Override
    public void deleteMessages(AWSCredentials credentials, List<String> receiptHandles, SQSConfig config) {
        try {
            // Setup SQS Client
            AmazonSQSClient sqsClient = new AmazonSQSClient(credentials);
            sqsClient.setRegion(Region.getRegion(Regions.fromName(config.getRegion())));
            sqsClient.setEndpoint(config.getEndpoint());

            logger.info("SQS Endpoint URL --> {}", config.getEndpoint());

            GetQueueUrlRequest queueUrlRequest = new GetQueueUrlRequest(config.getQueue());
            String queueUrl = sqsClient.getQueueUrl(queueUrlRequest).getQueueUrl();

            for (String receiptHandle : receiptHandles) {
                DeleteMessageRequest deleteRequest = new DeleteMessageRequest();
                deleteRequest.setQueueUrl(queueUrl);
                deleteRequest.setReceiptHandle(receiptHandle);

                logger.info("Delete Request for Message Receipt Handle --> {}", receiptHandle);
                sqsClient.deleteMessage(deleteRequest);
            }
        } catch (Exception e) {
            logger.error("{}: {}", e.getClass().getCanonicalName(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public String sqsUri(SQSConfig sqsConfig , String sqsClientName) {
        return String.format(
                "aws-sqs://%s?"
                        + "amazonSQSClient=#%s&"
                        + "region=%s&"
                        + "queueOwnerAWSAccountId=%s",

                sqsConfig.getQueue(), sqsClientName, sqsConfig.getRegion(), sqsConfig.getAccountId());
    }
    
}
