package io.hmheng.reporting.aggregator.core.service.assignments.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.hmheng.reporting.aggregator.utils.JsonDateTimeDeserializerUtc;
import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import org.joda.time.DateTime;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class StudentAssignmentReport {

    private UUID refId; //studentAssignmentRefId
    private UUID studentPersonalRefId;
	private UUID schoolRefId;
	private UUID leaRefId;
    private AssignmentStatus status;
    private UUID activityId; //test event activity id
    private DateTime startDate;
    private DateTime submitDate;

    //student's instance of activity (their activity id) aka their session id
    private Set<StudentActivityRefIdDto> activities = new HashSet<>();
    private UUID studentActivityRefId;   //session_id

    private UUID studentGroupRefId;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(DateTime submitDate) {
        this.submitDate = submitDate;
    }

	public UUID getSchoolRefId() {
		return schoolRefId;
	}

	public void setSchoolRefId(UUID schoolRefId) {
		this.schoolRefId = schoolRefId;
	}

	public UUID getLeaRefId() {
		return leaRefId;
	}

	public void setLeaRefId(UUID leaRefId) {
		this.leaRefId = leaRefId;
	}

    public Set<StudentActivityRefIdDto> getActivities() {
        return activities;
    }

    public void setActivities(Set<StudentActivityRefIdDto> activities) {
        this.activities = activities;
    }

    public UUID getStudentGroupRefId() {
        return studentGroupRefId;
    }

    public void setStudentGroupRefId(UUID studentGroupRefId) {
        this.studentGroupRefId = studentGroupRefId;
    }


    /**
     * Utility function to get the studentActivityRefId from the Set of activities.
     * For more info see Assignment endpoint /v2/testingEvents/{id}/studentAssignments
     * @return
     */
    public UUID getStudentActivityRefId(){
        if(this.studentActivityRefId == null && this.activities!=null && this.activities.size()>0){
            //Note: As of 21st July 2016 there is a 1 to 1 relationship between StudentAssignment and Activity
            //so we take the first one in the set
            this.studentActivityRefId = this.activities.iterator().next().getRefId();
        }
        return this.studentActivityRefId;
    }

    //formative sets this id directly, benchmark derives it from the list of activities above in getStudentActivityRefId()
    public void setStudentActivityRefId(UUID studentActivityRefId){
        this.studentActivityRefId = studentActivityRefId;
    }

	@Override
    public String toString() {
        return "StudentAssignmentReport{" +
                "refId=" + refId +
                ", studentPersonalRefId=" + studentPersonalRefId +
				", schoolRefId=" + schoolRefId +
				", leaRefId=" + leaRefId +
                ", status=" + status +
                ", activityId=" + activityId +
                ", startDate=" + startDate +
                ", submitDate=" + submitDate +
                ", studentActivityRefId=" + studentActivityRefId +
                ", activities=" + activities +
                '}';
    }
}
