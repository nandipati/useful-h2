package io.hmheng.reporting.aggregator.web.handler;

/**
 * Created by nandipatim on 2/15/17.
 */
public enum PlatformId {
  IDS;
}
