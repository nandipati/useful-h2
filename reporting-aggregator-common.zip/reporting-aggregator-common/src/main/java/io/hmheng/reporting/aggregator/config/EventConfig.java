package io.hmheng.reporting.aggregator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties(prefix = "event")
public class EventConfig {

    @NestedConfigurationProperty
    private SingleEventConfig location;

    @NestedConfigurationProperty
    private SingleEventConfig demographic;

    @NestedConfigurationProperty
    private SingleEventConfig studentCompleted;

    @NestedConfigurationProperty
    private SingleEventConfig assignmentDelete;

    @NestedConfigurationProperty
    private SingleEventConfig testingEvent;

    @NestedConfigurationProperty
    private SingleEventConfig testEventClosed;

    @NestedConfigurationProperty
    private SingleEventConfig testEventClosedRetry;

    @NestedConfigurationProperty
    private SingleEventConfig testingEventSaveAndAssign;

    @NestedConfigurationProperty
    private SingleEventConfig eventDetails;

    @NestedConfigurationProperty
    private SingleEventConfig studentCompletedScores;

    @NestedConfigurationProperty
    private SingleEventConfig studentCompletedScoresRetry;

    @NestedConfigurationProperty
    private SingleEventConfig testEventReopened;

    @NestedConfigurationProperty
    private SingleEventConfig studentInProgress;

    @NestedConfigurationProperty
    private SingleEventConfig studentReadyForScoring;

    @NestedConfigurationProperty
    private SingleEventConfig studentUpdated;

    @NestedConfigurationProperty
    private SingleEventConfig teacherAssignmentCreate;

    @NestedConfigurationProperty
    private SingleEventConfig teacherAssignmentUpdate;

    @NestedConfigurationProperty
    private SingleEventConfig teacherAssignmentDelete;

    @NestedConfigurationProperty
    private SingleEventConfig pushScoresScoringStream;

    @NestedConfigurationProperty
    private SingleEventConfig scoresDeadLetter;

    @NestedConfigurationProperty
    private SingleEventConfig studentAssignmentStandardScores;


    public SingleEventConfig getLocation() {
        return location;
    }

    public void setLocation(SingleEventConfig location) {
        this.location = location;
    }

    public SingleEventConfig getDemographic() {
        return demographic;
    }

    public void setDemographic(SingleEventConfig demographic) {
        this.demographic = demographic;
    }

    public SingleEventConfig getTestingEvent() {
        return testingEvent;
    }

    public void setTestingEvent(SingleEventConfig testingEvent) {
        this.testingEvent = testingEvent;
    }

    public SingleEventConfig getTestingEventSaveAndAssign() {
        return testingEventSaveAndAssign;
    }

    public void setTestingEventSaveAndAssign(SingleEventConfig testingEventSaveAndAssign) {
        this.testingEventSaveAndAssign = testingEventSaveAndAssign;
    }

    public SingleEventConfig getStudentCompleted() {
        return studentCompleted;
    }

    public void setStudentCompleted(SingleEventConfig studentCompleted) {
        this.studentCompleted = studentCompleted;
    }

    public SingleEventConfig getTestEventClosed() {
        return testEventClosed;
    }

    public void setTestEventClosedRetry(SingleEventConfig testEventClosedRetry) {
        this.testEventClosedRetry = testEventClosedRetry;
    }

    public SingleEventConfig getTestEventClosedRetry() {
        return testEventClosedRetry;
    }

    public void setTestEventClosed(SingleEventConfig testEventClosed) {
        this.testEventClosed = testEventClosed;
    }

    public SingleEventConfig getEventDetails() {
        return eventDetails;
    }

    public void setEventDetails(SingleEventConfig eventDetails) {
        this.eventDetails = eventDetails;
    }

    public SingleEventConfig getStudentCompletedScores() {
        return studentCompletedScores;
    }

    public void setStudentCompletedScores(SingleEventConfig studentCompletedScores) {
        this.studentCompletedScores = studentCompletedScores;
    }

    public SingleEventConfig getStudentCompletedScoresRetry() {
        return studentCompletedScoresRetry;
    }

    public void setStudentCompletedScoresRetry(SingleEventConfig studentCompletedScoresRetry) {
        this.studentCompletedScoresRetry = studentCompletedScoresRetry;
    }

    public SingleEventConfig getTestEventReopened() {
        return testEventReopened;
    }

    public void setTestEventReopened(SingleEventConfig testEventReopened) {
        this.testEventReopened = testEventReopened;
    }

    public SingleEventConfig getStudentInProgress() {
        return studentInProgress;
    }

    public SingleEventConfig getStudentReadyForScoring() {
        return studentReadyForScoring;
    }

    public void setStudentInProgress(SingleEventConfig studentInProgress) {
        this.studentInProgress = studentInProgress;
    }

    public void setStudentReadyForScoring(SingleEventConfig studentReadyForScoring) {
        this.studentReadyForScoring = studentReadyForScoring;
    }

    public SingleEventConfig getStudentUpdated() {
        return studentUpdated;
    }

    public void setStudentUpdated(SingleEventConfig studentUpdated) {
        this.studentUpdated = studentUpdated;
    }

    public SingleEventConfig getTeacherAssignmentCreate() {
        return teacherAssignmentCreate;
    }

    public void setTeacherAssignmentCreate(SingleEventConfig teacherAssignmentCreate) {
        this.teacherAssignmentCreate = teacherAssignmentCreate;
    }

    public SingleEventConfig getTeacherAssignmentUpdate() {
        return teacherAssignmentUpdate;
    }

    public void setTeacherAssignmentUpdate(SingleEventConfig teacherAssignmentUpdate) {
        this.teacherAssignmentUpdate = teacherAssignmentUpdate;
    }

    public SingleEventConfig getPushScoresScoringStream() {
        return pushScoresScoringStream;
    }

    public void setPushScoresScoringStream(SingleEventConfig pushScoresScoringStream) {
        this.pushScoresScoringStream = pushScoresScoringStream;
    }

    public SingleEventConfig getScoresDeadLetter() {
        return scoresDeadLetter;
    }

    public void setScoresDeadLetter(SingleEventConfig scoresDeadLetter) {
        this.scoresDeadLetter = scoresDeadLetter;
    }

    public SingleEventConfig getTeacherAssignmentDelete() {
        return teacherAssignmentDelete;
    }

    public void setTeacherAssignmentDelete(SingleEventConfig teacherAssignmentDelete) {
        this.teacherAssignmentDelete = teacherAssignmentDelete;
    }

    public SingleEventConfig getAssignmentDelete() {
        return assignmentDelete;
    }

    public void setAssignmentDelete(SingleEventConfig assignmentDelete) {
        this.assignmentDelete = assignmentDelete;
    }

    public SingleEventConfig getStudentAssignmentStandardScores() {
        return studentAssignmentStandardScores;
    }

    public void setStudentAssignmentStandardScores(SingleEventConfig studentAssignmentStandardScores) {
        this.studentAssignmentStandardScores = studentAssignmentStandardScores;
    }
}
