package io.hmheng.reporting.aggregator.core.service.assignments.domain;


import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ActivitiesBatch {
    private UUID testingEventRefId;
    private List<ActivityForScores> activities;

    public ActivitiesBatch(){

    }

    public ActivitiesBatch(UUID testingEventRefId){
        this.testingEventRefId = testingEventRefId;
    }

    public UUID getTestingEventRefId() {
        return testingEventRefId;
    }

    public void setTestingEventRefId(UUID testingEventRefId) {
        this.testingEventRefId = testingEventRefId;
    }

    public List<ActivityForScores> getActivities() {
        return activities;
    }

    public void setActivities(List<ActivityForScores> activities) {
        this.activities = activities;
    }

    public void addActivity(ActivityForScores activityForScores){
        if (activities==null){
            activities = new ArrayList<>();
        }
        activities.add(activityForScores);
    }

    @Override
    public String toString() {
        return "ActivitiesBatch [testingEventRefId=" + testingEventRefId
                + ", activities=" + activities + "]";
    }
}
