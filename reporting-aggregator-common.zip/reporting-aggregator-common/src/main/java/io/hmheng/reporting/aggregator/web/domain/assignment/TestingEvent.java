package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.hmheng.reporting.aggregator.core.service.domain.Organisation;
import io.hmheng.reporting.aggregator.utils.JsonDateTimeDeserializerUtc;
import org.codehaus.jackson.annotate.JsonProperty;
import org.joda.time.DateTime;

import java.util.Set;
import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestingEvent {

    private UUID refId;
    private String eventName;
    private UUID staffPersonalRefId;
    private DateTime startDate;
    private DateTime finishDate;
    private DateTime originalStartDate;
    private DateTime originalFinishDate;
    private DateTime normDate;
    private TestingEventStatus status;
    private AssignmentStatus assignmentStatus;
    private String discipline;
    private String productId;
    private String programName;
    @JsonProperty("organisations")
    private Set<Organisation> organisations;
    private UUID leaRefId;    //aka districtId
    private UUID schoolRefId;
    private AssignmentCountInfo assignmentCountInfo;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(DateTime finishDate) {
        this.finishDate = finishDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getOriginalStartDate() {
        return originalStartDate;
    }

    public void setOriginalStartDate(DateTime originalStartDate) {
        this.originalStartDate = originalStartDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getOriginalFinishDate() {
        return originalFinishDate;
    }

    public void setOriginalFinishDate(DateTime originalFinishDate) {
        this.originalFinishDate = originalFinishDate;
    }

    public TestingEventStatus getStatus() {
        return status;
    }

    public void setStatus(TestingEventStatus status) {
        this.status = status;
    }

    public AssignmentStatus getAssignmentStatus() {
        return assignmentStatus;
    }

    public void setAssignmentStatus(AssignmentStatus assignmentStatus) {
        this.assignmentStatus = assignmentStatus;
    }

    public String getDiscipline() {
        return discipline;
    }

    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Set<Organisation> getOrganisations() {
        return organisations;
    }

    public void setOrganisations(Set<Organisation> organisations) {
        this.organisations = organisations;
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
	public DateTime getNormDate() {
		return normDate;
	}

	public void setNormDate(DateTime normDate) {
		this.normDate = normDate;
	}

    public boolean isOpen() {
        return TestingEventStatus.OPEN.equals(status);
    }

	public String getProgramName() {
		return programName;
	}
    
	public void setProgramName(String programName) {
		this.programName = programName;
	}

    public AssignmentCountInfo getAssignmentCountInfo() {
        return assignmentCountInfo;
    }

    public void setAssignmentCountInfo(AssignmentCountInfo assignmentCountInfo) {
        this.assignmentCountInfo = assignmentCountInfo;
    }

    @Override
    public String toString() {
        return "{" +
                "refId=" + refId +
                ", eventName='" + eventName + '\'' +
                ", staffPersonalRefId=" + staffPersonalRefId +
                ", startDate=" + startDate +
                ", finishDate=" + finishDate +
                ", originalStartDate=" + originalStartDate +
                ", originalFinishDate=" + originalFinishDate +
                ", normDate=" + normDate +
                ", status=" + status +
                ", assignmentStatus=" + assignmentStatus +
                ", discipline='" + discipline + '\'' +
                ", productId='" + productId + '\'' +
                ", programName='" + programName + '\'' +
                ", organisations=" + organisations +
                ", leaRefId=" + leaRefId +
                ", schoolRefId=" + schoolRefId +
                ", assignmentCountInfo=" + assignmentCountInfo +
                '}';
    }
}
