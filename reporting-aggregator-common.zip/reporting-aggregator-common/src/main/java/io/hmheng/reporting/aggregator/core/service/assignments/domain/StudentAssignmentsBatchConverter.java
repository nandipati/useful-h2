package io.hmheng.reporting.aggregator.core.service.assignments.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.Activity;
import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObject;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import io.hmheng.reporting.aggregator.web.domain.assignment.Student;
import io.hmheng.reporting.aggregator.web.domain.assignment.StudentAssignment;
import io.hmheng.reporting.aggregator.web.domain.assignment.TeacherAssignment;
import io.hmheng.reporting.aggregator.web.domain.assignment.TeacherAssignmentUpdate;
import io.hmheng.reporting.aggregator.web.domain.event.Message;
import io.hmheng.reporting.aggregator.web.domain.event.StudentUpdatedEvent;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class StudentAssignmentsBatchConverter {


	public static StudentAssignmentsBatch toStudentAssignmentBatch(StudentUpdatedEvent studentUpdatedEvent) {
		StudentAssignmentsBatch studentAssignmentsBatch = new StudentAssignmentsBatch();

		if(!CollectionUtils.isEmpty(studentUpdatedEvent)){
			for(Message message: studentUpdatedEvent){
				StudentAssignmentReport studentAssignmentReport = new StudentAssignmentReport();
				studentAssignmentReport.setStudentPersonalRefId(message.getStudentRefUUID());
				studentAssignmentReport.setLeaRefId(message.getDistrictRefUUID());
				studentAssignmentReport.setSchoolRefId(message.getSchoolRefUUID());
				studentAssignmentsBatch.addStudentAssignment(studentAssignmentReport);
			}
		}

		return studentAssignmentsBatch;
	}

    public static StudentAssignmentsBatch toStudentAssignmentBatch(TeacherAssignment teacherAssignment) {

        StudentAssignmentsBatch studentAssignmentsBatch = new StudentAssignmentsBatch();
        SourceObjectType sourceObjectType = teacherAssignment.getSourceObjectType();

        studentAssignmentsBatch.setEventRefId(teacherAssignment.getRefId());
        studentAssignmentsBatch.setSourceObjectType(sourceObjectType);
        studentAssignmentsBatch.setSchoolRefId(teacherAssignment.getSchoolRefId());
        studentAssignmentsBatch.setSectionId(teacherAssignment.getSectionId());
        studentAssignmentsBatch.setLeaRefId(teacherAssignment.getLeaRefId());

        UUID activityId = teacherAssignment.getUgenRefId();

        for(Student student: teacherAssignment.getStudents()){
            StudentAssignmentReport studentAssignmentReport = new StudentAssignmentReport();
            if(sourceObjectType == SourceObjectType.PERFORMANCE_TASK){
                studentAssignmentReport.setActivityId(teacherAssignment.getRefId());
            }else{
                studentAssignmentReport.setActivityId(activityId);
            }
            studentAssignmentReport.setStudentPersonalRefId(student.getStudentPersonalRefId());
            studentAssignmentReport.setStatus(student.getStatus());
            studentAssignmentReport.setSchoolRefId(student.getSchoolRefId());
            studentAssignmentReport.setStudentActivityRefId(student.getStudentActivityRefId());
            studentAssignmentReport.setStudentGroupRefId(student.getStudentGroupRefId());

            studentAssignmentsBatch.addStudentAssignment(studentAssignmentReport);
        }

        return studentAssignmentsBatch;
    }

    public static StudentAssignmentsBatch toStudentAssignmentBatch(StudentAssignment studentAssignment) {
        StudentAssignmentsBatch studentAssignmentsBatch = new StudentAssignmentsBatch();

        SourceObjectType sourceObjectType = studentAssignment.getSourceObjectType();
        studentAssignmentsBatch.setEventRefId( studentAssignment.getEventRefId() );
        studentAssignmentsBatch.setSourceObjectType( sourceObjectType );
        studentAssignmentsBatch.setSchoolRefId(studentAssignment.getSchoolRefId());
        studentAssignmentsBatch.setSectionId(studentAssignment.getSectionId());
        Set<Activity> activities = studentAssignment.getActivities();

        if (!CollectionUtils.isEmpty(activities)) {
            boolean isBenchmark = studentAssignment.isBenchmark();
            for (Activity activity : activities) {

                SourceObject sourceObject = activity.getSourceObject();
                UUID ugenRefId = sourceObject.getUgenRefId();

                StudentAssignmentReport studentAssignmentReport = new StudentAssignmentReport();
              if(sourceObjectType == SourceObjectType.PERFORMANCE_TASK){
                studentAssignmentReport.setActivityId(studentAssignment.getTeacherAssignmentRefId());
              }else {
                studentAssignmentReport.setActivityId(ugenRefId);
              }
                studentAssignmentReport.setStudentActivityRefId(activity.getRefId());
                studentAssignmentReport.setRefId(studentAssignment.getRefId());

                if (studentAssignmentReport.getStudentActivityRefId() == null){
                    throw new IllegalArgumentException("Session Id cannot be Null for sourceObject -->" +
                            sourceObjectType +" ActivityForScores Id[" + studentAssignmentReport.getActivityId()+"]");
                }


                studentAssignmentReport.setStatus(activity.getStatus());
                studentAssignmentReport.setStudentPersonalRefId(studentAssignment.getStudentPersonalRefId());
                studentAssignmentReport.setStartDate(studentAssignment.getStartDate());
                studentAssignmentReport.setSubmitDate(studentAssignment.getSubmitDate());


                if (isBenchmark){
                    activity.setGrade(studentAssignment.getGrade());
                    activity.setLevel(studentAssignment.getLevel());
                }
                studentAssignmentsBatch.addStudentAssignment(studentAssignmentReport);
            }
        }
        return studentAssignmentsBatch;
    }

    public static StudentAssignmentsBatch toStudentAssignmentBatch(TeacherAssignmentUpdate teacherAssignmentUpdate) {

        StudentAssignmentsBatch studentAssignmentsBatch = new StudentAssignmentsBatch();
        SourceObjectType sourceObjectType = teacherAssignmentUpdate.getSourceObjectType();
        studentAssignmentsBatch.setEventRefId(teacherAssignmentUpdate.getRefId());
        studentAssignmentsBatch.setSourceObjectType(sourceObjectType);
        studentAssignmentsBatch.setSchoolRefId(teacherAssignmentUpdate.getSchoolRefId());
        studentAssignmentsBatch.setSectionId(teacherAssignmentUpdate.getSectionId());
        studentAssignmentsBatch.setLeaRefId(teacherAssignmentUpdate.getLeaRefId());
         if(!teacherAssignmentUpdate.getStudentsAdded().isEmpty()){
        studentAssignmentsBatch.setStudentsAdded(teacherAssignmentUpdate.getStudentsAdded());
        }

        if(!teacherAssignmentUpdate.getStudentsRemoved().isEmpty()){
            studentAssignmentsBatch.setStudentsRemoved(teacherAssignmentUpdate.getStudentsRemoved());
        }

        UUID activityId = teacherAssignmentUpdate.getUgenRefId();

        for(Student student: teacherAssignmentUpdate.getStudents()){
            StudentAssignmentReport studentAssignmentReport = new StudentAssignmentReport();

            if(teacherAssignmentUpdate.getStudentsAdded().contains(student.getStudentPersonalRefId())) {
                studentAssignmentReport.setStudentPersonalRefId(student.getStudentPersonalRefId());
              if(sourceObjectType == SourceObjectType.PERFORMANCE_TASK){
                studentAssignmentReport.setActivityId(teacherAssignmentUpdate.getRefId());
              }else{
                studentAssignmentReport.setActivityId(activityId);
              }
                studentAssignmentReport.setStatus(student.getStatus());
                studentAssignmentReport.setSchoolRefId(student.getSchoolRefId());
                studentAssignmentReport.setStudentActivityRefId(student.getStudentActivityRefId());
                studentAssignmentReport.setStudentGroupRefId(student.getStudentGroupRefId());
                studentAssignmentsBatch.addStudentAssignment(studentAssignmentReport);
            }

        }

        for(UUID studentId: teacherAssignmentUpdate.getStudentsRemoved()){
                StudentAssignmentReport studentAssignmentReport = new StudentAssignmentReport();
                studentAssignmentReport.setStudentPersonalRefId(studentId);
          if(sourceObjectType == SourceObjectType.PERFORMANCE_TASK){
            studentAssignmentReport.setActivityId(teacherAssignmentUpdate.getRefId());
          }else{
            studentAssignmentReport.setActivityId(activityId);
          }
                studentAssignmentReport.setSchoolRefId(teacherAssignmentUpdate.getSchoolRefId());
                studentAssignmentReport.setStatus(AssignmentStatus.REMOVED);
                studentAssignmentsBatch.addStudentAssignment(studentAssignmentReport);
        }

        return studentAssignmentsBatch;
    }

}
