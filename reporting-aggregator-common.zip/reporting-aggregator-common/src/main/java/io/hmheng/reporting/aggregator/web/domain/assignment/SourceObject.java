package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.utils.JsonObjectUtil;
import java.util.Map;
import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SourceObject {
	
    private String value;
    private String isbn;
    private SourceObjectType sif_RefObject;
    private UUID ugenRefId;
    private String name;
	  private String subjectCode;
    private Boolean manualScoringRequired;
    private String attributes;
    private Map<AssignmentStatus, Long> statusCount;

    public SourceObject() {}

	public SourceObject(String value, String isbn, SourceObjectType sif_RefObject, UUID ugenRefId, String attributes) {
		this.value = value;
		this.isbn = isbn;
		this.sif_RefObject = sif_RefObject;
		this.ugenRefId = ugenRefId;
		this.manualScoringRequired = false;
		this.attributes = attributes;
	}

    public SourceObject(String value, String isbn, SourceObjectType sif_RefObject, UUID ugenRefId, String name, String subjectCode, Boolean manualScoringRequired, String attributes) {
        this(value, isbn, sif_RefObject, ugenRefId, attributes);
        this.name = name;
        this.subjectCode = subjectCode;
        this.manualScoringRequired = manualScoringRequired;
    }

	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	public String getIsbn() {
		return isbn;
	}
	
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

    public SourceObjectType getSif_RefObject() {
        return sif_RefObject;
    }

    public void setSif_RefObject(SourceObjectType sif_RefObject) {
        this.sif_RefObject = sif_RefObject;
    }

    public UUID getUgenRefId() {
		return ugenRefId;
	}
	
	public void setUgenRefId(UUID ugenRefId) {
		this.ugenRefId = ugenRefId;
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubjectCode() {
		return subjectCode;
	}

	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}

    public Boolean getManualScoringRequired() {
        return manualScoringRequired;
    }

    public void setManualScoringRequired(Boolean manualScoringRequired) {
        this.manualScoringRequired = manualScoringRequired;
    }

    public String getAttributes() {
		return attributes;
	}
	
	  public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

    public Map<AssignmentStatus, Long> getStatusCount() {
        return statusCount;
    }

    public void setStatusCount(Map<AssignmentStatus, Long> statusCount) {
        this.statusCount = statusCount;
    }

    public String getProgramId(){
        return JsonObjectUtil.getStringValueOf(this.attributes, Constants.PROGRAM_ID);
    }


    //If this method is changed, test io.hmheng.reporting.aggregator.web.domain.assignment.TestingEventUtils.getActivities()
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SourceObject that = (SourceObject) o;

        if (value != null ? !value.equals(that.value) : that.value != null) return false;
        if (isbn != null ? !isbn.equals(that.isbn) : that.isbn != null) return false;
        return ugenRefId != null ? ugenRefId.equals(that.ugenRefId) : that.ugenRefId == null;

    }

    @Override
    public int hashCode() {
        int result = value != null ? value.hashCode() : 0;
        result = 31 * result + (isbn != null ? isbn.hashCode() : 0);
        result = 31 * result + (ugenRefId != null ? ugenRefId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SourceObject{" +
                "value='" + value + '\'' +
                ", isbn='" + isbn + '\'' +
                ", sif_RefObject=" + sif_RefObject +
                ", ugenRefId=" + ugenRefId +
                ", name='" + name + '\'' +
                ", subjectCode='" + subjectCode + '\'' +
                ", manualScoringRequired=" + manualScoringRequired +
                ", attributes='" + attributes + '\'' +
                ", statusCount=" + statusCount +
                '}';
    }
}
