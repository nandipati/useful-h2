package io.hmheng.reporting.aggregator.core.service;

import com.hmhpub.common.token.auth.SIFAuthorization;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import io.hmheng.reporting.aggregator.config.SifAuthConfig;
import io.hmheng.reporting.aggregator.config.SifClientConfig;

@Service
@EnableConfigurationProperties(SifAuthConfig.class)
public class AuthorizationServiceImpl implements AuthorizationService {

    @Autowired
    private SifAuthConfig sifAuthConfig;

    private DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTime();

    @Override
    public AuthorizationDetails createSIFAuthorization(Service service) {
        return createSIFAuthorization(service, false);
    }
    @Override
    public AuthorizationDetails createSIFAuthorization(Service service, boolean useIds) {
        String isoAuthCurrentDateTime = dateTimeFormatter.print(DateTime.now());

        SifClientConfig sifClientConfig;

        switch (service) {
            case Assignments:
                sifClientConfig = sifAuthConfig.getAssignments();
                break;

            case IDM:
                sifClientConfig = sifAuthConfig.getIdm();
                break;

            case Reporting:
                sifClientConfig = sifAuthConfig.getReporting();
                break;

            case Grading:
                sifClientConfig = sifAuthConfig.getGrading();
                break;

            case Scoring:
                sifClientConfig = sifAuthConfig.getScoring();
                break;

            case CLM:
                sifClientConfig = sifAuthConfig.getClm();
                break;

            case MDS:
                sifClientConfig = sifAuthConfig.getMds();
                break;

            case IDS:
                sifClientConfig = sifAuthConfig.getIds();
                break;
            case OneSearch:
                sifClientConfig = sifAuthConfig.getOneSearch();
                break;
            default:
                throw new IllegalArgumentException("unknown service: " + service);
        }



        SIFAuthorization sifAuthorization;
        if(Service.IDS == service) {
            sifAuthorization = new SIFAuthorization(sifClientConfig.getClientId(), sifClientConfig.getSecret(),
                "");
        } else {
            sifAuthorization = new SIFAuthorization(sifClientConfig.getClientId(), sifClientConfig.getSecret(),
                isoAuthCurrentDateTime);
        }
        return new AuthorizationDetails(sifAuthorization, isoAuthCurrentDateTime);
    }

}
