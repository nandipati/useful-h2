package io.hmheng.reporting.aggregator.web.domain.assignment;

/**
 * Created by suryadevarap on 10/17/17.
 */
public enum ProductType {
  NONE,
  HMH1,
  ED;
}
