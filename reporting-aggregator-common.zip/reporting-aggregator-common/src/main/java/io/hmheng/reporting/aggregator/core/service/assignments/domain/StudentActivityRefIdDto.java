package io.hmheng.reporting.aggregator.core.service.assignments.domain;


import java.util.UUID;

public class StudentActivityRefIdDto {
    private UUID refId;

    public StudentActivityRefIdDto(){

    }

    public StudentActivityRefIdDto(UUID refId){
        this.refId = refId;
    }

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    @Override
    public String toString() {
        return "StudentActivityRefIdDto{" +
                "refId=" + refId +
                '}';
    }
}
