package io.hmheng.reporting.aggregator.web.domain.assignment;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Group {

    private UUID refId;
    private UUID parentGroupRefId;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public UUID getParentGroupRefId() {
        return parentGroupRefId;
    }

    public void setParentGroupRefId(UUID parentGroupRefId) {
        this.parentGroupRefId = parentGroupRefId;
    }
}
