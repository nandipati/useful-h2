package io.hmheng.reporting.aggregator.web.domain.assignment;


import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.UUID;

public class Student {


    private UUID studentPersonalRefId;
    private AssignmentStatus status;
    private UUID schoolRefId;
    private List<UUID> studentActivities;
    private UUID studentGroupRefId;

    public UUID getStudentGroupRefId() {
        return studentGroupRefId;
    }

    public void setStudentGroupRefId(UUID studentGroupRefId) {
        this.studentGroupRefId = studentGroupRefId;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    public List<UUID> getStudentActivities() {
        return studentActivities;
    }

    public void setStudentActivities(List<UUID> studentActivities) {
        this.studentActivities = studentActivities;
    }

    public UUID getStudentActivityRefId() {
	    if(!CollectionUtils.isEmpty(studentActivities)) {
		    return studentActivities.get(0);
	    }
        return null;
    }

    @Override
    public boolean equals(Object o) {
        if ( this == o ) return true;
        if ( !(o instanceof Student) ) return false;

        Student student = (Student) o;

        return getStudentPersonalRefId().equals(student.getStudentPersonalRefId());

    }

    @Override
    public int hashCode() {
        return getStudentPersonalRefId().hashCode();
    }
}
