package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.hmheng.reporting.aggregator.utils.JsonDateTimeDeserializerUtc;
import org.codehaus.jackson.annotate.JsonProperty;
import org.joda.time.DateTime;

import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Activity {
    
    private UUID refId;
    private UUID studentAssignmentRefId;
    private UUID teacherReviewRefId;
    private AssignmentStatus status;
    private DateTime startDate;
    private DateTime submitDate;
    @JsonProperty("sourceObjectRest")
    private SourceObject sourceObject;
    private StudentAssignment studentAssignment;
    private String grade;
    private String level;


    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

	public UUID getStudentAssignmentRefId() {
        return studentAssignmentRefId;
    }

    public void setStudentAssignmentRefId(UUID studentAssignmentRefId) {
        this.studentAssignmentRefId = studentAssignmentRefId;
    }

    public UUID getTeacherReviewRefId() {
        return teacherReviewRefId;
    }

    public void setTeacherReviewRefId(UUID teacherReviewRefId) {
        this.teacherReviewRefId = teacherReviewRefId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getSubmitDate() {
        return submitDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public void setSubmitDate(DateTime submitDate) {
        this.submitDate = submitDate;
    }

    public SourceObject getSourceObject() {
        return sourceObject;
    }

    public void setSourceObject(SourceObject sourceObject) {
        this.sourceObject = sourceObject;
    }

    public StudentAssignment getStudentAssignment() {
        return studentAssignment;
    }

    public void setStudentAssignment(StudentAssignment studentAssignment) {
        this.studentAssignment = studentAssignment;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    //If this method is changed, test io.hmheng.reporting.aggregator.web.domain.assignment.TestingEventUtils.getActivities()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Activity activity = (Activity) o;

        if (!refId.equals(activity.refId)) return false;
        return sourceObject != null ? sourceObject.equals(activity.sourceObject) : activity.sourceObject == null;

    }

    @Override
    public int hashCode() {
        int result = refId.hashCode();
        result = 31 * result + (sourceObject != null ? sourceObject.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Activity{" +
                "refId=" + refId +
                ", studentAssignmentRefId=" + studentAssignmentRefId +
                ", teacherReviewRefId=" + teacherReviewRefId +
                ", status=" + status +
                ", startDate=" + startDate +
                ", submitDate=" + submitDate +
                ", sourceObject=" + sourceObject +
                ", studentAssignment=" + studentAssignment +
                ", grade='" + grade + '\'' +
                ", level='" + level + '\'' +
                '}';
    }
}
