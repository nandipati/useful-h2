package io.hmheng.reporting.aggregator.core.service.domain;


import java.util.UUID;

public class Resource {
    private UUID instanceRefId;
    private String primaryId;
    private String secondaryId;
    public Resource() {

    }

    public UUID getInstanceRefId() {
        return instanceRefId;
    }

    public void setInstanceRefId(UUID instanceRefId) {
        this.instanceRefId = instanceRefId;
    }

    public String getPrimaryId() {
        return primaryId;
    }

    public void setPrimaryId(String primaryId) {
        this.primaryId = primaryId;
    }

    public String getSecondaryId() {
        return secondaryId;
    }

    public void setSecondaryId(String secondaryId) {
        this.secondaryId = secondaryId;
    }
}
