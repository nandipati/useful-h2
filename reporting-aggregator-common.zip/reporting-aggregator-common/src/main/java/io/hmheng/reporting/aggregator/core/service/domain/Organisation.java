package io.hmheng.reporting.aggregator.core.service.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Organisation {
    
    private UUID leaRefId;
    private UUID schoolRefId;
    private List<Grade> grades = new ArrayList<>();
    
    public UUID getLeaRefId() {
        return leaRefId;
    }
    
    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }
    
    public UUID getSchoolRefId() {
        return schoolRefId;
    }
    
    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }
    
    public List<Grade> getGrades() {
        return grades;
    }
    
    public void setGrades(List<Grade> grades) {
        this.grades = grades;
    }
}
