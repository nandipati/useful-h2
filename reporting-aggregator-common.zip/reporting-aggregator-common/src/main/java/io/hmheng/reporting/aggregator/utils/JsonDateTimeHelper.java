package io.hmheng.reporting.aggregator.utils;

import org.joda.time.DateTime;

import java.time.LocalDateTime;

/**
 * Created by nandipatim on 2/27/16.
 */
public interface JsonDateTimeHelper {

    String toJson(Object message);

    String toJsonWithHourMinuteSecondMillis(Object message);

    DateTime toJodaDateTime(LocalDateTime dateTime);
}
