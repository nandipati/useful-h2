package io.hmheng.reporting.aggregator.core.service.utils;

import org.mockito.Mockito;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * A generic bean coverage utility that can be used to carry out code coverage on a bean
 */
public class GenericBeanCoverage {

	private static final char PKG_SEPARATOR = '.';
	private static final char DIR_SEPARATOR = '/';
	private static final String BAD_PACKAGE_ERROR = "Unable to get resources from path '%s'. Are you sure the package '%s' exists?";
	private static final String CLASS_FILE_SUFFIX = ".class";

	public static void doBeanCodeCoverage(Class<?> c) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException {
        Object obj = c.newInstance();
        Method[] methods = c.getDeclaredMethods();

        for (Method method : methods) {
            System.out.println("Method : " + method.getName());
            Class<?>[] paramTypes = method.getParameterTypes();

			if((paramTypes.length > 0 && paramTypes[0] != null)
					&& ((paramTypes[0].getName().equals("java.util.UUID"))
					|| (paramTypes[0].getName().endsWith("assignment.TestType"))
					|| (paramTypes[0].getName().endsWith("AssignmentStatus"))
					|| (paramTypes[0].getName().endsWith("SourceObjectType"))
					|| (paramTypes[0].getName().endsWith("joda.time.DateTime")))){
				continue;
			}

            if (method.getName().startsWith("set")) {
                Object[] parameterInstances = buildParameterIObjectArray(paramTypes);
                method.invoke(obj, parameterInstances);
            }
            if (method.getName().startsWith("get")) {
                Object val = method.invoke(obj, (Object[])null);
                System.out.println(method.getName() + "\t" + val);
            }
			if (method.getName().startsWith("has")) {
				Object[] parameterInstances = buildParameterIObjectArray(paramTypes);
				method.invoke(obj, parameterInstances);
			}
            if (method.getName().startsWith("is")) {
                Object val = method.invoke(obj, (Object[])null);
                System.out.println(method.getName() + "\t" + val);
            }
        }
    }
    
    public static void doBuilderCodeCoverage(Class<?> c) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException, NoSuchMethodException, SecurityException {
        Object obj = c.newInstance();
        Method[] methods = c.getDeclaredMethods();
        
        List<String> methodNames = new ArrayList<>(methods.length-1);
        List<Class<?>[]> methodParamTypes = new ArrayList<>(methods.length-1);
        
        for (Method method : methods) {
            
            if (!method.getName().equals("build")) {
                 methodNames.add(method.getName());
                 methodParamTypes.add(method.getParameterTypes());
            } 
        }
        
        for (int i = 0; i < methodNames.size(); i++) {
            Class<?>[] paramTypes = methodParamTypes.get(i);
            Object[] parameterInstances = buildParameterIObjectArray(paramTypes);
            System.out.println("Method : " + methodNames.get(i));
            obj = c.getMethod(methodNames.get(i), paramTypes).invoke(obj, parameterInstances);
        }
        
        c.getMethod("build", (Class<?>[]) null).invoke(obj, (Object[]) null);
    }

    public static Object[] buildParameterIObjectArray(Class<?>[] paramTypes) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        List<Object> objInstances = new ArrayList<Object>();

        for (Class<?> c : paramTypes) {
			if("java.util.UUID".equals(c.getName())
					|| c.getName().endsWith("assignment.TestType")
					|| c.getName().endsWith("AssignmentStatus")
					|| c.getName().endsWith("SourceObjectType")
					|| c.getName().endsWith("joda.time.DateTime")){
				continue;
			}
            Object obj = primativeValue(c);
            if (obj == null) {
                obj = Mockito.mock(Class.forName(c.getName()));
            }
            objInstances.add(obj);
        }

        return objInstances.toArray(new Object[]{});

    }

    private static Object primativeValue(Class<?> c) {
        if (c == boolean.class) {
            return true;
        } else if (c == byte.class) {
            return (byte) 0;
        } else if (c == char.class) {
            return 'c';
        } else if (c == int.class) {
            return -1;
        } else if (c == double.class) {
            return -2;
        } else if (c == double.class) {
            return -2;
        } else if (c == float.class) {
            return -3;
        } else if (c == long.class) {
            return -4;
        } else if (c == short.class) {
            return -5;
        } else if (c == Boolean.class) {
            return new Boolean(true);
        } else if (c == Byte.class) {
            return new Byte((byte) 0);
        } else if (c == Integer.class) {
            return new Integer(1);
        } else if (c == Double.class) {
            return new Double(2);
        } else if (c == Float.class) {
            return new Float(3);
        } else if (c == Long.class) {
            return new Long(3);
        } else if (c == Short.class) {
            return new Short("4");
        } else if (c == String.class) {
            return new String("s");
        } else if (c == Date.class) {
            return new Date();
        } else {
            return null;
        }
    }

	public static void doBeanCodeCoverage(String scannedPackage) throws IllegalAccessException, InstantiationException, InvocationTargetException {
		String scannedPath = scannedPackage.replace(PKG_SEPARATOR, DIR_SEPARATOR);
		URL scannedUrl = Thread.currentThread().getContextClassLoader().getResource(scannedPath);
		if (scannedUrl == null) {
			throw new IllegalArgumentException(String.format(BAD_PACKAGE_ERROR, scannedPath, scannedPackage));
		}
		File scannedDir = new File(scannedUrl.getFile());
        if (scannedDir != null) {
           for (File file : scannedDir.listFiles()) {
              find(file, scannedPackage);
           }
	    }
	}

	private static void find(File file, String scannedPackage) throws IllegalAccessException, InvocationTargetException, InstantiationException {
		String resource = scannedPackage + PKG_SEPARATOR + file.getName();
		if (file.isDirectory()) {
			for (File child : file.listFiles()) {
				find(child, resource);
			}
		} else if (resource.endsWith(CLASS_FILE_SUFFIX)) {
			int endIndex = resource.length() - CLASS_FILE_SUFFIX.length();
			String className = resource.substring(0, endIndex);
			try {
				doBeanCodeCoverage(Class.forName(className));
			} catch (ClassNotFoundException ignore) {
			}
		}
	}
}