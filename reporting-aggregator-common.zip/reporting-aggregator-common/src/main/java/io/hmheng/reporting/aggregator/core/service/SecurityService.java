package io.hmheng.reporting.aggregator.core.service;

import com.amazonaws.auth.AWSCredentials;

public interface SecurityService {

    AWSCredentials getAWSCredentials();

    AWSCredentials getDeadLetterAWSCredentials();

}
