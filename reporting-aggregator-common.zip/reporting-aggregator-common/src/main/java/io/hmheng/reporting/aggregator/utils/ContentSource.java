package io.hmheng.reporting.aggregator.utils;

/**
 * Created by nandipatim on 8/29/17.
 */
public enum ContentSource {
  NONE,
  MDS,
  ONE_SEARCH;
}
