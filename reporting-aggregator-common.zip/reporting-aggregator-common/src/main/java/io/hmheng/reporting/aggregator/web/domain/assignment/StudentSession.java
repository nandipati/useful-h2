package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * Created by nandipatim on 3/1/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StudentSession {

    private UUID refId;
    private UUID studentPersonalRefId;
    private UUID eventRefId;
    private SourceObjectType sourceObjectType;
    @JsonProperty("activityRests")
    private Set<Activity> activities;
    private UUID sectionId;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

    public void setSourceObjectType(SourceObjectType sourceObjectType) {
        this.sourceObjectType = sourceObjectType;
    }

    public Set<Activity> getActivities() {
        return activities;
    }

    public void setActivities(Set<Activity> activities) {
        this.activities = activities;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    @Override
    public String toString() {
        return "StudentSession{" +
                "refId=" + refId +
                ", studentPersonalRefId=" + studentPersonalRefId +
                ", eventRefId=" + eventRefId +
                ", sourceObjectType=" + sourceObjectType +
                ", activities=" + activities +
                ", sectionId=" + sectionId +
                '}';
    }
}
