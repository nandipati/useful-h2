package io.hmheng.reporting.aggregator.web.domain.assignment;

import org.joda.time.DateTime;

import java.util.UUID;

/**
 * Created by jayachandranj on 3/28/17.
 */
public class Activities{
    private UUID refId;
    private UUID teacherReviewRefId;
    private AssignmentStatus status;
    private DateTime startDate;
    private DateTime submitDate;
    private SourceObjects sourceObject;
    private StudentAssignment studentAssignment;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public UUID getTeacherReviewRefId() {
        return teacherReviewRefId;
    }

    public void setTeacherReviewRefId(UUID teacherReviewRefId) {
        this.teacherReviewRefId = teacherReviewRefId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(DateTime submitDate) {
        this.submitDate = submitDate;
    }

    public SourceObjects getSourceObject() {
        return sourceObject;
    }

    public void setSourceObject(SourceObjects sourceObject) {
        this.sourceObject = sourceObject;
    }

    public StudentAssignment getStudentAssignment() {
        return studentAssignment;
    }

    public void setStudentAssignment(StudentAssignment studentAssignment) {
        this.studentAssignment = studentAssignment;
    }
}
