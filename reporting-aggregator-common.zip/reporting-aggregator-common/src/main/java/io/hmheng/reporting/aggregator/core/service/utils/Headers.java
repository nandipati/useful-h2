package io.hmheng.reporting.aggregator.core.service.utils;

public interface Headers {

    String CORRELATION_ID = "CorrelationId";
    String AUTHORIZATION = "Authorization";
    String AUTH_CURRENT_DATE_TIME = "authCurrentDateTime";
    String STUDENT_PERSONAL_REFID = "studentPersonalRefId";
    String STAFF_PERSONAL_REFID = "staffPersonalRefId";
    String SCHOOL_REFID = "schoolRefId";
    String LEA_REFID = "leaRefId";
    String CONTEXT_ID = "contextIdMatrixParameter";
    String TESTING_EVENT_REFID = "testingEventRefId";
    String STUDENT_REFID = "studentRefId";
    String EVENT_REFID = "eventId";
    String BLOB_ID = "blobId";
    String ACTIVITY_ID = "activityId";
    String ASSIGNMENT_EVENT_REFID="assignmentId";
    String ASSESSMENT_ID="assignmentId";
    String SECTION_REFID = "sectionRefId";
    String SESSION_REFID = "sessionId";
    String ITEM_REF_ID = "itemRefId";
    String STANDARD_ID = "standardId";
    String PAGE_LENGTH = "pageLength";
    String TESTEVENT_ID = "testeventId";
    String SESSION_ID = "sessionId";
    String PAGE = "page";
    String SIZE = "size";
    String COMPLETED_DATE = "completedDate";
    String STARTDATE = "startDate";
    String ENDDATE = "endDate";
    String EVENTSTATUS = "eventStatus";
    String TEST_EVENT_ID = "testeventId";
    String ASSIGNMENT_STATUS_HEADER = "assignmentStatusHeader";
    String MESSAGE_ID = "messageId";
    String CONTENT_TYPE = "Content-Type";
    String UPDATEEVENTGROUPS = "updateEventGroups";
    Boolean PUSHSTANDARDSCORES = true;

}
