package io.hmheng.reporting.aggregator.web.domain.assignment;

import java.util.Arrays;

public enum TestType {

    FORMATIVE(SourceObjectType.FORMATIVE_ASSESSMENT,ProductType.HMH1),
    BENCHMARK(SourceObjectType.ASSESSMENT,ProductType.HMH1),
    PROGRAM(SourceObjectType.PROGRAM_ASSESSMENT,ProductType.ED),
    PERFORMANCE_TASK(SourceObjectType.PERFORMANCE_TASK,ProductType.ED),
    CUSTOM(SourceObjectType.CUSTOM_ASSESSMENT,ProductType.ED);

    private final SourceObjectType sourceObjectType;
    private final ProductType productType;

    TestType(SourceObjectType sourceObjectType,ProductType productType){

        this.sourceObjectType = sourceObjectType;
        this.productType = productType;
    }

    public static TestType getTestTypeForSourceType(SourceObjectType sourceObjectType){

        return Arrays.stream(TestType.values()).filter(testType -> testType.sourceObjectType.equals(sourceObjectType))
                .findFirst().orElseThrow(() -> new IllegalArgumentException("no Supported SourceObjectType for " +
                        sourceObjectType.name()));
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

  public ProductType getProductType(){
    return productType;
  }

}
