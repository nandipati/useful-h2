package io.hmheng.reporting.aggregator.web.domain.assignment;

import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Set;

public class StudentSessionConverter {

    public static StudentSession toStudentSession(StudentAssignment studentAssignment){
        StudentSession studentSession = new StudentSession();


        boolean isBenchmark = studentAssignment.isBenchmark();
        boolean isFormative = studentAssignment.isFormative();

        studentSession.setEventRefId( studentAssignment.getEventRefId() );
        studentSession.setRefId(studentAssignment.getActivities().iterator().next().getRefId()); //student session id
        SourceObjectType sourceObjectType = studentAssignment.getSourceObjectType();
        ProductType productType = sourceObjectType.getProductType();
        studentSession.setSourceObjectType(sourceObjectType);
        studentSession.setStudentPersonalRefId(studentAssignment.getStudentPersonalRefId());

        Set<Activity> activities = studentAssignment.getActivities();

        studentSession.setActivities(new HashSet<>());

        if (!CollectionUtils.isEmpty(activities)) {
            for (Activity activity : activities) {

                Activity sessionActivity = new Activity();
                SourceObject sourceObject = activity.getSourceObject();
                sessionActivity.setRefId(sourceObject.getUgenRefId());

                if(isFormative || productType.equals(ProductType.ED)){
                    studentSession.setSectionId(studentAssignment.getSectionId());
                }else if(isBenchmark){
                    activity.setGrade(studentAssignment.getGrade());
                    activity.setLevel(studentAssignment.getLevel());
                }
                studentSession.getActivities().add(sessionActivity);
            }
        }
        return studentSession;
    }
}
