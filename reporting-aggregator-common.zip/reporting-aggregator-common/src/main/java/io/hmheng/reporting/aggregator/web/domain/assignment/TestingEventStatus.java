package io.hmheng.reporting.aggregator.web.domain.assignment;

public enum TestingEventStatus {

	OPEN,
	CLOSED,
	ARCHIVED,
  REOPENED,
  DELETED;
    
    public static TestingEventStatus fromString(String value) {
        return valueOf(value.trim().toUpperCase());
    }
    
}
