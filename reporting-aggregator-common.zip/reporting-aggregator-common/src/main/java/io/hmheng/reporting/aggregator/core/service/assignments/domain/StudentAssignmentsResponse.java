package io.hmheng.reporting.aggregator.core.service.assignments.domain;

import io.hmheng.reporting.aggregator.core.service.domain.Organisation;
import io.hmheng.reporting.aggregator.utils.StudentAssignmentUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StudentAssignmentsResponse {
    
    private UUID refId;
    private List<Organisation> organisations = new ArrayList<>();

    public boolean hasAssignments() {
        return StudentAssignmentUtil.hasAssignments(this.organisations);
    }

    public UUID getRefId() {
        return refId;
    }
    
    public void setRefId(UUID refId) {
        this.refId = refId;
    }
    
    public List<Organisation> getOrganisations() {
        return organisations;
    }
    
    public void setOrganisations(List<Organisation> organisations) {
        this.organisations = organisations;
    }
}
