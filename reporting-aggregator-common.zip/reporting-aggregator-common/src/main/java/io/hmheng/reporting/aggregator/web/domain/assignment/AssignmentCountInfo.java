package io.hmheng.reporting.aggregator.web.domain.assignment;

public class AssignmentCountInfo {

    private Integer allAssignmentCount;
    private Integer completedAssignmentCount;

    public AssignmentCountInfo(Integer allAssignmentCount, Integer completedAssignmentCount) {
        this.allAssignmentCount = allAssignmentCount;
        this.completedAssignmentCount = completedAssignmentCount;
    }

    public Integer getAllAssignmentCount() {
        return allAssignmentCount;
    }

    public void setAllAssignmentCount(Integer allAssignmentCount) {
        this.allAssignmentCount = allAssignmentCount;
    }

    public Integer getCompletedAssignmentCount() {
        return completedAssignmentCount;
    }

    public void setCompletedAssignmentCount(Integer completedAssignmentCount) {
        this.completedAssignmentCount = completedAssignmentCount;
    }
}
