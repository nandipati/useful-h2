package io.hmheng.reporting.aggregator.core.service.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.ArrayList;
import java.util.List;

import io.hmheng.reporting.aggregator.core.service.assignments.domain.StudentAssignmentReport;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Grade {
    
    private String grade;
    private String level;
    private Resource resource;
    private List<StudentAssignmentReport> studentAssignmentReports = new ArrayList<>();
    
    public String getGrade() {
        return grade;
    }
    
    public void setGrade(String grade) {
        this.grade = grade;
    }
    
    public String getLevel() {
        return level;
    }
    
    public void setLevel(String level) {
        this.level = level;
    }
    
    public List<StudentAssignmentReport> getStudentAssignmentReports() {
        return studentAssignmentReports;
    }
    
    public void setStudentAssignmentReports(List<StudentAssignmentReport> studentAssignmentReports) {
        this.studentAssignmentReports = studentAssignmentReports;
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }
}
