package io.hmheng.reporting.aggregator.utils;

import org.apache.camel.Exchange;

public interface AttributeHelper {

    String extractAttributesMethodName = "extractAttributes";
    void extractAttributes(Exchange exchange);

    String clearContextMethodName = "clearContext";
    void clearContext();
}
