package io.hmheng.reporting.aggregator.web.domain.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.joda.deser.LocalDateTimeDeserializer;
import io.hmheng.reporting.aggregator.utils.JsonCommons;
import org.codehaus.jackson.map.ext.JodaSerializers;
import org.joda.time.DateTime;

import java.time.LocalDateTime;

/**
 * Created by pabonaj on 5/2/17.
 */
public class ScoresAssessmentDeadLetterMessage {

  private String failureType;
  private String failedEventType;
  private Object exception;
  private Object data;
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializerISOFormat.class)
  private LocalDateTime failureDate;

  public Object getData() {
    return data;
  }

  public void setData(Object data) {
    this.data = data;
  }

  public String getFailureType() {
    return failureType;
  }

  public void setFailureType(String failureType) {
    this.failureType = failureType;
  }

  public String getFailedEventType() {
    return failedEventType;
  }

  public void setFailedEventType(String failedEventType) {
    this.failedEventType = failedEventType;
  }

  public Object getException() {
    return exception;
  }

  public void setException(Object exception) {
    this.exception = exception;
  }

  public LocalDateTime getFailureDate() {
    return failureDate;
  }

  public void setFailureDate(LocalDateTime failureDate) {
    this.failureDate = failureDate;
  }

}
