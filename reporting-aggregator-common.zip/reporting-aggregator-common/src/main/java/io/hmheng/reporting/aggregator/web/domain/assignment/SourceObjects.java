package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

/**
 * Created by jayachandranj on 3/27/17.
 */
public class SourceObjects{
    private String value;
    @JsonProperty("sif_RefObject")
    private String sifRefObject;
    private String isbn;
    private String name;
    private String subjectCode;

    private UUID customLessonId;
    private boolean manualScoring;

    public String getValue(){
        return value;
    }
    public void setValue(String input){
        this.value = input;
    }
    public String getSifRefObject(){
        return sifRefObject;
    }
    public void setSifRefObject(String input){
        this.sifRefObject = input;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public boolean isManualScoring() {
        return manualScoring;
    }

    public UUID getCustomLessonId(){
        return customLessonId;
    }
    public void setCustomLessonId(UUID input){
        this.customLessonId = input;
    }
    public boolean getManualScoring(){
        return manualScoring;
    }
    public void setManualScoring(boolean input){
        this.manualScoring = input;
    }
}
