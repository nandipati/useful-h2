package io.hmheng.reporting.aggregator.web.domain.assignment;

import java.util.List;

/**
 * Created by jayachandranj on 4/4/17.
 */
public class FormativeLocation {
    private ReProcessAssignment reProcessAssignment;
    private List<ReprocessStudentAssignment> reprocessStudentAssignment;

    public FormativeLocation(ReProcessAssignment reProcessAssignment, List<ReprocessStudentAssignment> reprocessStudentAssignment) {
        this.reProcessAssignment = reProcessAssignment;
        this.reprocessStudentAssignment = reprocessStudentAssignment;
    }

    public ReProcessAssignment getReProcessAssignment() {
        return reProcessAssignment;
    }

    public void setReProcessAssignment(ReProcessAssignment reProcessAssignment) {
        this.reProcessAssignment = reProcessAssignment;
    }

    public List<ReprocessStudentAssignment> getReprocessStudentAssignment() {
        return reprocessStudentAssignment;
    }

    public void setReprocessStudentAssignment(List<ReprocessStudentAssignment> reprocessStudentAssignment) {
        this.reprocessStudentAssignment = reprocessStudentAssignment;
    }

}
