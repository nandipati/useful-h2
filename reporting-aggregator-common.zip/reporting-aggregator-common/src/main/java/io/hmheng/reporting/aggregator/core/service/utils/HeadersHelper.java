package io.hmheng.reporting.aggregator.core.service.utils;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.AuthorizationDetails;
import io.hmheng.reporting.aggregator.core.service.AuthorizationService;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static io.hmheng.reporting.aggregator.Constants.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.Constants.PLATFORM_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.CONTENT_TYPE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.CONTEXT_ID;

/**
 * Created by nandipatim on 3/16/16.
 */
@Component
public class HeadersHelper {

    @Autowired
    private AuthorizationService authorizationService;

    public Map<String, Object> createBasicHeaders(String contextId,String platformId ,AuthorizationService.Service service) {
        return createBasicHeaders(contextId, platformId, service, false);
    }
    public Map<String, Object> createBasicHeaders(String contextId ,String platformId , AuthorizationService.Service service, boolean useIds) {
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(service, useIds);
        Map<String, Object> headers = new HashMap<>();

        headers.put(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.put(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());
        if(!StringUtils.isEmpty(contextId)) {
            headers.put(CONTEXT_ID, contextId != null ? ";contextId=" + contextId : "");
        }
        if(!StringUtils.isEmpty(platformId)) {
            headers.put(PLATFORM_ID, platformId != null ? platformId : "");
        }
        // FIXME headers.put(CORRELATION_ID, MDC.get(CORRELATION_ID));

        return headers;
    }

    public Map<String, Object> createBasicHeadersWithCorrelation(AuthorizationService.Service service) {
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(service);
        Map<String, Object> headers = new HashMap<>();
        headers.put(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.put(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());
        headers.put(CORRELATION_ID, MDC.get(CORRELATION_ID));

        return headers;
    }
    public Map<String, Object> createBasicHeadersWithOutCorrelation(AuthorizationService.Service service) {
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(service);
        Map<String, Object> headers = new HashMap<>();
        headers.put(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.put(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());
        headers.put(CONTENT_TYPE,MediaType.APPLICATION_JSON_VALUE);

        return headers;
    }

    public Map<String, Object> createHeaderWithCorrelationOnly() {
        Map<String, Object> headers = new HashMap<>();
        headers.put(CORRELATION_ID, MDC.get(CORRELATION_ID));
        return headers;
    }

    public HttpHeaders createHttpHeaders(AuthorizationService.Service service){
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(service);
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.add(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        return headers;
    }

    public Map<String, Object> createBasicHeadersWithCorrelationForReprocess(AuthorizationService.Service service) {
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(service);
        Map<String, Object> headers = new HashMap<>();
        headers.put(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.put(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());
        headers.put(CORRELATION_ID, Constants.RE_PROCESS_CORRELATION_ID);

        return headers;
    }
}
