package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.hmheng.reporting.aggregator.utils.JsonDateTimeDeserializerUtc;
import io.hmheng.reporting.aggregator.utils.SourceObjectTypeUtil;
import org.joda.time.DateTime;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Created by akellas on 11/13/16.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class TeacherAssignmentUpdate {
    private UUID refId;
    private String title;
    private String preamble;
    private UUID staffPersonalRefId;
    private UUID creatorRefId;
    private Set<Student> students;
    private Set<SourceObject> sourceObjectRests;
    private List<UUID> studentsAdded;
    private List<UUID> studentsRemoved;
    private List<UUID> studentsUnchanged;

    private DateTime availableDate;
    private DateTime dueDate;
    private UUID leaRefId;    //aka districtId
    private UUID schoolRefId;
    private UUID sectionId;
    private AssignmentStatus status;

    private List<Group> studentGroupRests;

    private List<Group> studentGroups;

    public List<Group> getStudentGroups() {
        return studentGroups;
    }

    public void setStudentGroups(List<Group> studentGroups) {
        this.studentGroups = studentGroups;
    }

    public List<Group> getStudentGroupRests() {
        return studentGroupRests;
    }

    public void setStudentGroupRests(List<Group> studentGroupRests) {
        this.studentGroupRests = studentGroupRests;
    }
    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPreamble() {
        return preamble;
    }

    public void setPreamble(String preamble) {
        this.preamble = preamble;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    public UUID getCreatorRefId() {
        return creatorRefId;
    }

    public void setCreatorRefId(UUID creatorRefId) {
        this.creatorRefId = creatorRefId;
    }

    public Set<SourceObject> getSourceObjectRests() {
        return sourceObjectRests;
    }

    public void setSourceObjectRests(Set<SourceObject> sourceObjectRests) {
        this.sourceObjectRests = sourceObjectRests;
    }

    public List<UUID> getStudentsAdded() {
        return studentsAdded;
    }

    public void setStudentsAdded(List<UUID> studentsAdded) {
        this.studentsAdded = studentsAdded;
    }

    public List<UUID> getStudentsRemoved() {
        return studentsRemoved;
    }

    public void setStudentsRemoved(List<UUID> studentsRemoved) {
        this.studentsRemoved = studentsRemoved;
    }

    public List<UUID> getStudentsUnchanged() {
        return studentsUnchanged;
    }

    public void setStudentsUnchanged(List<UUID> studentsUnchanged) {
        this.studentsUnchanged = studentsUnchanged;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(DateTime availableDate) {
        this.availableDate = availableDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(DateTime dueDate) {
        this.dueDate = dueDate;
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }
    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }

    public SourceObjectType getSourceObjectType() {
        return getSourceObjectRests().iterator().next().getSif_RefObject();
    }

    public SourceObject getSourceObject(){
        return getSourceObjectRests().iterator().next();
    }

    public UUID getUgenRefId() {
        return getSourceObject().getUgenRefId();
    }

    public boolean isWorkflow() {
        return SourceObjectTypeUtil.isWorkflow(getSourceObjectType());
    }

    public boolean isValidToProcess(){
        return SourceObjectTypeUtil.isValidToProcess(getSourceObjectType());
    }
}
