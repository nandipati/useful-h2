package io.hmheng.reporting.aggregator.web.domain.assignment;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.utils.JsonObjectUtil;
import io.hmheng.reporting.aggregator.utils.SourceObjectTypeUtil;

import org.codehaus.jackson.annotate.JsonProperty;
import org.joda.time.DateTime;

import java.util.Set;
import java.util.UUID;

public class StudentAssignment {

    public static final String REFID="refId";
    private UUID refId;
    private String title;
    private String preamble;

    private UUID studentPersonalRefId;
    private UUID teacherAssignmentRefId; //aka assignmentId
    private UUID schoolRefId;
    private AssignmentStatus status;
    private DateTime startDate;
    private DateTime submitDate;
    @JsonProperty("activityRests")
    private Set<Activity> activities;
    private DateTime dueDate;
    private DateTime availableDate;
    private String customClientData;
    private UUID staffPersonalRefId;
    private UUID sectionId;
    private String attributes;
    private String messageAttributes;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPreamble() {
        return preamble;
    }

    public void setPreamble(String preamble) {
        this.preamble = preamble;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getTeacherAssignmentRefId() {
        return teacherAssignmentRefId;
    }

    public void setTeacherAssignmentRefId(UUID teacherAssignmentRefId) {
        this.teacherAssignmentRefId = teacherAssignmentRefId;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(DateTime submitDate) {
        this.submitDate = submitDate;
    }

    public Set<Activity> getActivities() {
        return activities;
    }

    public void setActivities(Set<Activity> activities) {
        this.activities = activities;
    }

    public DateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(DateTime dueDate) {
        this.dueDate = dueDate;
    }

    public DateTime getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(DateTime availableDate) {
        this.availableDate = availableDate;
    }

    public String getCustomClientData() {
        return customClientData;
    }

    public void setCustomClientData(String customClientData) {
        this.customClientData = customClientData;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    public String getMessageAttributes() {
        return messageAttributes;
    }

    public void setMessageAttributes(String messageAttributes) {
        this.messageAttributes = messageAttributes;
    }

    public String getProgramName(){
        return JsonObjectUtil.getStringValueOf(this.customClientData, Constants.PROGRAM_NAME);
    }

    public String getGrade(){
        return JsonObjectUtil.getStringValueOf(this.attributes, Constants.GRADE);
    }

    public String getLevel(){
        return JsonObjectUtil.getStringValueOf(this.attributes, Constants.LEVEL);
    }

    public SourceObjectType getSourceObjectType() {
        return getActivities().iterator().next().getSourceObject().getSif_RefObject();
    }

    public UUID getEventRefId(){
        return (isBenchmark()) ? UUID.fromString(getPreamble()) : getTeacherAssignmentRefId();
    }

    /**
     * Continuum Benchmark StudentAssignments are guaranteed to have only one ActivityForScores with an associated SourceObject.
     */
    public boolean isBenchmark() {
        return SourceObjectTypeUtil.isBenchmark(getSourceObjectType());
    }

    public boolean isWorkflow() {
        return SourceObjectTypeUtil.isWorkflow(getSourceObjectType());
    }

    public boolean isValidToProcess(){
        return SourceObjectTypeUtil.isValidToProcess(getSourceObjectType());
    }

    public boolean isFormative() {
        return SourceObjectTypeUtil.isFormative(getSourceObjectType());
    }

    public boolean isProgramAssesment() {return SourceObjectTypeUtil.isProgramAssessments(getSourceObjectType());}

    public boolean isPerformanceTask() {
        return SourceObjectTypeUtil.isPerformanceTask(getSourceObjectType());
    }

    public boolean isCustomAssesment() {return SourceObjectTypeUtil.isCustomAssessment(getSourceObjectType());}

    @Override
    public String toString() {
        return "StudentAssignment{" +
                "refId=" + refId +
                ", title='" + title + '\'' +
                ", preamble='" + preamble + '\'' +
                ", studentPersonalRefId=" + studentPersonalRefId +
                ", teacherAssignmentRefId=" + teacherAssignmentRefId +
                ", schoolRefId=" + schoolRefId +
                ", status=" + status +
                ", startDate=" + startDate +
                ", submitDate=" + submitDate +
                ", activities=" + activities +
                ", dueDate=" + dueDate +
                ", availableDate=" + availableDate +
                ", customClientData='" + customClientData + '\'' +
                ", staffPersonalRefId=" + staffPersonalRefId +
                ", sectionId=" + sectionId +
                ", attributes='" + attributes + '\'' +
                ", messageAttributes='" + messageAttributes + '\'' +
                '}';
    }
}
