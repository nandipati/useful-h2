package io.hmheng.reporting.aggregator.utils;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 2/27/16.
 */
@Component
public class GsonDateHourMinuteSecondMillisSerializerUtc implements JsonSerializer<DateTime> {

    private static DateTimeFormatter formatter = ISODateTimeFormat.dateHourMinuteSecondMillis();

    @Override
    public JsonElement serialize(DateTime src, Type typeOfSrc, JsonSerializationContext context) {
        return (src == null) ? null : new JsonPrimitive( formatter.withZone(DateTimeZone.UTC).print(src) );
    }
}

