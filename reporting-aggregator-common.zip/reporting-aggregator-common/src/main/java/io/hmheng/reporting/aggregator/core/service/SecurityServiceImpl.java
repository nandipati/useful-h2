package io.hmheng.reporting.aggregator.core.service;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClient;
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
import com.amazonaws.services.securitytoken.model.AssumeRoleResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import java.util.UUID;

import io.hmheng.reporting.aggregator.config.AWSConfig;

@Service
@EnableConfigurationProperties(AWSConfig.class)
public class SecurityServiceImpl implements SecurityService {
    
    private static final Logger logger = LoggerFactory.getLogger(SecurityServiceImpl.class);
    
    @Autowired
    private AWSConfig awsConfig;
    
    @Override
    public AWSCredentials getAWSCredentials() {
        return getBasicSessionCredentials();
    }

    @Override
    public AWSCredentials getDeadLetterAWSCredentials() {
        return getDeadletterSessionCredentials();
    }
    
    private BasicSessionCredentials getBasicSessionCredentials() {
        AWSSecurityTokenServiceClient tokenServiceClient = new AWSSecurityTokenServiceClient();
        
        logger.info("Assuming Role for ARN: {}", awsConfig.getCrossAccountArn());
        
        AssumeRoleRequest assumeRequest = new AssumeRoleRequest().withRoleArn(awsConfig.getCrossAccountArn())
            .withDurationSeconds(awsConfig.getSessionTokenDurationSeconds())
            .withRoleSessionName(UUID.randomUUID().toString());
            
        AssumeRoleResult assumeResult = tokenServiceClient.assumeRole(assumeRequest);
        
        return new BasicSessionCredentials(
            assumeResult.getCredentials().getAccessKeyId(),
            assumeResult.getCredentials().getSecretAccessKey(),
            assumeResult.getCredentials().getSessionToken());
    }

    private BasicSessionCredentials getDeadletterSessionCredentials() {
        AWSSecurityTokenServiceClient tokenServiceClient = new AWSSecurityTokenServiceClient();

        logger.info("Assuming Role for ARN: {}", awsConfig.getDeadLetterArn());

        AssumeRoleRequest assumeRequest = new AssumeRoleRequest().withRoleArn(awsConfig.getDeadLetterArn())
                .withDurationSeconds(awsConfig.getSessionTokenDurationSeconds())
                .withRoleSessionName(UUID.randomUUID().toString());

        AssumeRoleResult assumeResult = tokenServiceClient.assumeRole(assumeRequest);

        return new BasicSessionCredentials(
                assumeResult.getCredentials().getAccessKeyId(),
                assumeResult.getCredentials().getSecretAccessKey(),
                assumeResult.getCredentials().getSessionToken());
    }
    
}
