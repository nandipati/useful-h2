package io.hmheng.reporting.aggregator.core.service.assignments.domain;


import java.util.UUID;

public class ActivityForScores {

    private UUID activityId;

    public ActivityForScores(){

    }

    public ActivityForScores(UUID activityId){
        this.activityId=activityId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    @Override
    public String toString() {
        return "ActivityForScores [activityId=" + activityId  + "]";
    }
}
