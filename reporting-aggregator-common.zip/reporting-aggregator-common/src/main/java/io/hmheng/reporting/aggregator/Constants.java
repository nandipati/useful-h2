package io.hmheng.reporting.aggregator;

public interface Constants {

    String CONTEXT_ID = "contextId";
    String CORRELATION_ID = "CorrelationId";
    String GRADE = "grade";
    String LEVEL = "level";
    String MESSAGE = "Message";
    String MESSAGE_ATTRIBUTES = "MessageAttributes";
    String PRODUCT_ID = "productId";
    String PROGRAM_NAME = "programName";
    String RECEIPT_HANDLE = "ReceiptHandle";
    String VALUE = "Value";
    String SOURCE_TOPIC_NAME = "sourceTopicName";
	  String SPAN_ID = "SpanId";
    //TODO: Has to move to Enum with Inprogress complete implementation.
    String STATUS_COMPLETED = "COMPLETED";
    String EVENTSTATUS_INPROGRESS = "0";
    String PLATFORM_ID = "platformId";
    String PROGRAM_ID = "programId";
    String RE_PROCESS_CORRELATION_ID = "f4f704f9-832b-4fd7-a59c-da51430b0876";
}
