package io.hmheng.reporting.aggregator.web.handler;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.common.collect.Sets;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.web.domain.assignment.Activity;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObject;
import io.hmheng.reporting.aggregator.web.domain.assignment.StudentAssignment;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static io.hmheng.reporting.aggregator.Constants.CONTEXT_ID;

public abstract class CommonMessageUtils {

    public static final String CONTEXT_TC = "tc";
    private static final String CONTEXT_TCK = "tck"; //we convert these to 'tc' 
    public static final String CONTEXT_HMOF = "hmof";
    private static final Set<String> VALID_CONTEXT_IDS = Sets.newHashSet(CONTEXT_HMOF, CONTEXT_TC);

    private static Logger logger = LoggerFactory.getLogger(CommonMessageUtils.class);

    public static <T> T mapMessageToEntity(String messageBody, Class<T> clazz) {
        T entity;
        try {
            if (StudentAssignment.class.isAssignableFrom(clazz)) {
                entity = clazz.cast(mapMessageToStudentAssignment(messageBody));
            } else {
                Object jsonObject;
                if (List.class.isAssignableFrom(clazz)) {
                    jsonObject = new JsonParser().parse(messageBody).getAsJsonArray();
                } else {
                    jsonObject = new JsonParser().parse(messageBody).getAsJsonObject();
                }
                entity = objectMapper().readValue(jsonObject.toString(), clazz);
            }
        } catch(InvalidFormatException ife) {
	        logger.error("{}: {}", ife.getClass().getCanonicalName(), ife.getMessage(), ife);
            throw new RuntimeException(ife);
        } catch (IOException e) {
            logger.error("{}: {}", e.getClass().getCanonicalName(), e.getMessage(), e);
            throw new RuntimeException(e);
        }

        return entity;
    }
    
    private static StudentAssignment mapMessageToStudentAssignment(String messageBody) {
        JsonObject studentAssignmentJson = new JsonParser().parse(messageBody).getAsJsonObject();
        Set<Activity> activities = activitiesFromJson(studentAssignmentJson);
        
        try {
            StudentAssignment studentAssignment = objectMapper().readValue(messageBody, StudentAssignment.class);
            studentAssignment.setActivities(activities);

            return studentAssignment;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    private static Set<Activity> activitiesFromJson(JsonObject json) {
        Set<Activity> activities = Sets.newHashSet();
        
        for (JsonElement jsonElement : json.get("activityRests").getAsJsonArray()) {
            try {
                Activity activity = objectMapper().readValue(jsonElement.toString(), Activity.class);
                activity.setSourceObject(sourceObjectFromJson(jsonElement.getAsJsonObject()));
                
                activities.add(activity);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        
        return activities;
    }
    
    private static SourceObject sourceObjectFromJson(JsonObject json) {
        try {
            return objectMapper().readValue(json.get("sourceObjectRest").toString(), SourceObject.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper;
    }
    
    public static boolean isContextIdValid(String contextId) {
        return StringUtils.isNotBlank(contextId) && VALID_CONTEXT_IDS.contains(contextId);
    }

    public static String getCorrelationId(String message, Map<String, Object> headers) {
        String correlationId = getMessageAttribute(Constants.CORRELATION_ID, message, headers);
        logger.debug("extracted correlationId {} from message", correlationId);
        return correlationId;
    }

    public static JsonElement getMessageAttributes(String message) {
        JsonElement attributesObject = null;
        if (!StringUtils.isBlank(message)) {
            JsonObject messageObject = new JsonParser().parse(message).getAsJsonObject();
            attributesObject = messageObject.get(Constants.MESSAGE_ATTRIBUTES);
        }
        return attributesObject;
    }

    public static boolean isPlatformIdValid(String platformId) {
        return StringUtils.isNotBlank(platformId) && EnumUtils.isValidEnum(PlatformId.class , platformId);
    }

    public static String getMessageAttribute(String attributeName, String message, Map<String, Object> headers) {
        String attribute = null;
        if (!StringUtils.isBlank(message)) {
            JsonElement messageAttributes = getMessageAttributes(message);
            attribute = getAttribute(attributeName, messageAttributes);
        }
        if (StringUtils.isBlank(attribute) && headers != null && headers.get(attributeName) != null) {
            attribute = headers.get(attributeName).toString();
        }
        
        if(CONTEXT_ID.equals(attributeName) && attribute!=null){
            //FAST-4365: some events such as 'student_updated' have:
            // 1: the contextId as upper case, CommonMessageUtils.isContextIdValid will
            //return false for uppercase HMOF/TC, therefore calls to IDM won't have the context id. So we convert it to lowercase regardless
            // 2: the contextId as TCK, we only use TC, so convert it if this situation arises.
            attribute = attribute.toLowerCase();
            if(CONTEXT_TCK.equals(attribute)){
                attribute = CONTEXT_TC;
            }
        }
        return attribute;
    }

    public static String getAttribute(String attributeName, JsonElement messageAttributes) {
        String attributeValue = null;
        if (messageAttributes != null) {
            JsonElement attributeElement = messageAttributes.getAsJsonObject().get(attributeName);
            if (attributeElement != null) {
                JsonElement valueElement = attributeElement.getAsJsonObject().get(Constants.VALUE);
                if (valueElement != null) {
                    attributeValue = valueElement.getAsString();
                }
            }
        }
        return attributeValue;
    }
}
