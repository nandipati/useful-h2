package io.hmheng.reporting.aggregator.web.domain.assignment;

public enum AssignmentStatus {

    NOT_STARTED(Boolean.TRUE , Boolean.TRUE , Boolean.FALSE),
    IN_PROGRESS(Boolean.FALSE , Boolean.FALSE , Boolean.FALSE),
    COMPLETED(Boolean.TRUE, Boolean.TRUE , Boolean.TRUE),
    EXPIRED(Boolean.FALSE, Boolean.FALSE , Boolean.FALSE),
    NOT_SCORED(Boolean.FALSE, Boolean.FALSE , Boolean.FALSE),
    PEER_REVIEW_REQUIRED(Boolean.FALSE, Boolean.FALSE , Boolean.FALSE),
    READY_FOR_SCORING(Boolean.FALSE, Boolean.FALSE , Boolean.TRUE),
    TEACHER_ACTION_REQUIRED(Boolean.FALSE, Boolean.FALSE , Boolean.TRUE),
    TURNED_IN(Boolean.FALSE, Boolean.FALSE , Boolean.TRUE),
    REMOVED(Boolean.FALSE, Boolean.FALSE , Boolean.TRUE);

    private final Boolean locationDetailsRequired;
    private final Boolean demographicsDetailsRequired;
    private final Boolean allowScores;

    AssignmentStatus(Boolean locationDetailsRequired , Boolean demographicsDetailsRequired , Boolean allowScores) {
        this.locationDetailsRequired = locationDetailsRequired;
        this.demographicsDetailsRequired = demographicsDetailsRequired;
        this.allowScores = allowScores;
    }

    public Boolean isLocationDetailsRequired() {
        return this.locationDetailsRequired;
    }
    public Boolean isDemographicsDetailsRequired() {
        return this.demographicsDetailsRequired;
    }
    public Boolean isAllowsScores(){return this.allowScores ; }

    public static AssignmentStatus fromString(String value) {
        return valueOf(value.trim().toUpperCase());
    }
}
