package io.hmheng.reporting.aggregator.core.service;

public interface AuthorizationService {

    enum Service {
        IDM,
        Reporting,
        Assignments,
        Grading,
        Scoring,
        CLM,
        MDS,
        OneSearch,
        IDS
    }
    
    /**
     * @return an IDM SIFAuthorization
     */
    AuthorizationDetails createSIFAuthorization(Service service);
    AuthorizationDetails createSIFAuthorization(Service service, boolean useIds);
    
}


