package io.hmheng.reporting.aggregator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "aws")
public class AWSConfig {

    private String crossAccountId;
    private int sessionTokenDurationSeconds;
    private String crossAccountArn;
    private String region;
    private String localArn;
    private String localAccountId;
    private String lernosityKinesisArn;
    private String deadLetterArn;

    public String getDeadLetterArn() {
        return deadLetterArn;
    }

    public void setDeadLetterArn(String deadLetterArn) {
        this.deadLetterArn = deadLetterArn;
    }

    public String getCrossAccountId() {
        return crossAccountId;
    }

    public void setCrossAccountId(String crossAccountId) {
        this.crossAccountId = crossAccountId;
    }

    public int getSessionTokenDurationSeconds() {
        return sessionTokenDurationSeconds;
    }

    public void setSessionTokenDurationSeconds(int sessionTokenDurationSeconds) {
        this.sessionTokenDurationSeconds = sessionTokenDurationSeconds;
    }

    public String getCrossAccountArn() {
        return crossAccountArn;
    }

    public void setCrossAccountArn(String crossAccountArn) {
        this.crossAccountArn = crossAccountArn;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getLocalArn() {
        return localArn;
    }

    public void setLocalArn(String localArn) {
        this.localArn = localArn;
    }

    public String getLocalAccountId() {
        return localAccountId;
    }

    public void setLocalAccountId(String localAccountId) {
        this.localAccountId = localAccountId;
    }

    public String getLernosityKinesisArn() {
        return lernosityKinesisArn;
    }

    public void setLernosityKinesisArn(String lernosityKinesisArn) {
        this.lernosityKinesisArn = lernosityKinesisArn;
    }
}
