package io.hmheng.reporting.aggregator.utils;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class AttributeHelperImpl implements AttributeHelper {

    private static final Logger logger = LoggerFactory.getLogger(AttributeHelperImpl.class);

    @Override
    public void extractAttributes(Exchange exchange) {
        ProcessorUtils.setHmhHeaders(exchange);

    }

    @Override
    public void clearContext() {
        ProcessorUtils.clearMdc();
    }
}
