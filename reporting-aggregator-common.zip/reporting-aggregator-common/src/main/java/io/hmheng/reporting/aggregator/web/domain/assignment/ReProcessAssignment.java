package io.hmheng.reporting.aggregator.web.domain.assignment;

import java.util.List;
import java.util.UUID;

/**
 * Created by jayachandranj on 3/27/17.
 */
public class ReProcessAssignment{
    private UUID refId;
    private String title;
    private String preamble;
    private UUID staffPersonalRefId;
    private String creatorRefId;
    private String availableDate;
    private String dueDate;
    private UUID leaRefId;
    private UUID schoolRefId;
    private AssignmentStatus status;
    private UUID sectionId;
    private List<Student> students;
    private List<SourceObjects> sourceObjects;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPreamble() {
        return preamble;
    }

    public void setPreamble(String preamble) {
        this.preamble = preamble;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    public String getCreatorRefId() {
        return creatorRefId;
    }

    public void setCreatorRefId(String creatorRefId) {
        this.creatorRefId = creatorRefId;
    }

    public String getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(String availableDate) {
        this.availableDate = availableDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public List<SourceObjects> getSourceObjects() {
        return sourceObjects;
    }

    public void setSourceObjects(List<SourceObjects> sourceObjects) {
        this.sourceObjects = sourceObjects;
    }
}



