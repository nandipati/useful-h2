package io.hmheng.reporting.aggregator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties(prefix = "sifAuthorization")
public class SifAuthConfig {

    @NestedConfigurationProperty
    private SifClientConfig idm;

    @NestedConfigurationProperty
    private SifClientConfig ids;

    @NestedConfigurationProperty
    private SifClientConfig reporting;

    @NestedConfigurationProperty
    private SifClientConfig assignments;

    @NestedConfigurationProperty
    private SifClientConfig grading;

    @NestedConfigurationProperty
    private SifClientConfig scoring;

    @NestedConfigurationProperty
    private SifClientConfig clm;

    @NestedConfigurationProperty
    private SifClientConfig mds;

    @NestedConfigurationProperty
    private SifClientConfig oneSearch;

    public SifClientConfig getOneSearch() {
        return oneSearch;
    }

    public void setOneSearch(SifClientConfig oneSearch) {
        this.oneSearch = oneSearch;
    }

    public SifClientConfig getIdm() {
        return idm;
    }

    public void setIdm(SifClientConfig idm) {
        this.idm = idm;
    }

    public SifClientConfig getReporting() {
        return reporting;
    }

    public void setReporting(SifClientConfig reporting) {
        this.reporting = reporting;
    }

    public SifClientConfig getAssignments() {
        return assignments;
    }

    public void setAssignments(SifClientConfig assignments) {
        this.assignments = assignments;
    }

    public SifClientConfig getGrading() {
        return grading;
    }

    public void setGrading(SifClientConfig grading) {
        this.grading = grading;
    }

    public SifClientConfig getScoring() {
        return scoring;
    }

    public void setScoring(SifClientConfig scoring) {
        this.scoring = scoring;
    }

    public SifClientConfig getClm() {
        return clm;
    }

    public void setClm(SifClientConfig clm) {
        this.clm = clm;
    }

    public SifClientConfig getMds() {
        return mds;
    }

    public void setMds(SifClientConfig mds) {
        this.mds = mds;
    }

    public SifClientConfig getIds() { return ids; }

    public void setIds(SifClientConfig ids) { this.ids = ids; }
}
