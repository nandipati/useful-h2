package io.hmheng.reporting.aggregator.web.domain.assignment;

import io.hmheng.reporting.aggregator.core.service.domain.Grade;
import io.hmheng.reporting.aggregator.core.service.domain.GradeUtils;
import io.hmheng.reporting.aggregator.core.service.domain.Organisation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TestingEventUtils {

    private static final Logger logger = LoggerFactory.getLogger(TestingEventUtils.class);

    /**
     * Return all the Activities inside a Testing Event
     * @param testingEvent
     * @return
     */
    public static Set<Activity> getActivities(TestingEvent testingEvent){
        Set<Organisation> organisations = testingEvent.getOrganisations();

        if (CollectionUtils.isEmpty(organisations)) {
            logger.info("no organisations for testing event {}", testingEvent.getRefId());
        }
        Set<Activity> activitySet = new HashSet<>();
        for (Organisation organisation: organisations) {
            List<Grade> grades = organisation.getGrades();
            if (!CollectionUtils.isEmpty(grades)) {

                for (Grade grade : grades) {
                    Activity activity = GradeUtils.toActivity(grade);
                    if (activity != null) {
                        activitySet.add(activity);
                    }
                }
            }
        }
        return activitySet;
    }
}
