package io.hmheng.reporting.aggregator.helper;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.sqs.model.Message;

import java.util.List;

import io.hmheng.reporting.aggregator.config.SQSConfig;

public interface SQSMessageHelper {

    List<Message> readMessages(AWSCredentials credentials, SQSConfig config);
    
    void deleteMessage(AWSCredentials credentials, String receiptHandle, SQSConfig config);
    
    void deleteMessages(AWSCredentials credentials, List<String> receiptHandles, SQSConfig config);

    String sqsUri(SQSConfig sqsConfig , String sqsClientName);
    
}
