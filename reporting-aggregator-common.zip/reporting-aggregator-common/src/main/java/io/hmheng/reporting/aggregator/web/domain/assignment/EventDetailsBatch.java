package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.hmheng.reporting.aggregator.utils.JsonCommons;
import io.hmheng.reporting.aggregator.utils.JsonDateTimeDeserializerUtc;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.joda.time.DateTime;

/**
 * Created by nandipatim on 2/24/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventDetailsBatch {

    private UUID refId;
    private String eventName;
    private SourceObjectType sourceObjectType;
    private DateTime dueDate;
    private DateTime availableDate;
    private UUID sectionId;
    private UUID staffPersonalRefId;
    private DateTime originalStartDate;
    private DateTime originalFinishDate;
    private DateTime normDate;
    private TestingEventStatus eventStatus;
    private AssignmentStatus status;
    private String discipline;
    private String productId;
    private String programName;
    private SourceObject sourceObject;
    private UUID leaRefId;    //aka districtId


    private Set<Activity> activities;

    private List<Group> groups;

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }


    public UUID getRefId() { return refId; }

    public void setRefId(UUID refId) { this.refId = refId; }

    public String getEventName() { return eventName; }

    public void setEventName(String eventName) { this.eventName = eventName; }

    public AssignmentStatus getStatus() { return status; }

    public void setStatus(AssignmentStatus status) { this.status = status; }

    public SourceObjectType getSourceObjectType() { return sourceObjectType; }

    public void setSourceObjectType(SourceObjectType sourceObjectType) { this.sourceObjectType = sourceObjectType; }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    @JsonSerialize(using = JsonCommons.JodaDateTimeSerializerUTC.class)
    public DateTime getAvailableDate() { return availableDate; }

    public void setAvailableDate(DateTime availableDate) { this.availableDate = availableDate;}

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    @JsonSerialize(using = JsonCommons.JodaDateTimeSerializerUTC.class)
    public DateTime getDueDate() { return dueDate; }

    public void setDueDate(DateTime dueDate) { this.dueDate = dueDate; }

    public UUID getSectionId() { return sectionId; }

    public void setSectionId(UUID sectionId) { this.sectionId = sectionId; }

    public Set<Activity> getActivities() { return activities; }

    public void setActivities(Set<Activity> activities) { this.activities = activities; }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getOriginalStartDate() {
        return originalStartDate;
    }

    public void setOriginalStartDate(DateTime originalStartDate) {
        this.originalStartDate = originalStartDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getOriginalFinishDate() {
        return originalFinishDate;
    }

    public void setOriginalFinishDate(DateTime originalFinishDate) {
        this.originalFinishDate = originalFinishDate;
    }

    @JsonDeserialize(using = JsonDateTimeDeserializerUtc.class)
    public DateTime getNormDate() {
        return normDate;
    }

    public void setNormDate(DateTime normDate) {
        this.normDate = normDate;
    }

    public TestingEventStatus getEventStatus() {
        return eventStatus;
    }

    public void setEventStatus(TestingEventStatus eventStatus) {
        this.eventStatus = eventStatus;
    }

    public String getDiscipline() {
        return discipline;
    }

    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public void addActivities(Activity activity){

        if(activities == null)
            activities = new HashSet<Activity>();

        activities.add(activity);
    }

    public SourceObject getSourceObject() {
        return sourceObject;
    }

    public void setSourceObject(SourceObject sourceObject) {
        this.sourceObject = sourceObject;
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    @Override
    public String toString() {
        return "EventDetailsBatch{" +
                "refId=" + refId +
                ", eventName='" + eventName + '\'' +
                ", sourceObjectType=" + sourceObjectType +
                ", dueDate=" + dueDate +
                ", availableDate=" + availableDate +
                ", sectionId=" + sectionId +
                ", staffPersonalRefId=" + staffPersonalRefId +
                ", originalStartDate=" + originalStartDate +
                ", originalFinishDate=" + originalFinishDate +
                ", normDate=" + normDate +
                ", eventStatus=" + eventStatus +
                ", status=" + status +
                ", discipline='" + discipline + '\'' +
                ", productId='" + productId + '\'' +
                ", programName='" + programName + '\'' +
                ", activities=" + activities +
                '}';
    }
}
