package io.hmheng.reporting.aggregator.exception;

public class ApplicationException extends RuntimeException {

    private static final long serialVersionUID = 8992093926670495071L;

    public ApplicationException() {
    }

    public ApplicationException(String message) {
        super(message);
    }

    public ApplicationException(String message, Throwable ex) {
        super(message, ex);
    }

}
