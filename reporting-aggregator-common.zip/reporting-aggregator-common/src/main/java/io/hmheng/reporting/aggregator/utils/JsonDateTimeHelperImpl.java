package io.hmheng.reporting.aggregator.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * Created by nandipatim on 2/27/16.
 */
@Component
public class JsonDateTimeHelperImpl implements JsonDateTimeHelper {

    @Autowired
    private GsonDateTimeSerializerUtc gsonDateTimeSerializerUtc;

    @Autowired
    private GsonDateHourMinuteSecondMillisSerializerUtc gsonDateTimeHHMMSSSSerializerUtc;

    private Gson gson;

    private Gson gsonUTCDateTime;

    @PostConstruct
    public void setup() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(DateTime.class, this.gsonDateTimeSerializerUtc)
                .create();
        this.gsonUTCDateTime = new GsonBuilder()
                .registerTypeAdapter(DateTime.class, this.gsonDateTimeHHMMSSSSerializerUtc)
                .create();
    }

    public String toJson(Object message){
        return this.gson.toJson(message);
    }


    public String toJsonWithHourMinuteSecondMillis(Object message){
        return this.gsonUTCDateTime.toJson(message);
    }

    public DateTime toJodaDateTime(LocalDateTime dateTime){
        return  new org.joda.time.LocalDateTime(dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
                .toDateTime();

    }

}
