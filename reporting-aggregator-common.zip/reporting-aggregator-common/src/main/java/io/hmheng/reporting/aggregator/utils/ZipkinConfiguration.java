package io.hmheng.reporting.aggregator.utils;

import com.github.kristofa.brave.SpanCollector;
import com.twitter.zipkin.gen.Annotation;
import com.twitter.zipkin.gen.BinaryAnnotation;
import com.twitter.zipkin.gen.Span;

import org.apache.camel.CamelContext;
import org.apache.camel.zipkin.ZipkinTracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

import zipkin.reporter.AsyncReporter;
import zipkin.reporter.urlconnection.URLConnectionSender;

/**
 * Created by fodori on 10/12/16.
 */
@Configuration
public class ZipkinConfiguration {

  private static final Logger logger = LoggerFactory.getLogger(ZipkinConfiguration.class);

  @Autowired
  private CamelContext camelContext;

  @Value("${spring.zipkin.baseUrl}")
  private String baseUrl;

  @Value("${spring.zipkin.flushIntervalSeconds}")
  private Integer flushIntervalSeconds;

  @Value("${spring.zipkin.includeBody}")
  private Boolean includeBody;

  @Value("${spring.zipkin.reportingRate}")
  private Float reportingRate;

  @Value("${spring.zipkin.serviceName}")
  private String serviceName;

  @Bean
  public ZipkinTracer zipkinTracer(CamelContext camelContext) {
    logger.info("Initializing Zipkin with baseUrl={}, flushIntervalSeconds={}, includeBody={}, reportingRate={}, "
        + "serviceName={}", baseUrl, flushIntervalSeconds, includeBody, reportingRate, serviceName);
    ZipkinTracer zipkin = new ZipkinTracer();
    zipkin.setSpanCollector(new AggregatorZipkinSpanCollector(baseUrl, flushIntervalSeconds));
    // capture 100% of all the events
    zipkin.setRate(reportingRate);
    // include message bodies in the traces (not recommended for production)
    zipkin.setIncludeMessageBodyStreams(includeBody);
    // add zipkin to CamelContext
    zipkin.setServiceName(serviceName);
    zipkin.init(camelContext);
    return zipkin;
  }

  class AggregatorZipkinSpanCollector implements SpanCollector {

    private final AsyncReporter reporter;

    private AggregatorZipkinSpanCollector(String host, int flushInterval) {
      this.reporter = AsyncReporter
          .builder(URLConnectionSender.builder().compressionEnabled(false).endpoint(host).build())
          .messageTimeout(flushInterval, TimeUnit.SECONDS).build();
    }

    @Override
    public void collect(Span span) {
      if (span != null) {
        this.reporter.report(toZipkin(span));
      }
    }

    @Override
    @Deprecated
    public void addDefaultAnnotation(String key, String value) {
      //Intentionally left blank, as this is a deprecated method
    }

    protected zipkin.Span toZipkin(Span span) {
      zipkin.Span.Builder target = zipkin.Span.builder();
      target.traceId(span.getTrace_id()).name(span.getName()).id(span.getId()).parentId(span.getParent_id())
          .debug(span.isDebug()).timestamp(span.getTimestamp()).duration(span.getDuration());

      for (Annotation annotation : span.getAnnotations()) {
        zipkin.Endpoint targetEndpoint = convertEndpoint(annotation.host);
        zipkin.Annotation targetAnnotation = zipkin.Annotation.builder().timestamp(annotation.timestamp)
            .value(annotation.value).endpoint(targetEndpoint).build();

        target.addAnnotation(targetAnnotation);
      }

      for (BinaryAnnotation binaryAnnotation : span.getBinary_annotations()) {
        zipkin.Endpoint targetEndpoint = convertEndpoint(binaryAnnotation.host);
        zipkin.BinaryAnnotation targetBinAnnotation = zipkin.BinaryAnnotation.builder().endpoint(targetEndpoint)
            .key(binaryAnnotation.key).value(binaryAnnotation.value)
            .type(zipkin.BinaryAnnotation.Type.fromValue(binaryAnnotation.type.getValue())).build();
        target.addBinaryAnnotation(targetBinAnnotation);
      }

      return target.build();
    }

    protected zipkin.Endpoint convertEndpoint(com.twitter.zipkin.gen.Endpoint host) {
      zipkin.Endpoint targetEndpoint = null;
      if (host != null) {
        targetEndpoint = zipkin.Endpoint.builder().ipv4(host.ipv4).port(host.port).serviceName(host.service_name)
            .build();
      }
      return targetEndpoint;
    }
  }

}

