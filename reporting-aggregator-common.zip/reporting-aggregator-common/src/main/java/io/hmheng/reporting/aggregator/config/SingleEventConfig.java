package io.hmheng.reporting.aggregator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties
public class SingleEventConfig {
    
    @NestedConfigurationProperty
    private SQSConfig sqs;

    @NestedConfigurationProperty
    private SNSConfig sns;

    @NestedConfigurationProperty
    private KinesisConfig kinesis;


    private final static String sqsConnectionTemplateUrl = "aws-sqs://%s?"
            + "amazonSQSClient=#%s&"
            + "visibilityTimeout=%s&"
            + "concurrentConsumers=%s&"
            + "region=%s&"
            + "queueOwnerAWSAccountId=%s&"
        + "delay=1000";

    public SQSConfig getSqs() {
        return sqs;
    }

    public void setSqs(SQSConfig sqs) {
        this.sqs = sqs;
    }

    public SNSConfig getSns() {
        return sns;
    }

    public void setSns(SNSConfig sns) {
        this.sns = sns;
    }

    public KinesisConfig getKinesis() {
      return kinesis;
    }

    public void setKinesis(KinesisConfig kinesis) {
      this.kinesis = kinesis;
    }

    public String getAwsSqsConnectionString(String sqsClientName) {

          return String.format(sqsConnectionTemplateUrl,
                  this.sqs.getQueue(),
                  sqsClientName,
                  this.sqs.getVisibilityTimeout(),
                  this.sqs.getConcurrentConsumers(),
                  this.sqs.getRegion(),
                  this.sqs.getAccountId());
      }
}
