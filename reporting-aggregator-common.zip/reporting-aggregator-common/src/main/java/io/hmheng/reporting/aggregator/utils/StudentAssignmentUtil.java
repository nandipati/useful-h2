package io.hmheng.reporting.aggregator.utils;

import io.hmheng.reporting.aggregator.core.service.domain.Organisation;
import java.util.Collection;
import java.util.stream.Stream;
import org.springframework.util.CollectionUtils;

/**
 * Created by nandipatim on 3/10/16.
 */
public class StudentAssignmentUtil {

    public static boolean hasAssignments(Collection<Organisation> organisations) {
        return !CollectionUtils.isEmpty(organisations) && organisations.stream()
                .flatMap(o -> CollectionUtils.isEmpty(o.getGrades()) ? Stream.empty() : o.getGrades().stream())
                .anyMatch(g -> !CollectionUtils.isEmpty(g.getStudentAssignmentReports()));
    }
}
