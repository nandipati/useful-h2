package io.hmheng.reporting.aggregator.utils;

import io.hmheng.reporting.aggregator.web.domain.assignment.ProductType;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;

/**
 * Created by nandipatim on 3/4/16.
 */
public class SourceObjectTypeUtil {

    public static Boolean isBenchmark(SourceObjectType sourceObjectType){
        return SourceObjectType.ASSESSMENT == sourceObjectType;
    }

    public static Boolean isFormative(SourceObjectType sourceObjectType){
        return  SourceObjectType.FORMATIVE_ASSESSMENT == sourceObjectType;
    }

    public static Boolean isWorkflow(SourceObjectType sourceObjectType){
        return  SourceObjectType.WORKFLOW == sourceObjectType;
    }

    public static Boolean isProgramAssessments(SourceObjectType sourceObjectType){
        return  SourceObjectType.PROGRAM_ASSESSMENT == sourceObjectType;
    }
    public static Boolean isPerformanceTask(SourceObjectType sourceObjectType){
        return  SourceObjectType.PERFORMANCE_TASK == sourceObjectType;
    }

    public static Boolean isProductType(SourceObjectType sourceObjectType){
        return  ProductType.ED == sourceObjectType.getProductType();
    }

    public static Boolean isValidToProcess(SourceObjectType sourceObjectType){

        if(sourceObjectType == null){
            return Boolean.FALSE;
        }

        return sourceObjectType.isValidToProcess();
    }
    public static Boolean isCustomAssessment(SourceObjectType sourceObjectType){
        return  SourceObjectType.CUSTOM_ASSESSMENT == sourceObjectType;
    }
}
