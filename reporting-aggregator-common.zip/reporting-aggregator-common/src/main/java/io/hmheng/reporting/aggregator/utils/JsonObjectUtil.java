package io.hmheng.reporting.aggregator.utils;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Created by nandipatim on 3/10/16.
 */
public class JsonObjectUtil {

    public static String getStringValueOf(String jsonPayload , String elementName) {

        if(jsonPayload == null)
            return null;

        JsonObject eventMessage = new JsonParser().parse(jsonPayload).getAsJsonObject();
        JsonElement element = (eventMessage != null)? eventMessage.get(elementName) : null;
        return  (element != null) ? element.getAsString() : null ;
    }
}
