package io.hmheng.reporting.aggregator.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils;

@Component
public class ExchangeUtils {

    private static final JsonParser jsonParser = new JsonParser();

    /**
     * Returns the "Body" as a JsonObject
     * @param exchange
     * @return
     */
    private static JsonObject getBodyAsJsonObject(Exchange exchange){
        String body = getBody(exchange);
        return jsonParser.parse(body).getAsJsonObject();
    }

    /**
     * Extracts and returns the "Message" attribute from the JsonObject
     * @param bodyJson
     * @return
     */
    private static String getMessage(JsonObject bodyJson){
        return bodyJson.get(Constants.MESSAGE).getAsString();
    }

    /**
     * Sets the Body to be an empty String
     * @param exchange
     */
    public static final String CLEAR_MESSAGE_BODY = "clearMessageBody"; //MUST be the same name as this method
    public static void clearMessageBody(Exchange exchange){
        exchange.getIn().setBody("");
    }

    /**
     * Returns the "Body" as a String
     * @param exchange
     * @return
     */
    public static String getBody(Exchange exchange){
        return exchange.getIn().getBody(String.class);
    }

    /**
     * Returns the "Message" payload as a String
     * @param exchange
     * @return
     */
    public static String getMessage(Exchange exchange){
        JsonObject bodyJson = getBodyAsJsonObject(exchange);
        return getMessage(bodyJson);
    }

    /**
     * Returns the "Message" payload as a JsonObject
     * @param exchange
     * @return
     */
    public static JsonObject getMessageAsJsonObject(Exchange exchange){
        String message = getMessage(exchange);
        return jsonParser.parse(message).getAsJsonObject();
    }

    /**
     * Converts the "Message" payload to the targetClass
     * @param exchange
     * @param targetClass
     * @param <T>
     * @return
     */
    public static <T> T convertMessage(Exchange exchange, Class<T> targetClass) {
        return CommonMessageUtils.mapMessageToEntity( getMessage( exchange ), targetClass);
    }



}
