package io.hmheng.reporting.aggregator.core.service.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.Activity;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObject;

import java.util.Optional;
import java.util.UUID;

public class GradeUtils {

    public static UUID getActivityId(Grade grade) {
        UUID activityId = Optional.ofNullable(grade).map(Grade::getResource).map(Resource::getInstanceRefId).orElse(null);
        return activityId;
    }

    /**
     * Get the Activity from the Grade
     * @param grade
     * @return
     */
    public static Activity toActivity(Grade grade){
        UUID activityId = getActivityId(grade);
        Activity activity = null;
        if(activityId!=null){
            activity = new Activity();
            activity.setRefId(activityId);
            activity.setGrade(grade.getGrade());
            activity.setLevel(grade.getLevel());

            SourceObject sourceObject = new SourceObject();
            Resource resource = grade.getResource();
            sourceObject.setIsbn(resource.getSecondaryId());
            sourceObject.setValue(resource.getPrimaryId());
            sourceObject.setUgenRefId(activityId); //NOTE: this is the activity (In Assignments, referred to as the assessment id)
            activity.setSourceObject(sourceObject);
        }
        return activity;
    }

}
