package io.hmheng.reporting.aggregator.web.domain.assignment;

import io.hmheng.reporting.aggregator.utils.ContentSource;

public enum SourceObjectType {

    //TODO When ever you are enabling Source Object you have enable Content Source too.
    ACTIVITY(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    AIR(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    ASSESSMENT(Boolean.TRUE , ContentSource.NONE, ProductType.HMH1),
    CUSTOM_UGEN(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    CUSTOM_UGEN_DLO(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    ENRICHMENT(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    INTERVENTION(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    LEARNING_RESOURCE(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    LESSON(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    OTHER_SEARCHABLE_RESOURCE(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    OTHER_TEXT_RESOURCE(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    OTHER_URL_RESOURCE(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    REASSESSMENT(Boolean.TRUE , ContentSource.NONE, ProductType.NONE),
    WAE(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    TEACHER_CREATED(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    FORMATIVE_ASSESSMENT(Boolean.TRUE , ContentSource.MDS, ProductType.HMH1),
    WORKFLOW(Boolean.FALSE , ContentSource.NONE, ProductType.NONE),
    PERFORMANCE_TASK(Boolean.TRUE , ContentSource.ONE_SEARCH, ProductType.ED),
    PROGRAM_ASSESSMENT(Boolean.TRUE , ContentSource.ONE_SEARCH, ProductType.ED),
    CUSTOM_ASSESSMENT(Boolean.TRUE , ContentSource.ONE_SEARCH, ProductType.ED);

    private final Boolean isValidToProcess;
    private final ContentSource contentSource;
    private final ProductType productType;

    SourceObjectType(Boolean isValidToProcess , ContentSource contentSource, ProductType productType){
        this.isValidToProcess = isValidToProcess ;
        this.contentSource = contentSource;
        this.productType=productType;
    }

    public Boolean isValidToProcess() {
        return this.isValidToProcess;
    }

    public static SourceObjectType fromString(String value) {
        return valueOf(value.trim().toUpperCase());
    }

    public ContentSource getContentSource() {
        return contentSource;
    }

    public ProductType getProductType() {
        return productType;
    }
}
