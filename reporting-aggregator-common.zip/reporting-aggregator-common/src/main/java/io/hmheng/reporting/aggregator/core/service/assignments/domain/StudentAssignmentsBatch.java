package io.hmheng.reporting.aggregator.core.service.assignments.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StudentAssignmentsBatch {

    private UUID schoolRefId;
    private UUID eventRefId;
    private UUID sectionId;
    private UUID leaRefId;
    private SourceObjectType sourceObjectType;
    private List<UUID> studentsAdded;
    private List<UUID> studentsRemoved;
    private List<StudentAssignmentReport> studentAssignmentReports = new ArrayList<>();
    private UUID staffPersonalRefId;

    /**
	 * The published source topic name in the event service queue from where this batch is orchestrated.
	 * Can be used as a marker to differentiate between messages being processed within the aggregator.
	 */
	  private String sourceTopicName;

    public StudentAssignmentsBatch() {
    }

    public StudentAssignmentsBatch(UUID leaRefId, UUID schoolRefId, UUID eventRefId) {
        this.leaRefId = leaRefId;
        this.schoolRefId = schoolRefId;
        this.eventRefId = eventRefId;
    }
    public StudentAssignmentsBatch(StudentAssignmentsBatch copySource) {
        this.schoolRefId=copySource.getSchoolRefId();
        this.eventRefId=copySource.getEventRefId();
        this.sectionId=copySource.getSectionId();
        this.leaRefId=copySource.getEventRefId();
        this.sourceObjectType=copySource.getSourceObjectType();
    }
    public void addStudentAssignment(StudentAssignmentReport studentAssignment) {
        studentAssignmentReports.add(studentAssignment);
    }

    public List<StudentAssignmentReport> getStudentAssignmentReports() {
        return studentAssignmentReports;
    }

    public void setStudentAssignmentReports(List<StudentAssignmentReport> studentAssignmentReports) {
        this.studentAssignmentReports = studentAssignmentReports;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

    public void setSourceObjectType(SourceObjectType sourceObjectType) {
        this.sourceObjectType = sourceObjectType;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    @Override
    public String toString() {
        return "StudentAssignmentsBatch{" +
                "  schoolRefId=" + schoolRefId +
                ", eventRefId=" + eventRefId +
                ", leaRefId=" + leaRefId +
                ", sectionId=" + sectionId +
                ", sourceObjectType=" + sourceObjectType +
                ", sourceTopicName=" + sourceTopicName +
                ", studentAssignmentReports=" + studentAssignmentReports +
                '}';
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

	  public String getSourceTopicName() {
		 return sourceTopicName;
	  }

	  public void setSourceTopicName(String sourceTopicName) {
		 this.sourceTopicName = sourceTopicName;
	  }

    public List<UUID> getStudentsAdded() {
        return studentsAdded;
    }

    public void setStudentsAdded(List<UUID> studentsAdded) {
        this.studentsAdded = studentsAdded;
    }

    public List<UUID> getStudentsRemoved() {
        return studentsRemoved;
    }

    public void setStudentsRemoved(List<UUID> studentsRemoved) {
        this.studentsRemoved = studentsRemoved;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }
}
