package io.hmheng.reporting.aggregator.web.domain.assignment;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.utils.JsonObjectUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import java.util.Set;

public class EventDetailsBatchConverter {

    public static EventDetailsBatch toEventDetailsBatch(StudentAssignment studentAssignment){
        EventDetailsBatch eventDetailsBatch = new EventDetailsBatch();
        eventDetailsBatch.setRefId( studentAssignment.getEventRefId() );
        BeanUtils.copyProperties(studentAssignment, eventDetailsBatch, StudentAssignment.REFID);

        eventDetailsBatch.setEventName(studentAssignment.getTitle());
        eventDetailsBatch.setSourceObjectType(studentAssignment.getSourceObjectType());
        if(studentAssignment.isBenchmark()){
            eventDetailsBatch.setEventStatus(TestingEventStatus.OPEN);
            eventDetailsBatch.setProgramName(studentAssignment.getProgramName());

            String productId = null;
            Set<Activity> activities = studentAssignment.getActivities();
            if (!CollectionUtils.isEmpty(activities)) {
                for (Activity activity : activities) {
                    productId = JsonObjectUtil.getStringValueOf(activity.getSourceObject().getAttributes(), Constants.PRODUCT_ID);
                    if (productId != null) {
                        break;
                    }
                }
            }

            eventDetailsBatch.setProductId(productId);
        }
        eventDetailsBatch.setStatus(studentAssignment.getStatus());

        return eventDetailsBatch;
    }

    public static EventDetailsBatch toEventDetailsBatch(TeacherAssignment teacherAssignment) {
        EventDetailsBatch eventDetailsBatch = new EventDetailsBatch();

        BeanUtils.copyProperties(teacherAssignment, eventDetailsBatch);
        if (teacherAssignment.getStudentGroupRests() != null) {
            eventDetailsBatch.setGroups(teacherAssignment.getStudentGroupRests());
        } else if(teacherAssignment.getStudentGroups() != null){
            eventDetailsBatch.setGroups(teacherAssignment.getStudentGroups());
        }
        eventDetailsBatch.setEventName(teacherAssignment.getTitle());
        eventDetailsBatch.setSourceObject(teacherAssignment.getSourceObject());
        eventDetailsBatch.setSourceObjectType(teacherAssignment.getSourceObjectType());

        return eventDetailsBatch;

    }

    public static EventDetailsBatch toEventDetailsBatch(TestingEvent testingEvent) {
        EventDetailsBatch eventDetailsBatch = new EventDetailsBatch();
        BeanUtils.copyProperties(testingEvent, eventDetailsBatch);

        eventDetailsBatch.setAvailableDate(testingEvent.getStartDate());
        eventDetailsBatch.setDueDate(testingEvent.getFinishDate());
        eventDetailsBatch.setSourceObjectType(SourceObjectType.ASSESSMENT);
        eventDetailsBatch.setEventStatus(testingEvent.getStatus());
        eventDetailsBatch.setStatus(testingEvent.getAssignmentStatus());

        return eventDetailsBatch;
    }

    public static EventDetailsBatch toEventDetailsBatch(TeacherAssignmentUpdate teacherAssignmentUpdate) {
        EventDetailsBatch eventDetailsBatch = new EventDetailsBatch();

        BeanUtils.copyProperties(teacherAssignmentUpdate, eventDetailsBatch);
        if (teacherAssignmentUpdate.getStudentGroupRests() != null) {
            eventDetailsBatch.setGroups(teacherAssignmentUpdate.getStudentGroupRests());
        } else if(teacherAssignmentUpdate.getStudentGroups() != null){
            eventDetailsBatch.setGroups(teacherAssignmentUpdate.getStudentGroups());
        }

        eventDetailsBatch.setEventName(teacherAssignmentUpdate.getTitle());
        eventDetailsBatch.setSourceObject(teacherAssignmentUpdate.getSourceObject());
        eventDetailsBatch.setSourceObjectType(teacherAssignmentUpdate.getSourceObjectType());

        return eventDetailsBatch;

    }
}
