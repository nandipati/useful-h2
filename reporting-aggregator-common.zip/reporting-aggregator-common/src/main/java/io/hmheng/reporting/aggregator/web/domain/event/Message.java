package io.hmheng.reporting.aggregator.web.domain.event;

import java.util.UUID;

public class Message {
	private UUID studentRefUUID;
	private UUID districtRefUUID;
	private UUID schoolRefUUID;

	public UUID getStudentRefUUID() {
		return studentRefUUID;
	}

	public void setStudentRefUUID(UUID studentRefUUID) {
		this.studentRefUUID = studentRefUUID;
	}

	public UUID getDistrictRefUUID() {
		return districtRefUUID;
	}

	public void setDistrictRefUUID(UUID districtRefUUID) {
		this.districtRefUUID = districtRefUUID;
	}

	public UUID getSchoolRefUUID() {
		return schoolRefUUID;
	}

	public void setSchoolRefUUID(UUID schoolRefUUID) {
		this.schoolRefUUID = schoolRefUUID;
	}
}
