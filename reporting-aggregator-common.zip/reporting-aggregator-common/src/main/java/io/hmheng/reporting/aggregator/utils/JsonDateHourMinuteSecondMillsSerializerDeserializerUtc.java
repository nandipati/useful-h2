package io.hmheng.reporting.aggregator.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

/**
 * Created by nandipatim on 3/11/16.
 */

public class JsonDateHourMinuteSecondMillsSerializerDeserializerUtc extends JsonDeserializer<DateTime> {
    private static DateTimeFormatter jodaDateFormatter = ISODateTimeFormat.dateHourMinuteSecondMillis().withZone(DateTimeZone.UTC);

    @Override
    public DateTime deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        return jodaDateFormatter.parseDateTime(jsonParser.getText());
    }
}
