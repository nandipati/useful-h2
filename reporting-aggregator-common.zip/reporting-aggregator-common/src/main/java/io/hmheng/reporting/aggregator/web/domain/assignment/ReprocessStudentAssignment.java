package io.hmheng.reporting.aggregator.web.domain.assignment;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.joda.time.DateTime;

import java.util.List;
import java.util.UUID;

/**
 * Created by jayachandranj on 3/28/17.
 */

public class ReprocessStudentAssignment {
    private UUID refId;
    private String title;
    private String preamble;
    private UUID studentPersonalRefId;
    private UUID teacherAssignmentRefId; //aka assignmentId
    private AssignmentStatus status;
    private DateTime startDate;
    private DateTime submitDate;
    private String availableDate;
    private String dueDate;
    private UUID staffPersonalRefId;
    private UUID sectionId;
    private List<Activities> activities;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPreamble() {
        return preamble;
    }

    public void setPreamble(String preamble) {
        this.preamble = preamble;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getTeacherAssignmentRefId() {
        return teacherAssignmentRefId;
    }

    public void setTeacherAssignmentRefId(UUID teacherAssignmentRefId) {
        this.teacherAssignmentRefId = teacherAssignmentRefId;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(DateTime submitDate) {
        this.submitDate = submitDate;
    }


    public String getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(String availableDate) {
        this.availableDate = availableDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public List<Activities> getActivities() {
        return activities;
    }

    public void setActivities(List<Activities> activities) {
        this.activities = activities;
    }
}
