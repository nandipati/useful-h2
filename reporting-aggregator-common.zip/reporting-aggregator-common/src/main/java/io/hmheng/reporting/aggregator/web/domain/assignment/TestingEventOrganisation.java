package io.hmheng.reporting.aggregator.web.domain.assignment;

import java.util.UUID;

public class TestingEventOrganisation {

    private UUID leaRefId;
    private UUID schoolRefId;
    private boolean standalone;

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }
    
    public boolean isStandalone() {
        return standalone;
    }
    
    public void setStandalone(boolean standalone) {
        this.standalone = standalone;
    }
}
