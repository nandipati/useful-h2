package io.hmheng.streaming.spark.streams;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesisClient;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;

import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kinesis.KinesisUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import io.hmheng.streaming.spark.utils.Constants;

/**
 * Created by nandipatim on 1/24/17.
 */
@Component
public class AmazonKinesisStreamFactory implements InputStreamFactory<String>, Serializable {

  private static final long serialVersionUID = 1L;

  @Autowired
  private AmazonKinesisClient kinesisClient;

  @Value("${aws.kinesis.region}")
  private String awsRegion;

  @Value("${aws.kinesis.endpoint}")
  private String kinesisEndpoint;

  @Value("${aws.kinesis.app.name}")
  private String kinesisAppName;

  @Value("${aws.kinesis.app.stream}")
  private String kinesisAppStream;

  public JavaDStream<String> create(JavaStreamingContext streamingContext) {
    String env = streamingContext.sparkContext().getConf().get(Constants.ENVIRONMENT_KEY);
    //String kinesisAppName = String.format("io.hmheng.%s.hmhone.score.learnocity.application", env);
    //String scoresMessageStream = String.format("io.hmheng.%s.kinesis.hmhone.assessment.score", env);
    int numShards = kinesisClient.describeStream(kinesisAppStream).getStreamDescription().getShards().size();
    List<JavaDStream<byte[]>> dStreamLists = createStreams(streamingContext, kinesisAppName, kinesisAppStream, kinesisEndpoint,
        awsRegion, new Duration(2000), numShards);
    JavaDStream<byte[]> uStreams = unionStreams(dStreamLists, streamingContext);
    return convertToStringFromByteStream(uStreams);
  }

  private AmazonKinesisClient createAmazonKinesisClient() {
    AmazonKinesisClient client = new AmazonKinesisClient(new DefaultAWSCredentialsProviderChain());
    client.setRegion(Region.getRegion(Regions.US_EAST_1));
    return client;
  }

  private static List<JavaDStream<byte[]>> createStreams(JavaStreamingContext jssc, String kinesisAppName, String streamName,
                                                         String endpointUrl, String regionName, Duration kinesisCheckpointInterval,
                                                         int numStreams) {
    List<JavaDStream<byte[]>> dStreamsList = new ArrayList<>(numStreams);
    for (int i = 0; i < numStreams; i++) {
      dStreamsList.add(
          KinesisUtils.createStream(jssc, kinesisAppName, streamName, endpointUrl, regionName,
              InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval, StorageLevel.MEMORY_AND_DISK_2()));
    }
    return dStreamsList;
  }

  private static JavaDStream<byte[]> unionStreams(List<JavaDStream<byte[]>> dStreamLists, JavaStreamingContext streamingContext) {
    return (dStreamLists.size() > 1) ? streamingContext.union(dStreamLists.get(0), dStreamLists.subList(1, dStreamLists.size())) : dStreamLists.get(0);
  }

  private static JavaDStream<String> convertToStringFromByteStream(JavaDStream<byte[]> uStreams) {
    return uStreams.flatMap(byteStr -> Arrays.asList(new String(byteStr, StandardCharsets.UTF_8)).iterator());
  }


}
