package io.hmheng.streaming.spark;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import io.hmheng.streaming.spark.streams.InputStreamFactory;
import io.hmheng.streaming.spark.streams.SparkRunner;
import io.hmheng.streaming.spark.utils.StreamingContextFactory;

/**
 * Created by nandipatim on 1/24/17.
 */
@Configuration
@ComponentScan
public class SparkConfiguration {

  @Autowired
  StreamingContextFactory streamingContextFactory;

  @Autowired
  InputStreamFactory<String> inputStreamFactory;

  @Bean
  SparkRunner sparkRunner() {
      SparkRunner sparkRunner = new SparkRunner(streamingContextFactory , inputStreamFactory);
    try {
      sparkRunner .execute();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    return sparkRunner;
  }
}
