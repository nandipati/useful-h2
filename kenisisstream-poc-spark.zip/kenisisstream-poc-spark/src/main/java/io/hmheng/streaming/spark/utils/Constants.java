package io.hmheng.streaming.spark.utils;

/**
 * Created by nandipatim on 1/24/17.
 */
public interface Constants {
  public final static String ENVIRONMENT_KEY = "spark.app.env";
  public final static String CHECKPOINT_DIR_KEY = "spark.app.checkpoint_dir";
  public final static String LOCAL_ENV = "local";
  public final static String TEST_ENV = "test";
}
