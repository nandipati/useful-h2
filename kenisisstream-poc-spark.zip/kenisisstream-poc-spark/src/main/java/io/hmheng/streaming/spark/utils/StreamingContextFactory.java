package io.hmheng.streaming.spark.utils;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * Created by nandipatim on 1/24/17.
 */
@Component
public class StreamingContextFactory implements Serializable {
  private static final long serialVersionUID = 1L;
  private final static long BATCH_SPAN_MILLISECONDS = 10000;

  @Value("${spring.profiles.active}")
  private String environment;

  @Value("${spark.app.env}")
  private String sparkAppEnv;

  @Value("${spark.app.master}")
  private String sparkMaster;

  @Value("${spark.app.home}")
  private String sparkHome;

  @Value("${aws.app.disableCertChecking}")
  private String awsDisableCertChecking;

  @Value("${spark.app.mesos.mesosExecutor.cores}")
  private String mesosExecutorCores;

  @Value("${spark.app.memory.fraction}")
  private String sparkMemoryFraction;

  @Value("${spark.app.memory.storageFraction}")
  private String sparkMemoryStorageFraction;

  @Value("${spark.executor.uri}")
  private String sparkExecutorUri;

  @Value("${spark.executor.memory}")
  private String sparkExecutorMemory;

  @Value("${spark.driver.memory}")
  private String sparkDriverMemory;

  public JavaStreamingContext create() {
    //TODO: All the config has to be moved to yml or config service
    SparkConf conf = new SparkConf().setAppName("datastreampoc");
    System.getProperties().setProperty("com.amazonaws.sdk.disableCertChecking", awsDisableCertChecking);
    conf.setMaster(sparkMaster);
      //Change it the local Where spark is installed to
    conf.setSparkHome(sparkHome);
      //Below means you are working Yarn standalone rather than mesos cluster for development.
      //Change it the local Where spark is installed to
    conf.set("spark.executor.uri", sparkExecutorUri);
      //Want to use docker pass on docker image
      //sparkConfig.set("spark.mesos.executor.docker.image", )
    conf.set("spark.mesos.mesosExecutor.cores", mesosExecutorCores);
    conf.set("spark.memory.fraction", sparkMemoryFraction);
    conf.set("spark.memory.storageFraction", sparkMemoryStorageFraction);
    conf.set("spark.driver.memory" , sparkDriverMemory);
    conf.set("spark.executor.memory" , sparkExecutorMemory);
    conf.set("spark.app.env", sparkAppEnv);
      //Below should be used when we are going from checkpoint
      //conf.set("spark.app.checkpoint_dir", "/Users/nandipatim/Projects/develop/aurora/spark-2.0.0");
    //setIfNotDefined(conf, Constants.CHECKPOINT_DIR_KEY, String.format("/mnt/efs/service/roles/hmheng-report/spark/%s/checkpoint/", environment));
    return new JavaStreamingContext(new JavaSparkContext(conf), new Duration(BATCH_SPAN_MILLISECONDS));
  }

  /**
   * Set a configuration value according to an order of precedence
   * 1. System Property
   * 2. Value passed into the conf
   * 3. Default value
   *
   * @param conf
   * @param key
   * @param value
   * @return Spark Conf
   */
  private String setIfNotDefined(SparkConf conf, String key, String value) {
    String setValue = value;
    // Use a value in the conf if set
    if (conf.contains(key)) {
      setValue = conf.get(key);
    } else {
      conf.set(key, setValue);
    }
    return setValue;
  }
}
