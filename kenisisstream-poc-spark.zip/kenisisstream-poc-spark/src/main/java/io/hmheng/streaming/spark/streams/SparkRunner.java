package io.hmheng.streaming.spark.streams;

import io.hmheng.streaming.spark.utils.StreamingContextFactory;

import java.io.Serializable;

import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 1/24/17.
 */
@Component
public class SparkRunner implements Serializable {
  private static final long serialVersionUID = 1L;

  private final StreamingContextFactory streamingContextFactory;
  private final InputStreamFactory<String> inputStreamFactory;

  @Autowired
  public SparkRunner(StreamingContextFactory streamingContextFactory,
                     InputStreamFactory<String> inputStreamFactory){
    this.streamingContextFactory = streamingContextFactory;
    this.inputStreamFactory = inputStreamFactory;
  }

  public void execute() throws InterruptedException {
    JavaStreamingContext streamingContext = streamingContextFactory.create();
    //streamingContext.checkpoint(streamingContext.sparkContext().getConf().get(Constants.CHECKPOINT_DIR_KEY));
    JavaDStream<String> eventsStream = inputStreamFactory.create(streamingContext);
    eventsStream.print();

    run(streamingContext);
  }

  private void run(JavaStreamingContext streamingContext) throws InterruptedException {
    streamingContext.start();
    streamingContext.awaitTermination();
  }
}
