package io.hmheng.streaming.spark;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by nandipatim on 1/24/17.
 */

@SpringBootApplication
public class SparkStreamApp{

  public static void main(String[] args) {
    SpringApplication.run(SparkStreamApp.class, args);
  }
}
