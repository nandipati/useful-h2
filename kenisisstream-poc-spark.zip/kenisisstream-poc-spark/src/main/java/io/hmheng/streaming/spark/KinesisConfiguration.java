package io.hmheng.streaming.spark;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesisClient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Created by fodori on 1/27/17.
 */
@Configuration
@Profile({"local","dev","int","cert","prod"})
public class KinesisConfiguration {

  @Bean
  public AmazonKinesisClient kinesisClient() {

    AmazonKinesisClient client = new AmazonKinesisClient(new DefaultAWSCredentialsProviderChain());
    client.setRegion(Region.getRegion(Regions.US_EAST_1));
    return client;
  }
}
