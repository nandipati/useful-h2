package io.hmheng.streaming.spark;

import com.amazonaws.services.kinesis.AmazonKinesisClient;
import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.kinesis.model.ListStreamsResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Created by fodori on 1/27/17.
 */
@Configuration
@Profile("test")
public class TestKinesisConfiguration {

  public static final Logger LOGGER = LoggerFactory.getLogger(TestKinesisConfiguration.class);

  @Value("${aws.kinesis.endpoint}")
  private String kinesisEndpoint;

  @Value("${aws.kinesis.app.stream}")
  private String kinesisAppStream;

  @Bean
  public AmazonKinesisClient kinesisClient() throws InterruptedException {
    AmazonKinesisClient client = new AmazonKinesisClient();
    client.setEndpoint("http://localhost:4567");

    LOGGER.info("Creating test stream");
    createStream(client, kinesisAppStream);
    return client;
  }

  protected void createStream(AmazonKinesisClient client, String streamName) throws InterruptedException {
    ListStreamsResult listStreamsResult = client.listStreams();
    if (!listStreamsResult.getStreamNames().contains(streamName)) {
      client.createStream(streamName, 10);
    }
    DescribeStreamResult stream1 = client.describeStream(streamName);
    String streamStatus = stream1.getStreamDescription().getStreamStatus();
    if (!streamStatus.equals("ACTIVE")) {
      do {
        LOGGER.info("Stream {} is not ready, status is {}, .. waiting", streamName, streamStatus);
        Thread.sleep(100l);
      } while (! (streamStatus = client.describeStream(streamName).getStreamDescription().getStreamStatus()).equals
          ("ACTIVE"));
    }
    LOGGER.info("Stream {} ready!", streamName);
  }
}
