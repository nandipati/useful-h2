package io.hmheng.streaming.spark;

import com.amazonaws.SDKGlobalConfiguration;
import com.amazonaws.services.kinesis.AmazonKinesisClient;
import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.kinesis.model.GetRecordsRequest;
import com.amazonaws.services.kinesis.model.GetRecordsResult;
import com.amazonaws.services.kinesis.model.GetShardIteratorRequest;
import com.amazonaws.services.kinesis.model.ListStreamsResult;
import com.amazonaws.services.kinesis.model.PutRecordRequest;
import com.amazonaws.services.kinesis.model.PutRecordResult;
import com.amazonaws.services.kinesis.model.Shard;
import com.amazonaws.services.kinesis.model.ShardIteratorType;
import com.github.klousiaj.junit.DockerRule;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SparkStreamAppTest {

  public static final String STREAM_NAME = "test-stream";
  public static final Logger LOGGER = LoggerFactory.getLogger(SparkStreamAppTest.class);

  @Autowired
  public AmazonKinesisClient kinesisClient;

  @BeforeClass
  public static void setEnv() {
    System.setProperty(SDKGlobalConfiguration.AWS_CBOR_DISABLE_SYSTEM_PROPERTY, "true");
    if (System.getProperty("os.name").contains("OS X")) {
      System.setProperty("os.name", System.getProperty("os.name") + " linux ");
    }
  }

  /*
   * If Unit test throws error, it is possible that the docker instance is left running.
   * To clean up the running instance run the following on the® command line:
   *
   * docker kill $(docker ps | grep kinesalite | awk '{print $1}')
   */
  @ClassRule
  public static DockerRule kinesisRule = DockerRule.builder().image("relateiq/kinesalite:latest").ports("4567:4567")
      .cleanVolumes(true).leaveRunning(false).waitForPort("4567/tcp").waitForLog(null).build();

  @ClassRule
  public static DockerRule dynamodbRule = DockerRule.builder().image("ka2n/dynalite:latest").ports("4566:4567")
      .cleanVolumes(true).leaveRunning(false).waitForPort("4567/tcp").waitForLog(null).build();



  @Test
  public void test() throws InterruptedException {
    AmazonKinesisClient client = createClient();
    createStream(client, STREAM_NAME);

    //DescribeLimitsResult describeLimitsResult = client.describeLimits(new DescribeLimitsRequest());

    for (int i = 0; i < 20; i++) {
      PutRecordResult putRecordResult = putRecord(client, String.valueOf(i % 5), "HelloWorld-" + i);
      LOGGER.info("Sent message to shard {} with sequence# {}", putRecordResult.getShardId(),
          putRecordResult.getSequenceNumber());
    }
    Thread.sleep(1000l);
    consumeMessages(client, STREAM_NAME);

  }

  protected List<Shard> getShards(AmazonKinesisClient client, String streamName) {
    DescribeStreamResult describeStreamResult = client.describeStream(streamName);
    List<Shard> shards = new ArrayList<>(describeStreamResult.getStreamDescription().getShards());
    while (describeStreamResult.getStreamDescription().getHasMoreShards()) {
      describeStreamResult = client.describeStream(streamName, 10, shards.get(shards.size() - 1).getShardId());
      shards.addAll(describeStreamResult.getStreamDescription().getShards());
    }
    return shards;
  }

  protected void consumeMessages(AmazonKinesisClient client, String streamName) {
    List<Shard> shards = getShards(client, streamName);
    for (Shard shard : shards) {
      GetShardIteratorRequest request = new GetShardIteratorRequest().withShardId(shard.getShardId())
          .withShardIteratorType(ShardIteratorType.TRIM_HORIZON).withStreamName(streamName);
      String shardIterator = client.getShardIterator(request).getShardIterator();
      GetRecordsResult getRecordsResult = null;

      do {
        GetRecordsRequest getRecordsRequest = new GetRecordsRequest().withShardIterator(shardIterator).withLimit(2);
        getRecordsResult = client.getRecords(getRecordsRequest);
        shardIterator = getRecordsResult.getNextShardIterator();
        String concatenatedMessages = getRecordsResult.getRecords().stream().map(m -> new String(m.getData().array()))
            .collect(Collectors.joining(","));
        LOGGER.info("Got messages {} from shard {}",
            concatenatedMessages, shard.getShardId());
        Assert.assertThat(concatenatedMessages, new BaseMatcher<String>() {
          @Override
          public void describeTo(Description description) {
            description.appendValue("Regex match of message");
          }

          @Override
          public boolean matches(Object _item) {
            String item = (String) _item;
            return (item == null) || item.matches("(HelloWorld-\\d+,?)*");
          }



        });


      } while (getRecordsResult.getRecords().size() > 0);
    }

  }

  protected AmazonKinesisClient createClient() {
    AmazonKinesisClient client = new AmazonKinesisClient();
    client.setEndpoint("http://localhost:4567");
    return client;
  }

  protected PutRecordResult putRecord(AmazonKinesisClient client, String shardId, String message) {
    PutRecordRequest pr = new PutRecordRequest();
    pr.setStreamName(STREAM_NAME);
    pr.setData(ByteBuffer.wrap(message.getBytes()));
    pr.setPartitionKey(shardId);
    return client.putRecord(pr);
  }

  protected void createStream(AmazonKinesisClient client, String streamName) throws InterruptedException {
    ListStreamsResult listStreamsResult = client.listStreams();
    if (!listStreamsResult.getStreamNames().contains(streamName)) {
      client.createStream(streamName, 10);
    }
    DescribeStreamResult stream1 = client.describeStream(streamName);
    String streamStatus = stream1.getStreamDescription().getStreamStatus();
    if (!streamStatus.equals("ACTIVE")) {
      do {
        LOGGER.info("Stream {} is not ready, status is {}, .. waiting", streamName);
        Thread.sleep(100l);
      } while (!client.describeStream(streamName).getStreamDescription().getStreamStatus().equals("ACTIVE"));
    }
    LOGGER.info("Stream {} ready!", streamName);
  }


}
