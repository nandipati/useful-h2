-- session_id - b2a48303-9703-c8f8-e62c-be96184e40c9
-- activity_id - 7c98cfa3-f2ea-5a91-09c5-0e8cf65e9716

-- making sure the newly created items are removed


delete from student_score where session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9';

commit;

delete from activity_item_score where activity_refid in (select activity_refid from student_session where session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9');
delete from activity_item_score where refid >= 9000000000000000000;

delete from student_question where student_item_refid in (select refid from student_item where session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9');
delete from student_question where refid >= 9000000000000000000;

delete from student_item where session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9';
delete from student_item where refid >= 9000000000000000000;

delete from student_session where session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9';
delete from activity where activity_refid in ('7c98cfa3-f2ea-5a91-09c5-0e8cf65e9716');
delete from item where item_reference in ('0e37df36-f698-11e6-8dd4-cb9ced3df976', 'a81bc81b-dead-4e5d-abff-90865d1e13b1');
delete from score where score_reference in ('0e37df36-f698-11e6-8dd4-cb9ced3df976', 'a81bc81b-dead-4e5d-abff-90865d1e13b1');
delete from question where question_reference in ('0e37df36-f698-11e6-8dd4-cb9ced3df976', 'a81bc81b-dead-4e5d-abff-90865d1e13b1');

commit;

-- switch back to the official sequences
alter table activity_item_score alter column refid set default nextval('activity_item_score_refid_seq');
alter table student_item alter column refid set default nextval('student_item_refid_seq');
alter table student_question alter column refid set default nextval('student_question_refid_seq');

-- drop the testing sequences
drop sequence if exists test_activity_item_score_refid_seq;
drop sequence if exists test_student_item_refid_seq;
drop sequence if exists test_student_question_refid_seq;

-- restoring sequence numbers to the current max + 1

-- select setval('activity_item_score_refid_seq', (select max(refid) + 1 from activity_item_score), false);
-- select setval('student_item_refid_seq', (select max(refid) + 1 from student_item), false);
-- select setval('student_question_refid_seq', (select max(refid) + 1 from student_question), false);

commit;