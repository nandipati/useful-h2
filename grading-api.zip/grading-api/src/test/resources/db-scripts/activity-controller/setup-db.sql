-- session_id - b2a48303-9703-c8f8-e62c-be96184e40c9
-- activity_id - 7c98cfa3-f2ea-5a91-09c5-0e8cf65e9716

-- SELECT setval('activity_item_score_refid_seq', 9000000000000000000, false);
-- SELECT setval('student_item_refid_seq', 9000000000000000000, false);
-- SELECT setval('student_question_refid_seq', 9000000000000000000, false);
drop sequence if exists test_activity_item_score_refid_seq;
create sequence test_activity_item_score_refid_seq;
SELECT setval('test_activity_item_score_refid_seq', 9000000000000000000, false);
drop sequence if exists test_student_item_refid_seq;
create sequence test_student_item_refid_seq;
SELECT setval('test_student_item_refid_seq', 9000000000000000000, false);
drop sequence if exists test_student_question_refid_seq;
create sequence test_student_question_refid_seq;
SELECT setval('test_student_question_refid_seq', 9000000000000000000, false);

alter table activity_item_score alter column refid set default nextval('test_activity_item_score_refid_seq');
alter table student_item alter column refid set default nextval('test_student_item_refid_seq');
alter table student_question alter column refid set default nextval('test_student_question_refid_seq');

commit;

INSERT INTO activity
(
  activity_refid,
  teacher_assignment_refid,
  staff_personal_refid,
  num_questions,
  max_score,
  max_time,
  created_at,
  updated_at,
  activity_template_id
)
VALUES
(
  '7c98cfa3-f2ea-5a91-09c5-0e8cf65e9716',
  'c2a94e0f-9da5-405d-adef-86acf70dfd38',
  'c2a94e0f-9da5-405d-adef-86acf70dfd38',
  220,
  230,
  120,
  TIMESTAMP '2017-05-16 15:53:38.364',
  TIMESTAMP '2017-10-29 09:04:26.097',
  NULL
);

INSERT INTO score
(
   score_reference,
   automarkable,
   correct_response,
   created_at,
   updated_at,
   title,
   description,
   type,
   error_message
)
VALUES
(
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  false,
  '13',
  '2017-05-16 20:58:50',
  '2017-05-16 20:58:50',
  'Fake score for testing',
  'Fake score for testing',
  '',
  ''
);


INSERT INTO item(
   item_reference,
   organisation_id,
   item_pool_id,
   type,
   created_at,
   updated_at
)
VALUES
(
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  22,
  'Fake Item for testing',
  'array',
  '2017-05-16 20:58:50',
  '2017-05-16 20:58:50'
);

INSERT INTO item(
   item_reference,
   organisation_id,
   item_pool_id,
   type,
   created_at,
   updated_at
)
VALUES
(
  'a81bc81b-dead-4e5d-abff-90865d1e13b1',
  22,
  'Fake Item for testing',
  'array',
  '2017-05-16 20:58:50',
  '2017-05-16 20:58:50'
);

INSERT INTO question
(
   question_reference,
   rubric_reference,
   question_type,
   created_at,
   updated_at ,
   automarkable ,
   error_message
)
VALUES
 (
   '0e37df36-f698-11e6-8dd4-cb9ced3df976',
   'TU-6322',
   'mcq',
   '2017-05-16 20:58:50',
   '2017-05-16 20:58:50',
   true,
   ''
 );

INSERT INTO question
(
   question_reference,
   rubric_reference,
   question_type,
   created_at,
   updated_at ,
   automarkable ,
   error_message
)
VALUES
 (
   'a81bc81b-dead-4e5d-abff-90865d1e13b1',
   'TU-6322',
   'mcq',
   '2017-05-16 20:58:50',
   '2017-05-16 20:58:50',
   true,
   ''
 );

INSERT INTO activity_item_score
(
  activity_refid,
  item_reference,
  score_reference,
  max_score,
  weight,
  created_at,
  updated_at,
  question_reference
)
VALUES
(
  '7c98cfa3-f2ea-5a91-09c5-0e8cf65e9716',
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  10,
  10,
  TIMESTAMP '2017-05-16 16:08:45.648',
  TIMESTAMP '2017-05-16 16:08:45.648',
  NULL
);




INSERT INTO student_session
(
  session_refid,
  activity_refid,
  student_personal_refid,
  num_attempted,
  score,
  session_duration,
  status,
  dt_started,
  dt_completed,
  user_agent,
  created_at,
  updated_at,
  scoring_stream_seq,
  scoring_push_dt,
  status_stream_seq,
  status_push_dt
)
VALUES
(
  'b2a48303-9703-c8f8-e62c-be96184e40c9',
  '7c98cfa3-f2ea-5a91-09c5-0e8cf65e9716',
  'c12605b6-aac8-4abd-be2b-3407a46bbb43',
  20,
  240,
  3330,
  '3',
  TIMESTAMP '2017-05-15 12:57:58.860',
  TIMESTAMP '2017-05-15 12:57:58.860',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.100 Safari/537.36',
  TIMESTAMP '2017-05-16 15:53:38.373',
  TIMESTAMP '2017-10-29 09:04:26.036',
  '49567549007104038271951493646128120617229268841857548290',
  TIMESTAMP '2017-10-29 09:04:24.819',
  NULL,
  NULL
);

INSERT INTO student_item
(
  session_refid,
  item_reference,
  TIME,
  max_score,
  user_flagged,
  created_at,
  updated_at
)
VALUES
(
  'b2a48303-9703-c8f8-e62c-be96184e40c9',
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  2220,
  320,
  TRUE,
  TIMESTAMP '2017-05-16 15:53:38.374',
  TIMESTAMP '2017-05-16 15:53:38.385'
);


INSERT INTO student_item
(
  session_refid,
  item_reference,
  TIME,
  max_score,
  user_flagged,
  created_at,
  updated_at
)
VALUES
(
  'b2a48303-9703-c8f8-e62c-be96184e40c9',
  'a81bc81b-dead-4e5d-abff-90865d1e13b1',
  2220,
  20,
  TRUE,
  TIMESTAMP '2017-05-16 16:08:45.656',
  TIMESTAMP '2017-05-16 16:08:45.665'
);

commit;

INSERT INTO student_question
(
  student_item_refid,
  question_reference,
  actual_response,
  created_at,
  updated_at,
  response_id
)
select
  si.refid,
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  '76882f3e-a71f-4662-91c6-2097afeedd89_fa090e85f05c32afb10db91335865c20',
  TIMESTAMP '2017-05-16 13:59:04.761',
  TIMESTAMP '2017-05-16 13:59:04.765',
  NULL
from student_item si
where si.session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9'
and si.item_reference = '0e37df36-f698-11e6-8dd4-cb9ced3df976';


INSERT INTO student_question
(
  student_item_refid,
  question_reference,
  actual_response,
  created_at,
  updated_at,
  response_id
)
select
  si.refid,
  'a81bc81b-dead-4e5d-abff-90865d1e13b1',
  '9ed5e97e-57f3-4f53-addb-46cfa45129bc_a11e40a9c0ccbd033337740046a8e8f3',
  TIMESTAMP '2017-05-16 13:59:19.343',
  TIMESTAMP '2017-05-16 13:59:19.349',
  NULL
from student_item si
where si.session_refid = 'b2a48303-9703-c8f8-e62c-be96184e40c9'
and si.item_reference = 'a81bc81b-dead-4e5d-abff-90865d1e13b1';


INSERT INTO student_score
(
  response_id,
  session_refid,
  student_item_refid,
  student_question_refid,
  score_reference,
  staff_personal_refid,
  attemted,
  value,
  weight,
  max_score,
  score,
  created_at,
  updated_at
)
VALUES
(
  'b2a48303-9703-c8f8-e62c-be96184e40c9_d275055d-2648-5917-be03-05253d583373',
  'b2a48303-9703-c8f8-e62c-be96184e40c9',
  9000000000000000000,
  9000000000000000000,
  '0e37df36-f698-11e6-8dd4-cb9ced3df976',
  'd4a94e0f-9da5-405d-adef-86acf70dfd38',
  TRUE,
  '1',
  240,
  230,
  240,
  TIMESTAMP '2017-05-16 16:08:45.665',
  TIMESTAMP '2017-05-16 16:08:45.665'
);

commit;

