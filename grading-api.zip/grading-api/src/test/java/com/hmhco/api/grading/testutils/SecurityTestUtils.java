package com.hmhco.api.grading.testutils;

import com.hmhco.api.grading.security.GradingUser;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

public class SecurityTestUtils {

    public static void authenticateAs(GradingUser user) {
        SecurityContextHolder.getContext()
                .setAuthentication(new PreAuthenticatedAuthenticationToken(user, user.getPassword(), user.getAuthorities()));
    }

    public static void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    public static GradingUser createUser(String id, List<String> grants) {
        return new GradingUser(id, grants.stream().map(grant -> new SimpleGrantedAuthority(grant)).collect(Collectors.toList()));
    }
}
