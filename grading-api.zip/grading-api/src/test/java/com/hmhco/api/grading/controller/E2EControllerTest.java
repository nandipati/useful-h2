package com.hmhco.api.grading.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hmhco.api.grading.testutils.AuthenticateAs;
import com.hmhco.api.grading.testutils.AuthenticationRule;
import com.hmhco.api.grading.views.SessionWrapper;
import com.hmhco.api.grading.views.postresponse.PushScoreStatus;
import io.hmheng.grading.streams.kinesis.KinesisStreamDataService;
import io.hmheng.grading.streams.kinesis.model.KinesisPutRecordResult;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class E2EControllerTest extends RestControllerTest {
  private static String version = "1";

  @Rule
  public AuthenticationRule authenticationRule = new AuthenticationRule();

  @Configuration
  static class Config {
    @Bean
    @Primary
    public KinesisStreamDataService kinesisStreamDataService() {
      kinesisStreamDataService = Mockito.mock(KinesisStreamDataService.class);
      return kinesisStreamDataService;
    }
  }

  private static KinesisStreamDataService kinesisStreamDataService;

  public E2EControllerTest()
  {
    setupDBScripts("classpath:db-scripts/activity-controller/setup-db.sql", "classpath:db-scripts/activity-controller/cleanup-db.sql");
  }


  @Before
  public void initMocks(){
    MockitoAnnotations.initMocks(this);

    // make sure the kenesis stream service is not actually pushing the result to AWS
    when(kinesisStreamDataService.pushToStream(any(), any())).thenReturn(new KinesisPutRecordResult());
  }

  @Test
  @AuthenticateAs(AuthenticateAs.AuthType.TRUSTED_API)
  public void testPushScoreBySessionIds() throws Exception {

    SessionWrapper wrapper = new SessionWrapper();
    wrapper.setSessionIds(new ArrayList<UUID>());
    wrapper.getSessionIds().add(UUID.fromString("b2a48303-9703-c8f8-e62c-be96184e40c9"));
    wrapper.getSessionIds().add(UUID.fromString("6099f039-4ff1-ce74-69b9-37f9b7a87653"));

    //TODO comment out for now to make build, will mock the kenesis stream integration soon
    MvcResult result = mockMvc.perform(post("/v{version}/activities/pushScores",version)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(wrapper)))
            .andDo(print())
            .andExpect(status().isOk())
            .andReturn();

    List<PushScoreStatus> list = objectMapper.readValue(result.getResponse().getContentAsString(), new TypeReference<List<PushScoreStatus>>(){});
    assertTrue(list.stream().anyMatch(item -> "b2a48303-9703-c8f8-e62c-be96184e40c9".equals(item.getSessionId().toString()) && item.getMessage().contains("successful")) );
    assertTrue(list.stream().anyMatch(item -> "6099f039-4ff1-ce74-69b9-37f9b7a87653".equals(item.getSessionId().toString()) && item.getMessage().contains("not found")) );

  }

}
