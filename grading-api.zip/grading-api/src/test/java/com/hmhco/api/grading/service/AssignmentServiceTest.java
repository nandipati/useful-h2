package com.hmhco.api.grading.service;

import com.hmhco.api.grading.dao.readonly.ItemViewEntityRepository;
import com.hmhco.api.grading.entities.readonly.ItemViewEntity;
import com.hmhco.api.grading.entities.readonly.ItemViewId;
import com.hmhco.api.grading.mapper.viewmapper.ActivityItemsViewMapper;
import com.hmhco.api.grading.service.AssignmentService;
import com.hmhco.api.grading.service.AssignmentServiceImpl;
import com.hmhco.api.grading.testutils.TestUtils;
import com.hmhco.api.grading.views.ActivityItemsView;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by tallurir on 9/20/17.
 */
public class AssignmentServiceTest {
    UUID activityRefId;

    @Rule
    public MockitoRule mocitoRule = MockitoJUnit.rule();

    @InjectMocks
    private AssignmentService assignmentService = new AssignmentServiceImpl();
    @Mock
    private ItemViewEntityRepository itemViewEntityRepository;

    private ActivityItemsViewMapper activityMapper = TestUtils.configureActivityItemsViewMapper();
    private ActivityItemsView response;


    @Before
    public void setUp() {
        activityRefId = UUID.randomUUID();
        Boolean manualScoredRequired = true;
        ReflectionTestUtils.setField(assignmentService, "activityItemsViewMapper", activityMapper);
        when(itemViewEntityRepository.findByActivityRefId(any())).thenReturn(getItemViewEntityList());

    }

    @Test
    public void testItemsByActivityId() {

        response = assignmentService.getItemsByActivityId(activityRefId, true);
        assertNotNull(response);



    }


    public List<ItemViewEntity> getItemViewEntityList() {

        List<ItemViewEntity> entityList = new ArrayList<ItemViewEntity>();

        entityList.add(getItemViewEntity());

        return entityList;

    }

    private ItemViewEntity getItemViewEntity() {

        ItemViewId itemViewId = new ItemViewId();
        itemViewId.setItemReference("test");
        itemViewId.setQuestionReference("test");
        itemViewId.setScoreReference("test");

        ItemViewEntity viewentity = new ItemViewEntity();
        viewentity.setId(itemViewId);
        viewentity.setActivityRefId(activityRefId);
        viewentity.setNumQuestions(10);
        viewentity.setDescription("math");
        viewentity.setCorrectResponse("");
        viewentity.setMaxScore(10);
        viewentity.setMaxTime(100);
        viewentity.setRubricReference("tem-1987");
        viewentity.setQuestionAutomarkable(true);



        return viewentity;
    }




}
