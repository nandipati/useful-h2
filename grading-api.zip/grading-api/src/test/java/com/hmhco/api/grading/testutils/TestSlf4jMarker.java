package com.hmhco.api.grading.testutils;

import io.hmheng.grading.utils.Slf4jLogType;
import io.hmheng.grading.utils.Slf4jUtils;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jayachandranj on 12/14/17.
 */
public class TestSlf4jMarker {

    @Test(expected = ClassCastException.class)
    public void testMarkerwithlong() throws Exception{
        long difference = getTimeDifference();
                Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MARKER, "difference",difference);
  }

    @Test
    public void testMarkerwithMap() throws Exception{
        long difference = getTimeDifference();
        Map<String, Object> map = new HashMap<>();
        map.put("difference",difference);
        Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MARKER, "difference",map);
    }

    private long getTimeDifference(){
        String time1 = "16:00:00";
        String time2 = "19:00:00";
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        Date date1 = null;
        Date date2 = null;
        try {
            date1 = format.parse(time1);
            date2 = format.parse(time2);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long difference = date2.getTime() - date1.getTime();
        return difference;

    }
}
