package com.hmhco.api.grading.testutils;

import java.util.UUID;
import javax.ws.rs.BadRequestException;
import org.apache.commons.lang3.StringUtils;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

public class AuthenticationRule extends TestWatcher {

    protected void starting(Description description) {
        AuthenticateAs auth = description.getAnnotation(AuthenticateAs.class);
        if (auth == null) {
            return;
        }

        AuthenticateAs.AuthType authType = auth.value();
        GradingUserBuilder userBuilder;

        switch (authType) {
            case STUDENT: {
                userBuilder = GradingUserBuilder.student();
                break;
            }

            case TEACHER: {
                userBuilder = GradingUserBuilder.teacher();
                break;
            }

            case DISTRICT_ADMIN: {
                userBuilder = GradingUserBuilder.districtAdmin();
                break;
            }

            case SCHOOL_ADMIN: {
                userBuilder = GradingUserBuilder.schoolAdmin();
                break;
            }

            case TRUSTED_API: {
                userBuilder = GradingUserBuilder.trustedApi();
                break;
            }

            default: {
                throw new BadRequestException();
            }
        }

        if (!StringUtils.isBlank(auth.userId())) {
            userBuilder.withUserId(UUID.fromString(auth.userId()));
        }
        if (!StringUtils.isBlank(auth.leaRefId())) {
            userBuilder.withLeaRefId(UUID.fromString(auth.leaRefId()));
        }
        if (!StringUtils.isBlank(auth.schoolRefId())) {
            userBuilder.withSchoolRefId(UUID.fromString(auth.schoolRefId()));
        }


        SecurityTestUtils.authenticateAs(userBuilder.build());
    }

    @Override
    protected void finished(Description description) {
        SecurityTestUtils.clearSecurityContext();
    }
}
