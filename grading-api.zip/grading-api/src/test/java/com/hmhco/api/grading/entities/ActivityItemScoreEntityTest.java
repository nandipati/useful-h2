package com.hmhco.api.grading.entities;

import com.hmhco.api.grading.testutils.GenericBeanCoverage;
import org.junit.Test;

/**
 * Created by srikanthk on 4/28/17.
 */
public class ActivityItemScoreEntityTest {

    @Test
    public void testBean ()throws Exception{

        GenericBeanCoverage.doBeanCodeCoverage(ActivityItemScoreEntity.class);

    }

}
