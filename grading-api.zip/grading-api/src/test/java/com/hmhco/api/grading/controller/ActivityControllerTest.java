package com.hmhco.api.grading.controller;

import com.hmhco.api.grading.testutils.AuthenticateAs;
import com.hmhco.api.grading.testutils.AuthenticationRule;
import com.hmhco.api.grading.testutils.StudentSessionViewBuilder;
import com.hmhco.api.grading.service.StudentSessionService;
import com.hmhco.api.grading.service.action.SaveStudentSessionRequest;
import com.hmhco.api.grading.service.action.SaveStudentSessionResponse;
import com.hmhco.api.grading.views.SessionWrapper;
import com.hmhco.api.grading.views.StudentActivitySessionView;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MvcResult;


import java.util.ArrayList;
import java.util.UUID;


import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.Matchers.any;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by srikanthk on 4/28/17.
 */
public class ActivityControllerTest  extends RestControllerTest{


    private MockHttpSession session = new MockHttpSession();


    @Autowired
    private StudentSessionService studentSessionService;

    @Rule
    public AuthenticationRule authenticationRule = new AuthenticationRule();

    public ActivityControllerTest() {
        setupDBScripts("classpath:db-scripts/activity-controller/setup-db.sql", "classpath:db-scripts/activity-controller/cleanup-db.sql");
    }

    //@Test
    //@AuthenticateAs(AuthenticateAs.AuthType.TRUSTED_API)
    public void testStudentSession() throws Exception{

        UUID sessionId = UUID.randomUUID();
        UUID activityID = UUID.randomUUID();

        StudentSessionViewBuilder studentSessionView = new StudentSessionViewBuilder();

        StudentActivitySessionView studentActivitySessionView = studentSessionView.withAll(activityID).build().getStudentActivitySessionView();

        try {
          when(studentSessionService.getOrCreateStudentSession(any(SaveStudentSessionRequest.class)))
              .thenReturn(new SaveStudentSessionResponse(studentActivitySessionView));
        }catch (Exception ex){

        }

        mockMvc.perform(post("/v1/activities/{sessionId}/init",sessionId)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(studentActivitySessionView)))
                .andDo(print())
                .andExpect(status().is5xxServerError()
                );


    }

    @Test
    @AuthenticateAs(AuthenticateAs.AuthType.TEACHER)
    public void testGetStudentActivityItems() throws Exception{


        SessionWrapper wrapper = new SessionWrapper();
        wrapper.setSessionIds(new ArrayList<UUID>());
        wrapper.getSessionIds().add(UUID.fromString("b2a48303-9703-c8f8-e62c-be96184e40c9"));  // fake data
        MvcResult result = mockMvc.perform(get("/v1/activities/{sessionId}/items","b2a48303-9703-c8f8-e62c-be96184e40c9")

                .contentType("application/hal+json").content(objectMapper.writeValueAsString(wrapper)))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        String response  =result.getResponse().getContentAsString();

        assertTrue(response!= null);
        assertTrue(!response.isEmpty());
        assertTrue(response.contains("\"sessionId\":\"b2a48303-9703-c8f8-e62c-be96184e40c9\""));
        assertTrue(response.contains("\"questions\":null"));



    }

    @Test
    @AuthenticateAs(AuthenticateAs.AuthType.TEACHER)
    public void testGetStudentActivityItemsWithIncludeQuestionsAndScores() throws Exception{


        SessionWrapper wrapper = new SessionWrapper();
        wrapper.setSessionIds(new ArrayList<UUID>());
        wrapper.getSessionIds().add(UUID.fromString("b2a48303-9703-c8f8-e62c-be96184e40c9"));  // fake data
        MvcResult result = mockMvc.perform(get("/v1/activities/{sessionId}/items?includeQuestionsAndScores=true","b2a48303-9703-c8f8-e62c-be96184e40c9")

                .contentType("application/hal+json").content(objectMapper.writeValueAsString(wrapper)))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        String response  =result.getResponse().getContentAsString();

        assertTrue(response!= null);
        assertTrue(!response.isEmpty());
        assertTrue(response.contains("\"sessionId\":\"b2a48303-9703-c8f8-e62c-be96184e40c9\""));
        assertTrue(response.contains("\"questionReference\":\"0e37df36-f698-11e6-8dd4-cb9ced3df976\""));
    }


}
