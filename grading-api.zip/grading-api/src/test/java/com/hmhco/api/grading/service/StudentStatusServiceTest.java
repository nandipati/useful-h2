package com.hmhco.api.grading.service;

import com.hmhco.api.grading.dao.readwrite.StudentSessionEntityRepository;
import com.hmhco.api.grading.entities.StudentSessionEntity;
import com.hmhco.api.grading.views.SessionStatusView;
import com.hmhco.api.grading.views.getresponse.ScoringCompleteResponse;
import io.hmheng.grading.utils.StudentAssignmentStatus;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by jayachandranj on 12/14/17.
 */
public class StudentStatusServiceTest {

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Mock
    private StudentSessionEntityRepository studentSessionEntityRepository;

    @InjectMocks
    private StudentSessionServiceImpl studentSessionService = new StudentSessionServiceImpl();

    private UUID sessionId;

    private ScoringCompleteResponse scoringCompleteResponse;


    private SessionStatusView sessionStatusViewResponse;

    @Mock
    private StudentSessionEntity studentSessionEntityResponse;

    private LocalDateTime gradeStartTime;
    private LocalDateTime gradeStartTimeUpdated;

    @Before
    public void setUp() {
        gradeStartTime =LocalDateTime.now();
        sessionId = UUID.fromString("d122e8e2-04f9-4e62-abeb-4d6d30604a2b");
        studentSessionEntityResponse.setSessionRefId(sessionId);
        studentSessionEntityResponse.setStatus(StudentAssignmentStatus.READY_FOR_SCORING);
        studentSessionEntityResponse.setStudentPersonalRefId(UUID.randomUUID());
        gradeStartTimeUpdated =LocalDateTime.now();

        when(studentSessionEntityRepository.findBySessionRefId(sessionId)).thenReturn(getStudentSessionEntityResult());


    }
    private StudentSessionEntity getStudentSessionEntityResult(){
        StudentSessionEntity studentSessionEntity = new StudentSessionEntity();
        studentSessionEntity.setSessionRefId(sessionId);
        studentSessionEntity.setStatus(StudentAssignmentStatus.READY_FOR_SCORING);
        studentSessionEntity.setStudentPersonalRefId(UUID.randomUUID());
        return studentSessionEntity;
    }

    private SessionStatusView getSessionStatusView(){
        SessionStatusView sessionStatusView =new SessionStatusView();
        sessionStatusView.setSessionId(sessionId);
        sessionStatusView.setStatus(StudentAssignmentStatus.READY_FOR_SCORING);
        sessionStatusView.setStudentPersonalRefId(UUID.randomUUID());
        return sessionStatusView;
    }

    @Test
    public void testUpdateSessionStatus() {

        studentSessionEntityResponse=studentSessionEntityRepository.findBySessionRefId(sessionId);
        StudentAssignmentStatus dbStatus=StudentAssignmentStatus.READY_FOR_SCORING;
        StudentAssignmentStatus viewStatus=StudentAssignmentStatus.SCORING_IN_PROGRESS;
        if(StudentAssignmentStatus.SCORING_COMPLETED != dbStatus
                && (StudentAssignmentStatus.SCORING_IN_PROGRESS == viewStatus
                || StudentAssignmentStatus.READY_FOR_SCORING == viewStatus)){
            studentSessionEntityResponse.setDateGradeStartTime(gradeStartTime);
            studentSessionEntityResponse.setUpdatedGradeStartTime(gradeStartTimeUpdated);
        }

        assertThat(studentSessionEntityResponse.getDateGradeStartTime()).isEqualTo(gradeStartTime);
        assertThat(studentSessionEntityResponse.getUpdatedGradeStartTime()).isAfterOrEqualTo(gradeStartTime);

        assertThat(studentSessionEntityResponse.getUpdatedGradeStartTime()).isNotNull();

    }

    @Test
    public void testCompletedSessionStatus() {

        studentSessionEntityResponse=studentSessionEntityRepository.findBySessionRefId(sessionId);
        StudentAssignmentStatus dbStatus=StudentAssignmentStatus.SCORING_COMPLETED;
        StudentAssignmentStatus viewStatus=StudentAssignmentStatus.SCORING_IN_PROGRESS;
        if(StudentAssignmentStatus.SCORING_COMPLETED != dbStatus
                && (StudentAssignmentStatus.SCORING_IN_PROGRESS == viewStatus
                || StudentAssignmentStatus.READY_FOR_SCORING == viewStatus)){
            studentSessionEntityResponse.setDateGradeStartTime(gradeStartTime);
        }
        assertThat(studentSessionEntityResponse.getDateGradeStartTime()).isNull();
        assertThat(studentSessionEntityResponse.getUpdatedGradeStartTime()).isNull();
        assertThat(studentSessionEntityResponse.getDateGradeStartTime()).isNotEqualTo(gradeStartTime);

    }

}
