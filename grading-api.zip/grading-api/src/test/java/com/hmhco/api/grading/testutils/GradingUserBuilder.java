package com.hmhco.api.grading.testutils;

import com.hmhco.api.grading.security.GradingUser;
import com.hmhco.api.grading.security.RoleConverter;
import java.util.Arrays;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.security.core.authority.SimpleGrantedAuthority;


public class GradingUserBuilder {

    private UUID userId;
    private UUID leaRefId;
    private UUID schoolRefId;
    private String[] roles;

    public GradingUser build() {
        GradingUser reportingUser = new GradingUser(userId.toString(),
                Arrays.stream(roles).map(SimpleGrantedAuthority::new).collect(Collectors.toList()));

        reportingUser.setUserGuid(userId);
        reportingUser.setLeaRefId(leaRefId);
        reportingUser.setSchoolRefId(schoolRefId);
        return reportingUser;
    }

    public static GradingUserBuilder districtAdmin() {
        return user(randomId(), randomId(), null, RoleConverter.ROLE_ADMINISTRATOR);
    }

    public static GradingUserBuilder districtAdmin(UUID district) {
        return user(randomId(), district, null, RoleConverter.ROLE_ADMINISTRATOR);
    }

    public static GradingUserBuilder schoolAdmin() {
        return user(randomId(), randomId(), randomId(), RoleConverter.ROLE_ADMINISTRATOR);
    }

    public static GradingUserBuilder student() {
        return user(randomId(), randomId(), randomId(), RoleConverter.ROLE_STUDENT);
    }

    public static GradingUserBuilder teacher() {
        return user(randomId(), randomId(), randomId(), RoleConverter.ROLE_TEACHER);
    }

    public static GradingUserBuilder trustedApi() {
        return user(randomId(), randomId(), randomId(), RoleConverter.ROLE_TRUSTED_API);
    }

    public GradingUserBuilder withUserId(UUID userId) {
        this.userId = userId;
        return this;
    }

    public GradingUserBuilder withLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
        return this;
    }

    public GradingUserBuilder withSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
        return this;
    }

    public GradingUserBuilder withRoles(String... roles) {
        this.roles = roles;
        return this;
    }

    private GradingUserBuilder createUser(UUID userId, UUID leaRefId, UUID schoolRefId, String... roles) {
        this.userId = userId;
        this.leaRefId = leaRefId;
        this.schoolRefId = schoolRefId;
        this.roles = roles;
        return this;
    }

    private static GradingUserBuilder user(UUID userId, UUID leaRefId, UUID schoolRefId, String... roles) {
        return new GradingUserBuilder().createUser(userId, leaRefId, schoolRefId, roles);
    }

    private static UUID randomId() {
        return UUID.randomUUID();
    }
}
