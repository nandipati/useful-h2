package com.hmhco.api.grading.testutils;

import org.junit.Test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Created by jayachandranj on 12/19/17.
 */
public class TestTimeUtils {

    @Test
    public void testTimeDifferenceInMillis() throws Exception{
        LocalDateTime startTime = LocalDateTime.now();
        Thread.sleep(100);
        LocalDateTime endTime = LocalDateTime.now();
        long timeInMills = ChronoUnit.MILLIS.between(startTime,endTime);
        assertTrue("TimeDifference is non-negative",timeInMills>=0);

        timeInMills = ChronoUnit.MILLIS.between(endTime,startTime);
        assertFalse("TimeDifference is negative",timeInMills>=0);

    }
    @Test
    public void testTimeDifferenceInSecs() throws Exception{
        LocalDateTime startTime = LocalDateTime.now();
        Thread.sleep(1000);
        LocalDateTime endTime = LocalDateTime.now();
        long timeInMills = ChronoUnit.SECONDS.between(startTime,endTime);
        assertTrue("TimeDifference is non-negative",timeInMills>=0);

        timeInMills = ChronoUnit.SECONDS.between(endTime,startTime);
        assertFalse("TimeDifference is negative",timeInMills>=0);
    }
}
