alter table public.SCORE ALTER COLUMN TYPE type VARCHAR(16)
