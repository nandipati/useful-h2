alter table public.activity ADD COLUMN source_type VARCHAR(16);

update public.activity set assignment_type = 'PROGRAM',source_type='ED';
