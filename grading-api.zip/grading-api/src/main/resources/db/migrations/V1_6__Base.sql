
alter table public.question add column automarkable boolean;

alter table public.student_question add column response_id character varying(150);

