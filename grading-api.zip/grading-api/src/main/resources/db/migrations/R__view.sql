DROP  VIEW IF EXISTS   activitystudentitemquestionscore_view;

DROP  VIEW IF EXISTS   item_question_view;

DROP  VIEW IF EXISTS   activitystudentscore_view;



create or replace VIEW
  activitystudentscore_view
  (
      responseId,
      scoreReference,
      staffPersonalRefId,
      studentQuestionRefId,
      attempted,
      value,
      weight,
	    maxScore,
      Score,
      title,
      description,
      automarkable,
      correctResponse,
      score_type,
      error_message
  ) AS
 SELECT
    distinct ss.response_id,
    	    	ss.score_reference,
    	    	ss.staff_personal_refid,
    	    	ss.student_question_refid,
            ss.attemted,
            ss.value,
            ss.weight,
            ss.max_score,
            ss.score,
            score.title,
            score.description,
            score.automarkable,
            score.correct_response,
            score.type,
            score.error_message
            from student_score ss
            inner join
            	score score on
                ss.score_reference = score.score_reference;


DROP  VIEW IF EXISTS   activitystudentitem_view;


create or replace VIEW
  activitystudentitem_view
  (
      refId,
      sessionId,
      time,
      itemReference,
      maxScore,
      userFlagged,
      organisationId,
      itemPoolId,
      type,
      automarkable
  ) AS
 SELECT
    distinct st.refid,st.session_refid, st.time,item.item_reference, st.max_score, st.user_flagged,
                item.organisation_id, item.item_pool_id, item.type, automarkable
                from student_item st inner join  item item on  st.item_reference = item.item_reference
                inner join student_question sq on sq.student_item_refid = st.refid
                inner join question q on q.question_reference = sq.question_reference;


DROP  VIEW IF EXISTS   activitystudentquestion_view;

create or replace VIEW
  activitystudentquestion_view
  (
      refId,
      questionReference,
      studentItemRefId,
      actualResponse,
      responseId,
      rubricReference,
      questionType,
      automarkable,
      error_message
  ) AS
 SELECT
    distinct sq.refid,
    		sq.question_reference,
    		sq.student_item_refid,
    		sq.actual_response,
    		sq.response_id,
            question.rubric_reference,
            question.question_type,
            question.automarkable,
            question.error_message
            from student_question sq
            inner join
            	question question on
                sq.question_reference = question.question_reference;


DROP  VIEW IF EXISTS   activityitemlist_view;


CREATE OR REPLACE VIEW activityitemlist_view AS
 SELECT activity.activity_refid,
    activity.teacher_assignment_refid,
    activity.staff_personal_refid,
    activity.num_questions,
    activity.max_score,
    activity.max_time,
    activity.assignment_type,
    activity.activity_template_id,
    activity_item_score.item_reference,
    activity_item_score.score_reference,
    activity_item_score.weight,
    activity_item_score.question_reference,
    item.organisation_id,
    item.item_pool_id,
    item.type AS item_type,
    question.rubric_reference,
    question.question_type,
    question.automarkable AS question_automarkable,
    score.automarkable AS score_automarkable,
    score.correct_response,
    score.title,
    score.description,
    score.type AS score_type,
    activity_item_score.max_score score_max_score
   FROM activity,
    activity_item_score,
    item,
    question,
    score
  WHERE activity.activity_refid = activity_item_score.activity_refid AND activity_item_score.item_reference = item.item_reference
   AND activity_item_score.question_reference = question.question_reference
   AND activity_item_score.score_reference = score.score_reference;

CREATE OR REPLACE VIEW item_question_view AS
SELECT astv.refid,
         astv.item_reference,
         astv.session_refid,
         item.organisation_id,
         item.type,
         item.item_pool_id,
         astv.max_score,
         astv.user_flagged,
         astv.time,
         asqv.refid as question_refid,
         asqv.question_reference,
         asqv.actual_response,
             question.automarkable,
             question.error_message
            FROM student_item astv
           JOIN item item ON item.item_reference = astv.item_reference
           JOIN student_question asqv ON astv.refid = asqv.student_item_refid
           JOIN question question ON  asqv.question_reference = question.question_reference;


CREATE OR REPLACE VIEW question_score_view AS
        SELECT
          asqv.refid as question_refid,
         asqv.question_reference,
         asqv.actual_response,
         question.automarkable,
         question.error_message,
         assv.response_id,
         assv.score_reference,
         assv.staff_personal_refid,
         assv.attemted,
         assv.value,
         assv.weight,
         assv.max_score as score_max_score,
         assv.score,
         score.automarkable as score_automarkable,
         score.error_message as score_error_message,
         score.title,
         score.description,
         score.correct_response
            FROM  student_question asqv
            JOIN student_score assv ON asqv.refid = assv.student_question_refid
            JOIN question question ON  asqv.question_reference = question.question_reference
            JOIN score score ON  assv.score_reference =score.score_reference;