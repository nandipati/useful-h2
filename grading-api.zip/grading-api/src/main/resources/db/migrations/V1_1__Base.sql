alter table public.SCORE ADD COLUMN title VARCHAR(128);
alter table public.SCORE ADD COLUMN description TEXT;

