CREATE INDEX student_score_session_idx ON public.student_score USING btree (session_refid);
commit;

CREATE INDEX student_question_refid_idx ON public.student_score USING btree (student_question_refid);
commit;

CREATE INDEX activity_item_score_activity_idx ON public.activity_item_score USING btree (activity_refid);
commit;

