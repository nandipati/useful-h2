alter table public.score ADD COLUMN ERROR_MESSAGE VARCHAR(150);
