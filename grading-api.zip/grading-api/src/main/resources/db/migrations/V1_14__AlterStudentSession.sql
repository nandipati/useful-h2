alter table public.STUDENT_SESSION ADD COLUMN grade_start_time_updated TIMESTAMP;
