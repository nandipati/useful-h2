alter table public.question ADD COLUMN ERROR_MESSAGE VARCHAR(150);
