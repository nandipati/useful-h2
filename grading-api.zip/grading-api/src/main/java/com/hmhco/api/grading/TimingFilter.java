package com.hmhco.api.grading;

import io.hmheng.grading.utils.Constants;
import io.hmheng.grading.utils.Slf4jLogType;
import io.hmheng.grading.utils.Slf4jUtils;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import io.hmheng.grading.utils.StopwatchUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.util.StopWatch;
import org.springframework.web.filter.GenericFilterBean;


public class TimingFilter extends GenericFilterBean {

  private final Logger logger = LoggerFactory.getLogger(TimingFilter.class);

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    String fullRequestString = "";
    String queryString = "";
    if (request instanceof HttpServletRequest) {
      queryString = ((HttpServletRequest)request).getQueryString();
      fullRequestString = ((HttpServletRequest)request).getRequestURL().toString() + (queryString == null ? "" :
          "?" + queryString);
    }
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC,Constants.SERVICE_NAME_TAG, Constants.SERVICE_NAME);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC,Constants.FULL_REQUEST_STRING, fullRequestString);
    logger.info("Received request to {}", fullRequestString);
    StopWatch sw = StopwatchUtils.start();
    chain.doFilter(request, response);
    StopwatchUtils.stop(sw);
    Slf4jUtils.addTimestampPropertyToSlf4jLogType(sw);
    logger.info("Finished request to {}. Request took {} seconds.", fullRequestString, sw.getTotalTimeSeconds());

  }
}
