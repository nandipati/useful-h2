package com.hmhco.api.grading.controller;

import com.hmhco.api.grading.views.postresponse.PushScoreStatus;
import io.hmheng.grading.utils.Constants;
import com.hmhco.api.grading.resource.StudentItemResource;
import com.hmhco.api.grading.security.RoleConverter;
import com.hmhco.api.grading.service.StudentSessionService;
import com.hmhco.api.grading.service.action.SaveResponseRequest;
import com.hmhco.api.grading.service.action.SaveStudentSessionRequest;
import com.hmhco.api.grading.service.action.SaveStudentSessionResponse;
import com.hmhco.api.grading.utils.StudentSessionRequestType;
import com.hmhco.api.grading.views.ActivityView;
import com.hmhco.api.grading.views.SessionStatusView;
import com.hmhco.api.grading.views.SessionWrapper;
import com.hmhco.api.grading.views.StudentSessionView;
import com.hmhco.api.grading.views.StudentActivitySessionView;
import com.hmhco.api.grading.views.getresponse.ScoringCompleteResponse;
import com.hmhco.api.grading.views.getresponse.StudentItemGetView;
import com.hmhco.api.grading.views.getresponse.StudentSessionGetView;
import com.hmhco.api.grading.views.request.GradingEndpoint;
import com.hmhco.api.grading.views.request.ResponseView;
import com.hmhco.api.grading.assembler.ViewResolver;
import com.hmhco.api.grading.views.request.StudentStatusRequest;
import io.hmheng.grading.utils.Slf4jLogType;
import io.hmheng.grading.utils.Slf4jUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import io.hmheng.grading.utils.TimeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;

import javax.validation.Valid;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.NotFoundException;
import java.util.Map;
import java.util.UUID;

import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import static net.logstash.logback.marker.Markers.append;

/**
 * Created by srikanthk on 4/24/17.
 */

@RestController
@RequestMapping("v{"+ Constants.VERSION_PARAM_NAME +"}/activities")
public class ActivityController extends BaseController {

  private static  final Logger logger = LoggerFactory.getLogger(ActivityController.class);

  @Autowired
  private StudentSessionService studentSessionService;

  @Autowired
  private ViewResolver viewResolver;

  @Value("${spring.grading.countoSessionAfterThreshold}")
  private Long countoSessionAfterThreshold;

  @PreAuthorize("hasRole('" + RoleConverter.ROLE_TRUSTED_API+ "')")
  @RequestMapping(value="/{sessionId}/init", method = RequestMethod.POST,
                        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   public StudentActivitySessionView saveStudentSessionActivity(
            @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
            @PathVariable("sessionId")UUID sessionId,
            @Valid  @RequestBody StudentActivitySessionView studentActivitySessionview) {
                checkForVersion(versionNbr , GradingEndpoint.ACTIVITY_INIT_POST);

      if(sessionId == null) {
        throw new BadRequestException();
      }

      SaveStudentSessionRequest request = new SaveStudentSessionRequest(sessionId, studentActivitySessionview);
      request.setRequestType(StudentSessionRequestType.INIT);

      SaveStudentSessionResponse response = studentSessionService.getOrCreateStudentSession(request);
      StudentActivitySessionView studentActivitySessionView = response.getStudentActivitySessionView();
      if(studentActivitySessionView  != null) {
        Slf4jUtils.addPropertiesToSlf4jLogType(Slf4jLogType.MDC,studentActivitySessionView.getTeacherAssignmentRefId() ,
          studentActivitySessionView.getActivityRefId() , studentActivitySessionView.getSessionRefId(),
          studentActivitySessionView.getStudentPersonalRefId());
      }

      return response.getStudentActivitySessionView();
    }

  @ResponseStatus(HttpStatus.CREATED)
  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/{sessionId}/items/scores", method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public StudentSessionView scoringCompletePerSession(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId") UUID sessionId,
      @Valid @RequestBody StudentSessionView studentSessionview) {
    checkForVersion(versionNbr , GradingEndpoint.ACTIVITY_ITEM_SCORES_POST);
    if(sessionId == null) {
      throw new BadRequestException();
    }
    SaveStudentSessionRequest request = new SaveStudentSessionRequest(sessionId, studentSessionview);
    request.setRequestType(StudentSessionRequestType.SCORES);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG, sessionId.toString());
    SaveStudentSessionResponse response = studentSessionService.getOrCreateStudentSession(request);

    StudentSessionView sessionView = response.getStudentSessionView();
    ActivityView activityView = sessionView.getAssignment();
    if(sessionView != null) {
      Slf4jUtils.addPropertiesToSlf4jLogType(Slf4jLogType.MDC,activityView.getTeacherAssignmentRefId() ,
              activityView.getActivityRefId() , sessionView.getSessionRefId(),
              sessionView.getStudentPersonalRefId());
    }

    return response.getStudentSessionView();
  }

  @ResponseStatus(HttpStatus.CREATED)
  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/{sessionId}/itemresponses/{responseId}", method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseView saveItemResponse(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId")UUID sessionId,
      @PathVariable("responseId")String responseId,
      @Valid  @RequestBody ResponseView responseView) {
    checkForVersion(versionNbr, GradingEndpoint.STUDENT_ITEMSCORES_RESPONSE_POST);

    if(sessionId == null || responseId == null) {
      throw new BadRequestException();
    }

    SaveResponseRequest saveResponseRequest = new SaveResponseRequest(sessionId , responseId , responseView);
    responseView = studentSessionService.createOrUpdateItemReponse(saveResponseRequest);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC,Constants.SESSION_ID_TAG,sessionId.toString());
    return responseView;
  }

  @ResponseStatus(HttpStatus.ACCEPTED)
  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/{sessionId}/status", method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public SessionStatusView saveItemResponse(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId")UUID sessionId,
      @Valid  @RequestBody StudentStatusRequest studentStatusRequest) {
    checkForVersion(versionNbr , GradingEndpoint.STUDENT_SESSION_STATUS);

    if(sessionId == null) {
      throw new BadRequestException();
    }

    SessionStatusView responseView = studentSessionService.updateSessionStatus(sessionId, studentStatusRequest);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC,Constants.SESSION_ID_TAG,sessionId.toString());
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC,Constants.STUDENT_ID_TAG, responseView.getStudentPersonalRefId().toString());

    return responseView;
  }


  @RequestMapping(value = "/{sessionId}/items/{itemReference}", method = RequestMethod.GET, produces = Constants.HALJSON)
  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  public StudentItemResource getItemDetails(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId")UUID sessionId,
      @PathVariable("itemReference")String itemReference) {
    checkForVersion(versionNbr , GradingEndpoint.STUDENT_ITEM_DETAILS_GET);
   //TODO Create a new StudentItemGetView and should be changes only used for producing contract

    if(sessionId == null || itemReference == null)
      throw new BadRequestException();
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG, sessionId.toString());
    return viewResolver.resolveSingleDtoView(studentSessionService.getStudentItems(sessionId,itemReference ) , versionNbr);
  }

  @ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
  @ResponseBody
  public ResponseEntity resolveMessageNotReadableException() {
    ResponseEntity<String> responseEntity = new ResponseEntity<>("Invalid request parameter(s)", HttpStatus.BAD_REQUEST);
    return responseEntity;
  }

  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/{sessionId}/scoringcomplete", method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ScoringCompleteResponse scoringCompletePerSession(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId") UUID sessionId,
      HttpServletResponse response) {

    response.setStatus(HttpServletResponse.SC_CREATED);
    checkForVersion(versionNbr, GradingEndpoint.STUDENT_SESSION_SCORING_COMPLETE);

    if(sessionId == null){
      throw new BadRequestException();
    }
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG, sessionId.toString());
    ScoringCompleteResponse scoringCompleteResponse = studentSessionService.scoringCompleted(sessionId);
    UUID activityRefId = scoringCompleteResponse.getActivityRefId();
    ActivityView activityView = studentSessionService.getActivityDetails(activityRefId);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.ACTIVITY_ID_TAG, activityRefId.toString());
    scoringCompleteResponse.getStudentSession().setAssignment(activityView);
    if(!CollectionUtils.isEmpty(scoringCompleteResponse.getIncompleteItemReferences())){
      response.setStatus(HttpServletResponse.SC_PRECONDITION_FAILED);
    }else if(activityView != null) {
      StudentSessionGetView studentSessionGetView = scoringCompleteResponse.getStudentSession();
      Slf4jUtils.addPropertiesToSlf4jLogType(Slf4jLogType.MDC,activityView.getTeacherAssignmentRefId() ,
        activityRefId , scoringCompleteResponse.getStudentSession().getSessionRefId(),
        scoringCompleteResponse.getStudentSession().getStudentPersonalRefId());
      if(studentSessionGetView.getCreatedDate() != null && studentSessionGetView.getUpdatedDate() != null) {
        Map<String, Object> contextMap = new HashMap<>();
        long timeInMills = TimeUtils.differenceInTimeMillis(studentSessionGetView.getCreatedDate(), studentSessionGetView.getUpdatedDate());
        if(studentSessionGetView.getDateGradeStartTime()!=null) {
          long teacherGradePendingTimeInMills = TimeUtils.differenceInTimeMillis(studentSessionGetView.getCreatedDate(), studentSessionGetView.getDateGradeStartTime());
          contextMap.put(Constants.GRADEPENDING_TIME, teacherGradePendingTimeInMills);
          if(studentSessionGetView.getUpdatedGradeStartTime()!=null) {
            long gradetimeInMills = TimeUtils.differenceInTimeMillis(studentSessionGetView.getUpdatedGradeStartTime(), studentSessionGetView.getUpdatedDate());
            contextMap.put(Constants.TIMESPENT_BYTEACHER, gradetimeInMills);
          }
        }
          contextMap.put(Constants.ELAPSED_TIMEMILLS_INGRADING,timeInMills);

          Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MARKER, "timeInGrading", contextMap);
      }
    }

    return scoringCompleteResponse;
  }

  @PreAuthorize("hasAnyRole('"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="markscoringcomplete", method = RequestMethod.POST,
          consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> markScoringCompleted(
          @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
          @RequestBody SessionWrapper sessionWrapper){

    checkForVersion(versionNbr, GradingEndpoint.STUDENT_SESSION_PUSH_SCORING);
    List<UUID> sessionIdList = sessionWrapper.getSessionIds();

    if(CollectionUtils.isEmpty(sessionIdList)) {
      throw new BadRequestException();
    }

    for(UUID sessionId : sessionIdList){
      studentSessionService.scoringCompleted(sessionId);
    }

    return new ResponseEntity<>(HttpStatus.OK);
  }

  @PreAuthorize("hasAnyRole('"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/{sessionId}/pushScoresToScoring", method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> pushScoresToScoring(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId") UUID sessionId){

    checkForVersion(versionNbr, GradingEndpoint.STUDENT_SESSION_PUSH_SCORING);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG, sessionId.toString());
    studentSessionService.pushScoresToScoring(sessionId);

    return new ResponseEntity<>(HttpStatus.OK);
  }

  @PreAuthorize("hasAnyRole('"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="pushScores", method = RequestMethod.POST,
          consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PushScoreStatus> pushScores(
          @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
          @RequestBody SessionWrapper sessionWrapper){

    checkForVersion(versionNbr, GradingEndpoint.STUDENT_SESSION_PUSH_SCORING);

    List<PushScoreStatus> listStatus = new ArrayList<PushScoreStatus>();

    List<UUID> sessionIdList = sessionWrapper.getSessionIds();

    if(CollectionUtils.isEmpty(sessionIdList)) {
      throw new BadRequestException();
    }

    for(UUID sessionId : sessionIdList){
      listStatus.add(studentSessionService.pushScoresToScoring(sessionId));
    }

    return listStatus;
  }

  @PreAuthorize("hasAnyRole('"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/{sessionId}/pushStatusForAssignment", method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> pushStatusForAssignment(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId") UUID sessionId){

    checkForVersion(versionNbr, GradingEndpoint.STUDENT_SESSION_PUSH_SCORING);
    studentSessionService.pushStatusToAssignment(sessionId);
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG, sessionId.toString());
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @ResponseStatus(HttpStatus.ACCEPTED)
  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  @RequestMapping(value="/pushStatus", method = RequestMethod.POST,
          consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> pushStatus(
          @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
          @RequestBody SessionWrapper sessionWrapper) {
    checkForVersion(versionNbr , GradingEndpoint.STUDENT_SESSION_STATUS);

    List<UUID> sessionIdList = sessionWrapper.getSessionIds();

    if(CollectionUtils.isEmpty(sessionIdList)) {
      throw new BadRequestException();
    }

    for(UUID sessionId : sessionIdList){
       studentSessionService.pushStatusToAssignment(sessionId);
    }

    return new ResponseEntity<>(HttpStatus.OK);
  }


  @RequestMapping(value = "/{sessionId}/items", method = RequestMethod.GET, produces = Constants.HALJSON)
  @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TEACHER + "','"+RoleConverter.ROLE_TRUSTED_API+"')")
  public Page<StudentItemGetView> getStudentActivityItems(
      @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
      @PathVariable("sessionId")UUID sessionId,
      @RequestParam(value = "onlyManualScored", required = false, defaultValue = "false") Boolean onlyManualScored,
      @RequestParam(value = "includeQuestionsAndScores", required = false, defaultValue = "false") Boolean includeQuestionsAndScores,
      Pageable pageable) {
    checkForVersion(versionNbr, GradingEndpoint.STUDENT_ITEMS_GET);

    if(sessionId == null)
      throw new BadRequestException();
    Slf4jUtils.addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG, sessionId.toString());
    Page<StudentItemGetView> views = studentSessionService.getStudentActivityItems(pageable, sessionId, onlyManualScored, includeQuestionsAndScores);
    return views;
  }


  @ResponseStatus(HttpStatus.OK)
  @PreAuthorize("hasRole('" + RoleConverter.ROLE_TRUSTED_API + "')")
  @RequestMapping(
        value = "/sessions/countoSessionAfter/{INTERVAL}/inmins",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
  public long getSessionCount(@PathVariable("INTERVAL") long interval) throws Exception {

    LocalDateTime localDateTime = LocalDateTime.now().minusMinutes(interval);

    long formativeCount = studentSessionService.countFindByDateAfter(localDateTime);

    if (formativeCount <= countoSessionAfterThreshold) {
      // send failing HTTP status so the monitoring jobs can display error message
      throw new Exception("countoSessionAfter call returning count <"
            + formativeCount
            + ">, which is not above threshold <"
            + countoSessionAfterThreshold
            + ">" );
    }

    return formativeCount;
  }
}
