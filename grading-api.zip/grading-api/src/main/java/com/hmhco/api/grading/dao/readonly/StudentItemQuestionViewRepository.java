package com.hmhco.api.grading.dao.readonly;

import com.hmhco.api.grading.entities.readonly.ItemQuestionEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface StudentItemQuestionViewRepository extends JpaRepository<ItemQuestionEntity, Long> {


    Page<ItemQuestionEntity> findBySessionIdAndAutomarkable(UUID sessionId, Boolean automarkable, Pageable pageable);

    Page<ItemQuestionEntity> findBySessionId(UUID sessionId, Pageable pageable);
}
