package com.hmhco.api.grading.utils;

/**
 * Created by nandipatim on 5/2/17.
 */
public enum StudentSessionRequestType {
  INIT,
  SCORES;
}
