package com.hmhco.api.grading.entities;

import java.io.Serializable;

/**
 * Created by srikanthk on 4/25/17.
 */
public class AbstractEntity implements Serializable {

    private static final long serialVersionUID = 2176877874214969461L;
}
