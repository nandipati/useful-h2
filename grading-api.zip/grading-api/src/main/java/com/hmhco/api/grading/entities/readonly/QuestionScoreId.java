package com.hmhco.api.grading.entities.readonly;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@Embeddable
public class QuestionScoreId implements Serializable {

    @Column(name="score_reference")
    private String scoreReference;

    @Column(name="question_reference")
    private String questionReference;
}
