package com.hmhco.api.grading.views.postresponse;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.hmheng.grading.utils.JsonCommons;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by mfeng on 10/19/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("pushscore-status")
public class PushScoreStatus {

  @JsonProperty("sessionId")
  private UUID sessionId;

  @JsonProperty("message")
  private String message;

}
