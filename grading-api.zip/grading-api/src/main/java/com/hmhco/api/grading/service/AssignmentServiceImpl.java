package com.hmhco.api.grading.service;

import com.hmhco.api.grading.dao.readonly.ItemViewEntityRepository;
import com.hmhco.api.grading.entities.readonly.ItemViewEntity;
import com.hmhco.api.grading.mapper.viewmapper.ActivityItemsViewMapper;
import com.hmhco.api.grading.service.config.ReadWriteService;
import com.hmhco.api.grading.utils.ActivityItemsViewUtil;
import com.hmhco.api.grading.views.ActivityItemsView;
import com.hmhco.api.grading.views.ItemsView;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.UUID;

/**
 * Created by tallurir on 9/18/17.
 */

@ReadWriteService
public  class AssignmentServiceImpl  implements  AssignmentService{

    @Autowired
    private ItemViewEntityRepository itemViewEntityRepository;

    @Autowired
    private ActivityItemsViewMapper activityItemsViewMapper;


    @Override
    public ActivityItemsView getItemsByActivityId(UUID activityId, Boolean manualScoredRequired) {
        List<ItemsView> itemViewsList = null;
        ActivityItemsView activityItemsView = new ActivityItemsView();

        if(activityId != null) {
            List<ItemViewEntity> itemViewEntityList = itemViewEntityRepository.findByActivityRefId(activityId);

            if(!itemViewEntityList.isEmpty()) {

                BeanUtils.copyProperties(itemViewEntityList.stream().findFirst().get(), activityItemsView);


                ActivityItemsViewUtil activityItemsViewUtil = activityItemsViewMapper.convert(itemViewEntityList, manualScoredRequired);
                itemViewsList = activityItemsViewUtil.getItemsViews();
                if (itemViewsList != null) {
                    activityItemsView.setItems(itemViewsList);
                    activityItemsView.setScoresExtn(activityItemsViewUtil.getScoreExtnViews());
                }
            }
        }

        return activityItemsView;
    }
}
