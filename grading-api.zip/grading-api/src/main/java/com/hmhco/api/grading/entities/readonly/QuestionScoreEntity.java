package com.hmhco.api.grading.entities.readonly;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.UUID;

@Data
@NoArgsConstructor
@Entity
@Table(name="question_score_view")
public class QuestionScoreEntity {

    private static final long serialVersionUID = -2343765976993505712L;

    @EmbeddedId
    private QuestionScoreId id;

    @Column(name="question_refid")
    private Long questionRefid;


    @Column(name="response_id")
    private String responseId;

    @Column(name="staff_personal_refid")
    private UUID staffPersonalRefId;


    @Column(name="attemted")
    private Boolean attempted;

    @Column(name = "value")
    private String value;

    @Column(name="weight")
    private Integer weight;

    @Column(name="score_max_score")
    private Integer scoreMaxScore;

    @Column(name="score")
    private Integer score;


    @Column(name="score_automarkable")
    private Boolean scoreAutomarkable;

    @Column(name="score_error_message")
    private String scoreErrorMessage;

    @Column(name="actual_response")
    private String actualResponse;


    @Column(name="automarkable")
    private Boolean automarkable;

    @Column(name="error_message")
    private String errorMessage;

    @Column(name="title")
    private String title;

    @Column(name="description")
    private String description;

    @Column(name="correct_response")
    private String correctResponse;
}
