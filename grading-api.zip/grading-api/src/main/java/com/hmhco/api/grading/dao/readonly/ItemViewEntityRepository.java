package com.hmhco.api.grading.dao.readonly;

import com.hmhco.api.grading.entities.ItemEntity;
import com.hmhco.api.grading.entities.readonly.ItemViewEntity;
import com.hmhco.api.grading.entities.readonly.ActivityStudentScoreViewEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

/**
 * Created by tallurir on 9/17/17.
 */
public interface ItemViewEntityRepository extends JpaRepository<ItemViewEntity, Long> {

    List<ItemViewEntity> findByActivityRefId(UUID activityRefId);

}