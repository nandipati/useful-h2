package com.hmhco.api.grading.entities.readonly;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@Embeddable
public class ItemQuestionId implements Serializable {

    @Column(name="item_reference")
    private String itemReference;

    @Column(name="question_reference")
    private String questionReference;
}
