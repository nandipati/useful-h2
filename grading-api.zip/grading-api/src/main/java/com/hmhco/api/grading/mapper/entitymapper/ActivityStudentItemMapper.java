package com.hmhco.api.grading.mapper.entitymapper;

import com.hmhco.api.grading.controller.utils.MapperUtil;
import com.hmhco.api.grading.entities.AbstractEntity;
import com.hmhco.api.grading.entities.readonly.ActivityStudentItemViewEntity;
import com.hmhco.api.grading.entities.readonly.ItemQuestionEntity;
import com.hmhco.api.grading.entities.readonly.QuestionScoreEntity;
import com.hmhco.api.grading.mapper.SingleEntityMapper;
import com.hmhco.api.grading.mapper.viewmapper.ActivityStudentQuestionMapper;
import com.hmhco.api.grading.views.getresponse.StudentItemGetView;
import com.hmhco.api.grading.views.getresponse.StudentQuestionGetView;
import com.hmhco.api.grading.views.getresponse.StudentScoreGetView;
import io.hmheng.grading.utils.Status;



import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by srikanthk on 5/12/17.
 */

@Component
public class ActivityStudentItemMapper implements SingleEntityMapper<ActivityStudentItemViewEntity, StudentItemGetView> {

    @Autowired
    private ActivityStudentQuestionMapper activityStudentQuestionMapper;

    @Autowired
    MapperUtil mapperUtil;

    public List<StudentItemGetView> convert(Collection<ActivityStudentItemViewEntity> entities , Boolean excludeQuestionsAndScores) {
      List<StudentItemGetView> studentItemGetViews = new ArrayList<>();
       entities.stream().forEach(activityStudentItemViewEntity ->
           studentItemGetViews.add(convert(activityStudentItemViewEntity , excludeQuestionsAndScores)));

      return studentItemGetViews;
    }

    public StudentItemGetView convert(ActivityStudentItemViewEntity entity , Boolean  excludeQuestionsAndScores){

      StudentItemGetView studentItemGetView = new StudentItemGetView();
      BeanUtils.copyProperties(entity,studentItemGetView );

      List<StudentQuestionGetView> questions = activityStudentQuestionMapper.convert(entity.getQuestions());
      if(questions!= null )
      {
        studentItemGetView.setQuestions(questions);
        studentItemGetView.setStatus(getItemStatus(questions));
        studentItemGetView.setIsValidRubrics(isValidRubrics(questions));
        Integer maxScore = rollupMaxScore(questions);
        studentItemGetView.setMaxScore(maxScore);
      }

      if (excludeQuestionsAndScores) {
        studentItemGetView.setQuestions(null);
      }

      return studentItemGetView;
    }

    @Override
    public StudentItemGetView convert(ActivityStudentItemViewEntity entity) {

      return convert(entity , false);
    }

    public List<StudentItemGetView> convertTo(Collection<ItemQuestionEntity> entities , List<QuestionScoreEntity> questionScoreEntities, Boolean excludeQuestionsAndScores) {

        Map<String,List<ItemQuestionEntity>> itemsMap = entities.stream().collect(Collectors.groupingBy(s->s.getId().getItemReference(),Collectors.toList()));

        List<StudentItemGetView> studentItemGetViews = new ArrayList<>();
        itemsMap.keySet().forEach(key ->
                studentItemGetViews.add(convert(itemsMap.get(key) , excludeQuestionsAndScores, questionScoreEntities)));

        return studentItemGetViews;
    }

    public StudentItemGetView convert(List<ItemQuestionEntity> entities , Boolean  excludeQuestionsAndScores, List<QuestionScoreEntity> questionScoreEntities){
        StudentItemGetView studentItemGetView = new StudentItemGetView();

        if(entities != null && !entities.isEmpty()) {
            List<StudentQuestionGetView> questions = new ArrayList<>();
            ItemQuestionEntity item =entities.get(0);
            BeanUtils.copyProperties(item, studentItemGetView);
            studentItemGetView.setMaxScore(item.getMaxScore());
            studentItemGetView.setRefId(item.getItemRefId());
            studentItemGetView.setItemReference(item.getId().getItemReference());
            Set<String> questionMap1 = new HashSet<>();
            Map<String, ItemQuestionEntity> questionItemMap = new HashMap<>();
            entities.forEach(s -> questionItemMap.put(s.getId().getQuestionReference(), s));


            entities.forEach(s->{
                questionMap1.add(s.getId().getQuestionReference());
            });


            Map<String, List<QuestionScoreEntity>> questionMap = questionScoreEntities.stream().collect(Collectors.groupingBy(s->s.getId().getQuestionReference(), Collectors.toList()));

            if(questionMap!= null && !questionMap.isEmpty()) {

                questionMap1.forEach(k -> {


                    List<QuestionScoreEntity> questionEntities = questionMap.get(k);
                    List<StudentScoreGetView> scores = new ArrayList<>();
                    if (questionEntities != null) {

                        questionEntities.forEach(s -> {

                            StudentScoreGetView score = new StudentScoreGetView();

                            score.setScoreReference(s.getId().getScoreReference());
                            score.setScore(s.getScore());
                            score.setMaxScore(s.getScoreMaxScore());
                            score.setAttempted(s.getAttempted());
                            score.setAutomarkable(s.getScoreAutomarkable());
                            score.setCorrectResponse(s.getCorrectResponse());
                            score.setErrorMessage(s.getScoreErrorMessage());
                            score.setTitle(s.getTitle());
                            score.setWeight(s.getWeight());
                            score.setAutomarkable(s.getScoreAutomarkable());
                            score.setErrorMessage(s.getScoreErrorMessage());
                           score.setDescription(s.getDescription());
                            score.setResponseId(s.getResponseId());

                            String valueStr = s.getValue();
                            Object value = mapperUtil.transformToObject(valueStr);
                           score.setValue(value);

                            scores.add(score);

                        });


                        QuestionScoreEntity question = questionEntities.get(0);
                        StudentQuestionGetView studentQuestionGetView = new StudentQuestionGetView();
                        BeanUtils.copyProperties(question, studentQuestionGetView);
                        studentQuestionGetView.setQuestionReference(question.getId().getQuestionReference());
                        studentQuestionGetView.setAutomarkable(question.getAutomarkable());
                        studentQuestionGetView.setErrorMessage(question.getErrorMessage());
                        studentQuestionGetView.setResponses(scores);
                        String actualResponseStr = question.getActualResponse();
                        Object actualResponseObj = mapperUtil.transformToObject(actualResponseStr);
                        studentQuestionGetView.setActualResponse(actualResponseObj);

                        Integer maxScore = null;
                        for (StudentScoreGetView score : studentQuestionGetView.getResponses()) {
                            if (score.getScore() != null) {
                                maxScore = maxScore == null ? score.getMaxScore() : maxScore + score.getMaxScore();
                            }
                        }
                        studentQuestionGetView.setMaxScore(maxScore);


                        questions.add(studentQuestionGetView);
                    } else {
                        ItemQuestionEntity itemQuestionEntity = questionItemMap.get(k);
                        StudentQuestionGetView studentQuestionGetView = new StudentQuestionGetView();
                        studentQuestionGetView.setQuestionReference(itemQuestionEntity.getId().getQuestionReference());
                        studentQuestionGetView.setAutomarkable(itemQuestionEntity.getAutomarkable());
                        studentQuestionGetView.setErrorMessage(itemQuestionEntity.getErrorMesage());
                        String actualResponseStr = itemQuestionEntity.getActualResponse();
                        Object actualResponseObj = mapperUtil.transformToObject(actualResponseStr);
                        studentQuestionGetView.setActualResponse(actualResponseObj);
                        questions.add(studentQuestionGetView);
                    }


               });
            }

            if (!CollectionUtils.isEmpty(questions)) {
                studentItemGetView.setQuestions(questions);
                studentItemGetView.setStatus(getItemStatus(questions));
                studentItemGetView.setIsValidRubrics(isValidRubrics(questions));
                Integer maxScore = rollupMaxScore(questions);
                studentItemGetView.setMaxScore(maxScore);
            }

            if (excludeQuestionsAndScores) {
                studentItemGetView.setQuestions(null);
            }
        }


        return studentItemGetView;
    }

    public Status getItemStatus(List<StudentQuestionGetView> questions){

    Status status = Status.NOT_SCORED;

    for (StudentQuestionGetView question : questions) {
      int responsecnt = 0;
      if (question.getResponses() != null) {
        for (StudentScoreGetView score : question.getResponses()) {

          if (score.getScore() != null || score.getAutomarkable()) {
            responsecnt++;
          }
        }
      }
             if(responsecnt > 0)
                    status = (responsecnt == question.getResponses().size() ? Status.SCORING_COMPLETED: Status
                     .SCORING_IN_PROGRESS);
         }


         return status;

    }

    public Boolean isValidRubrics(List<StudentQuestionGetView> questions){

        Boolean isValidRubrics = Boolean.TRUE;

        for(StudentQuestionGetView question : questions){

          if(question.getAutomarkable() != null && !question.getAutomarkable()
              && question.getErrorMessage() != null){
            return Boolean.FALSE;
          }
      if (question.getResponses() != null) {
        for (StudentScoreGetView score : question.getResponses()) {

          if (score.getScore() != null)
            if (score.getAutomarkable()) {
              continue;
            } else if (isValidRubrics) {
              if (question.getErrorMessage() != null || score.getErrorMessage() != null) {
                isValidRubrics = Boolean.FALSE;
              }
            }
        }
      }
    }
    return isValidRubrics;
    }

    public Integer rollupMaxScore(List<StudentQuestionGetView> questions) {
        Integer maxScore = null;
        for (StudentQuestionGetView question : questions){
            if (question.getMaxScore() != null) {
                maxScore = maxScore == null ? question.getMaxScore() : maxScore + question.getMaxScore();
            }
        }
        return maxScore;
    }

    @Override
    public boolean supports(Class<? extends AbstractEntity> clazz) {
        return ActivityStudentItemViewEntity.class.equals(clazz);
    }
}