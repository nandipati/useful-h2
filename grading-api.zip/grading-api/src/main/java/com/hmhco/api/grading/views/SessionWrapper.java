package com.hmhco.api.grading.views;

import java.util.List;
import java.util.UUID;
import lombok.Data;

@Data
public class SessionWrapper {

  private List<UUID> sessionIds;

}