package com.hmhco.api.grading.entities.readonly;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * Created by tallurir on 9/18/17.
 */
@Data
@NoArgsConstructor
@Embeddable
public class ItemViewId implements Serializable {
    @Column(name="item_reference")
    private String itemReference;

    @Column(name="question_reference")
    private String questionReference;

    @Column(name="score_reference")
    private String scoreReference;


}