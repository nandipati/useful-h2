package com.hmhco.api.grading.controller;

import io.hmheng.grading.utils.Constants;
import com.hmhco.api.grading.security.RoleConverter;
import com.hmhco.api.grading.service.AssignmentService;
import com.hmhco.api.grading.views.ActivityItemsView;
import com.hmhco.api.grading.views.request.GradingEndpoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.BadRequestException;
import java.util.UUID;

/**
 * Created by tallurir on 9/18/17.
 */
@RestController
@RequestMapping("v{"+ Constants.VERSION_PARAM_NAME +"}/assignments")
public class AssignmentController extends BaseController {

    @Autowired
    AssignmentService assignmentService;

    @RequestMapping(value = "/{activityId}/activityItems", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAnyRole('" + RoleConverter.ROLE_TRUSTED_API + "')")
    public ActivityItemsView getItemsByActivityId(
            @PathVariable(Constants.VERSION_PARAM_NAME) String versionNbr,
            @PathVariable("activityId") UUID activityId,
            @RequestParam(value = "manualScoredRequired", defaultValue = "true") Boolean manualScoredRequired) {
        checkForVersion(versionNbr, GradingEndpoint.STUDENT_ITEMS_GET);

        if (activityId == null)
            throw new BadRequestException();

        return assignmentService.getItemsByActivityId(activityId, manualScoredRequired);

    }

}

