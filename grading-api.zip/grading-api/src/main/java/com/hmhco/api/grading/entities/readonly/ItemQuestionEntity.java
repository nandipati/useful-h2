package com.hmhco.api.grading.entities.readonly;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.UUID;

@Data
@NoArgsConstructor
@Entity
@Table(name="item_question_view")
public class ItemQuestionEntity {
    private static final long serialVersionUID = 898668825365994643L;

    @EmbeddedId
    private ItemQuestionId id;

    @Column(name="refid")
    private Long itemRefId;


    @Column(name="time")
    private Integer time;

    @Column(name="max_score")
    private Integer maxScore;


    @Column(name="user_flagged")
    private Boolean userFlagged;

    @Column(name="organisation_id")
    private Integer organizationId;

    @Column(name="item_pool_id")
    private String itemPoolId;

    @Column(name="type")
    private String type;

    @Column(name="session_refid")
    private UUID sessionId;

    @Column(name="question_refid")
    private Long refId;

    @Column(name="automarkable")
    private Boolean automarkable;

    @Column(name = "error_message")
    private String errorMesage;

    @Column(name = "actual_response")
    private String actualResponse;


}
