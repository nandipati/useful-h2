package com.hmhco.api.grading.service.helper;

import com.hmhco.api.grading.entities.StudentItemEntity;
import com.hmhco.api.grading.entities.StudentQuestionEntity;
import com.hmhco.api.grading.entities.StudentScoreEntity;
import io.hmheng.grading.utils.BeanPropertyUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.collections.ListUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * Created by nandipatim on 5/15/17.
 */
@Component
public class StudentQuestionHelper {

  @Autowired
  private StudentScoreHelper studentScoreHelper;

  public List<StudentQuestionEntity> getOrCreateStudentQuestionEntity(StudentItemEntity studentItemEntityFromDB,
                                                                      StudentItemEntity studentItemEntityFromView,
                                                                      HashMap<String, List<StudentQuestionEntity>> mapQuestions,
                                                                      HashMap<String, List<StudentScoreEntity>> mapQuestionScores) {

    List<StudentQuestionEntity> studentQuestionEntitiesFromView = studentItemEntityFromView.getStudentQuestions();
    List<StudentQuestionEntity> studentQuestionEntitiesFromDB = null;
    if(studentItemEntityFromDB.getRefId() != null)
    {
      studentQuestionEntitiesFromDB = mapQuestions.get(studentItemEntityFromDB.getRefId().toString());
    }

    if (studentQuestionEntitiesFromView == null) {
      return studentQuestionEntitiesFromDB;
    }

    if (!CollectionUtils.isEmpty(studentQuestionEntitiesFromDB)) {
      studentQuestionEntitiesFromDB.stream().forEach(questionEntity -> {
        int indexOfQuestion = studentQuestionEntitiesFromView.indexOf(questionEntity);
        StudentQuestionEntity studentQuestionEntity = null;
        if (indexOfQuestion != -1) {
          studentQuestionEntity = studentQuestionEntitiesFromView.get(indexOfQuestion);
        }
        if (studentQuestionEntity != null) {

          List<StudentScoreEntity> studentScoreEntities = new ArrayList<StudentScoreEntity>();
          if(questionEntity.getRefId() != null)
          {
            studentScoreEntities = mapQuestionScores.get(questionEntity.getRefId().toString());
          }

          studentQuestionEntity.setRefId(questionEntity.getRefId());
          BeanPropertyUtils.copyPropertiesWithOnlyPopulated(studentQuestionEntity, questionEntity);
          questionEntity.setStudentScores(studentScoreEntities);
          questionEntity.setStudentItems(studentItemEntityFromDB);
          questionEntity.setStudentScores(studentScoreHelper.getOrCreateStudentScores(studentItemEntityFromView.getSessionRefId(), questionEntity, studentQuestionEntity, mapQuestionScores));
        }
      });
    }

    if(CollectionUtils.isEmpty(studentQuestionEntitiesFromDB) )
    {
      studentQuestionEntitiesFromDB = new ArrayList<StudentQuestionEntity>();
    }
    List<StudentQuestionEntity> newEntities = ListUtils.subtract(studentQuestionEntitiesFromView, studentQuestionEntitiesFromDB);
    if(!CollectionUtils.isEmpty(newEntities))

    {
      newEntities.stream().forEach(question -> {
        question.setStudentItems(studentItemEntityFromDB);
        question.getStudentScores().stream().forEach(score -> {
          score.setSessionRefId(studentItemEntityFromView.getSessionRefId());
          score.setStudentSession(studentItemEntityFromDB.getStudentSession());
        });
      });

      studentQuestionEntitiesFromDB.addAll(newEntities);
    }


    return studentQuestionEntitiesFromDB;
  }
}
