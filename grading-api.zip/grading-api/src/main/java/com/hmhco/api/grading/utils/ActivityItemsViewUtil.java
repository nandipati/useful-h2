package com.hmhco.api.grading.utils;

import com.hmhco.api.grading.views.ItemsView;
import com.hmhco.api.grading.views.getresponse.ScoreExtnView;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 10/10/17.
 */
@Data
public class ActivityItemsViewUtil {
    private List<ItemsView> itemsViews;
    private List<ScoreExtnView> scoreExtnViews;
}
