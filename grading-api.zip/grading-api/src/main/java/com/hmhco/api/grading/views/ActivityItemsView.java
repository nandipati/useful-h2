package com.hmhco.api.grading.views;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.grading.views.getresponse.ScoreExtnView;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.core.Relation;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;


@Data
@NoArgsConstructor
@JsonRootName("activity")
public class ActivityItemsView extends AbstractView{
    @NotNull
    private UUID activityRefId;

    @NotNull
    private UUID teacherAssignmentRefId;

    @NotNull
    private UUID staffPersonalRefId;

    private String activityTemplateId;

    private Integer maxScore;

    private Integer maxTime;

    private Integer numQuestions;

    private String assignmentType;

    private List<ItemsView> items;

    private List<ScoreExtnView> scoresExtn;

}
