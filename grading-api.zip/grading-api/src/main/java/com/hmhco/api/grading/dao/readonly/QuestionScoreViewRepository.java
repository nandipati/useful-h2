package com.hmhco.api.grading.dao.readonly;

import com.hmhco.api.grading.entities.readonly.ItemQuestionEntity;
import com.hmhco.api.grading.entities.readonly.QuestionScoreEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.UUID;

public interface QuestionScoreViewRepository extends JpaRepository<QuestionScoreEntity, Long> {

    Page<QuestionScoreEntity> findByquestionRefidIn(Collection<Long> questionRefs, Pageable pageable);

}
