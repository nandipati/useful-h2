package com.hmhco.api.grading.views;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by srikanthk on 4/24/17.
 */
public class ResponseView  extends AbstractView{

  List<StudentItemView> studentItems = new ArrayList<>();

  List<StudentQuestionView> studentQuestions = new ArrayList<>();




}
