package com.hmhco.api.grading.views.request;

/**
 * Created by nandipatim on 5/8/17.
 */
public class JsonViews {

  public interface V1 {
  }

  public interface V2 extends V1 {
  }
}
