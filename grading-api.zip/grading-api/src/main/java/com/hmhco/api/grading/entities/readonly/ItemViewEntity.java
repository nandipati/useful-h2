package com.hmhco.api.grading.entities.readonly;

import com.hmhco.api.grading.entities.AuditableEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.UUID;

/**
 * Created by tallurir on 9/17/17.
 */




@Data
@NoArgsConstructor
@Entity
@Table(name="activityitemlist_view")
public class ItemViewEntity  {

    @EmbeddedId
    private ItemViewId id;


    @Column(name = "teacher_assignment_refid")
    private UUID teacherAssignmentRefId;

    @Column(name = "staff_personal_refid")
    private UUID staffPersonalRefId;

    @Column(name = "num_questions")
    private Integer numQuestions;

    @Column(name = "max_score")
    private Integer maxScore;

    @Column(name = "max_time")
    private Integer maxTime;

    @Column(name = "organisation_id")
    private Integer organizationId;

    @Column(name = "item_pool_id")
    private String itemPoolId;

    @Column(name = "activity_refid")
    private UUID activityRefId;

    @Column(name="item_type")
    private String type;


    @Column(name="rubric_reference")
    private String rubricReference;

    @Column(name="question_type")
    private String questionType;

    @Column(name="assignment_type")
    private String assignmentType;

    @Column(name = "question_automarkable")
    private Boolean questionAutomarkable;

    @Column(name="title")
    private String title;

    @Column(name="description")
    private String description;

    @Column(name="score_automarkable")
    private Boolean scoreAutomarkable;

    @Column(name="correct_response")
    private String correctResponse;

    @Column(name="score_max_score")
    private Integer scoreMaxScore;

    @Override
    public String toString() {
        return "ItemViewEntity{" +

                ", organizationId=" + organizationId +
                ", itemPoolId='" + itemPoolId + '\'' +
                ", type='" + type + '\'' +
                ", rubricReference='" + rubricReference + '\'' +
                ", questionType='" + questionType + '\'' +
                ", questionAutomarkable=" + questionAutomarkable +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", scoreAutomarkable='" + scoreAutomarkable + '\'' +
                ", correctResponse='" + correctResponse + '\'' +
                '}';
    }



}