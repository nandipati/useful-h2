package com.hmhco.api.grading.mapper.viewmapper;

import com.hmhco.api.grading.entities.ActivityEntity;
import com.hmhco.api.grading.entities.ActivityItemScoreEntity;
import com.hmhco.api.grading.entities.ItemEntity;
import com.hmhco.api.grading.entities.QuestionEntity;
import com.hmhco.api.grading.entities.ScoreEntity;
import com.hmhco.api.grading.entities.readonly.ItemViewEntity;
import com.hmhco.api.grading.utils.ActivityItemsViewUtil;
import com.hmhco.api.grading.views.AbstractView;
import com.hmhco.api.grading.views.ActivityItemsView;
import com.hmhco.api.grading.views.ItemsView;
import com.hmhco.api.grading.views.QuestionsView;
import com.hmhco.api.grading.views.ScoresView;
import com.hmhco.api.grading.views.getresponse.ScoreExtnView;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by tallurir on 9/14/17.
 */

@Component
public class ActivityItemsViewMapper implements  SingleViewMapper<ActivityItemsView,ActivityEntity> {


    public ActivityItemsViewUtil convert(List<ItemViewEntity> itemViewEntityList, Boolean manualScoredRequired){

        Map<String, ItemsView> itemsViewMap = new HashMap<>();
        Map<String, QuestionsView> questionsViewMap = new HashMap<>();
        List<ScoreExtnView> scoreExtnViews = new ArrayList<>();
        ActivityItemsViewUtil activityItemsViewUtil = new ActivityItemsViewUtil();

        for(ItemViewEntity itemViewEntity : itemViewEntityList) {


            String scoreRef = itemViewEntity.getId().getScoreReference();
            String title = itemViewEntity.getTitle();
            String description = itemViewEntity.getDescription();
            Boolean automarkable = itemViewEntity.getScoreAutomarkable();
            String correctResponse = itemViewEntity.getCorrectResponse();
            ScoresView scoresView = new ScoresView();
            scoresView.setScoreReference(scoreRef);
            scoresView.setTitle(title);
            scoresView.setDescription(description);
            scoresView.setAutomarkable(automarkable);
            scoresView.setCorrectResponse(correctResponse);
            ScoreExtnView scoreExtnView = new ScoreExtnView();
            scoreExtnView.setScoreReference(scoreRef);
            scoreExtnView.setMaxScore(itemViewEntity.getScoreMaxScore());

            QuestionsView questionsView = null;

            if (!questionsViewMap.containsKey(itemViewEntity.getId().getQuestionReference())) {
                String quesRef = itemViewEntity.getId().getQuestionReference();
                String rubricRef = itemViewEntity.getRubricReference();
                String questionType = itemViewEntity.getQuestionType();
                Boolean questionAutomarkable = itemViewEntity.getQuestionAutomarkable();
                questionsView = new QuestionsView();
                questionsView.setQuestionReference(quesRef);
                questionsView.setRubricReference(rubricRef);
                questionsView.setQuestionType(questionType);
                questionsView.setAutomarkable(questionAutomarkable);
                questionsViewMap.put(quesRef, questionsView);

            } else {
                questionsView = questionsViewMap.get(itemViewEntity.getId().getQuestionReference());
            }


            if (questionsView.getScores() == null) {
                questionsView.setScores(new ArrayList<>());
            }
            List<ScoresView> scoresViewList = questionsView.getScores();

            if(!scoresViewList.contains(scoresView)) {
                scoresViewList.add(scoresView);
            }

            ItemsView itemsView = null;
            if (!itemsViewMap.containsKey(itemViewEntity.getId().getItemReference())) {
                String itemRef = itemViewEntity.getId().getItemReference();
                Integer organisationId = itemViewEntity.getOrganizationId();
                String itemPoolId = itemViewEntity.getItemPoolId();
                String type = itemViewEntity.getType();
                itemsView = new ItemsView();
                itemsView.setItemReference(itemRef);
                itemsView.setOrganizationId(organisationId);
                itemsView.setItemPoolId(itemPoolId);
                itemsView.setType(type);
                itemsView.setManualScoredRequired(manualScoredRequired);
                itemsViewMap.put(itemRef, itemsView);

            } else {
                itemsView = itemsViewMap.get(itemViewEntity.getId().getItemReference());
            }


            if (itemsView.getQuestions() == null) {
                itemsView.setQuestions(new ArrayList<>());
            }
            List<QuestionsView> questionViewList = itemsView.getQuestions();
            if(manualScoredRequired) {
                if (!questionViewList.contains(questionsView)) {
                    questionViewList.add(questionsView);
                }
                if(!questionsView.getAutomarkable())
                    scoreExtnViews.add(scoreExtnView);
            }
            else if(!manualScoredRequired){
                if(!questionViewList.contains(questionsView) && questionsView.getAutomarkable()){
                    questionViewList.add(questionsView);
                }
                if(questionsView.getAutomarkable())
                    scoreExtnViews.add(scoreExtnView);
            }
            else if(manualScoredRequired == null){
                if(questionViewList.contains(questionsView)){
                    questionViewList.add(questionsView);
                }
                scoreExtnViews.add(scoreExtnView);
            }

        }
        List<ItemsView> itemsViewList =  new ArrayList<>();

        Collection<ItemsView> tempList = itemsViewMap.values();

        for(ItemsView view:tempList) {

            itemsViewList.add(view);
        }
        activityItemsViewUtil.setItemsViews(itemsViewList.stream().filter(i-> !i.getQuestions().isEmpty()).collect(Collectors.toList()));
        activityItemsViewUtil.setScoreExtnViews(scoreExtnViews);
        return activityItemsViewUtil;
    }

    @Override
    public ActivityEntity convert(ActivityItemsView view) {
        return null;
    }

    @Override
    public boolean supports(Class<? extends AbstractView> clazz) {
        return false;
    }
}
