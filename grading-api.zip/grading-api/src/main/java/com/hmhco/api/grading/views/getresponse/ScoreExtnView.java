package com.hmhco.api.grading.views.getresponse;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.core.Relation;

/**
 * Created by nandipatim on 10/10/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("score-extn")
@Relation(value = "score-extn", collectionRelation = "scoresExtn")
public class ScoreExtnView {

    private String scoreReference;

    private Integer maxScore;

}
