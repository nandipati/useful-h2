package com.hmhco.api.grading.service;

import com.hmhco.api.grading.views.ActivityItemsView;

import java.util.UUID;

/**
 * Created by tallurir on 9/18/17.
 */
public  interface AssignmentService {

    ActivityItemsView getItemsByActivityId(UUID activityId, Boolean manualScoredRequired);
}
