package io.hmheng.reporting.aggregator.core.service.mds;

import io.hmheng.reporting.aggregator.core.service.idm.domain.IDMStudentStaffResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OnesearchItemResponse;
import org.junit.Assert;
import org.junit.Test;

import static io.hmheng.reporting.aggregator.core.service.mds.MDSServiceImpl.getGsonObject;

public class MdsParsingTest {
  @Test
  public void testOnesearchItemResponses() {
    String[] responses=new String[] { "{\n" +
        "    \"item\": [\n" +
        "        {\n" +
        "            \"identifier\": \"556638793_556642444\",\n" +
        "            \"lastModified\": \"2017-07-25T13:43:17.063145+00:00\",\n" +
        "            \"manuallyScorable\": \"false\",\n" +
        "            \"title\": {\n" +
        "                \"string\": \"<p><span style=\\\"font-weight:bold\\\">Part B</span></p><p><br /></p><p>Which detail from the passage BEST supports the reasoned judgment in Part A?</p>\"\n" +
        "            },\n" +
        "            \"depthOfKnowledge\": \"2\",\n" +
        "            \"printable\": \"true\",\n" +
        "            \"userId\": \"OneMDS\",\n" +
        "            \"questionCount\": \"2\",\n" +
        "            \"question\": [\n" +
        "                {\n" +
        "                    \"identifier\": \"556638793\",\n" +
        "                    \"interactivityType\": \"mcq\",\n" +
        "                    \"manuallyScorable\": \"false\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"identifier\": \"556642444\",\n" +
        "                    \"interactivityType\": \"mcq\",\n" +
        "                    \"manuallyScorable\": \"false\"\n" +
        "                }\n" +
        "            ],\n" +
        "            \"passage\": {\n" +
        "                \"identifier\": \"SP_37409_1\"\n" +
        "            },\n" +
        "            \"standardSet\": [\n" +
        "                {\n" +
        "                    \"name\": \"OneCMS_CC_CF6A375C-67AD-11DF-AB5F-995D9DFF4B22_LANG_2010.xml\",\n" +
        "                    \"region\": \"National\",\n" +
        "                    \"provider\": \"AB\",\n" +
        "                    \"standard\": [\n" +
        "                        {\n" +
        "                            \"id\": \"CCSS.ELA-Literacy.RH.6-8.8\",\n" +
        "                            \"guid\": \"2A5E898C-74F7-11DF-80DD-6B359DFF4B22\"\n" +
        "                        }\n" +
        "                    ]\n" +
        "                }\n" +
        "            ],\n" +
        "            \"program\": \"United States History\",\n" +
        "            \"poolId\": \"SS 2018 MS USH\"\n" +
        "        }\n" +
        "    ]\n" +
        "}",
    "{\n" +
        "    \"item\": [\n" +
        "        {\n" +
        "            \"identifier\": \"532991517\",\n" +
        "            \"lastModified\": \"2017-07-25T13:43:17.063145+00:00\",\n" +
        "            \"manuallyScorable\": \"false\",\n" +
        "            \"title\": \"<p>What do critics say will be an effect of globalization?</p>\",\n" +
        "            \"depthOfKnowledge\": \"1\",\n" +
        "            \"printable\": \"true\",\n" +
        "            \"userId\": \"OneMDS\",\n" +
        "            \"questionCount\": \"1\",\n" +
        "            \"question\": [\n" +
        "                {\n" +
        "                    \"identifier\": \"532991517\",\n" +
        "                    \"interactivityType\": \"mcq\",\n" +
        "                    \"manuallyScorable\": \"false\"\n" +
        "                }\n" +
        "            ],\n" +
        "            \"program\": \"United States History\",\n" +
        "            \"poolId\": \"SS 2018 MS USH\"\n" +
        "        }\n" +
        "    ]\n" +
        "}"};
    for(String response: responses) {
      OnesearchItemResponse gsonObject = getGsonObject(response, OnesearchItemResponse.class);
      Assert.assertNotNull(gsonObject.getFirstItem().getTitle());
    }
  }
  @Test
  public void idmParseTest() {
    String response="{\n" +
        "  \"staffPersons\" : [ {\n" +
        "    \"anies\" : [ ],\n" +
        "    \"refId\" : \"f7369560-6ed8-4785-a713-a6993920b131\",\n" +
        "    \"name\" : {\n" +
        "      \"nameOfRecord\" : {\n" +
        "        \"familyName\" : \"1AutoQA_G5_TAL\",\n" +
        "        \"givenName\" : \"1AutoQA_G5_TAF\",\n" +
        "        \"middleName\" : \"M\",\n" +
        "        \"anies\" : [ ]\n" +
        "      }\n" +
        "    },\n" +
        "    \"localId\" : {\n" +
        "      \"idValue\" : \"f73695606ed84785a713a6993920b131\"\n" +
        "    },\n" +
        "    \"externalId\" : {\n" +
        "      \"idValue\" : \"1AUTOQA_G5_TA\"\n" +
        "    },\n" +
        "    \"emailList\" : {\n" +
        "      \"emails\" : [ {\n" +
        "        \"emailAddress\" : \"1AutoQA_G5_TA@email.com\"\n" +
        "      } ]\n" +
        "    }\n" +
        "  } ]\n" +
        "}";
    IDMStudentStaffResponse resp = getGsonObject(response, IDMStudentStaffResponse.class);
    System.out.println(resp.getStaffPersons().length);
  }
}
