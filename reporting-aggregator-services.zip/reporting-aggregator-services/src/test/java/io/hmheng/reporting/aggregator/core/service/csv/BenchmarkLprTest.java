package io.hmheng.reporting.aggregator.core.service.csv;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkScore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.util.*;


import io.hmheng.reporting.aggregator.core.service.TestEventCloseServiceImpl;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Session;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Sessions;

/**
 * Created by suryadevarap on 7/25/16.
 */
//@RunWith(value = Parameterized.class)

public class BenchmarkLprTest {

    public BenchmarkLprTest() throws IOException {
    }

    private static final Logger logger = LoggerFactory.getLogger(BenchmarkLprTest.class);

    public static final String CONTENT_ELA = "ELA";
    public static final String CONTENT_MATH = "MATH";

    private static final String SCORE_TYPE_TOTALS = "T";

    private static final int SLOT_MATH_TOTALS = 12;
    private static final int SLOT_ELA_TOTALS = 8;

    // these 2 files were the latest files sent to Reserach
    //private static final String INPUT_CSV = "src/test/resources/csv/simulationCompleteTestCases_08-30-2016.csv";
    //private static final String OUTPUT_CSV = "src/test/resources/csv/simulationCompleteTestCases_08-30-2016WithLPR.csv";

    private static final String INPUT_CSV = "src/test/resources/csv/simulationCompleteTestCases.csv";
    private static final String OUTPUT_CSV = "src/test/resources/csv/simulationCompleteTestCasesWithLPR.csv";

    private static final int COLUMN_SESSION_ID = 1;
    private static final int COLUMN_ACTIVITY_ID = 2;

    private static final int COLUMN_GRADE = 10;
    private static final int COLUMN_LEVEL = 11;

    private static final int COLUMN_CONTENT = 9;
    private static final int COLUMN_SCALE_SCORE_1 = 133;
    private static final int COLUMN_SCALE_SCORE_2 = 142;
    private static final int COLUMN_SCALE_SCORE_3 = 151;
    private static final int COLUMN_SCALE_SCORE_4 = 160;
    private static final int COLUMN_SCALE_SCORE_5 = 169;
    private static final int COLUMN_SCALE_SCORE_6 = 178;
    private static final int COLUMN_SCALE_SCORE_7 = 187;
    private static final int COLUMN_SCALE_SCORE_8 = 196;
    private static final int COLUMN_SCALE_SCORE_9 = 205;
    private static final int COLUMN_SCALE_SCORE_10 = 214;
    private static final int COLUMN_SCALE_SCORE_11 = 223;
    private static final int COLUMN_SCALE_SCORE_12 = 232;
    private static final int COLUMN_SCALE_SCORE_13 = 241;
    private static final int COLUMN_SCALE_SCORE_14 = 250;

    private static final String COLUMN_NAME_LPR_SLOT_08 = "LPR_slot08";
    private static final String COLUMN_NAME_LPR_SLOT_12 = "LPR_slot12";

    @InjectMocks
    private TestEventCloseServiceImpl testEventCloseService = new TestEventCloseServiceImpl();

    @Test
    public void readCSVFile() throws IOException {
        String[] col = null;
        Map<String,BenchmarkActivityScoresResponse> sessionsToActivityMap = new HashMap<>();
        CSVReader reader = new CSVReader(new FileReader(INPUT_CSV));
        List<Session> sessionList = new ArrayList<>();
        int lineNumber = 0;
        while((col = reader.readNext()) != null) {
            logger.debug(String.format("Reading CSV row number %d", lineNumber));
            if(lineNumber == 0){
                lineNumber++;
                continue;
            }
            lineNumber++;
            UUID sessionId= UUID.fromString(col[COLUMN_SESSION_ID]);
            UUID actvityId= UUID.fromString(col[COLUMN_ACTIVITY_ID]);
            String content = col[COLUMN_CONTENT];
            String grade = col[COLUMN_GRADE];
            String level = col[COLUMN_LEVEL];
            String key = content + "_" + grade + "_" + level;

            List<String> scaleScoreList = new ArrayList<String>();
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_1]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_2]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_3]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_4]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_5]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_6]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_7]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_8]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_9]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_10]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_11]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_12]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_13]);
            scaleScoreList.add(col[COLUMN_SCALE_SCORE_14]);

            BenchmarkActivityScoresResponse resp =  new BenchmarkActivityScoresResponse();
            resp.setActivityId(actvityId);

            Sessions sessions = new Sessions();
            List<Session> contentList = new ArrayList<Session>();

            Session session = new Session();
            session.setActivityId(actvityId);
            session.setSessionId(sessionId);

            List<BenchmarkScore> scores = new ArrayList<BenchmarkScore>();

            for (int index=0; index<scaleScoreList.size(); index++) {
                String scaleScore = scaleScoreList.get(index);
                if (!scaleScore.equals("")) {
                    boolean isELATotal = content.equals(CONTENT_ELA) && (index == SLOT_ELA_TOTALS - 1);
                    boolean isMathTotal = content.equals(CONTENT_MATH) && (index == SLOT_MATH_TOTALS - 1);
                    if (isELATotal || isMathTotal) {
                        BenchmarkScore benchmarkScore = new BenchmarkScore();
                        benchmarkScore.setSessionId(sessionId);
                        benchmarkScore.setSlot(String.valueOf(index+1));
                        benchmarkScore.setScaleScore(Double.parseDouble(scaleScore));
                        benchmarkScore.setScoreType(SCORE_TYPE_TOTALS);
                        scores.add(benchmarkScore);
                    }
                }
            }

            session.setScores(scores);

            if (sessionsToActivityMap.containsKey(key)){
                BenchmarkActivityScoresResponse respExists = sessionsToActivityMap.get(key);
                respExists.getSessions().getContent().add(session);
            }
            else {
                contentList.add(session);
                sessions.setContent(contentList);
                resp.setSessions(sessions);
                sessionsToActivityMap.put(key,resp);
            }
        }
        reader.close();

        Map<String,Set<BenchmarkScore>> calculatedScoresMap = new HashMap<>();

        for (Map.Entry<String,BenchmarkActivityScoresResponse> entry : sessionsToActivityMap.entrySet()) {
            logger.debug(String.format("Calculating scores for %s", entry.getKey()));
            BenchmarkActivityScoresResponse activityScoresResponse = entry.getValue();
            if (activityScoresResponse != null) {
                Set<BenchmarkScore> activityCalculatedScores = testEventCloseService.getBenchmarkScores(activityScoresResponse);
                calculatedScoresMap.put(entry.getKey(), activityCalculatedScores);
            }
        }

        lineNumber = 0;
        reader = new CSVReader(new FileReader(INPUT_CSV));
        CSVWriter writer = new CSVWriter(new FileWriter(OUTPUT_CSV));

        while((col = reader.readNext()) != null) {
            logger.debug(String.format("Processing CSV row number %d", lineNumber));
            ArrayList<String> columnList = new ArrayList<String>(Arrays.asList(col));
            if (lineNumber == 0) {
                columnList.add(COLUMN_NAME_LPR_SLOT_08);
                columnList.add(COLUMN_NAME_LPR_SLOT_12);
                writer.writeNext(columnList.stream().toArray(String[]::new));
                lineNumber++;
                continue;
            }
            lineNumber++;
            UUID sessionId= UUID.fromString(col[COLUMN_SESSION_ID]);
            String content = col[COLUMN_CONTENT];
            String grade = col[COLUMN_GRADE];
            String level = col[COLUMN_LEVEL];
            String key = content + "_" + grade + "_" + level;

            Set<BenchmarkScore> calculatedScores = calculatedScoresMap.get(key);

            if (calculatedScores != null) {
                for (BenchmarkScore s : calculatedScores) {
                    if (s.getSessionId().equals(sessionId) && content.equals(CONTENT_ELA)) {
                        if (s.getScoreType().equals(SCORE_TYPE_TOTALS) && s.getSlot().equals(String.valueOf(SLOT_ELA_TOTALS))) {
                            String lprSlot08 = s.getLpr().toString();
                            columnList.add(lprSlot08);
                        }
                    }
                    if (s.getSessionId().equals(sessionId) && content.equals(CONTENT_MATH)) {
                        if (s.getSlot().equals(String.valueOf(SLOT_MATH_TOTALS)) && s.getScoreType().equals(SCORE_TYPE_TOTALS)) {
                            String lprSlot12 = s.getLpr().toString();
                            columnList.add("");
                            columnList.add(lprSlot12);
                        }
                    }
                }
            }
            writer.writeNext(columnList.stream().toArray(String[]::new));
        }
        reader.close();
        writer.close();
    }
}
