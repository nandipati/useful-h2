package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.util.Arrays;

import static org.junit.Assert.*;

/**
 * Created by suryadevarap on 12/19/17.
 */
@RunWith(Parameterized.class)
public class PerformanceLevelTest {


  @Parameters
  public static Iterable<Object[]> data() {
    return Arrays.asList(new Object[][] {
        { PerformanceLevel.MASTERED, 80.00,100.00, "Mastered" },
        { PerformanceLevel.NOT_MASTERED, 0.00,64.99, "Not Mastered"},
        { PerformanceLevel.PARTIALLY_MASTERED, 65.00,79.99, "Partially Mastered" },
    });
  }

  private PerformanceLevel enumValue;
  private Double lowerLimit;
  private Double upperLimit;
  private String expectedString;

  public PerformanceLevelTest(PerformanceLevel enumValue, Double lowerLimit,Double upperLimit, String expectedString) {
    this.enumValue = enumValue;
    this.upperLimit =upperLimit;
    this.lowerLimit = lowerLimit;
    this.expectedString = expectedString;
  }

  @Test
  public void testRange() {

    Double upper = this.enumValue.getUpperLimit();
    Double lower =  this.enumValue.getLowerLimit();
    assertEquals(lowerLimit,lower);
    assertEquals(upperLimit,upper);

  }

  @Test
  public void testTestType() {
    String result = this.enumValue.getName();
    assertEquals(expectedString, result);
  }

}
