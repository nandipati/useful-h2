package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.DemographicService;
import io.hmheng.reporting.aggregator.core.service.DemographicServiceImpl;
import io.hmheng.reporting.aggregator.core.service.arg.DemographicRequest;
import io.hmheng.reporting.aggregator.core.service.idm.IDMService;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentDemographicInformation;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceTopicName;
import io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils;
import io.hmheng.reporting.aggregator.web.handler.PlatformId;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static java.util.UUID.randomUUID;

/**
 * Created by Dare Famuyiwa on 24/05/2016.
 */
public class DemographicsTest {

	@Rule
	public MockitoRule mockitoRule = MockitoJUnit.rule();

	@InjectMocks
	private DemographicService demographicService = new DemographicServiceImpl();

	@Mock
	private ReportingService reportingService;

	@Mock
	private IDMService idmService;

	DemographicRequest demographicRequest;

	@Before
	public void setUp() throws Exception {
		UUID assignmentRef = randomUUID();
		UUID studentPersonalRefId = randomUUID();
		UUID eventRefId = randomUUID();
		String contextId = CommonMessageUtils.CONTEXT_HMOF;

		demographicRequest = new DemographicRequest(assignmentRef, studentPersonalRefId,
				eventRefId, contextId , null);
		demographicRequest.setSourceTopicName(SourceTopicName.testing_event_closed.name());
	}


	@Test
	public void whenHandleMultiValuedDemographics(){

		StudentDemographic.EthnicityList ethnicityList = new StudentDemographic.EthnicityList();
		List<StudentDemographic.Codable> codables = new ArrayList<>();
		StudentDemographic.Codable codableA = new StudentDemographic.Codable();
		codableA.setCode("0");
		StudentDemographic.Codable codableB = new StudentDemographic.Codable();
		codableB.setCode("1");
		StudentDemographic.Codable codableC = new StudentDemographic.Codable();
		codableC.setCode("3");
		codables.add(codableA);
		codables.add(codableB);
		codables.add(codableC);
		ethnicityList.setEthnicities(codables);

		StudentDemographic studentDemographic = generateStudentDemographic(Arrays.asList(new String[]{"1", "2"}),
				Arrays.asList(new String[]{"2", "3", "4"}), ethnicityList);
		when(idmService.getStudentDemographic(any(), any(), any())).thenReturn(studentDemographic);
		ArgumentCaptor<StudentDemographicInformation> studentDemographicInformation = ArgumentCaptor.forClass(StudentDemographicInformation.class);

		demographicService.handleDemographic(demographicRequest);

		verify(reportingService).publishStudentDemographicInfo(any(), any(), studentDemographicInformation.capture());
		StudentDemographicInformation demographicInfo = studentDemographicInformation.getValue();

		assert(demographicInfo.getContextId().equals(CommonMessageUtils.CONTEXT_HMOF));
		assert(demographicInfo.getSpecialConditionCodes().size() == 2);
		assert(demographicInfo.getSpecialConditionCodes().get(0).equals("1"));
		assert(demographicInfo.getSpecialConditionCodes().get(1).equals("2"));
		assert(demographicInfo.getSpecialServiceCodes().size() == 3);
		assert(demographicInfo.getSpecialServiceCodes().get(0).equals("2"));
		assert(demographicInfo.getSpecialServiceCodes().get(1).equals("3"));
		assert(demographicInfo.getSpecialServiceCodes().get(2).equals("4"));
		assert(demographicInfo.getEconomicStatusCode().equals("4"));
		assert(demographicInfo.getEthnicityCodes().size() == 3);
		assert(demographicInfo.getEthnicityCodes().get(0).equals("0"));
		assert(demographicInfo.getEthnicityCodes().get(1).equals("1"));
		assert(demographicInfo.getEthnicityCodes().get(2).equals("3"));
		assert(demographicInfo.getEnglishProficiencyCode().equals("3"));
		assert(demographicInfo.getFamilyName().equals("Foo"));
		assert(demographicInfo.getGivenName().equals("Bar"));
		assert(demographicInfo.getGender().equals("F"));
	}

	@Test
	public void whenHandleEmptyMultiValuedDemographics(){

		StudentDemographic.EthnicityList ethnicityList = new StudentDemographic.EthnicityList();
		List<StudentDemographic.Codable> codables = new ArrayList<>();
		StudentDemographic.Codable codableA = new StudentDemographic.Codable();
		codableA.setCode("0");
		StudentDemographic.Codable codableB = new StudentDemographic.Codable();
		codableB.setCode("1");
		StudentDemographic.Codable codableC = new StudentDemographic.Codable();
		codableC.setCode("3");
		codables.add(codableA);
		codables.add(codableB);
		codables.add(codableC);
		ethnicityList.setEthnicities(codables);

		StudentDemographic studentDemographic = generateStudentDemographic(null,
				null, ethnicityList);
		when(idmService.getStudentDemographic(any(), any(), any())).thenReturn(studentDemographic);
		ArgumentCaptor<StudentDemographicInformation> studentDemographicInformation = ArgumentCaptor.forClass(StudentDemographicInformation.class);

		demographicService.handleDemographic(demographicRequest);

		verify(reportingService).publishStudentDemographicInfo(any(), any(), studentDemographicInformation.capture());
		StudentDemographicInformation demographicInfo = studentDemographicInformation.getValue();

		assert(demographicInfo.getContextId().equals(CommonMessageUtils.CONTEXT_HMOF));
		assert(demographicInfo.getSpecialConditionCodes() == null);
		assert(demographicInfo.getSpecialServiceCodes() == null);
		assert(demographicInfo.getEconomicStatusCode().equals("4"));
		assert(demographicInfo.getEthnicityCodes().size() == 3);
		assert(demographicInfo.getEthnicityCodes().get(0).equals("0"));
		assert(demographicInfo.getEthnicityCodes().get(1).equals("1"));
		assert(demographicInfo.getEthnicityCodes().get(2).equals("3"));
		assert(demographicInfo.getEnglishProficiencyCode().equals("3"));
		assert(demographicInfo.getFamilyName().equals("Foo"));
		assert(demographicInfo.getGivenName().equals("Bar"));
		assert(demographicInfo.getGender().equals("F"));
	}

	@Test
	public void whenHandleEmptyValuedDemographics(){

		StudentDemographic.EthnicityList ethnicityList = new StudentDemographic.EthnicityList();
		List<StudentDemographic.Codable> codables = new ArrayList<>();
		ethnicityList.setEthnicities(codables);

		StudentDemographic studentDemographic = generateStudentDemographic(Arrays.asList(new String[]{}),
				Arrays.asList(new String[]{}), ethnicityList);
		when(idmService.getStudentDemographic(any(), any(), any())).thenReturn(studentDemographic);
		ArgumentCaptor<StudentDemographicInformation> studentDemographicInformation = ArgumentCaptor.forClass(StudentDemographicInformation.class);

		demographicService.handleDemographic(demographicRequest);

		verify(reportingService).publishStudentDemographicInfo(any(), any(), studentDemographicInformation.capture());
		StudentDemographicInformation demographicInfo = studentDemographicInformation.getValue();

		assert(demographicInfo.getContextId().equals(CommonMessageUtils.CONTEXT_HMOF));
		assert(demographicInfo.getSpecialConditionCodes().size() == 0);
		assert(demographicInfo.getSpecialServiceCodes().size() == 0);
		assert(demographicInfo.getEthnicityCodes() == null);
		assert(demographicInfo.getEconomicStatusCode().equals("4"));
		assert(demographicInfo.getEnglishProficiencyCode().equals("3"));
		assert(demographicInfo.getFamilyName().equals("Foo"));
		assert(demographicInfo.getGivenName().equals("Bar"));
		assert(demographicInfo.getGender().equals("F"));
	}

	@Test
	public void whenHandleSingleValuedDemographics(){

		StudentDemographic.EthnicityList ethnicityList = new StudentDemographic.EthnicityList();
		List<StudentDemographic.Codable> codables = new ArrayList<>();
		StudentDemographic.Codable codable = new StudentDemographic.Codable();
		codable.setCode("4");
		codables.add(codable);
		ethnicityList.setEthnicities(codables);

		StudentDemographic studentDemographic = generateStudentDemographic(Arrays.asList(new String[]{"1"}),
				Arrays.asList(new String[]{"2"}), ethnicityList);
		when(idmService.getStudentDemographic(any(), any(),any())).thenReturn(studentDemographic);
		ArgumentCaptor<StudentDemographicInformation> studentDemographicInformation = ArgumentCaptor.forClass(StudentDemographicInformation.class);

		demographicService.handleDemographic(demographicRequest);

		verify(reportingService).publishStudentDemographicInfo(any(), any(), studentDemographicInformation.capture());
		StudentDemographicInformation demographicInfo = studentDemographicInformation.getValue();

		assert(demographicInfo.getContextId().equals(CommonMessageUtils.CONTEXT_HMOF));
		assert(demographicInfo.getSpecialConditionCodes().size() == 1);
		assert(demographicInfo.getSpecialConditionCodes().get(0).equals("1"));
		assert(demographicInfo.getSpecialServiceCodes().size() == 1);
		assert(demographicInfo.getSpecialServiceCodes().get(0).equals("2"));
		assert(demographicInfo.getEthnicityCodes().size() == 1);
		assert(demographicInfo.getEthnicityCodes().get(0).equals("4"));
		assert(demographicInfo.getEnglishProficiencyCode().equals("3"));
		assert(demographicInfo.getEconomicStatusCode().equals("4"));
		assert(demographicInfo.getFamilyName().equals("Foo"));
		assert(demographicInfo.getGivenName().equals("Bar"));
		assert(demographicInfo.getGender().equals("F"));
	}

	private StudentDemographic generateStudentDemographic(List<String> specialConditions,
														  List<String> specialServices,
														  StudentDemographic.EthnicityList ethnicityList){
		StudentDemographic studentDemographic = new StudentDemographic();
		studentDemographic.setRefId(randomUUID());
		StudentDemographic.Demographics demographics = new StudentDemographic.Demographics();
		demographics.setSexus("F");
		demographics.setLanguageProficiency("3");

		List<StudentDemographic.IDMDemographicsAny> idmDemographicsAnies = new ArrayList<>(1);
		StudentDemographic.IDMDemographicsAny any = new StudentDemographic.IDMDemographicsAny();
		any.setEconomicStatus("4");
		any.setSpecialConditions(specialConditions);
		any.setSpecialServices(specialServices);
		idmDemographicsAnies.add(any);

		demographics.setEthnicityList(ethnicityList);
		demographics.setAnies(idmDemographicsAnies);
		demographics.setBirthDate("10/10/2001");

		studentDemographic.setDemographics(demographics);
		StudentDemographic.Disability disability = new StudentDemographic.Disability();
		disability.setIdeaenvironment(new StudentDemographic.Codable());
		disability.setPrimaryDisability(new StudentDemographic.Codable());
		studentDemographic.setDisability(disability);

		studentDemographic.setEconomicDisadvantage("Yes");

		StudentDemographic.LocalId localId = new StudentDemographic.LocalId();
		localId.setIdValue(randomUUID().toString());
		studentDemographic.setLocalId(localId);

		StudentDemographic.Name name = new StudentDemographic.Name();
		StudentDemographic.NameOfRecord nameOfRecord = new StudentDemographic.NameOfRecord();
		nameOfRecord.setFamilyName("Foo");
		nameOfRecord.setGivenName("Bar");
		name.setNameOfRecord(nameOfRecord);
		studentDemographic.setName(name);

		return studentDemographic;
	}
}
