package io.hmheng.reporting.aggregator.core.service.idm.domain;

import io.hmheng.reporting.aggregator.core.service.utils.GenericBeanCoverage;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by Dare Famuyiwa on 24/05/2016.
 */
public class StudentDemographicTest {

	@Test
	public void testGettersAndSetters() throws InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		GenericBeanCoverage.doBeanCodeCoverage(StudentDemographic.class);
	}
}
