package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import com.fasterxml.jackson.core.type.TypeReference;

import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.util.Assert;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import io.hmheng.reporting.aggregator.core.service.reporting.ReportingRouteBuilder;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingServiceImpl;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemBase;
import io.hmheng.reporting.aggregator.core.service.utils.GenericBeanCoverage;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;

import static io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils.objectMapper;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * Created by Dare Famuyiwa on 25/05/2016.
 */
public class StudentDemographicInformationTest {
	@Rule
	 public MockitoRule mockitoRule = MockitoJUnit.rule();

	@Mock
	ProducerTemplate producerTemplate;

	@Mock
	HeadersHelper headersHelper=new HeadersHelper();

	@InjectMocks
	ReportingService reportingService=new ReportingServiceImpl();

	private String json="[{\"itemRefId\":\"471949147\",\"itemName\":\"Item 5\",\"questionType\":\"mcq\","
			+ "\"depthOfKnowledge\":\"1\",\"manuallyScorable\":\"true\",\"standards\":[{\"id\":\"LA.8.L.1\",\"type\":\"AB\","
			+ "\"abguids\":{\"abguid\":\"1D9C5354-9892-11E0-8388-5F489DFF4B22\"}},{\"id\":\"LA.8.CCSS.L.8.1\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"81168A66-7440-11DF-93FA-01FD9CFF4B22\"}}]},{\"itemRefId\":\"471899109\",\"itemName\":\"Item 2\",\"questionType\":\"mcq,passage\",\"depthOfKnowledge\":\"2\",\"standards\":[{\"id\":\"LA.8.RI.5\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"1D71D94E-9892-11E0-8388-5F489DFF4B22\"}},{\"id\":\"LA.8.CCSS.RI.8.5\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"81001556-7440-11DF-93FA-01FD9CFF4B22\"}}]},{\"itemRefId\":\"471946172\",\"itemName\":\"Item 4\",\"questionType\":\"mcq\",\"depthOfKnowledge\":\"3\",\"standards\":[{\"id\":\"LA.8.W.2.f\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"1D81CE94-9892-11E0-8388-5F489DFF4B22\"}},{\"id\":\"LA.8.CCSS.W.8.2f\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"8108F3E2-7440-11DF-93FA-01FD9CFF4B22\"}}]},{\"itemRefId\":\"471913354\",\"itemName\":\"Item 3\",\"questionType\":\"mcq,passage\",\"depthOfKnowledge\":\"2\",\"standards\":[{\"id\":\"LA.8.L.4.a\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"1DA6BC5E-9892-11E0-8388-5F489DFF4B22\"}},{\"id\":\"LA.8.CCSS.RI.8.4\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"80FF9BB2-7440-11DF-93FA-01FD9CFF4B22\"}},{\"id\":\"LA.8.CCSS.L.8.4a\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"811D39BA-7440-11DF-93FA-01FD9CFF4B22\"}},{\"id\":\"LA.8.RI.4\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"45172084-995B-11E0-AB37-AD0A9DFF4B22\"}}]},{\"itemRefId\":\"471898172\",\"itemName\":\"Item 1\",\"questionType\":\"mcq,passage\",\"depthOfKnowledge\":\"2\",\"standards\":[{\"id\":\"LA.8.CCSS.RI.8.2\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"80FEA6A8-7440-11DF-93FA-01FD9CFF4B22\"}},{\"id\":\"LA.8.RI.2\",\"type\":\"AB\",\"abguids\":{\"abguid\":\"1D6F1F7E-9892-11E0-8388-5F489DFF4B22\"}}]}]";
	@Test
	public void testGettersAndSetters() throws InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		GenericBeanCoverage.doBeanCodeCoverage(StudentDemographicInformation.class);
	}

	@Before
	public void setup() {

	}
	@Test
	public void testDeserializeFromCache() {
		when(producerTemplate.requestBodyAndHeaders(eq(ReportingRouteBuilder.getCachedObjectEndpoint),any(), any(), any())).thenReturn(json);
		ArrayList cached=null;
		try {
			cached=objectMapper().readValue(json, new TypeReference<ArrayList<AssignmentItemBase>>() {});
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(cached);
		ArrayList cachedObject = reportingService.getCachedObject("70737758-1931-38d5-80c1-d9e2ee3a6bdf", new TypeReference<ArrayList<AssignmentItemBase>>() {});
		Assert.isTrue(cachedObject.size()==5);
	}
}
