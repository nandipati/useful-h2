package io.hmheng.reporting.aggregator.core.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.hmheng.reporting.aggregator.core.service.ClassSummaryInfoService;
import io.hmheng.reporting.aggregator.core.service.ClassSummaryInfoServiceImpl;
import io.hmheng.reporting.aggregator.core.service.arg.ClassSummaryInfoRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentClassSummaryInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoringService;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentTotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.FormativeActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Session;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Sessions;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static io.hmheng.reporting.aggregator.core.service.scoring.domain.ItemResponse.CORRECT;
import static java.util.UUID.randomUUID;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ClassSummaryInfoTest {
    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @InjectMocks
    private ClassSummaryInfoService classSummaryInfoService = new ClassSummaryInfoServiceImpl();

    @Mock
    private ScoringService scoringService;

    @Mock
    private ReportingService reportingService;


    @Test
    public void whenHandleClassSummaryInfoExecutes(){
        UUID activityId = randomUUID();
        UUID sectionId = randomUUID();
        UUID eventId = randomUUID();
        int numberOfStudents = 4;
        StudentSessionScores classSummaryInfoRequest = new StudentSessionScores();
        classSummaryInfoRequest.setActivityId(activityId);
        classSummaryInfoRequest.setEventType(TestType.FORMATIVE);
        FormativeActivityScoresResponse formativeActivityScoresResponse = createFormativeActivityScoresResponse();
        when(scoringService.getFormativeActivityScores(any())).thenReturn(formativeActivityScoresResponse);
        ArgumentCaptor<AssignmentClassSummaryInfo> classSummaryInfoArgumentCaptor = ArgumentCaptor.forClass(AssignmentClassSummaryInfo.class);

        classSummaryInfoService.handleClassSummaryInfo(classSummaryInfoRequest);

        verify(reportingService).publishClassSummaryInfo(any(),classSummaryInfoArgumentCaptor.capture());
        AssignmentClassSummaryInfo assignmentClassSummaryInfo = classSummaryInfoArgumentCaptor.getValue();

        assert(assignmentClassSummaryInfo.getStudentIncludedCount() == numberOfStudents);
        assert((assignmentClassSummaryInfo.getAdvancedStudentsCount() +
                assignmentClassSummaryInfo.getProficientStudentsCount() +
                assignmentClassSummaryInfo.getBasicStudentsCount() +
                assignmentClassSummaryInfo.getBelowBasicStudentsCount() +
                assignmentClassSummaryInfo.getFarBelowBasicStudentsCount() == numberOfStudents));
        assert((assignmentClassSummaryInfo.getAdvancedStudentsPercentage() +
                assignmentClassSummaryInfo.getProficientStudentsPercentage() +
                assignmentClassSummaryInfo.getBasicStudentsPercentage() +
                assignmentClassSummaryInfo.getBelowBasicStudentsPercentage() +
                assignmentClassSummaryInfo.getFarBelowBasicStudentsPercentage() == 1.0));
    }

    private FormativeActivityScoresResponse createFormativeActivityScoresResponse() {
        FormativeActivityScoresResponse formativeActivityScoresResponse = new FormativeActivityScoresResponse();
        Sessions sessions = new Sessions();
        List<Session> content = new ArrayList<>();
        UUID activityId = randomUUID();
        String status = "completed";

        while(content.size() < 4){
            content.add(generateSession(activityId,status));
        }

        formativeActivityScoresResponse.setActivityId(activityId);
        formativeActivityScoresResponse.setEventType("formative");
        formativeActivityScoresResponse.setStatus(status);
        sessions.setContent(content);
        formativeActivityScoresResponse.setSessions(sessions);

        return formativeActivityScoresResponse;
    }

    private Session generateSession(UUID activityId, String status) {
        Session session = new Session();
        UUID sessionId = randomUUID();
        UUID studentPersonRefId = randomUUID();
        List<AssignmentItemScore> itemScores = new ArrayList<>();
        AssignmentTotalScore assignmentTotalScore = new AssignmentTotalScore();

        while(itemScores.size() < 4){
            itemScores.add(generateItemScore(sessionId));
        }

        assignmentTotalScore.setItemsCorrect(5);
        assignmentTotalScore.setPointsCorrect(5);
        assignmentTotalScore.setSessionId(sessionId);
        assignmentTotalScore.setTotalAttainedPoints(10);
        assignmentTotalScore.setTotalItems(30);
        assignmentTotalScore.setTotalPoints(30);
        assignmentTotalScore.setTotalProficiencyScore(Math.random()/1.0);

        session.setSessionId(sessionId);
        session.setActivityId(activityId);
        session.setTotalScore(assignmentTotalScore);
        session.setItemScores(itemScores);
        session.setStatus(status);
        session.setStudentPersonRefId(studentPersonRefId);
        return session;
    }

    private AssignmentItemScore generateItemScore(UUID sessionId) {
        AssignmentItemScore assignmentItemScore = new AssignmentItemScore();
        assignmentItemScore.setItemRefId("1111");
        assignmentItemScore.setSessionId(sessionId);
        assignmentItemScore.setItemScore(1);
        assignmentItemScore.setItemMaxScore(1);
        assignmentItemScore.setItemProficiencyScore(1.0);
        assignmentItemScore.setItemResponse(CORRECT);
        return assignmentItemScore;
    }
}
