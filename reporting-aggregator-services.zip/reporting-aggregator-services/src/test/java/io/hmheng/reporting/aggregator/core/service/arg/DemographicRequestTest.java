package io.hmheng.reporting.aggregator.core.service.arg;

import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic;
import io.hmheng.reporting.aggregator.core.service.utils.GenericBeanCoverage;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by Dare Famuyiwa on 27/06/2016.
 */
public class DemographicRequestTest {
	@Test
	public void testGettersAndSetters() throws InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		GenericBeanCoverage.doBeanCodeCoverage(DemographicRequest.class);
	}
}
