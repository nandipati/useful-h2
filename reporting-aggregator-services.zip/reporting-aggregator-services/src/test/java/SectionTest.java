import io.hmheng.reporting.aggregator.core.service.idm.domain.Section;
import io.hmheng.reporting.aggregator.core.service.idm.domain.YearGroup;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by nandipatim on 5/23/16.
 */
public class SectionTest {

    @Test
    public void testGrade(){
        Section section = new Section();
        YearGroup yearGroup = new YearGroup();
        yearGroup.setCode("0K");
        section.setYearGroup(yearGroup);

        assertEquals("K", section.getGrade());

        yearGroup = new YearGroup();
        yearGroup.setCode("1");
        section.setYearGroup(yearGroup);

        assertEquals("01", section.getGrade());

        yearGroup = new YearGroup();
        yearGroup.setCode("10");
        section.setYearGroup(yearGroup);

        assertEquals("10", section.getGrade());

        yearGroup = new YearGroup();
        yearGroup.setCode("K0");
        section.setYearGroup(yearGroup);

        assertEquals("K", section.getGrade());
    }
}
