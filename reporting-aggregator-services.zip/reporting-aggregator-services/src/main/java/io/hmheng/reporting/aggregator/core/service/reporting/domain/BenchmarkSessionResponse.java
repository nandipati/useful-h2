package io.hmheng.reporting.aggregator.core.service.reporting.domain;

/**
 * Created by pabonaj on 11/18/16.
 */
public class BenchmarkSessionResponse {

    private BenchmarkSessions benchmarkSessions;

    public BenchmarkSessions getBenchmarkSessions() {
        return benchmarkSessions;
    }

    public void setBenchmarkSessions(BenchmarkSessions benchmarkSessions) {
        this.benchmarkSessions = benchmarkSessions;
    }

}
