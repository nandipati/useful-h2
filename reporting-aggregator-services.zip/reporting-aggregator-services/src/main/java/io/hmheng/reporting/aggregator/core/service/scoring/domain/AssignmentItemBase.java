package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.google.gson.annotations.Expose;

import java.util.Set;

import io.hmheng.reporting.aggregator.core.service.mds.domains.Standard;

/**
 * Created by Ron on 9/9/2016.
 */
public class AssignmentItemBase {
    private String itemRefId;
    private String itemName;
    @Expose
    private String cognitiveDifficulty;
    @Expose
    private String bloomTaxonomy;
    @Expose
    private String questionType;
    @Expose
    private String depthOfKnowledge;
    @Expose
    private String manuallyScorable;
    @Expose
    private Integer sequenceNumber;
    @Expose
    private Integer itemNumber;


    @Expose
    private Set<Standard> standards;
    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCognitiveDifficulty() {
        return cognitiveDifficulty;
    }

    public void setCognitiveDifficulty(String cognitiveDifficulty) {
        this.cognitiveDifficulty = cognitiveDifficulty;
    }

    public String getBloomTaxonomy() {
        return bloomTaxonomy;
    }

    public void setBloomTaxonomy(String bloomTaxonomy) {
        this.bloomTaxonomy = bloomTaxonomy;
    }

    public String getQuestionType() {
        return questionType;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public String getDepthOfKnowledge() {
        return depthOfKnowledge;
    }

    public void setDepthOfKnowledge(String depthOfKnowledge) {
        this.depthOfKnowledge = depthOfKnowledge;
    }

    public String getManuallyScorable() {
      return manuallyScorable;
    }

    public void setManuallyScorable(String manuallyScorable) {
      this.manuallyScorable = manuallyScorable;
    }

    public Set<Standard> getStandards() {
        return standards;
    }

    public void setStandards(Set<Standard> standards) {
        this.standards = standards;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public Integer getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(Integer itemNumber) {
        this.itemNumber = itemNumber;
    }

    public AssignmentItemBase getBaseCopy() {
        AssignmentItemBase ib=new AssignmentItemBase();
        ib.setItemRefId(this.getItemRefId());
        ib.setItemName(this.getItemName());
        ib.setCognitiveDifficulty(this.getCognitiveDifficulty());
        ib.setBloomTaxonomy(this.getBloomTaxonomy());
        ib.setQuestionType(this.getQuestionType());
        ib.setDepthOfKnowledge(this.getDepthOfKnowledge());
        ib.setStandards(this.getStandards());
        ib.setSequenceNumber(this.getSequenceNumber());
        ib.setItemNumber(this.itemNumber);
        return ib;
    }
}
