package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentEventInfo;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardToItems;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsPerformance;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsToItemsMapInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentScoreInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScoreInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScoreRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.Subscore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoreHelper;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoringService;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentTotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Session;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StandardSession;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import io.hmheng.reporting.aggregator.utils.ContentSource;
import io.hmheng.reporting.aggregator.utils.JsonDateTimeHelper;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

/**
 * Created by nandipatim on 3/4/16.
 */
@Component
public class StudentSessionScoresServiceImpl implements StudentSessionScoresService {

    private static final Logger logger = LoggerFactory.getLogger(StudentSessionScoresServiceImpl.class);

    @Autowired
    private ScoringService scoringService;

    @Autowired
    private ReportingService reportingService;

    @Autowired
    private ScoreHelper scoreHelper;

    @Autowired
    private JsonDateTimeHelper jsonDateTimeHelper;

    public void handleStudentSessionScores(StudentSessionScores studentSessionScoresResponse){
        if (TestType.BENCHMARK == studentSessionScoresResponse.getEventType()) {
            postBenchmarkScoresToReporting(studentSessionScoresResponse);
            postTestEventUpdateToReporting(studentSessionScoresResponse );
        }else if(EnumUtils.isValidEnum(TestType.class , studentSessionScoresResponse.getEventType().name())) {
            postAssignmentScoresToReporting(studentSessionScoresResponse);
        }else
            throw new IllegalArgumentException("Not a Supported SourceType "+studentSessionScoresResponse.getEventType());

    }

    public void handleStandardSessionScores(StandardSession standardSessionScores) {
        postStandardScoresToReporting(standardSessionScores);
    }

    private void postBenchmarkScoresToReporting(StudentSessionScores studentSessionScoresResponse){

        Session session = studentSessionScoresResponse.getSession();

      if(studentSessionScoresResponse.getSession() == null ||  CollectionUtils.isEmpty(studentSessionScoresResponse.getSession().getScores()))
            throw new ApplicationException("Benchmark Scores cannot be Null or missing for ActivityForScores: "+studentSessionScoresResponse.getActivityId()
                +" and Session: "+session.getSessionId()+" in Scoring");

        List<BenchmarkScore> benchmarkScores = session.getScores();
        if(!CollectionUtils.isEmpty(benchmarkScores)) {
            List<Subscore> subscores = new ArrayList<Subscore>();
            TotalScore totalScore = null;
            for(BenchmarkScore  benchmarkScore :benchmarkScores){
                if("T".equals(benchmarkScore.getScoreType())) {
                  benchmarkScore.setSkippedQuestions(session.isSkippedQuestions());
                  benchmarkScore.setItemsOmitted(session.isItemsOmitted());
                  benchmarkScore.setCompletionCriteriaNotMet(session.isCompletionCriteriaNotMet());
                  benchmarkScore.setInCompleteTestRecord(session.isInCompleteTestRecord());
                  totalScore = scoreHelper.convertScoreIntoTotalScore(benchmarkScore);
                }
                else
                    subscores.add(scoreHelper.convertScoreIntoSubScore(benchmarkScore));
            }

            if(totalScore != null)
                totalScore.setStudentSubScores(subscores);

            reportingService.publishBenchmarkStudentScores( studentSessionScoresResponse.getActivityId()
            ,session.getSessionId() , session.getStudentPersonRefId(), totalScore);
        }
    }

    private void postAssignmentScoresToReporting(StudentSessionScores studentSessionScoresResponse){

        logger.info("+postAssignmentScoresToReporting {}", studentSessionScoresResponse);

        Session session = studentSessionScoresResponse.getSession();

      if(studentSessionScoresResponse.getSession() == null || CollectionUtils.isEmpty(studentSessionScoresResponse.getSession().getItemScores()))
            throw new ApplicationException("Formative Item Scores cannot be Null or empty for ActivityForScores: "+studentSessionScoresResponse.getActivityId()
                +" and Session: "+session.getSessionId()+" in Scoring");

        if(studentSessionScoresResponse.getSession() == null || studentSessionScoresResponse.getSession().getTotalScore() == null)
            throw new ApplicationException("Formative Total Scores cannot be Null for ActivityForScores: "+studentSessionScoresResponse.getActivityId()
                +" and Session: "+session.getSessionId()+" in Scoring");

        final TestType testType=studentSessionScoresResponse.getEventType();
        AssignmentTotalScore assignmentTotalScore = session.getTotalScore();
        List<AssignmentItemScore> assignmentItemScores = session.getItemScores();

        AssignmentStudentScoreInfo studentScoreInfo = new AssignmentStudentScoreInfo();
        studentScoreInfo.setTestType(studentSessionScoresResponse.getEventType());
        ContentSource contentSource =  studentSessionScoresResponse.getEventType().getSourceObjectType().getContentSource();

        logger.info("calling getStandardsToItemsMapInfo {}", studentSessionScoresResponse.getSession().getSessionId());

        List<ActivityStandardsPerformance>  standardsPerformances = reportingService.getStandardsToItemsMapInfo(
                studentSessionScoresResponse.getActivityId());
        AtomicBoolean hasStandardSets=new AtomicBoolean(false);
        AtomicBoolean hasInvalidSequence=new AtomicBoolean(false);
        if(standardsPerformances!=null) {
            standardsPerformances.forEach(t -> {
                hasStandardSets.set(t.getStandardSet() != null || hasStandardSets.get());
                hasInvalidSequence.set(t.getItems().stream().anyMatch(aip -> aip.getSequenceNumber() == -1) || hasInvalidSequence.get());
            });
        }
        if(contentSource==ContentSource.ONE_SEARCH && !hasStandardSets.get() || hasInvalidSequence.get()) {
        logger.info("Reached ContentSource of ONE_SEARCH, Standards are consumed from scoring Queue as part of new feature ");
        }
        try {
            logger.info("retrieving names for scores {}", studentSessionScoresResponse.getSession().getSessionId());

            List<AssignmentItemScore> assignmentItemScoresCopy = scoreHelper.populateItemNamesForScores(
                assignmentItemScores , testType , scoreHelper.getItemsMap(standardsPerformances));
            studentScoreInfo.setActivityItemScores(assignmentItemScoresCopy);

        }catch (CloneNotSupportedException cns){
            throw new ApplicationException("Issue while cloning Object -->" , cns);
        }


        if(assignmentTotalScore == null) {
            throw new ApplicationException("Assignment Total Scores cannot be null");
        }

        logger.info("retrieving assignment total score info {}", studentSessionScoresResponse.getSession().getSessionId());
        studentScoreInfo.setActivityTotalScore(scoreHelper.getAssignmentTotalScoreInfo(assignmentTotalScore,
                studentSessionScoresResponse.getEventType()));

        if(studentScoreInfo.getActivityTotalScore() == null)
            throw new ApplicationException("Assignment Total Scores cannot be null");

        Future<?> activityTask=backgroundExecutor.submit(() -> {

            logger.info("calling reporting to publish student scores {}", studentSessionScoresResponse.getSession().getSessionId());
            //TODO: Remove retry logic once handle failures in Parallel Tasks
            reportingService.publishAssignmentStudentScores(studentSessionScoresResponse.getActivityId()
                ,session.getStudentPersonRefId() , session.getSessionId() , studentScoreInfo , ReportingService.NO_OF_RETRY);

        });

        //TODO: Remove retry logic when there failures posting to reporting.
        final List<ActivityStandardsPerformance> finalStandardsPerformances = standardsPerformances;

        Future<?> standardsTask = backgroundExecutor.submit(() -> {
            List<StandardToItems> standards=null;
            if( contentSource == ContentSource.MDS) {
                logger.info("retrieving standards {}", studentSessionScoresResponse.getSession().getSessionId());
                standards = scoreHelper.getStandardsForItems(assignmentItemScores, studentSessionScoresResponse.getActivityId());
                processStandardScoresforMDS(studentSessionScoresResponse, session, testType, standards, contentSource , finalStandardsPerformances);
            } else if(contentSource == ContentSource.ONE_SEARCH){
             logger.info("Reached ContentSource of ONE_SEARCH, Standards are consumed from scoring Queue as part of new feature ");
            } else {
                throw new IllegalArgumentException("Not valid contentSource :"+contentSource);
            }
        });

        Future<?>[] tasks = {standardsTask, activityTask};
        for(Future<?> task : tasks) {
            try {
                task.get();
            } catch(Exception e) {
                throw new RuntimeException(e);
            }

        }

        logger.info("-postAssignmentScoresToReporting {}", studentSessionScoresResponse);
    }


    private void postStandardScoresToReporting(StandardSession standardSessionScores) {
        ActivityStandardsToItemsMapInfo activityStandardsToItemsMapInfo = scoreHelper.getStandardsAndItemsFromScoringQueue(standardSessionScores);
      reportingService.publishAssignmentStandardPerformance(standardSessionScores.getActivityId(),activityStandardsToItemsMapInfo);
    }

    private AssignmentStudentStandardScoreRequest getAssignmentStudentStandardScoreRequest(StudentSessionScores studentSessionScoresResponse,
                                             List<AssignmentStudentStandardScore> studentStandardScores) {
        AssignmentStudentStandardScoreRequest assignmentStudentStandardScoreRequest = new AssignmentStudentStandardScoreRequest();
        AssignmentStudentStandardScoreInfo assignmentStudentStandardScoreInfo = new AssignmentStudentStandardScoreInfo();
        assignmentStudentStandardScoreInfo.setActivityStandardScores(studentStandardScores);
        assignmentStudentStandardScoreInfo.setSessionId(studentSessionScoresResponse.getSession().getSessionId());
        assignmentStudentStandardScoreInfo.setTestType(studentSessionScoresResponse.getEventType());
        assignmentStudentStandardScoreRequest.setAssignmentStudentStandardScoreInfo(assignmentStudentStandardScoreInfo);
        return assignmentStudentStandardScoreRequest;
    }

    private void processStandardScoresforMDS(StudentSessionScores studentSessionScoresResponse, Session session,
        TestType testType, List<StandardToItems> standards, ContentSource contentSource ,
        List<ActivityStandardsPerformance>  standardsPerformances) {
        if (!CollectionUtils.isEmpty(standards)) {
                AssignmentStudentStandardScoreRequest assignmentStudentStandardScoreInfo =
                    scoreHelper.getStandardAssignmentScores(standards, session.getSessionId(), studentSessionScoresResponse.getEventType());

                logger.info("About to call Reporting Services pusblishAssignmentStandardScores endpoint");
                reportingService.pusblishAssignmentStandardScores(studentSessionScoresResponse.getActivityId()
                    , session.getStudentPersonRefId(), assignmentStudentStandardScoreInfo);

                if(CollectionUtils.isEmpty(standardsPerformances)) {
                    scoreHelper.populateStandardDescription(standards.stream().map(StandardToItems::getStandard).collect(Collectors.toList()), testType);

                    logger.info("Standards to be sent to Reporting");
                    for (StandardToItems std : standards) {
                        String standardString = ToStringBuilder.reflectionToString(std, ToStringStyle.MULTI_LINE_STYLE);
                        logger.info("Standard: {}", standardString);
                    }

                     ActivityStandardsToItemsMapInfo saveActivityPerformanceInfo = scoreHelper.calculateStandardPerformance(standards
                                , studentSessionScoresResponse.getEventType());

                     logger.info("About to call Reporting Services publishAssignmentStandardPerformance endpoint");
                     reportingService.publishAssignmentStandardPerformance(studentSessionScoresResponse.getActivityId()
                                , saveActivityPerformanceInfo);
                }
        }
    }

    private void postTestEventUpdateToReporting(StudentSessionScores studentSessionScoresResponse){

        TestEventInfo testEventInfo = new TestEventInfo();
        if(studentSessionScoresResponse.getDiscipline() != null)
            testEventInfo.setDiscipline(studentSessionScoresResponse.getDiscipline());
        if(studentSessionScoresResponse.getGrade() != null)
            testEventInfo.setGrade(studentSessionScoresResponse.getGrade());
        if(studentSessionScoresResponse.getLevel() != null)
            testEventInfo.setLevel(studentSessionScoresResponse.getLevel());
        if(studentSessionScoresResponse.getNormDate() != null)
            testEventInfo.setNormDate(jsonDateTimeHelper.toJodaDateTime(studentSessionScoresResponse.getNormDate()));

        //TODO:Implement Event Details for activity.
        reportingService.publishTestEventDetails(studentSessionScoresResponse.getActivityId(),testEventInfo);

    }
}
