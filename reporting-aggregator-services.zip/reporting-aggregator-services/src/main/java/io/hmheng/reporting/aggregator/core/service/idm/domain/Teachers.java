package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.List;

/**
 * Created by pabonaj on 2/21/17.
 */
public class Teachers {

    private List<Teacher> leadTeachers;
    private List<Teacher> teamTeachers;

    public List<Teacher> getLeadTeachers() {
        return leadTeachers;
    }

    public void setLeadTeachers(List<Teacher> leadTeachers) {
        this.leadTeachers = leadTeachers;
    }

    public List<Teacher> getTeamTeachers() {
        return teamTeachers;
    }

    public void setTeamTeachers(List<Teacher> teamTeachers) {
        this.teamTeachers = teamTeachers;
    }

}
