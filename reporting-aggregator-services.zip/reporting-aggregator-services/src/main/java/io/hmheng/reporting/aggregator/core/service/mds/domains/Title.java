package io.hmheng.reporting.aggregator.core.service.mds.domains;


import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

public class Title
{
  private String string;

  public String getString ()
  {
    return string;
  }

  public void setString (String string)
  {
    this.string = string;
  }

  public Title() {

  }
  public Title(String string) {
    this.string=string;
  }
  @Override
  public String toString()
  {
    return "ClassPojo [string = "+string+"]";
  }
  public static class TitleJsonDeserializer implements JsonDeserializer<Title> {
    @Override
    public Title deserialize(JsonElement jsonElement, Type type,
                             JsonDeserializationContext context) throws JsonParseException {
      if (jsonElement.isJsonPrimitive()) {
        return new Title(jsonElement.getAsString());
      }

      return context.deserialize(jsonElement, TitleWrapper.class);
    }
  }
  public static class TitleWrapper extends Title {

  }
}
