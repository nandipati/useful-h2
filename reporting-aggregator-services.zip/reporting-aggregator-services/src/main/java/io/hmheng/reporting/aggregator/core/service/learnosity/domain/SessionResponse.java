package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.Subscore;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 11/30/16.
 */
public class SessionResponse {

  @JsonProperty("activity_id")
  private String activityId;
  @JsonProperty("max_score")
  private Integer maxScore;
  private Integer score;
  @JsonProperty("session_id")
  private UUID sessionId;
  private String status;
  @JsonProperty("user_id")
  private String userId;
  @JsonProperty("dt_started")
  private String startDate;
  @JsonProperty("dt_completed")
  private String finishDate;
  @JsonProperty("num_attempted")
  private Integer numAttempted;
  @JsonProperty("num_questions")
  private Integer numQuestions;
  @JsonProperty("session_duration")
  private Integer sessionDuration;
  @JsonProperty("metadata")
  private Object metadata;

  private List<BenchmarkSubscores> subscores;
  private Object[] responses;
  private Object[] items;

  public String getActivityId() {
    return activityId;
  }

  public void setActivityId(String activityId) {
    this.activityId = activityId;
  }

  public Integer getMaxScore() {
    return maxScore;
  }

  public void setMaxScore(Integer maxScore) {
    this.maxScore = maxScore;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public UUID getSessionId() {
    return sessionId;
  }

  public void setSessionId(UUID sessionId) {
    this.sessionId = sessionId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public List<BenchmarkSubscores> getSubscores() {
    return subscores;
  }

  public void setSubscores(List<BenchmarkSubscores> subscores) {
    this.subscores = subscores;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getFinishDate() {
    return finishDate;
  }

  public void setFinishDate(String finishDate) {
    this.finishDate = finishDate;
  }

  public Object[] getResponses() {
    return responses;
  }

  public void setResponses(Object[] responses) {
    this.responses = responses;
  }

  public Object[] getItems() {
    return items;
  }

  public void setItems(Object[] items) {
    this.items = items;
  }

  public Integer getNumAttempted() {
    return numAttempted;
  }

  public void setNumAttempted(Integer numAttempted) {
    this.numAttempted = numAttempted;
  }

  public Integer getNumQuestions() {
    return numQuestions;
  }

  public void setNumQuestions(Integer numQuestions) {
    this.numQuestions = numQuestions;
  }

  public Integer getSessionDuration() {
    return sessionDuration;
  }

  public void setSessionDuration(Integer sessionDuration) {
    this.sessionDuration = sessionDuration;
  }

  public Object getMetadata() {
    return metadata;
  }

  public void setMetadata(Object metadata) {
    this.metadata = metadata;
  }


  @Override
  public String toString() {
    return "SessionResponse{" +
        "activityId='" + activityId + '\'' +
        ", maxScore=" + maxScore +
        ", score=" + score +
        ", sessionId='" + sessionId + '\'' +
        ", status='" + status + '\'' +
        ", subscores=" + subscores +
        ", userId='" + userId + '\'' +
        ", startDate=" + startDate +
        ", finishDate=" + finishDate +
        ", responses=" + Arrays.toString(responses) +
        ", items=" + Arrays.toString(items) +
        ", numAttempted=" + numAttempted +
        ", numQuestions=" + numQuestions +
        ", sessionDuration=" + sessionDuration +
        ", metadata=" + metadata +
        '}';
  }
}