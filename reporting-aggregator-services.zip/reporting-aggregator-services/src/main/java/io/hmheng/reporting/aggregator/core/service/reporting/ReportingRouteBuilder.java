package io.hmheng.reporting.aggregator.core.service.reporting;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import io.hmheng.reporting.aggregator.Constants;

import static io.hmheng.reporting.aggregator.Constants.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ACTIVITY_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ASSIGNMENT_EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.BLOB_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ENDDATE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.PAGE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SESSION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SESSION_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SIZE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STARTDATE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STUDENT_PERSONAL_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STUDENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TESTEVENT_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TESTING_EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.COMPLETED_DATE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.EVENTSTATUS;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TEST_EVENT_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.UPDATEEVENTGROUPS;

@Component
public class ReportingRouteBuilder extends RouteBuilder {

    public static final String classInfoRouteId = "rptClassInfoRoute";
    public static final String classInfoOnStudentUpdateRouteId = "rptClassInfoOnStudentUpdateRoute";
    public static final String studentDemographicRouteId = "rptStudentDemographicRoute";
    public static final String updateStudentDemographicRouteId = "rptUpdateStudentDemographicRoute";
    public static final String checkIfStudentExistsRouteId = "checkIfStudentExistsRoute";
    public static final String activityScoresRouteId = "rptActivityScoresRoute";
    public static final String assignmentActivityDetails = "rptAssignmentActivityRoute";
    public static final String getAssignmentActivityDetails = "rptGetAssignmentActivityRoute";
    public static final String testEventForActivityDetails = "rptTestEventForActivityRoute";
    public static final String testEventActivityDetails = "rptTestEventActivityRoute";
    public static final String testEventActivityReopenedDetails = "rptReopenedTestEventActivityRoute";    
    public static final String benchmarkStudentScore = "rptBenchmarkStudentScoreRoute";
    public static final String assignmentStudentScore = "rptAssignmentStudentScoreRoute";
    public static final String assignmentStudentSandardScores = "rptAssignmentStudentStandardScoreRoute";
    public static final String assignmentStandardPerformanceScores = "direct://postAssignmentStandardPerformanceScores";
    public static final String assignmentClassSummaryDetails = "rptAssignmentClassSummaryRoute";
    public static final String cacheRetrievalRouteId="rptCacheRetrievalRoute";
    public static final String cacheMultiRetrievalRouteId="rptCacheMultiRetrievalRoute";
    public static final String cacheAddRouteId="rptCacheAddRoute";
    public static final String rescoreStudentSessionByTestEventIdRouteId="rptRescoreStudentSessionByTestEventIdRoute";
    public static final String rescoreStudentSessionByActivityIdRouteId="rptRescoreStudentSessionByActivityIdRoute";
    public static final String rescoreStudentSessionIdsRouteId="rptRescoreStudentSessionIdsRoute";
    public static final String rescoreStudentSessionBySessionIdRouteId="rptRescoreStudentSessionBySessionIdRoute";
    public static final String rescoreBenchmarkStudentSessionNoScoresRouteId="rptRescoreBenchmarkStudentSessionNoScoresRoute";
    public static final String testEventSessionsRouteId="rptTestEventSessionsRoute";
    public static final String testEventActivityReopenRouteId="rptTestEventActivityReopenRoute";
    public static final String testEventActivitiesRouteId="rptTestEventActivitiesRoute";
    public static final String assignmentStandardsToItemsMap = "direct://getAssignmentStandardsToItemsMap";
    public static final String reProcessAssignments = "direct://getReProcessAssignments";
    public static final String deleteTeacherAssignmentRouteId="rptDeleteTeacherAssignmentRoute";

    public static final String postClassInfoEndpoint = "direct://postClassInfo";
    public static final String postClassInfoOnStudentUpdteEndpoint = "direct://postClassInfoOnStudentUpdate";
    public static final String postStudentDemographicEndpoint = "direct://postStudentDemographic";
    public static final String checkIfStudentExistsEndpoint = "direct://checkIfStudentExists";
    public static final String updateStudentDemographicEndpoint = "direct://updateStudentDemographic";
    public static final String postActivityScoresEndpoint = "direct://postActivityScores";
    public static final String postAssignmentEventDetailsEndpoint = "direct://postAssignmentEventDetailsInfo";
    public static final String getAssignmentEventDetailsEndpoint = "direct://getAssignmentEventDetailsInfo";
    public static final String postTestEventDetailsEndpoint = "direct://postTestEventDetailsInfo";
    public static final String postTestEventDetailsForActivityEndpoint = "direct://postTestEventDetailsInfoForActivity";
    public static final String putTestEventDetailsEndpoint = "direct://putTestEventDetailsInfo";
    public static final String postBenchmarkStudentScoreEndpoint = "direct://postBenchmarkStudentScore";
    public static final String postAssignmentStudentScoreEndpoint = "direct://postAssignmentStudentScore";
    public static final String postAssignmentStudentStandardScoreEndpoint = "direct://postAssignmentStandardScores";
    public static final String postAssignmentStandardPerformanceEndpoint = "direct://postAssignmentStandardPerformance";
    public static final String postAssignmentClassSummaryEndpoint = "direct://postAssignmentClassSummary";
    public static final String getCachedObjectEndpoint = "direct://getCachedObject";
    public static final String getCachedObjectsEndpoint = "direct://getCachedObjects";
    public static final String putCachedObjectEndpoint="direct://putCachedObject";
    public static final String deleteTeacherAssignmentEndpoint="direct://deleteTeacherAssignment";
    public static final String getStudentSessionByTestEventIdEndpoint="direct://getStudentSessionByTestEventIdEndpoint";
    public static final String getStudentSessionByActivityIdEndpoint="direct://getStudentSessionByActivityIdEndpoint";
    public static final String getAllSessionIdsEndpoint ="direct://getAllSessionIdsEndpoint";
    public static final String getStudentSessionBySessionIdEndpoint="direct://getStudentSessionBySessionIdEndpoint";
    public static final String getBenchmarkStudentSessionNoScoresEndpoint="direct://getBenchmarkStudentSessionNoScoresEndpoint";
    public static final String getTestEventSessionsEndpoint="direct://TestEventSessionsEndpoint";
    public static final String postTestEventActivityReopenEndpoint="direct://TestEventActivityReopenEndpoint";
    public static final String getTestEventActivitiesEndpoint="direct://TestEventActivitiesEndpoint";
    public static final String getStandardsToItemsMapEndpoint = "direct://StandardsToItemsMapEndpoint";
    public static final String getReprocessAssignmentsEndpoint= "direct://ReprocessAssignmentsEndpoint";
    public static final String postStudentAssignmentReportingEndpoint = "direct://postStudentAssignmentReportingEndpoint";

    public static final String postStudentAssignmentReportingRouteId = "scoringPostStudentAssignmentReportingRoute";


    @Value("${reporting.host.baseUrl}")
    public String reportingHost;

    @Autowired
    @Qualifier("gsonDateHourMinuteSecondMillsProcessor")
    private Processor gsonDateTimeProcessor;


    @Override
    public final void configure() throws Exception {
        configurePutEndpoint(putCachedObjectEndpoint,
            cacheAddRouteId,
            "/v4/blobs/${header." + BLOB_ID + "}");
        configureEndpoint(
            getCachedObjectEndpoint,
            cacheRetrievalRouteId,
            "/v4/blobs/${header." + BLOB_ID + "}", HttpMethods.GET, MediaType.TEXT_PLAIN);

        configureGetEndpoint(
            getCachedObjectsEndpoint,
            cacheMultiRetrievalRouteId,
            "/v4/blobs/ids=${header." + BLOB_ID + "}");
        configureEndpoint(
          deleteTeacherAssignmentEndpoint,
          deleteTeacherAssignmentRouteId,
          "/v4/assignments/${header." + EVENT_REFID + "}", HttpMethods.DELETE, MediaType.TEXT_PLAIN
        );
        configurePostEndpoint(
            postClassInfoEndpoint,
            classInfoRouteId,
            "/v4/students/${header." + EVENT_REFID + "}/class");

        configurePutEndpoint(
            postClassInfoOnStudentUpdteEndpoint,
            classInfoOnStudentUpdateRouteId,
            "/v4/students/${header." + STUDENT_REFID + "}/sections");

        configurePostEndpoint(
            postStudentDemographicEndpoint,
            studentDemographicRouteId,
            "/v4/students/${header." + STUDENT_REFID + "}/events/${header." + EVENT_REFID + "}/demographics");

        configurePutEndpoint(
            updateStudentDemographicEndpoint,
            updateStudentDemographicRouteId,
            "/v4/students/${header." + STUDENT_REFID + "}/details");

        configureGetEndpoint(
            checkIfStudentExistsEndpoint,
            checkIfStudentExistsRouteId,
            "/v4/students/${header." + STUDENT_REFID + "}");

        configurePostEndpoint(
            postActivityScoresEndpoint,
            activityScoresRouteId,
            "/v4/test_events/${header." + TESTING_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/benchmarkscores");

        configurePostEndpoint(
            postAssignmentEventDetailsEndpoint,
            assignmentActivityDetails,
            "/v4/assignments/${header." + ASSIGNMENT_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}" +
                    "/assignmentActivity?updateEventGroups=${header." + UPDATEEVENTGROUPS + "}");

        configurePostEndpoint(
                postTestEventDetailsEndpoint,
                testEventActivityDetails,
            "/v4/test_events/${header." + TESTING_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/benchmarkActivity");

    configurePostEndpoint(
        postStudentAssignmentReportingEndpoint,
        postStudentAssignmentReportingRouteId,
        "/v4/assignments/${header." + EVENT_REFID + "}/studentSessionGroups");

        configurePutEndpoint(
          putTestEventDetailsEndpoint,
          testEventActivityReopenedDetails,
          "/v4/test_events/${header." + TESTING_EVENT_REFID + "}");

          configurePostEndpoint(
              postTestEventDetailsForActivityEndpoint,
              testEventForActivityDetails,
              "/v4/activities/${header." + ACTIVITY_ID + "}/benchmarkActivity");


        configurePostEndpoint(
                postBenchmarkStudentScoreEndpoint,
                benchmarkStudentScore,
                "/v4/students/${header." + STUDENT_PERSONAL_REFID + "}/activities/${header." + ACTIVITY_ID + "}/sessions/${header." + SESSION_REFID + "}/benchmarkscores");
        //New Endpoint with in new Student Resource
        configurePostEndpoint(
                postAssignmentStudentScoreEndpoint,
                assignmentStudentScore,
                "/v4/students/${header." + STUDENT_PERSONAL_REFID + "}/activities/${header." + ACTIVITY_ID + "}" +
                        "/sessions/${header." + SESSION_REFID + "}/assignmentscores");//New Endpoint with in new Student Resource

        configurePostEndpoint(
                postAssignmentStudentStandardScoreEndpoint,
                assignmentStudentSandardScores,
                "/v4/students/${header." + STUDENT_PERSONAL_REFID + "}/activities/${header." + ACTIVITY_ID + "}" +
                        "/standardScores");//New Endpoint with in new Student Resource

        configurePostEndpoint(
                postAssignmentStandardPerformanceEndpoint,
                assignmentStandardPerformanceScores,
                "/v4/activities/${header." + ACTIVITY_ID + "}/standards");//New Endpoint with in new Activity Resource

        configurePostEndpoint(
                postAssignmentClassSummaryEndpoint,
                assignmentClassSummaryDetails,
                "/v4/activities/${header." + ACTIVITY_ID + "}/classSummary");//New Endpoint with in new Activity Resource


        String getFormativeStudentSessionNoScoresPath = String.format("/v3/rescore/sessions/formative/missingscores?"
                        + "page=${header.%s}&size=${header.%s}&completedDate=${header.%s}&startDate=${header.%s}",
                PAGE, SIZE, COMPLETED_DATE,STARTDATE);

        configureGetEndpoint(
                getAllSessionIdsEndpoint,
                rescoreStudentSessionIdsRouteId,
                getFormativeStudentSessionNoScoresPath);

        configureGetEndpoint(
                getStudentSessionBySessionIdEndpoint,
                rescoreStudentSessionBySessionIdRouteId,
                "/v3/rescore/sessions/${header." + SESSION_ID + "}/sessions");

        String getStudentSessionByTestEventIdPath = String.format("/v3/rescore/testevent/${header"
                + ".%s}/sessions?page=${header.%s}&size=${header.%s}", TESTEVENT_ID, PAGE, SIZE);

        configureGetEndpoint(
                getStudentSessionByTestEventIdEndpoint,
                rescoreStudentSessionByTestEventIdRouteId,
                getStudentSessionByTestEventIdPath);

        String getStudentSessionByActivityIdPath = String.format("/v3/rescore/activity/${header"
                + ".%s}/sessions?page=${header.%s}&size=${header.%s}", ACTIVITY_ID, PAGE, SIZE);

        configureGetEndpoint(
                getStudentSessionByActivityIdEndpoint,
                rescoreStudentSessionByActivityIdRouteId,
                getStudentSessionByActivityIdPath);

        String getBenchmarkStudentSessionNoScoresPath = String.format("/v3/rescore/sessions/benchmark/missingscores"
                + "?page=${header.%s}&size=${header.%s}&startDate=${header.%s}&endDate=${header.%s}", PAGE, SIZE, STARTDATE, ENDDATE);

        configureGetEndpoint(
                getBenchmarkStudentSessionNoScoresEndpoint,
                rescoreBenchmarkStudentSessionNoScoresRouteId,
                getBenchmarkStudentSessionNoScoresPath);

        String getTestEventSessionsPath = String.format("/v4/test_events/${header"
                + ".%s}/sessions?eventStatus=${header.%s}&page=${header.%s}&size=${header.%s}", EVENT_REFID, EVENTSTATUS, PAGE, SIZE);

        configureGetEndpoint(
                getTestEventSessionsEndpoint,
                testEventSessionsRouteId,
                getTestEventSessionsPath);

        configurePostEndpoint(
            postTestEventActivityReopenEndpoint,
            testEventActivityReopenRouteId,
            "/v4/test_events/${header." + TESTING_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/reopen");

        configureGetEndpoint(
            getTestEventActivitiesEndpoint,
            testEventActivitiesRouteId,
            "/v4/test_events/${header." + TEST_EVENT_ID + "}/activities");

        configureGetEndpoint(
            getAssignmentEventDetailsEndpoint,
            getAssignmentActivityDetails,
            "/v4/activities/${header." + ACTIVITY_ID + "}");

        configureGetEndpoint(
            getStandardsToItemsMapEndpoint,
            assignmentStandardsToItemsMap,
            "/v4/activities/${header." + ACTIVITY_ID + "}/standardsToItemsMap");


      configurePostEndpoint(
            getReprocessAssignmentsEndpoint,
            reProcessAssignments,
            "/v4/assignments/reprocess");


    }
    private void configureEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod) {
        configureEndpoint(endpoint, routeId, url, httpMethod, MediaType.APPLICATION_JSON_UTF8);
    }
    private void configureEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod, MediaType mediaType) {
        from(endpoint)
                .id(routeId)
                .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
                .setHeader(Exchange.CONTENT_TYPE, constant(mediaType))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .setHeader(CORRELATION_ID, simple("${header." + CORRELATION_ID + "}"))
		            .setHeader(Constants.SPAN_ID, simple("${header." + Constants.SPAN_ID + "}"))
                .bean(gsonDateTimeProcessor)
                .recipientList(simple(reportingHost + url))
                .end();
    }

    private void configurePutEndpoint(String endpoint, String routeId, String url) {
		configureEndpoint(endpoint, routeId, url, HttpMethods.PUT);
    }

	private void configurePostEndpoint(String endpoint, String routeId, String url) {
		configureEndpoint(endpoint, routeId, url, HttpMethods.POST);
	}

	private void configureGetEndpoint(String endpoint, String routeId, String url) {
		configureEndpoint(endpoint, routeId, url, HttpMethods.GET);
	}
}
