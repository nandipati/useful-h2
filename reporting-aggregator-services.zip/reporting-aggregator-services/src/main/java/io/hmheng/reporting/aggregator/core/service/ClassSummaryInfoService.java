package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;

public interface ClassSummaryInfoService {
    void handleClassSummaryInfo(StudentSessionScores request);
}
