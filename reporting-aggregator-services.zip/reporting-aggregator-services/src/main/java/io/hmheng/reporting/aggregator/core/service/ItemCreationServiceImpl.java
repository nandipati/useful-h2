package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.mds.MDSService;
import io.hmheng.reporting.aggregator.core.service.mds.domains.*;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsToItemsMapInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoreHelper;
import io.hmheng.reporting.aggregator.exception.ApplicationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by jayachandranj on 8/28/17.
 */
@Component
public class ItemCreationServiceImpl implements ItemCreationService {
    private static final Logger logger = LoggerFactory.getLogger(ItemCreationServiceImpl.class);

    @Autowired
    private MDSService mdsService;

    @Autowired
    private ScoreHelper scoreHelper;

    @Autowired
    private ReportingService reportingService;

    @Deprecated
    @Override
    public void handleItemCreation(ItemCreationRequest itemCreationRequest) {
        try {
            ActivityStandardsToItemsMapInfo activityStandardsToItemsMapInfo= scoreHelper.getStandardsAndItemsForNonMDSSource(itemCreationRequest.getResourceId(),itemCreationRequest.getTestType());

            logger.info("Invoking Reporting Services publishAssignmentStandardPerformance endpoint from ItemCreationImpl...");

            reportingService.publishAssignmentStandardPerformance(itemCreationRequest.getActivityId(),activityStandardsToItemsMapInfo);

        } catch (Exception e) {
            e.printStackTrace();
            throw new ApplicationException("Exception while publishing Items & Standards" + e);
        }

    }
}
