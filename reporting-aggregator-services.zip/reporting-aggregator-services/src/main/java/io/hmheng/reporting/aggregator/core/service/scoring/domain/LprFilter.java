package io.hmheng.reporting.aggregator.core.service.scoring.domain;


public class LprFilter {
    private String scoreType;
    private String slot;

    public LprFilter(String scoreType, String slot){
        this.scoreType = scoreType;
        this.slot = slot;
    }

    public String getScoreType() {
        return scoreType;
    }

    public void setScoreType(String scoreType) {
        this.scoreType = scoreType;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

    @Override
    public String toString() {
        return "LprFilter{" +
                "scoreType='" + scoreType + '\'' +
                ", slot='" + slot + '\'' +
                '}';
    }
}
