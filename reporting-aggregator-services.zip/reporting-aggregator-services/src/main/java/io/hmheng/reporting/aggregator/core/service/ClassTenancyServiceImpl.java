package io.hmheng.reporting.aggregator.core.service;

import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import io.hmheng.reporting.aggregator.core.service.arg.ClassTenancyRequest;
import io.hmheng.reporting.aggregator.core.service.clm.ClmService;
import io.hmheng.reporting.aggregator.core.service.clm.domain.District;
import io.hmheng.reporting.aggregator.core.service.clm.domain.School;
import io.hmheng.reporting.aggregator.core.service.idm.IDMService;
import io.hmheng.reporting.aggregator.core.service.idm.domain.Section;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StaffPerson;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentSectionAssociation;
import io.hmheng.reporting.aggregator.core.service.idm.domain.Teacher;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ClassStudentInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ClassStudentInformationListRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.EventClassInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.EventSectionInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSectionInformation;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceTopicName;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import org.springframework.util.StringUtils;

import static java.util.stream.Collectors.toSet;

@Service
public class ClassTenancyServiceImpl implements ClassTenancyService {

  private static final Logger logger = LoggerFactory.getLogger(ClassTenancyServiceImpl.class);

  @Autowired
  private IDMService idmService;

  @Autowired
  private ClmService clmService;

  @Autowired
  private ReportingService reportingService;

  /**
   * Publish School and Class information to Reporting on either Test Event Completion or Student Updated Event
   * Test Event /v4/students/{EVENT_REFID}/class
   * Student Update Event /v4/students/{STUDENT_ID}/sections
   *
   * @param request
   */
  @Override
  public void handleClassTenancy(ClassTenancyRequest request) {
    logger.info("+ClassTenancyRequest {}", request);
    //Check the sourceTopicName in the request
    if (SourceTopicName.isStudentUpdated(request.getSourceTopicName())) {
      publishClassInfoOnStudentUpdate(request);
    } else {
      logger.info("source topic name not student update, so trying to update class info since  {}", request.getTestingEventRefId() );
      SchoolAndDistrictInfo schoolAndDistrictInfo = getSchoolAndDistrictInfo(request);
      List<ClassStudentInformation> studentClassDetails = getStudentClassDetails(request);

      ClassStudentInformationListRequest classInfoRequest = new ClassStudentInformationListRequest();
      classInfoRequest.setClassStudentInformationList(studentClassDetails);
      classInfoRequest.setLeaRefId(schoolAndDistrictInfo.leaRefId);
      classInfoRequest.setLeaName(schoolAndDistrictInfo.leaName);
      classInfoRequest.setSchoolRefId(schoolAndDistrictInfo.schoolRefId);
      classInfoRequest.setSchoolName(schoolAndDistrictInfo.schoolName);
      if(classInfoRequest.getClassStudentInformationList().size() > 0 && classInfoRequest.getClassStudentInformationList().get(0).getEventClassViews().size() > 0) {
        logger.info("calling Reporting to publish class info {}", request.getTestingEventRefId());
        reportingService.publishClassInfo(request.getTestingEventRefId(), classInfoRequest);
      }
    }
    logger.info("-ClassTenancyRequest {}", request.getStudentPersonalRefId());

  }

  private void publishClassInfoOnStudentUpdate(ClassTenancyRequest request) {
    logger.info("+publishClassInfoOnStudentUpdate {}", request);

    UUID studentPersonalRefId = request.getStudentPersonalRefId();
    if (reportingService.checkIfStudentExists(studentPersonalRefId)) {
      SchoolAndDistrictInfo schoolAndDistrictInfo = getSchoolAndDistrictInfo(request);
      logger.info("schoolAndDistrictInfo {}", schoolAndDistrictInfo);
      List<ClassStudentInformation> studentClassDetails = getStudentClassDetails(request);
      logger.info("studentClassDetails {}", studentClassDetails);

      StudentSectionInformation sectionInformation = new StudentSectionInformation();
      sectionInformation.setLeaRefId(schoolAndDistrictInfo.leaRefId);
      sectionInformation.setLeaName(schoolAndDistrictInfo.leaName);
      sectionInformation.setSchoolRefId(schoolAndDistrictInfo.schoolRefId);
      sectionInformation.setSchoolName(schoolAndDistrictInfo.schoolName);
      sectionInformation.setStudentPersonRefId(studentPersonalRefId);

      for (ClassStudentInformation sections : studentClassDetails) {
        for (EventClassInfo eventClassInfo : sections.getEventClassViews()) {
          sectionInformation.addSection(EventSectionInfo.fromEventClassInfo(eventClassInfo));
        }
      }

      logger.info("calling Reporting to publish class info on stduent update {}", request.getStudentPersonalRefId());
      reportingService.publishClassInfoOnStudentUpdate(request.getStudentPersonalRefId(), sectionInformation);
    }

    logger.info("-publishClassInfoOnStudentUpdate {}", request.getStudentPersonalRefId());
  }

  private SchoolAndDistrictInfo getSchoolAndDistrictInfo(ClassTenancyRequest request) {
    logger.info("+getSchoolAndDistrictInfo {}", request);
    UUID schoolRefId = request.getSchoolRefId();
    School school = reportingService.getCachedObject(schoolRefId.toString(), new TypeReference<School>() {
    });
    if (school == null) {
      school = clmService.getSchool(schoolRefId);
      reportingService.addToCache(schoolRefId.toString(), school);
    }
    logger.info("got {} for schoolRefId {}", school, schoolRefId);

    UUID leaRefId = request.getLeaRefId() != null ? request.getLeaRefId() : school.getLeaRefId();
    District district = null;
    if (!leaRefId.equals(request.getSchoolRefId())) {
      district = reportingService.getCachedObject(leaRefId.toString(), new TypeReference<District>() {
      });
      if (district == null) {
        district = clmService.getDistrict(leaRefId);
        reportingService.addToCache(leaRefId.toString(), district);
      }
      logger.info("got {} for leaRefId {}", district, leaRefId);
    } else {
      //Private school, no district
      district = District.NO_DISTRICT;
      logger.debug("Private school, using dummy district {}", district);
    }

    return new SchoolAndDistrictInfo(leaRefId, district.getLeaName(), schoolRefId, school.getSchoolName());
  }

  /**
   * Return the Sections that is associated with studentPersonalRefId & the schoolRefId,
   * both of which are contained inside the ClassTenancyRequest parameter
   *
   * @param request
   * @return
   */
  private Set<Section> getStudentSections(ClassTenancyRequest request) {
    logger.info("+getStudentSections {}", request);
    String contextId = request.getContextId();
    String platformId = request.getPlatformId();
    Set<Section> studentSections = null;

    if(request.getSectionId()!=null && contextId!=null){
      logger.info("In getStudentSections If with sectionId passed.....{},{},{}" ,request.getSectionId(),contextId , platformId);
      studentSections =  new HashSet<>();
      studentSections.add(idmService.getSectionsDetails(request.getSectionId(), contextId, platformId));
    }else{
      logger.info("In getStudentSections Else w/o sectionId passed..-{},{},{}" ,request.getSectionId(),contextId , platformId);
      try {
        studentSections = idmService.getSectionsForStudent(request.getStudentPersonalRefId(), contextId, platformId);
      } catch (Exception e) {
        logger.error("In getStudentSections section info not found for studentId.-{}" ,request.getStudentPersonalRefId());
        e.printStackTrace();
      }
    }


    if(studentSections!=null && request.getSectionId()!=null) {
      logger.info(" compare the sectionId passed from assignment..{}",studentSections.size());
      studentSections = studentSections.stream().filter(s -> s.getRefId().equals(request.getSectionId())).collect(Collectors.toSet());
      logger.info("size of studentSections...{}",studentSections.size());
      return studentSections;

    }else{
      logger.error("studentSections..-{}" ,studentSections);
    }


    return studentSections;
  }

  /**
   * Return Map<Staff User Id, Staff User) of all staff for the specific school in the ClassTenancyRequest
   *
   * @param request
   * @return
   */
  private Map<UUID, Teacher> getSchoolStaff(ClassTenancyRequest request) {
    // Find all Staff within the given School
    Map<UUID, StaffPerson> staffPersons = new HashMap<>();
    Map<UUID, Teacher> teachers = new HashMap<>();
    if (StringUtils.isEmpty(request.getPlatformId())) {
      // go ahead with current IDM path
      try {
        idmService.getStaffPersonsForStudent(request.getStudentPersonalRefId(), request.getContextId())
            .forEach(staffPerson -> staffPersons.put(staffPerson.getRefId(), staffPerson));
          /*idmService.getStaffPersonsForSchool(request.getSchoolRefId(), request.getContextId())
              .forEach(staffPerson -> staffPersons.put(staffPerson.getRefId(), staffPerson));*/
        // StaffPerson to Teacher
        staffPersonsAdapter(staffPersons, teachers);
      } catch (Exception e) {
        logger.error("IDM No staff info found for this student -{}", request.getStudentPersonalRefId());
        e.printStackTrace();
      }
    } else {
      // go ahead with current IDS path

      try {
        idmService.getTeachersForStudent(request.getStudentPersonalRefId(), request.getPlatformId())
            .forEach(teacher -> teachers.put(teacher.getRefId(), teacher));
      } catch (Exception e) {
        logger.error("IDS No staff info found for this student -{}", request.getStudentPersonalRefId());
        e.printStackTrace();
      }
    }
    return teachers;
  }

  /**
   * Return a list of ClassStudentInformation objects, for every section that a student is associated with.
   */
  private List<ClassStudentInformation> getStudentClassDetails(ClassTenancyRequest request) {
    UUID schoolRefId = request.getSchoolRefId();

    logger.info("Student's schoolRefId: {}", schoolRefId);

    Set<Section> schoolStudentSections = getStudentSections(request);
    logger.info("schoolStudentSections {}", schoolStudentSections);

    Map<UUID, Teacher> staffPersons = getSchoolStaff(request);
    logger.info("staffPersons {}", staffPersons);

    return getClassStudentInformationList(request, schoolStudentSections, staffPersons);
  }

  /**
   * Return EventClassInfo - it merges the parameters to create one class that contains: class Id, name, grade, staff user id, staff name
   *
   * @param studentSection
   * @param staffPersons
   * @param schoolRefId
   * @return
   */
  private EventClassInfo getClassInfo(Section studentSection, Map<UUID, Teacher> staffPersons, UUID schoolRefId) {
    EventClassInfo classInfo = new EventClassInfo();

    // Section
    classInfo.setClassId(studentSection.getRefId());
    classInfo.setClassName(studentSection.getName());
    classInfo.setClassGrade(studentSection.getYearGroup().getCode());

    // Staff
    UUID staffPersonalRefId = null;

    try {

      staffPersonalRefId = studentSection.getSessionScheduleList()
          .getSessionSchedules().iterator().next()
          .getSectionTeacherList()
          .getSectionTeachers().iterator().next()
          .getStaffPersonalRefId();

      classInfo.setStaffPersonRefId(staffPersonalRefId);

      Teacher staffPerson = staffPersons.get(staffPersonalRefId);
      Teacher.Name staffName = staffPerson.getName();

      classInfo.setStaffFamilyName(staffName.getLastName());
      classInfo.setStaffGivenName(staffName.getFirstName());
      classInfo.setStaffMiddleName(staffName.getMiddleInitial()); // Optional

      logger.info("TestEventClassInfo: {}", classInfo);
    } catch (Exception e) {
      // log Section UUIDs which have failed to process.
      logger.warn("Student Section refIds not processed: {}", studentSection.getRefId());

      if (staffPersonalRefId == null) {
        logger.error("{}", "Required staffPersonalRefId not available from Section information");
      } else {
        logger.error("Required StaffPerson information [staffPersonalRefId={}] not available in the School [schoolRefId={}]",
            staffPersonalRefId, schoolRefId);
      }
      logger.error("{}: {}", e.getClass().getCanonicalName(), e);
    }
    return classInfo;
  }

  /**
   * Return a list of ClassStudentInformation objects, for every section that a student is associated with.
   *
   * @param request
   * @param schoolStudentSections
   * @param staffPersons
   * @return
   */
  private List<ClassStudentInformation> getClassStudentInformationList(
      ClassTenancyRequest request,
      Set<Section> schoolStudentSections,
      Map<UUID, Teacher> staffPersons) {
    logger.info("+getClassStudentInformationList {}", request);
    ClassStudentInformation classStudentInformation = new ClassStudentInformation();
    classStudentInformation.setSessionRefId(request.getStudentActivityRefId());
    classStudentInformation.setActivityRefId(request.getReportingActivityId());
    UUID studentPersonalRefId = request.getStudentPersonalRefId();
    classStudentInformation.setStudentPersonRefId(studentPersonalRefId);
     SourceObjectType sourceObjectType = request.getSourceObjectType();
    if (sourceObjectType == null) sourceObjectType = SourceObjectType.ASSESSMENT;
    classStudentInformation.setTestType(TestType.getTestTypeForSourceType(sourceObjectType));

    UUID schoolRefId = request.getSchoolRefId();
    // For every class, create an EventClassInfo
    if(schoolStudentSections!=null) {
      schoolStudentSections.forEach(studentSection -> {
        EventClassInfo classInfo = getClassInfo(studentSection, staffPersons, schoolRefId);
        if (classInfo != null) {
          classStudentInformation.addTestEventClassInfo(classInfo);
        }
      });
    }

    if (CollectionUtils.isEmpty(classStudentInformation.getEventClassViews())) {
      logger.error("No viable TestEventClassInfo records could be created for this Student [studentPersonalRefId={}]", studentPersonalRefId);

      throw new ApplicationException("Unable to process this Event. Data consistency issues have occurred.");
    }

    logger.info("-getClassStudentInformationList {}", classStudentInformation);
    return Collections.singletonList(classStudentInformation);
  }

  /**
   * A StaffPerson to Teacher Adapter
   *
   * @param staffPersons
   * @param teachers
   * @return
   */
  private void staffPersonsAdapter(Map<UUID, StaffPerson> staffPersons, Map<UUID, Teacher> teachers) {
    staffPersons.forEach((k, v) -> teachers.put(k, new Teacher(k, new Teacher.Name(v.getName().getNameOfRecord().getGivenName(),
        v.getName().getNameOfRecord().getMiddleName(), v.getName().getNameOfRecord().getFamilyName()))));
  }

  static class SchoolAndDistrictInfo {
    UUID leaRefId;
    String leaName;
    UUID schoolRefId;
    String schoolName;

    public SchoolAndDistrictInfo(UUID leaRefId, String leaName, UUID schoolRefId, String schoolName) {
      this.leaRefId = leaRefId;
      this.leaName = leaName;
      this.schoolRefId = schoolRefId;
      this.schoolName = schoolName;
    }
  }
}
