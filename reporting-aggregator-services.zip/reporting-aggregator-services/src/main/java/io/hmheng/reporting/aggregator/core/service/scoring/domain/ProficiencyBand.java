package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by suryadevarap on 5/22/18.
 */
public class ProficiencyBand {

  @JsonProperty(value = "bandSeq")
  private Long bandRefId;
  private String bandId;
  private String bandName;

  public Long getBandRefId() {
    return bandRefId;
  }

  public void setBandRefId(Long bandRefId) {
    this.bandRefId = bandRefId;
  }

  public String getBandId() {
    return bandId;
  }

  public void setBandId(String bandId) {
    this.bandId = bandId;
  }

  public String getBandName() {
    return bandName;
  }

  public void setBandName(String bandName) {
    this.bandName = bandName;
  }

  @Override
  public String toString() {
    return "ProficiencyBand{" +
        "bandRefId=" + bandRefId +
        ", bandId='" + bandId + '\'' +
        ", bandName='" + bandName + '\'' +
        '}';
  }
}
