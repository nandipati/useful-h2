package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.arg.DemographicRequest;
import io.hmheng.reporting.aggregator.core.service.idm.IDMService;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic.Codable;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic.Demographics;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentDemographicInformation;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceTopicName;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import org.joda.time.DateTime;
import org.joda.time.Minutes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.util.StringUtils;

@Component
public class DemographicServiceImpl implements DemographicService {

    private static final Logger logger = LoggerFactory.getLogger(DemographicServiceImpl.class);
    private static final String UNKNOWN = "UNKNOWN";
    private static final String UNKNOWN_CODE = "0";

    @Autowired
    private IDMService idmService;

    @Autowired
    private ReportingService reportingService;

    @Override
    public void handleDemographic(DemographicRequest request) {

        logger.info("+handleDemographic {}", request.getStudentPersonalRefId());

        UUID studentPersonalRefId = request.getStudentPersonalRefId();
        logger.info("Activity ID:{} Student's refId: {} PlatformId: {}",
            request.getActivityId(), studentPersonalRefId, request.getPlatformId());

        Boolean demographicsDetailsRequired = demographicsDetailsRequired(request);

        if(SourceTopicName.isStudentUpdated(request.getSourceTopicName())){
            updateStudentDemographicInfo(request , demographicsDetailsRequired);
        } else {
            StudentDemographicInformation studentDemographicInformation = getStudentDemographicInfo(request , demographicsDetailsRequired);
            logger.info("calling Reporting to publish student demographic info {}", studentPersonalRefId);
            reportingService.publishStudentDemographicInfo(request.getEventRefId(), studentPersonalRefId, studentDemographicInformation);
        }

        logger.info("-handleDemographic {}", request.getStudentPersonalRefId());
    }

    private void updateStudentDemographicInfo(DemographicRequest request , Boolean demographicsDetailsRequired){

        logger.info("+updateStudentDemographicInfo {}", request);

        UUID studentPersonalRefId = request.getStudentPersonalRefId();

        if(reportingService.checkIfStudentExists(studentPersonalRefId)){
            logger.info("student exists in Reporting {}", studentPersonalRefId);
            StudentDemographicInformation studentDemographicInformation = getStudentDemographicInfo(request , demographicsDetailsRequired);

            logger.info("calling Reporting to update student demographic info {}", studentPersonalRefId);
            reportingService.updateStudentDemographicInfo(studentPersonalRefId, studentDemographicInformation);
        }

        logger.info("-updateStudentDemographicInfo {}", request.getStudentPersonalRefId());
    }

    private StudentDemographicInformation getStudentDemographicInfo(DemographicRequest request , Boolean demographicsDetailsRequired){

        logger.info("+getStudentDemographicInfo {}", request);

        UUID studentPersonalRefId = request.getStudentPersonalRefId();
        String contextId = request.getContextId();
        StudentDemographic studentDemographic = null;
        if(demographicsDetailsRequired) {
            try {
                studentDemographic = idmService.getStudentDemographic(studentPersonalRefId, contextId, request.getPlatformId());
            } catch (Exception e) {
                logger.error("-getStudentDemographicInfo studentPersonRefId not found in IDM {}", request.getStudentPersonalRefId());
                e.printStackTrace();
            }
            if (studentDemographic == null) {
                logger.error("No student demographic data could be found for student with id {}", studentPersonalRefId);
                throw new ApplicationException("No student demographic data could be found");
            }
        }

        logger.info("-getStudentDemographicInfo {}", request.getStudentPersonalRefId());

        return constructDemographicInfo(studentDemographic, request , demographicsDetailsRequired);
    }

    private Boolean demographicsDetailsRequired(DemographicRequest demographicRequest){
        String sourceTopicName = demographicRequest.getSourceTopicName();
        AssignmentStatus assignmentStatus = demographicRequest.getStatus();
        if(sourceTopicName != null && (SourceTopicName.isTestingEventClosed(sourceTopicName)
            || SourceTopicName.isStudentUpdated(sourceTopicName))
            || (assignmentStatus != null && assignmentStatus.isDemographicsDetailsRequired())){
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

    private StudentDemographicInformation constructDemographicInfo(StudentDemographic studentDemographic
        , DemographicRequest demographicRequest , Boolean demographicsDetailsRequired) {

        StudentDemographicInformation demographicInfo = new StudentDemographicInformation();

        demographicInfo.setSessionId(demographicRequest.getStudentActivityRefId());
        demographicInfo.setEventStatus((demographicRequest.getStatus() != null) ? demographicRequest.getStatus().name() : AssignmentStatus.COMPLETED.name());
        demographicInfo.setContextId(getStudentContext(demographicRequest.getContextId() , demographicRequest.getPlatformId()));
        demographicInfo.setActvityId(demographicRequest.getActivityId());
        demographicInfo.setSectionId(demographicRequest.getSectionId());
        DateTime startDate = demographicRequest.getStartDate();
        demographicInfo.setDateStarted(startDate);
        DateTime submitDate = demographicRequest.getSubmitDate();
        demographicInfo.setDateCompleted(submitDate);
        demographicInfo.setSessionDuration(getSessionDuration(startDate, submitDate));
        SourceObjectType sourceObjectType = demographicRequest.getSourceObjectType();
        TestType testTypeForSourceType = TestType.getTestTypeForSourceType((sourceObjectType != null) ? sourceObjectType : SourceObjectType.ASSESSMENT);
        demographicInfo.setTestType(testTypeForSourceType);

        if(demographicsDetailsRequired) {

            if(studentDemographic != null){

            Demographics demographics = studentDemographic.getDemographics();

            if (demographics != null) {
                //FIXME:IDM is passing date of birth which is not valid date format.
                //demographicInfo.setDateOfBirth(demographics.getBirthDate());
                demographicInfo.setDateOfBirth(null);
                demographicInfo.setGender(getUnknownCode(demographics.getSexus()));
                demographicInfo.setEnglishProficiencyCode(demographics.getLanguageProficiency());
                demographicInfo.setEthnicityCodes(getCode(demographics));
                demographicInfo.setEconomicStatusCode(getEconomicStatus(demographics));
                demographicInfo.setSpecialConditionCodes(getSpecialConditionCodes(demographics));
                demographicInfo.setSpecialServiceCodes(getSpecialServiceCodes(demographics));
            }


                StudentDemographic.Name name = studentDemographic.getName();
                if (!StringUtils.isEmpty(demographicRequest.getPlatformId())) {
                    demographicInfo.setFamilyName((name.getLastName() != null) ? name.getLastName() : null);
                    demographicInfo.setGivenName((name.getFirstName() != null) ? name.getFirstName() : null);
                    demographicInfo.setStudentLocalId((studentDemographic.getLasid() != null) ? studentDemographic.getLasid() : null);
                } else {
                    demographicInfo.setFamilyName(getFamilyName(name));
                    demographicInfo.setGivenName(getGivenName(name));
                    demographicInfo.setStudentLocalId((studentDemographic.getLocalId() != null) ? studentDemographic.getLocalId().getIdValue() : null);
                }
                demographicInfo.setStudentUserName((studentDemographic.getUsername() != null) ? studentDemographic.getUsername() :
                    null);
            }
        }
        logger.info("Student Object Demographics {}", demographicInfo.toString());

        return demographicInfo;
    }

    private String getUnknownCode(String code){
        if (code != null && code.equals(UNKNOWN))
            return UNKNOWN_CODE;
        return code;
    }

    private List<String> getCode(Demographics demographics) {
        if (demographics.getEthnicityList() == null || CollectionUtils.isEmpty(demographics.getEthnicityList().getEthnicities())) {
            return null;
        }

        return demographics.getEthnicityList().getEthnicities().stream().map(Codable::getCode).collect(Collectors.toList());
    }

	private StudentDemographic.IDMDemographicsAny getDemographicsAny(Demographics demographics){
		if (CollectionUtils.isEmpty(demographics.getAnies())) {
			return null;
		}
		return demographics.getAnies().get(0);
	}

    private List<String> getSpecialConditionCodes(Demographics demographics) {
		StudentDemographic.IDMDemographicsAny any = getDemographicsAny(demographics);
		//All the extra demographic information are sent in the "anies" field
		return ((any != null)? any.getSpecialConditions() : null);
    }

	private List<String> getSpecialServiceCodes(Demographics demographics) {
		StudentDemographic.IDMDemographicsAny any = getDemographicsAny(demographics);
		//All the extra demographic information are sent in the "anies" field
		return ((any != null)? any.getSpecialServices() : null);
	}

	private String getEconomicStatus(Demographics demographics) {
		StudentDemographic.IDMDemographicsAny any = getDemographicsAny(demographics);
		//All the extra demographic information are sent in the "anies" field
		return ((any != null)? any.getEconomicStatus() : null);
	}

    private String getGivenName(StudentDemographic.Name name){
        if(name == null || name.getNameOfRecord() == null)
            return null;

        return name.getNameOfRecord().getGivenName();
    }

    private String getFamilyName(StudentDemographic.Name name){
        if(name == null || name.getNameOfRecord() == null)
            return null;

        return name.getNameOfRecord().getFamilyName();
    }

    private Integer getSessionDuration(DateTime startDate , DateTime submitDate){

        if(startDate == null || submitDate == null)
            return null;

        return Minutes.minutesBetween(startDate, submitDate).getMinutes();
    }

    private String getStudentContext(String contextId, String platformId){

        if(!StringUtils.isEmpty(platformId)){
            return platformId;
        }

        return contextId;
    }
}
