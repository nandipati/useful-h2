package io.hmheng.reporting.aggregator.core.service.grading.domain;

import java.util.List;
import java.util.UUID;

public class SessionWrapper {

  public List<UUID> getSessionIds() {
    return sessionIds;
  }

  public void setSessionIds(List<UUID> sessionIds) {
    this.sessionIds = sessionIds;
  }

  private List<UUID> sessionIds;


}