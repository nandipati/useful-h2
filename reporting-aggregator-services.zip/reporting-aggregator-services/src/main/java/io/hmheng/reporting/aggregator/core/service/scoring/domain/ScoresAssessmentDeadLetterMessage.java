package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import java.util.UUID;

/**
 * Created by pabonaj on 5/2/17.
 */
public class ScoresAssessmentDeadLetterMessage {

    private String scoresAssessmentDeadletterId;
    private UUID messageId;
    private String messageBody;

    public String getMessageBody() {
        return messageBody;
    }

    public void setMessageBody(String messageBody) {
        this.messageBody = messageBody;
    }

    public String getScoresAssessmentDeadletterId() {
        return scoresAssessmentDeadletterId;
    }

    public void setScoresAssessmentDeadletterId(String scoresAssessmentDeadletterId) {
        this.scoresAssessmentDeadletterId = scoresAssessmentDeadletterId;
    }

    public UUID getMessageId() {
        return messageId;
    }

    public void setMessageId(UUID messageId) {
        this.messageId = messageId;
    }

}
