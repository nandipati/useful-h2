package io.hmheng.reporting.aggregator.core.service.mds.domains;

import com.google.gson.JsonObject;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Set;

import io.hmheng.reporting.aggregator.core.service.utils.MDSMessageParserHelper;

/**
 * Created by nandipatim on 3/15/16.
 */
public class Result {

    public static final String NO_STANDARDS="NO STANDARDS";
    public static final String NO_STANDARD_ID ="0";
    public static final String STANDARD_TYPE_AB = "AB";
    public static final String QUESTION_TYPE="mcq";
    public static final String NO_STANDARDS_DESC = "This assessment does not contain standard alignments";

    public static final String ATTRIBUTES = "_attributes";
    public static final String CHILDREN = "_children";
    public static final String EDUCATIONAL = "educational";
    public static final String DEPENDENCY = "dependency";
    public static final String DIFFICULTY = "difficulty";
    public static final String LOM = "lom";
    public static final String METADATA = "metadata";
    public static final String RESOURCE = "resource";
    public static final String SOURCE = "source";
    public static final String SOURCE_BLOOM_TAXONOMY = "hmhco.com/BloomsTaxon";
    public static final String SOURCE_COGNITIVE_DIFFICULTY = "hmhco.com/CognitiveDifficulty";
    public static final String SOURCE_DEPTH_OF_KNOWLEDGE = "hmhco.com/DepthOfKnowledge";
    public static final String TYPE = "type";
    public static final String VALUE = "value";
    public static final int LENGTH_BLOOMS_TAXONOMY_TEXT = 17;
    public static final String TEXT_BLOOMS_TAXONOMY = "Bloom's Taxonomy:";

    public static final int IDENTIFIER_STANDARD_REF_ID_POS = 4;
    ItemsExternalRefIdResponse.Facets facets;
    @JsonIgnore
    private Set<Standard> standards;
    @JsonProperty(value = "content")
    private JsonObject content;

    public JsonObject getContent() {
        return content;
    }

    public void setContent(JsonObject content) {
        this.content = content;
    }

    public ItemsExternalRefIdResponse.Facets getFacets() {
        return facets;
    }

    public void setFacets(ItemsExternalRefIdResponse.Facets facets) {
        this.facets = facets;
    }

    public Set<Standard> getStandards(){
        if(standards!=null)
            return standards;
        standards = new HashSet<>();

        if(this.content == null) {
            standards.add(MDSMessageParserHelper.createNoStandard());
           return standards;
        }

        MDSMessageParserHelper.parseItemResponseContent(standards, this.content);

        if(CollectionUtils.isEmpty(standards))
            standards.add(MDSMessageParserHelper.createNoStandard());

        return standards;
    }

    public String getIdentifier() {

        String contentIdentifier = MDSMessageParserHelper.parseItemResponseContentIdentifier(this.content);

        if (contentIdentifier != null) {
            if (contentIdentifier.length() > IDENTIFIER_STANDARD_REF_ID_POS) {
                return contentIdentifier.substring(IDENTIFIER_STANDARD_REF_ID_POS);
            }
        }

        return null;
    }

    public String getQuestionType() {

        String questionType = MDSMessageParserHelper.parseItemResponseQuestionType(this.content);
        return questionType;
    }

    public String getBloomTaxonomy() {

        String bloomTaxonomy = MDSMessageParserHelper.parseItemResponseBloomsTaxonomy(this.content);
        return bloomTaxonomy;
    }

    public String getCognitiveDifficulty() {

        String cognitiveDifficulty = MDSMessageParserHelper.parseItemResponseCognitiveDifficulty(this.content);
        return cognitiveDifficulty;
    }

    public String getDepthOfKnowledge() {

    String depthOfKnowledge = MDSMessageParserHelper.parseItemResponseDepthOfKnowledge(this.content);
    return depthOfKnowledge;
    }

    @Override
    public String toString() {
        return "{" +
                "content=" + content +
                '}';
    }
}
