package io.hmheng.reporting.aggregator.core.service.reporting.domain;

public class AssignmentClassSummaryRequest {
    private AssignmentClassSummaryInfo assignmentClassSummaryInfo;

    public AssignmentClassSummaryInfo getAssignmentClassSummaryInfo() {
        return assignmentClassSummaryInfo;
    }

    public void setAssignmentClassSummaryInfo(AssignmentClassSummaryInfo assignmentClassSummaryInfo) {
        this.assignmentClassSummaryInfo = assignmentClassSummaryInfo;
    }
}
