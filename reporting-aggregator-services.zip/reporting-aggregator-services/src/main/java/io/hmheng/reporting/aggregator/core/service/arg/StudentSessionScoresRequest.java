package io.hmheng.reporting.aggregator.core.service.arg;

import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import java.util.UUID;

/**
 * Created by nandipatim on 3/4/16.
 */
public class StudentSessionScoresRequest {

    private UUID sessionId;
    private UUID activityId;
    private UUID studentPersonalRefId;
    private UUID eventRefId;
    private SourceObjectType sourceObjectType;
    private String contextId;

    public StudentSessionScoresRequest(UUID sessionId, UUID activityId, UUID studentPersonalRefId
            ,UUID eventRefId , SourceObjectType sourceObjectType){

        this.sessionId = sessionId;
        this.activityId = activityId;
        this.studentPersonalRefId = studentPersonalRefId;
        this.eventRefId = eventRefId;
        this.sourceObjectType = sourceObjectType;
        this.contextId = contextId;
    }

    public UUID getSessionId() {
        return sessionId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

    public String getContextId() {
        return contextId;
    }

    @Override
    public String toString() {
        return "StudentSessionScoresRequest{" +
                "sessionId=" + sessionId +
                ", activityId=" + activityId +
                ", studentPersonalRefId=" + studentPersonalRefId +
                ", eventRefId=" + eventRefId +
                ", sourceObjectType=" + sourceObjectType +
                ", contextId='" + contextId + '\'' +
                '}';
    }
}
