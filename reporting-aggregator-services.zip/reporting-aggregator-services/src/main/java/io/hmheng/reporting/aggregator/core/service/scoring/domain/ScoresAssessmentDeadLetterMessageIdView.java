package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import java.util.List;

/**
 * Created by pabonaj on 5/11/17.
 */
@JsonRootName("scoresAssessmentDeadLetterMessage")
public class ScoresAssessmentDeadLetterMessageIdView {

    @JsonProperty("message_id")
    private List<String> messageId;

    public List<String> getMessageIdList() {
        return messageId;
    }

    public void setMessageIdList(List<String> messageIdList) {
        this.messageId = messageIdList;
    }

}
