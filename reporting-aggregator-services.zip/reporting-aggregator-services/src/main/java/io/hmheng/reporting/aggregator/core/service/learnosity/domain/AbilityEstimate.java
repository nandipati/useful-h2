package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by nandipatim on 11/30/16.
 */
public class AbilityEstimate {

  @JsonProperty("ability_estimate")
  private Double abilityEstimate;
  @JsonProperty("standard_error")
  private Double standardError;
  @JsonProperty("method")
  private String method;

  public Double getAbilityEstimate() {
    return abilityEstimate;
  }

  public void setAbilityEstimate(Double abilityEstimate) {
    this.abilityEstimate = abilityEstimate;
  }

  public Double getStandardError() {
    return standardError;
  }

  public void setStandardError(Double standardError) {
    this.standardError = standardError;
  }

  public String getMethod() {
    return method;
  }

  public void setMethod(String method) {
    this.method = method;
  }

  @Override
  public String toString() {
    return "AbilityEstimate{" +
        "abilityEstimate=" + abilityEstimate +
        ", standardError=" + standardError +
        ", method=" + method +
        '}';
  }
}
