package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardSet;

import java.time.LocalDateTime;

/**
 * Created by nandipatim on 3/17/16.
 */
public class AssignmentStudentStandardScore {

    private String standardId;
    private String sequenceNumber;
    private Integer standardItems;
    private Integer standardPoints;
    private Double standardProficiencyScore;
    private PerformanceLevel standardPerformanceLevel;
    private Long bandId;
    private String standardName;
    private Integer standardItemsCorrect;
    private Integer standardItemsCorrectPoints;
    private Integer standardAttainedPoints;
    private StandardSet standardSet;

    public String getStandardId() {
        return standardId;
    }

    public void setStandardId(String standardId) {
        this.standardId = standardId;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public Integer getStandardItems() {
        return standardItems;
    }

    public void setStandardItems(Integer standardItems) {
        this.standardItems = standardItems;
    }

    public Integer getStandardPoints() {
        return standardPoints;
    }

    public void setStandardPoints(Integer standardPoints) {
        this.standardPoints = standardPoints;
    }

    public Double getStandardProficiencyScore() {
        return standardProficiencyScore;
    }

    public void setStandardProficiencyScore(Double standardProficiencyScore) {
        this.standardProficiencyScore = standardProficiencyScore;
    }

    public PerformanceLevel getStandardPerformanceLevel() {
        return standardPerformanceLevel;
    }

    public void setStandardPerformanceLevel(PerformanceLevel standardPerformanceLevel) {
        this.standardPerformanceLevel = standardPerformanceLevel;
    }

    public String getStandardName() {
        return standardName;
    }

    public void setStandardName(String standardName) {
        this.standardName = standardName;
    }

    public Integer getStandardItemsCorrect() {
        return standardItemsCorrect;
    }

    public void setStandardItemsCorrect(Integer standardItemsCorrect) {
        this.standardItemsCorrect = standardItemsCorrect;
    }

    public Integer getStandardItemsCorrectPoints() {
        return standardItemsCorrectPoints;
    }

    public void setStandardItemsCorrectPoints(Integer standardItemsCorrectPoints) {
        this.standardItemsCorrectPoints = standardItemsCorrectPoints;
    }

    public Integer getStandardAttainedPoints() {
        return standardAttainedPoints;
    }

    public void setStandardAttainedPoints(Integer standardAttainedPoints) {
        this.standardAttainedPoints = standardAttainedPoints;
    }

    public Long getBandId() {
        return bandId;
    }

    public void setBandId(Long bandId) {
        this.bandId = bandId;
    }

    @Override
    public String toString() {
        return "AssignmentStudentStandardScore{" +
            "standardId='" + standardId + '\'' +
            ", sequenceNumber='" + sequenceNumber + '\'' +
            ", standardItems=" + standardItems +
            ", standardPoints=" + standardPoints +
            ", standardProficiencyScore=" + standardProficiencyScore +
            ", standardPerformanceLevel=" + standardPerformanceLevel +
            ", bandId=" + bandId +
            ", standardName='" + standardName + '\'' +
            ", standardItemsCorrect=" + standardItemsCorrect +
            ", standardItemsCorrectPoints=" + standardItemsCorrectPoints +
            ", standardAttainedPoints=" + standardAttainedPoints +
            '}';
    }

    public void setStandardSet(StandardSet standardSet) {
        this.standardSet = standardSet;
    }

    public StandardSet getStandardSet() {
        return standardSet;
    }
}
