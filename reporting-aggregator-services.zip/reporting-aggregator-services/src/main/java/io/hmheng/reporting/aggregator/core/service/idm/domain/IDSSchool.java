package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.UUID;

/**
 * Created by nandipatim on 2/21/17.
 */
public class IDSSchool {

  private String orgId;
  private String name;
  private String type;
  private UUID sifRefId;
  private String pid;

  public String getOrgId() {
    return orgId;
  }

  public void setOrgId(String orgId) {
    this.orgId = orgId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public UUID getSifRefId() {
    return sifRefId;
  }

  public void setSifRefId(UUID sifRefId) {
    this.sifRefId = sifRefId;
  }

  public String getPid() {
    return pid;
  }

  public void setPid(String pid) {
    this.pid = pid;
  }
}
