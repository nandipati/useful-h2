package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import java.util.List;

/**
 * Created by pabonaj on 10/6/16.
 */
public class SessionsResponsesRequest {

    private List<String> session_id;
    private List<String> metadata;

    public List<String> getMetadata() {
        return metadata;
    }

    public void setMetadata(List<String> metadata) {
        this.metadata = metadata;
    }

    public List<String> getSession_id() {
        return session_id;
    }

    public void setSession_id(List<String> session_id) {
        this.session_id = session_id;
    }

}
