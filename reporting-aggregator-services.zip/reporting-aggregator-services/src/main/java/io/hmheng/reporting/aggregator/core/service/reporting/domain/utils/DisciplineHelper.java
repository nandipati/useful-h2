package io.hmheng.reporting.aggregator.core.service.reporting.domain.utils;

import io.hmheng.reporting.aggregator.core.service.reporting.domain.Discipline;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 3/9/16.
 */
@Component
public class DisciplineHelper {

    public Discipline getDisciplineForAssignmentDisciplineString(String discipline){

        if(discipline == null)
            throw new IllegalArgumentException("Discipline cannot be null.");

        String firstLetter = discipline.substring(0,1).toUpperCase();

        if(Discipline.M.name().equals(firstLetter))
            return Discipline.M;
        else if(Discipline.E.name().equals(firstLetter)|| discipline.toUpperCase().contains("LANGUAGE ARTS"))
            return Discipline.E;
        else if("B".equals(discipline)){
            if(discipline.contains("ELA"))
                return Discipline.E;
            else
                return Discipline.M;
        }

        throw new IllegalArgumentException("Unable to Determine Test Type "+discipline);
    }
}
