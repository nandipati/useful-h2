package io.hmheng.reporting.aggregator.core.service.clm;

import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.LEA_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SCHOOL_REFID;
import static io.hmheng.reporting.aggregator.core.service.AuthorizationService.Service.CLM;

import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import io.hmheng.reporting.aggregator.core.service.AuthorizationDetails;
import io.hmheng.reporting.aggregator.core.service.AuthorizationService;
import io.hmheng.reporting.aggregator.core.service.clm.domain.District;
import io.hmheng.reporting.aggregator.core.service.clm.domain.School;

@Component
public class ClmServiceImpl implements ClmService {

    private static final Logger logger = LoggerFactory.getLogger(ClmServiceImpl.class);

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Override
    public School getSchool(UUID schoolRefId) {
        logger.debug("+getSchool for ref id {}", schoolRefId);

        School school = producerTemplate.requestBodyAndHeaders(
                ClmRouteBuilder.clmSchoolEndpoint,
                "", generateHeadersForSchool(schoolRefId),
                School.class);

        logger.debug("-getSchool");
        return school;
    }

    @Override
    public District getDistrict(UUID leaRefId) {
        logger.debug("+getDistrict for ref id {}", leaRefId);

        District district = producerTemplate.requestBodyAndHeaders(
                ClmRouteBuilder.clmDistrictEndpoint,
                "", generateHeadersForDistrict(leaRefId),
                District.class);

        logger.debug("-getDistrict");
        return district;
    }

    private Map<String, Object> generateHeadersForSchool(UUID schoolRefId) {
        Map<String, Object> headers = createBasicHeaders();
        headers.put(SCHOOL_REFID, schoolRefId.toString());
        return headers;
    }

    private Map<String, Object> generateHeadersForDistrict(UUID leaRefId) {
        Map<String, Object> headers = createBasicHeaders();
        headers.put(LEA_REFID, leaRefId.toString());
        return headers;
    }

    private Map<String, Object> createBasicHeaders() {
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(CLM);
        Map<String, Object> headers = new HashMap<>();

        headers.put(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.put(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());

        return headers;
    }
}
