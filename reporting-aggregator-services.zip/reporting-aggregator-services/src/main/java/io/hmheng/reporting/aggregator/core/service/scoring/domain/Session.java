package io.hmheng.reporting.aggregator.core.service.scoring.domain;


import java.util.List;
import java.util.UUID;

public class Session {

    private UUID sessionId;
    private UUID activityId;
    private UUID studentPersonRefId;
    private String status;
    private String grade;
    private boolean skippedQuestions;
    private boolean itemsOmitted;
    private boolean completionCriteriaNotMet;
    private boolean inCompleteTestRecord;

    private List<BenchmarkScore> scores;
    private List<AssignmentItemScore> itemScores;
    private AssignmentTotalScore totalScore;

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public List<BenchmarkScore> getScores() {
        return scores;
    }

    public void setScores(List<BenchmarkScore> scores) {
        this.scores = scores;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public boolean isSkippedQuestions() {
        return skippedQuestions;
    }

    public void setSkippedQuestions(boolean skippedQuestions) {
        this.skippedQuestions = skippedQuestions;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public UUID getStudentPersonRefId() {
        return studentPersonRefId;
    }

    public void setStudentPersonRefId(UUID studentPersonRefId) {
        this.studentPersonRefId = studentPersonRefId;
    }

    public List<AssignmentItemScore> getItemScores() {
        return itemScores;
    }

    public void setItemScores(List<AssignmentItemScore> itemScores) {
        this.itemScores = itemScores;
    }

    public AssignmentTotalScore getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(AssignmentTotalScore totalScore) {
        this.totalScore = totalScore;
    }

    public boolean isItemsOmitted() {
        return itemsOmitted;
    }

    public void setItemsOmitted(boolean itemsOmitted) {
        this.itemsOmitted = itemsOmitted;
    }

    public boolean isCompletionCriteriaNotMet() {
        return completionCriteriaNotMet;
    }

    public void setCompletionCriteriaNotMet(boolean completionCriteriaNotMet) {
        this.completionCriteriaNotMet = completionCriteriaNotMet;
    }

    public boolean isInCompleteTestRecord() {
        return inCompleteTestRecord;
    }

    public void setInCompleteTestRecord(boolean inCompleteTestRecord) {
        this.inCompleteTestRecord = inCompleteTestRecord;
    }

    @Override
    public String toString() {
        return "Session{" +
                "sessionId=" + sessionId +
                ", activityId=" + activityId +
                ", studentPersonRefId=" + studentPersonRefId +
                ", status='" + status + '\'' +
                ", grade='" + grade + '\'' +
                ", skippedQuestions=" + skippedQuestions +
                ", itemsOmitted=" + itemsOmitted +
                ", completionCriteriaNotMet=" + completionCriteriaNotMet +
                ", inCompleteTestRecord=" + inCompleteTestRecord +
                ", scores=" + scores +
                ", itemScores=" + itemScores +
                ", totalScore=" + totalScore +
                '}';
    }
}
