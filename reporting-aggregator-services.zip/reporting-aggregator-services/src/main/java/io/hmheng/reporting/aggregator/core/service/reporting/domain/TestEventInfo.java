package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import org.joda.time.DateTime;

import java.util.UUID;

/**
 * Created by nandipatim on 3/9/16.
 */
public class TestEventInfo {

    private UUID eventRefId;
    private UUID activityId;
    private String activityName;
    private Discipline discipline;
    private String eventName;
    private DateTime normDate;
    private String product;
    private String programName;
    private DateTime startDate;
    private DateTime finishDate;
    private String status;
    private String isbn;
    private String grade;
    private String level;
    private String resourceId;
    private String programId;
    private TestType testType;
    private UUID leaRefId;


    public UUID getleaRefId() {
        return leaRefId;
    }

    public void setleaRefId(UUID districtId) {
        this.leaRefId = districtId;
    }

    public UUID getActivityId() { return activityId; }

    public void setActivityId(UUID activityId) { this.activityId = activityId; }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public DateTime getNormDate() {
        return normDate;
    }

    public void setNormDate(DateTime normDate) {
        this.normDate = normDate;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(DateTime finishDate) {
        this.finishDate = finishDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }
}
