package io.hmheng.reporting.aggregator.core.service;

/**
 * Created by jayachandranj on 8/28/17.
 */
public interface ItemCreationService {

    void handleItemCreation(ItemCreationRequest itemCreationRequest);
}
