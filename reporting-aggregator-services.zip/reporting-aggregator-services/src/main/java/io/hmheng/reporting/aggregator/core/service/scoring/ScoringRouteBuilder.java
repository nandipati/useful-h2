package io.hmheng.reporting.aggregator.core.service.scoring;


import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.*;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static io.hmheng.reporting.aggregator.Constants.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ACTIVITY_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.PAGE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SESSION_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SIZE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.MESSAGE_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.UPDATEEVENTGROUPS;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.PUSHSTANDARDSCORES;
import static org.apache.camel.component.http4.HttpMethods.GET;


@Component
public class ScoringRouteBuilder extends RouteBuilder {

    public static final String postEventBySessionRouteId = "postEventBySessionRoute";
    public static final String benchmarkActivityScoresRouteId = "scoringBenchmarkActivityScoresRoute";
    public static final String formativeActivityScoresRouteId = "scoringFormativeActivityScoresRoute";
    public static final String formativeStudentSessionScoresRouteId = "scoringFormativeStudentSessionScoresRoute";
    public static final String benchmarkStudentSessionScoresRouteId = "scoringBenchmarkStudentSessionScoresRoute";
    public static final String postEventRouteId = "scoringPostEventRoute";
    public static final String postStudentAssignmentRouteId = "scoringPostStudentAssignmentRoute";
    public static final String postScoresAssessmentDeadLetterRouteId = "postScoresAssessmentDeadLetterRoute";
    public static final String postScoresAssessmentDeadLetterReprocessRouteId = "postScoresAssessmentDeadLetterReprocessRoute";
    public static final String getScoresAssessmentDeadLetterRouteId = "getScoresAssessmentDeadLetterRoute";
    public static final String postAllScoresAssessmentDeadLetterRouteId = "postAllScoresAssessmentDeadLetterRoute";
    public static final String postUpdateStatusScoresAssessmentDeadLetterRouteId = "postUpdateStatusScoresAssessmentDeadLetterRoute";
    public static final String postBySessionRouteId = "postBySessionRoute";
  public static final String deleteTeacherAssignmentRouteId="scoringDeleteTeacherAssignmentRoute";

    public static final String postEventBySessionEndpoint = "direct://postEventBySession";
    public static final String getBenchmarkActivityScoresEndpoint = "direct://getBenchmarkActivityScores";
    public static final String getFormativeActivityScoresEndpoint = "direct://getFormativeActivityScores";
    public static final String getFormativeStudentSessionScoresEndpoint = "direct://getFormativeStudentEndpoint";
    public static final String getBenchmarkStudentSessionScoresEndpoint = "direct://getBenchmarkStudentEndpoint";
    public static final String postEventEndpoint = "direct://postEventEndpoint";
    public static final String postStudentAssignmentEndpoint = "direct://postStudentAssignmentEndpoint";
    public static final String postScoresAssessmentDeadLetterEndpoint = "direct://postScoresAssessmentDeadLetterEndpoint";
    public static final String postScoresAssessmentDeadLetterReprocessEndpoint = "direct://postcoresAssessmentDeadLetterReprocessEndpoint";
    public static final String getScoresAssessmentDeadLetterEndpoint = "direct://getScoresAssessmentDeadLetterEndpoint";
    public static final String postAllScoresAssessmentDeadLetterEndpoint = "direct://postAllScoresAssessmentDeadLetterEndpoint";
    public static final String postUpdateStatusScoresAssessmentDeadLetterEndpoint = "direct://postUpdateStatusScoresAssessmentDeadLetterEndpoint";
    public static final String postBySessionEndpoint = "direct://postBySession";
    public static final String deleteTeacherAssignmentEndpoint="direct://scoringdeleteTeacherAssignment";

    @Value("${scoring.host.baseUrl}")
    private String scoringHost;

    @Autowired
    @Qualifier("gsonDateHourMinuteSecondMillsProcessor")
    private Processor gsonDateTimeProcessor;

  @Override
    public void configure() throws Exception {
        //TODO Fix and parameterize page and size
        String getBenchmarkActivityScoresPath = String.format("/v1/benchmark/activities/${header"
            + ".%s}/sessions?page=${header.%s}&size=${header.%s}", ACTIVITY_ID, PAGE, SIZE);
        String getFormativeActivityScoresPath = String.format("/v2/formative/activities/${header"
            + ".%s}/sessions?page=${header.%s}&size=${header.%s}", ACTIVITY_ID, PAGE, SIZE);

        //Rescoring
        String postEventBySessionPath = String.format("/v1/events/sessions");

        //Formative
        String getFormativeStudentSessionScoresPath = String.format("/v2/formative/activities/${header"
            + ".%s}/sessions/${header.%s}", ACTIVITY_ID , SESSION_REFID);

        //Benchmark
        String getBenchmarkStudentSessionScoresPath = String.format("/v1/benchmark/activities/${header.%s}/sessions/${header.%s}", ACTIVITY_ID , SESSION_REFID);
        String postEventPath = String.format("/v1/events/${header.%s}/activities/${header.%s}/details?updateEventGroups=${header.%s}", EVENT_REFID, ACTIVITY_ID, UPDATEEVENTGROUPS);

      String postStudentAssignmentPath = String.format("/v1/events/${header.%s}/studentSessionGroups",EVENT_REFID);

      String postScoresAssessmentDeadLetterPath = String.format("/v1/deadletter");

        String getScoresAssessmentDeadLetterPath = String.format("/v1/deadletter/id/${header"
              + ".%s}/message", MESSAGE_ID);

        String postAllScoresAssessmentDeadLetterPath = String.format("/v1/deadletter/message/ids");

        String postUpdateStatusScoresAssessmentDeadLetterPath = String.format("/v1/deadletter/update/status/2");

        //ReProcess standards
        String postBySessionPath = String.format("/v2/formative/rescoreSessions?pushStandardScores=${header.%s}",PUSHSTANDARDSCORES);

        configurePostEndpoint(
                postEventBySessionEndpoint,
                postEventBySessionRouteId,
                postEventBySessionPath,
                List.class);

        configureEndpoint(
                getBenchmarkActivityScoresEndpoint,
                benchmarkActivityScoresRouteId,
                getBenchmarkActivityScoresPath,
                BenchmarkActivityScoresResponse.class);

        configureEndpoint(
                getFormativeActivityScoresEndpoint,
                formativeActivityScoresRouteId,
                getFormativeActivityScoresPath,
                FormativeActivityScoresResponse.class);

        configureEndpoint(
                getFormativeStudentSessionScoresEndpoint,
                formativeStudentSessionScoresRouteId,
                getFormativeStudentSessionScoresPath,
                StudentSessionScores.class);

        configureEndpoint(
                getBenchmarkStudentSessionScoresEndpoint,
                benchmarkStudentSessionScoresRouteId,
                getBenchmarkStudentSessionScoresPath,
                StudentSessionScores.class);

        configurePostEndpoint(
                postEventEndpoint,
                postEventRouteId,
                postEventPath,
            ScoreEventResponseInfo.class);

      configurePostEndpoint(
              postStudentAssignmentEndpoint,
              postStudentAssignmentRouteId,
              postStudentAssignmentPath,
              List.class);

        configurePostEndpoint(
                postScoresAssessmentDeadLetterEndpoint,
                postScoresAssessmentDeadLetterRouteId,
                postScoresAssessmentDeadLetterPath,
                ScoresAssessmentDeadLetterResponse.class);

        configurePostEndpoint(
                postAllScoresAssessmentDeadLetterEndpoint,
                postAllScoresAssessmentDeadLetterRouteId,
                postAllScoresAssessmentDeadLetterPath,
                List.class);

        configurePostEndpoint(
            postUpdateStatusScoresAssessmentDeadLetterEndpoint,
            postUpdateStatusScoresAssessmentDeadLetterRouteId,
            postUpdateStatusScoresAssessmentDeadLetterPath,
            List.class);

        configureEndpoint(
              getScoresAssessmentDeadLetterEndpoint,
              getScoresAssessmentDeadLetterRouteId,
              getScoresAssessmentDeadLetterPath,
              ScoresAssessmentDeadLetterResponse.class);

        configurePostEndpoint(
            postBySessionEndpoint,
            postBySessionRouteId,
            postBySessionPath,
            List.class);

    configureGetEndpoint(
                deleteTeacherAssignmentEndpoint,
                deleteTeacherAssignmentRouteId,
                "/v1/events/${header." + EVENT_REFID + "}/delete", HttpMethods.PUT, MediaType.TEXT_PLAIN
        );

  }

    private void configureEndpoint(String endpointUri, String endpointId, String url, Class<?> responseClass) {
        configureEndpoint(GET, endpointUri, endpointId, url, responseClass);
    }

    private void configurePostEndpoint(String endpoint, String routeId, String url, Class<?> responseClass) {
      configureEndpoint( HttpMethods.POST, endpoint, routeId, url, responseClass);
    }

    private void configureEndpoint(HttpMethods httpMethod, String endpointUri, String endpointId, String url, Class<?> responseClass) {
        from(endpointUri).id(endpointId)
                .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
                .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .bean(gsonDateTimeProcessor)
                .recipientList(simple(scoringHost + url))
                .unmarshal(configureDataFormat(responseClass))
                .end();
    }


    private JacksonDataFormat configureDataFormat(Class<?> clazz) {
      JacksonDataFormat dataFormat = new JacksonDataFormat(clazz);
      dataFormat.disableFeature(FAIL_ON_UNKNOWN_PROPERTIES);
      dataFormat.disableFeature(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
      dataFormat.disableFeature(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
      dataFormat.addModule(new JavaTimeModule());
      return dataFormat;
    }

    private void configureGetEndpoint(String endpoint, String routeId, String url) {
        configureGetEndpoint(endpoint, routeId, url, HttpMethods.GET);
    }

    private void configureGetEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod) {
        configureGetEndpoint(endpoint, routeId, url, httpMethod, MediaType.APPLICATION_JSON_UTF8);
    }
    private void configureGetEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod, MediaType mediaType) {
        from(endpoint)
                .id(routeId)
                .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
                .setHeader(Exchange.CONTENT_TYPE, constant(mediaType))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .bean(gsonDateTimeProcessor)
                .recipientList(simple(scoringHost + url))
                .end();
    }

}
