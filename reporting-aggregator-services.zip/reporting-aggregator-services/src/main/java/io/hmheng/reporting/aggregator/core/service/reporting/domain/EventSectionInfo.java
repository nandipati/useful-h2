package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.UUID;

public class EventSectionInfo {
    
    private UUID sectionId;
    private String sectionName;
    private String sectionGrade;
    private UUID staffPersonRefId;
    private String staffFamilyName;
    private String staffGivenName;
    private String staffMiddleName;

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getSectionGrade() {
        return sectionGrade;
    }

    public void setSectionGrade(String sectionGrade) {
        this.sectionGrade = sectionGrade;
    }
    
    public UUID getStaffPersonRefId() {
        return staffPersonRefId;
    }

    public void setStaffPersonRefId(UUID staffPersonRefId) {
        this.staffPersonRefId = staffPersonRefId;
    }

    public String getStaffFamilyName() {
        return staffFamilyName;
    }

    public void setStaffFamilyName(String staffFamilyName) {
        this.staffFamilyName = staffFamilyName;
    }

    public String getStaffGivenName() {
        return staffGivenName;
    }

    public void setStaffGivenName(String staffGivenName) {
        this.staffGivenName = staffGivenName;
    }

    public String getStaffMiddleName() {
        return staffMiddleName;
    }

    public void setStaffMiddleName(String staffMiddleName) {
        this.staffMiddleName = staffMiddleName;
    }

	public static EventSectionInfo fromEventClassInfo(EventClassInfo eventClassInfo){
		EventSectionInfo sectionInfo = new EventSectionInfo();

		sectionInfo.sectionId = eventClassInfo.getClassId();
		sectionInfo.sectionName = eventClassInfo.getClassName();
		sectionInfo.sectionGrade = eventClassInfo.getClassGrade();
		sectionInfo.staffFamilyName = eventClassInfo.getStaffFamilyName();
		sectionInfo.staffGivenName = eventClassInfo.getStaffFamilyName();
		sectionInfo.staffMiddleName = eventClassInfo.getStaffMiddleName();
		sectionInfo.staffPersonRefId = eventClassInfo.getStaffPersonRefId();

		return sectionInfo;
	}

    @Override
    public String toString() {
        return "TestEventClassInfo{" +
            "sectionId=" + sectionId +
            ", sectionName='" + sectionName + '\'' +
            ", sectionGrade='" + sectionGrade + '\'' +
            ", staffPersonRefId=" + staffPersonRefId +
            ", staffFamilyName='" + staffFamilyName + '\'' +
            ", staffGivenName='" + staffGivenName + '\'' +
            ", staffMiddleName='" + staffMiddleName + '\'' +
            '}';
    }
    
}