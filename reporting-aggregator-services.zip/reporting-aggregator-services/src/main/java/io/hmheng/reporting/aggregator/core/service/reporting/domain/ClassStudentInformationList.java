package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.List;

public class ClassStudentInformationList {

    private List<ClassStudentInformation> classStudentInformations;

    public List<ClassStudentInformation> getClassStudentInformations() {
        return classStudentInformations;
    }

    public void setClassStudentInformations(List<ClassStudentInformation> classStudentInformations) {
        this.classStudentInformations = classStudentInformations;
    }
    
}
