package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by pabonaj on 11/18/16.
 */
public class BenchmarkSession extends StudentSession {

    private String completedDate;

    public String getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(String completedDate) {
        this.completedDate = completedDate;
    }

}
