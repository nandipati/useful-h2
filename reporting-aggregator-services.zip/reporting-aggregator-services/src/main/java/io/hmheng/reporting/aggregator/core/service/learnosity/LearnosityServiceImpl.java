package io.hmheng.reporting.aggregator.core.service.learnosity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.AbilityEstimate;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.BenchmarkSubscores;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.Security;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionResponse;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionSubscoreRequest;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionsResponsesRequest;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionsResponsesResponse;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.LearnosityServiceResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.Discipline;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.utils.DisciplineHelper;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.util.StringUtils;

import static io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils.objectMapper;

/**
 * Created by pabonaj on 9/19/16.
 */
@Component
public class LearnosityServiceImpl implements LearnosityService {

    private static final Logger logger = LoggerFactory.getLogger(LearnosityServiceImpl.class);

    @Value("${learnosity.host.consumerKey}")
    public String consumerKey;

    @Value("${learnosity.host.domain}")
    public String domain;

    @Value("${learnosity.host.consumerSecret}")
    public String consumerSecret;

    @Value("${learnosity.host.maxNumberSessions}")
    public String maxNumberSessions;

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private HeadersHelper headersHelper;

    //TODO: Remove once we have full solution for Inprogress Student from io.hmheng.reporting.aggregator.config.lernosity.
    private static Map<UUID, AbilityEstimate> sessionToAbilityMap;

    @Autowired
    private DisciplineHelper disciplineHelper;

    private static final int SLOT_MATH_TOTALS = 12;
    private static final int SLOT_ELA_TOTALS = 8;

    @Override
    public LearnosityServiceResponse rescoreBySession(List<String> sessionList, List<Object> reportingSessionList){

        logger.debug("{}", "+rescoreBySession(List<String>)");

        List<Object> responseList = new ArrayList<Object>();
        LearnosityServiceResponse learnosityServiceResponse = new LearnosityServiceResponse();

        try {
            learnosityServiceResponse.setStatus(0);
            learnosityServiceResponse.setSessionIds(reportingSessionList);

            List<String> tmpList =  new ArrayList<String>();
            for (int i=0; i<sessionList.size(); i++) {
                tmpList.add(sessionList.get(i));
                int numberOfSessions = Integer.parseInt(maxNumberSessions);
                if (tmpList.size() == numberOfSessions || i == sessionList.size() - 1) {
                    try {
                        logger.debug("Sending session ids to Learnosity -->" + tmpList.toString());
                        String response = producerTemplate.requestBodyAndHeaders(
                                LearnosityRouteBuilder.postJobsSessionsScoresSubscoresEndpoint,
                                generateBodySessionSubscores(tmpList),
                                generateHeadersSessionSubscores(),
                                String.class);
                        logger.debug("Response from Learnosity -->" + response);
                        ObjectMapper mapper = new ObjectMapper();
                        Map<String,Object> map = mapper.readValue(response, Map.class);
                        responseList.add(map);
                    }
                    catch(Exception e) {
                        logger.warn("Exception from Learnosity: {}", e);
                        learnosityServiceResponse.appendToOtherIgnoredSessions(tmpList);
                    }
                    tmpList.clear();
                }
            }
            learnosityServiceResponse.setStatus(1);
            learnosityServiceResponse.setJsonLearnosity(responseList);
        }catch (Exception e) {
            logger.warn("Exception from LearnosityServiceImpl: {}", e);
            throw new RuntimeException(e);
        }
        logger.debug("{}", "-rescoreBySession(List<String>)");
        return learnosityServiceResponse;
    }

    @Override
    public LearnosityServiceResponse getSessionsResponses(List<String> sessionList, List<SessionsResponsesResponse> sessionResponseList){

        logger.debug("{}", "+getSessionsResponses(List<String>)");

        LearnosityServiceResponse learnosityServiceResponse = new LearnosityServiceResponse();

        try {
            List<SessionsResponsesResponse> sessionsResponsesResponseList = null;
            learnosityServiceResponse.setStatus(0);
            learnosityServiceResponse.setSessionIds((List)sessionList);
            List<String> tmpList =  new ArrayList<String>();

            for (int i=0; i<sessionList.size(); i++) {
                tmpList.add(sessionList.get(i));
                int numberOfSessions = Integer.parseInt(maxNumberSessions);
                if (tmpList.size() == numberOfSessions || i == sessionList.size() - 1) {
                    try {
                        logger.debug("Sending session ids to Learnosity -->" + tmpList.toString());
                        String response = producerTemplate.requestBodyAndHeaders(
                            LearnosityRouteBuilder.postSessionsResponsesEndpoint,
                            generateBodySessionsResponses(tmpList , Boolean.FALSE),
                            generateHeadersSessionSubscores(),
                            String.class);
                        logger.debug("Response from Learnosity -->" + response);
                        if (response != null && response.length() > 0) {
                            SessionsResponsesResponse sessionsResponsesResponse = objectMapper().readValue(response, new TypeReference<SessionsResponsesResponse>() {});
                            sessionResponseList.add(sessionsResponsesResponse);
                        }
                    }
                    catch(Exception e) {
                        logger.warn("Exception from Learnosity: {}", e);
                        learnosityServiceResponse.appendToOtherIgnoredSessions(tmpList);
                    }
                    tmpList.clear();
                }
            }
            learnosityServiceResponse.setStatus(1);
            learnosityServiceResponse.setJsonLearnosity((List)sessionResponseList);
        }catch (Exception e) {
            logger.warn("Exception from LearnosityServiceImpl: {}", e);
            throw new RuntimeException(e);
        }
        logger.debug("{}", "-getSessionsResponses(List<String>)");
        return learnosityServiceResponse;
    }

    @Override
    public Object[] getSessionsResponsesData(List<SessionsResponsesResponse> sessionsResponsesResponseList) {
        List<Object> dataList =  new ArrayList<Object>();
        for (SessionsResponsesResponse sessionsResponsesResponse : sessionsResponsesResponseList) {

            if (sessionsResponsesResponse != null && sessionsResponsesResponse.getData().size() > 0) {
                for (Object message : sessionsResponsesResponse.getData()) {
                    if (message != null) {
                        dataList.add(message);
                        logger.info("Lernosity Response {}", message.toString());
                    }
                }
            }

        }
        return dataList.toArray();
    }

    private Map<String, Object> generateHeadersSessionSubscores() {
        Map<String, Object> headers = headersHelper.createHeaderWithCorrelationOnly();
        return headers;
    }

    private String generateBodySessionSubscores(List<String> sessionList) {
        String body = null;
        try {

            Security security = new Security();
            SessionSubscoreRequest sessionSubscoreRequest = new SessionSubscoreRequest();

            sessionSubscoreRequest.setSession_id(sessionList);
            ObjectMapper objectMapper = new ObjectMapper();
            String strRequest = objectMapper.writeValueAsString(sessionSubscoreRequest);
            security.setDomain(this.domain);
            security.setConsumer_key(this.consumerKey);
            security.setConsumer_secret(this.consumerSecret);
            security.setSignature(strRequest);
            String strSecurity = objectMapper.writeValueAsString(security);

            body = String.format("security=%s&request=%s", strSecurity, strRequest);
            logger.debug("Subscores Job Parameters to Learnosity: {}", body);
        }
        catch(Exception e) {

        }
        return body;
    }

    private String generateBodySecurityRequest(String strRequest) {
        String body = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Security security = new Security();
            security.setDomain(this.domain);
            security.setConsumer_key(this.consumerKey);
            security.setConsumer_secret(this.consumerSecret);
            security.setSignature(strRequest);
            String strSecurity = objectMapper.writeValueAsString(security);
            body = String.format("security=%s&request=%s", strSecurity, strRequest);
        }
        catch(Exception e) {

        }
        return body;
    }

    private String generateBodySessionsResponses(List<String> sessionList , Boolean withMetadata) {
        String body = null;
        try {

            SessionsResponsesRequest sessionsResponses = new SessionsResponsesRequest();

            sessionsResponses.setSession_id(sessionList);
            if(withMetadata) {
                List<String> metadata = new ArrayList<String>();
                metadata.add("*");
                sessionsResponses.setMetadata(metadata);
            }

            ObjectMapper objectMapper = new ObjectMapper();
            String strRequest = objectMapper.writeValueAsString(sessionsResponses);
            body = generateBodySecurityRequest(strRequest);
        }
        catch(Exception e) {

        }
        return body;
    }

    private boolean isHttpResponseNotFound(Exception e) {
        return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
                && ((HttpOperationFailedException) e.getCause()).getStatusCode() == HttpStatus.NOT_FOUND.value();

    }

    public void populateAbilityEstimates(List<SessionsResponsesResponse> sessionsResponsesResponses){
        //TODO : Current requirement is populate from file if we have call any Lernosity Service.
        //TODO : Once Lernosity has service avaiable.
        if(sessionToAbilityMap == null){
            sessionToAbilityMap = new HashMap<>();

            String fileName = "lernosity/abilityestimate/INPROGRESS_SESSIONS.txt";

            try {
                ClassLoader classLoader = getClass().getClassLoader();
                File file = new File(classLoader.getResource(fileName).getFile());
                List<String> contents = FileUtils.readLines(file);

                // Iterate the result to print each line of the file.
                for (String line : contents) {
                    String[] columns = StringUtils.tokenizeToStringArray(line, "\t");
                    if(columns != null && columns.length > 1){
                        UUID sessionId = UUID.fromString(columns[0]);
                        AbilityEstimate abilityEstimate = new AbilityEstimate();
                        String abilityStringValue = columns[1];
                        if(!StringUtils.isEmpty(abilityStringValue)) {
                            abilityEstimate.setAbilityEstimate(Double.valueOf(abilityStringValue));
                        }
                        if(columns.length > 2){
                            String standardError = columns[2];
                            abilityEstimate.setStandardError(Double.valueOf(standardError));
                        }
                        if(!StringUtils.isEmpty(abilityStringValue)) {
                            sessionToAbilityMap.put(sessionId , abilityEstimate);
                        }
                    }
                }
            } catch (IOException e) {
                logger.error("Error while reading file {}",fileName,e);
            }
        }

        for(SessionsResponsesResponse sessionsResponsesResponse :sessionsResponsesResponses){
            List<SessionResponse> sessionResponses = sessionsResponsesResponse.getData();
            for(SessionResponse sessionResponse : sessionResponses){
                String status = sessionResponse.getStatus();
                if(!StringUtils.isEmpty(status) && !Constants.STATUS_COMPLETED.equals(status.toUpperCase())) {
                    UUID sessionId = sessionResponse.getSessionId();
                    AbilityEstimate abilityEstimate = sessionToAbilityMap.get(sessionId);
                    List<BenchmarkSubscores> subscores = sessionResponse.getSubscores();
                    for (BenchmarkSubscores subscore : subscores) {
                        String id = subscore.getId();
                        int slot = Integer.parseInt(id.substring(1));
                        Discipline decipline = disciplineHelper.getDisciplineForAssignmentDisciplineString(id);
                        if ((Discipline.E == decipline && SLOT_ELA_TOTALS == slot)
                            || (Discipline.M == decipline && SLOT_MATH_TOTALS == slot)) {
                            subscore.setAbilityEstimate(abilityEstimate);
                        } else {
                            //TODO: Code has to be removed and if conditions is not required.We will have Ability Estimatate
                            //TODO: At all Subscores level.
                            AbilityEstimate abilityEstimateDummy = new AbilityEstimate();
                            abilityEstimateDummy.setAbilityEstimate(0.0);
                            abilityEstimateDummy.setStandardError(0.0);
                            subscore.setAbilityEstimate(abilityEstimateDummy);
                        }
                    }
                }
            }
        }

    }

}
