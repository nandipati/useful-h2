package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.Discipline;
import io.hmheng.reporting.aggregator.utils.JsonCommons;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by nandipatim on 3/4/16.
 */
public class StudentSessionScores {

    private UUID activityId;
    private String grade;
    private String level;
    @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
    @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
    private LocalDateTime normDate;
    private Discipline discipline;
    private TestType eventType;
    private String resourceId;
    private Session session;

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public LocalDateTime getNormDate() {
        return normDate;
    }

    public void setNormDate(LocalDateTime normDate) {
        this.normDate = normDate;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public TestType getEventType() {
        return eventType;
    }

    public void setEventType(TestType eventType) {
        this.eventType = eventType;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    @Override
    public String toString() {
        return "StudentSessionScores{" +
            "activityId=" + activityId +
            ", grade='" + grade + '\'' +
            ", level='" + level + '\'' +
            ", normDate=" + normDate +
            ", discipline=" + discipline +
            ", eventType=" + eventType +
            ", session=" + session +
            '}';
    }
}
