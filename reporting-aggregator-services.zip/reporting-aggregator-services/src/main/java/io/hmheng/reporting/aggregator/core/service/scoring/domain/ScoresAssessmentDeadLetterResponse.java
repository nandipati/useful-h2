package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by pabonaj on 5/12/17.
 */
public class ScoresAssessmentDeadLetterResponse {

  private String scoresAssessmentDeadletterId;
  private UUID messageId;
  private String failureType;
  private String failureEventType;
  private String exception;
  private String data;
  private Integer status;
  private LocalDateTime failureDate;

  public String getScoresAssessmentDeadletterId() {
    return scoresAssessmentDeadletterId;
  }

  public void setScoresAssessmentDeadletterId(String scoresAssessmentDeadletterId) {
    this.scoresAssessmentDeadletterId = scoresAssessmentDeadletterId;
  }

  public UUID getMessageId() {
    return messageId;
  }

  public void setMessageId(UUID messageId) {
    this.messageId = messageId;
  }

  public String getFailureType() {
    return failureType;
  }

  public void setFailureType(String failureType) {
    this.failureType = failureType;
  }

  public String getFailureEventType() {
    return failureEventType;
  }

  public void setFailureEventType(String failureEventType) {
    this.failureEventType = failureEventType;
  }

  public String getException() {
    return exception;
  }

  public void setException(String exception) {
    this.exception = exception;
  }

  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  public LocalDateTime getFailureDate() {
    return failureDate;
  }

  public void setFailureDate(LocalDateTime failureDate) {
    this.failureDate = failureDate;
  }

}
