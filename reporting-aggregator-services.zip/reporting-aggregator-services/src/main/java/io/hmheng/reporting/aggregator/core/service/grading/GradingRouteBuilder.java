package io.hmheng.reporting.aggregator.core.service.grading;


import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static org.apache.camel.component.http4.HttpMethods.GET;


@Component
public class GradingRouteBuilder extends RouteBuilder {

    public static final String postPushScoresRouteId = "postPushScoresRoute";

    public static final String postPushScoresEndpoint = "direct://postPushScoresEndpoint";

    @Value("${grading.host.baseUrl}")
    private String gradingHost;

    @Autowired
    @Qualifier("gsonDateHourMinuteSecondMillsProcessor")
    private Processor gsonDateTimeProcessor;

    @Override
    public void configure() throws Exception {

        String postUpdateStatusScoresAssessmentDeadLetterPath = String.format("/v1/activities/pushScores");

        configurePostEndpoint(
            postPushScoresEndpoint,
            postPushScoresRouteId,
            postUpdateStatusScoresAssessmentDeadLetterPath,
            List.class);

    }

    private void configureEndpoint(String endpointUri, String endpointId, String url, Class<?> responseClass) {
        configureEndpoint(GET, endpointUri, endpointId, url, responseClass);
    }

    private void configurePostEndpoint(String endpoint, String routeId, String url, Class<?> responseClass) {
      configureEndpoint( HttpMethods.POST, endpoint, routeId, url, responseClass);
    }

    private void configureEndpoint(HttpMethods httpMethod, String endpointUri, String endpointId, String url, Class<?> responseClass) {
        from(endpointUri).id(endpointId)
                .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
                .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .bean(gsonDateTimeProcessor)
                .recipientList(simple(gradingHost + url))
                .unmarshal(configureDataFormat(responseClass))
                .end();
    }


    private JacksonDataFormat configureDataFormat(Class<?> clazz) {
      JacksonDataFormat dataFormat = new JacksonDataFormat(clazz);
      dataFormat.disableFeature(FAIL_ON_UNKNOWN_PROPERTIES);
      dataFormat.disableFeature(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
      dataFormat.disableFeature(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
      dataFormat.addModule(new JavaTimeModule());
      return dataFormat;
    }

    private void configureGetEndpoint(String endpoint, String routeId, String url) {
        configureGetEndpoint(endpoint, routeId, url, HttpMethods.GET);
    }

    private void configureGetEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod) {
        configureGetEndpoint(endpoint, routeId, url, httpMethod, MediaType.APPLICATION_JSON_UTF8);
    }
    private void configureGetEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod, MediaType mediaType) {
        from(endpoint)
                .id(routeId)
                .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
                .setHeader(Exchange.CONTENT_TYPE, constant(mediaType))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .bean(gsonDateTimeProcessor)
                .recipientList(simple(gradingHost + url))
                .end();
    }

}
