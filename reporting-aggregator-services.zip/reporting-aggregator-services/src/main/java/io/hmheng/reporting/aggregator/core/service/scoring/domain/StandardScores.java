package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import java.util.UUID;

/**
 * Created by suryadevarap on 4/4/18.
 */
public class StandardScores {

  private UUID standardId;
  private Integer itemCount;
  private Integer totalPoints;
  private Integer attainedPoints;
  private Integer correctItemsPoints;
  private Integer totalItemsCount;
  private Integer correctItemsCount;
  private Double avgItemsCorrect;
  private Double avgPointsCorrect;
  private Double standardProficiencyScore;
  private ProficiencyBand proficiencyBand;

  public UUID getStandardId() {
    return standardId;
  }

  public void setStandardId(UUID standardId) {
    this.standardId = standardId;
  }

  public Integer getItemCount() {
    return itemCount;
  }

  public void setItemCount(Integer itemCount) {
    this.itemCount = itemCount;
  }

  public Integer getTotalPoints() {
    return totalPoints;
  }

  public void setTotalPoints(Integer totalPoints) {
    this.totalPoints = totalPoints;
  }

  public Integer getAttainedPoints() {
    return attainedPoints;
  }

  public void setAttainedPoints(Integer attainedPoints) {
    this.attainedPoints = attainedPoints;
  }

  public Integer getCorrectItemsPoints() {
    return correctItemsPoints;
  }

  public void setCorrectItemsPoints(Integer correctItemsPoints) {
    this.correctItemsPoints = correctItemsPoints;
  }

  public Integer getTotalItemsCount() {
    return totalItemsCount;
  }

  public void setTotalItemsCount(Integer totalItemsCount) {
    this.totalItemsCount = totalItemsCount;
  }

  public Integer getCorrectItemsCount() {
    return correctItemsCount;
  }

  public void setCorrectItemsCount(Integer correctItemsCount) {
    this.correctItemsCount = correctItemsCount;
  }

  public Double getAvgItemsCorrect() {
    return avgItemsCorrect;
  }

  public void setAvgItemsCorrect(Double avgItemsCorrect) {
    this.avgItemsCorrect = avgItemsCorrect;
  }

  public Double getAvgPointsCorrect() {
    return avgPointsCorrect;
  }

  public void setAvgPointsCorrect(Double avgPointsCorrect) {
    this.avgPointsCorrect = avgPointsCorrect;
  }

  public Double getStandardProficiencyScore() {
    return standardProficiencyScore;
  }

  public void setStandardProficiencyScore(Double standardProficiencyScore) {
    this.standardProficiencyScore = standardProficiencyScore;
  }

  public ProficiencyBand getProficiencyBand() {
    return proficiencyBand;
  }

  public void setProficiencyBand(ProficiencyBand proficiencyBand) {
    this.proficiencyBand = proficiencyBand;
  }

  @Override
  public String toString() {
    return "StandardScores{" +
        "standardId=" + standardId +
        ", itemCount=" + itemCount +
        ", totalPoints=" + totalPoints +
        ", attainedPoints=" + attainedPoints +
        ", correctItemsPoints=" + correctItemsPoints +
        ", totalItemsCount=" + totalItemsCount +
        ", correctItemsCount=" + correctItemsCount +
        ", avgItemsCorrect=" + avgItemsCorrect +
        ", avgPointsCorrect=" + avgPointsCorrect +
        ", standardProficiencyScore=" + standardProficiencyScore +
        ", proficiencyBand=" + proficiencyBand +
        '}';
  }
}
