package io.hmheng.reporting.aggregator.core.service.scoring.domain;

/**
 * Created by nandipatim on 3/4/16.
 */
public enum ItemResponse {

    CORRECT,
    INCORRECT,
    NOT_ANSWERED,
    PARTIAL_CREDIT,
    NOT_SCORED
}
