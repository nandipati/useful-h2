package io.hmheng.reporting.aggregator.core.service.mds;

import io.hmheng.reporting.aggregator.core.service.AuthorizationService;
import io.hmheng.reporting.aggregator.core.service.mds.domains.ItemsExternalRefIdResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchAssessmentItemsListResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OnesearchItemResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardsResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Title;
import io.hmheng.reporting.aggregator.core.service.utils.Headers;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import io.hmheng.reporting.aggregator.web.domain.assignment.ProductType;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import static io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils.objectMapper;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.fasterxml.jackson.core.type.TypeReference;

import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created by nandipatim on 3/16/16.
 */
@Component
public class MDSServiceImpl implements MDSService{

    private static final Logger logger = LoggerFactory.getLogger(MDSServiceImpl.class);

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private HeadersHelper headersHelper;

    private LoadingCache<MdsStandardCacheKey, StandardsResponse> standardsResponseLoadingCache= CacheBuilder.newBuilder().
            expireAfterWrite(30, TimeUnit.MINUTES).softValues().build(new CacheLoader<MdsStandardCacheKey, StandardsResponse>() {
        @Override
        public StandardsResponse load(MdsStandardCacheKey s) throws Exception {
            return getStandardDetailsByStandardRefIdNotCached(s);
        }
    });
    @Override
    public OnesearchItemResponse getItemDetailsByProgramItemRefId(String itemRefId) {
        OnesearchItemResponse onesearchItemResponse=null;
        logger.debug("{}", "+getItemDetailsByProgramItemRefId(String)");
        try {

            String response = producerTemplate.requestBodyAndHeaders(
                MDSRouteBuilder.getItemDetailsFromOnesearchEndpoint,
                "",
                generateHeadersForItemRefId(itemRefId),
                String.class);
            logger.debug("Response from OneSearch -->" + response);
            if(response!= null)
                onesearchItemResponse = getGsonObject(response , OnesearchItemResponse.class);
        }catch (Exception e) {
            logger.warn("Exception from OneSearch: {}", e);
            return null;
        }


        logger.debug("{}", "-getItemDetailsByProgramItemRefId(String)");
        return onesearchItemResponse;
    }

    @Override
    public OneSearchAssessmentItemsListResponse getItemsByAssessmentId(String assessmentId) {

      OneSearchAssessmentItemsListResponse assessmentItemsListResponse = null;
      logger.debug("{}", "+getItemsByAssessmentId(String)");
      try {

        String response = producerTemplate.requestBodyAndHeaders(
            MDSRouteBuilder.getItemsListDetailsFromOneSearchEndpoint,
            "",
            generateHeadersForAssessmentIdOneSearch(assessmentId),
            String.class);
        logger.debug("Response from OneSearch -->" + response);
        if(response!= null)
            assessmentItemsListResponse = objectMapper().readValue(response, new TypeReference<OneSearchAssessmentItemsListResponse>() {});
      }catch (Exception e) {
        logger.warn("Exception from OneSearch: {}", e);
        return null;
      }

      logger.debug("{}", "-getItemDetailsByProgramItemRefId(String)");
      return assessmentItemsListResponse;
    }

    public ItemsExternalRefIdResponse getItemDetailByItemRefId(String itemRefId, int pageLength){

        ItemsExternalRefIdResponse itemsExternalRefIdResponse = null;

        logger.debug("{}", "+getItemDetailByItemRefId(String)");

        try {

            String response = producerTemplate.requestBodyAndHeaders(
                    MDSRouteBuilder.getItemDetailsForAssesmentEndpoint,
                    "",
                    generateHeadersForItemRefId(itemRefId, pageLength),
                    String.class);
            logger.debug("Response from MDS -->" + response);
            if(response!= null)
                itemsExternalRefIdResponse = getGsonObject(response , ItemsExternalRefIdResponse.class);
        }catch (Exception e) {
            logger.warn("Exception from MDS: {}", e);
            return null;
        }


        return itemsExternalRefIdResponse;
    }
    public StandardsResponse getStandardDetailsByStandardRefId(String standardRefId, TestType testType) {
        try {
            return standardsResponseLoadingCache.get(new MdsStandardCacheKey(standardRefId, testType));
        } catch (ExecutionException e) {
            logger.warn("Exception from (cached) MDS: {}", e);
        }
        return null;
    }
    private StandardsResponse getStandardDetailsByStandardRefIdNotCached(MdsStandardCacheKey standardInfo){

        StandardsResponse standardsResponse = null;

        logger.debug("{}", "+getStandardDetailsByStandardRefId(String)");
        String standardRefId=standardInfo.getStandardIds();
        TestType testType=standardInfo.getTestType();
        ProductType productType = testType.getProductType();
        try{
            String response=null;
          if(productType == ProductType.ED){
              response = producerTemplate.requestBodyAndHeaders(MDSRouteBuilder.getStandardDetailsOnesearchEndpoint, "",
                  generateHeadersForStandardRefIdOnesearch(standardRefId), String.class);
          }
          else {
                response = producerTemplate.requestBodyAndHeaders(
                    MDSRouteBuilder.getStandardDetailsEndpoint,
                    "",
                    generateHeadersForStandardRefId(standardRefId),
                    String.class);
            }
            logger.debug("Response from MDS getStandardDetailsByStandardRefId(String) --> id -->"+standardRefId+" Response -->" + response);
            if(response != null)
                standardsResponse = getGsonObject(response , StandardsResponse.class);
        }catch(Exception e){
            logger.warn("Exception from MDS: {}", e);

            return null;
        }

        return standardsResponse;
    }


    private Map<String, Object> generateHeadersForItemRefId(String itemRefId, int pageLength) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(null,null, AuthorizationService.Service.MDS);
        headers.put(Headers.ITEM_REF_ID, itemRefId);
        headers.put(Headers.PAGE_LENGTH, pageLength);
        return headers;
    }
    private Map<String, Object> generateHeadersForItemRefId(String itemRefId) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(null,null, AuthorizationService.Service.MDS);
        headers.put(Headers.ITEM_REF_ID, itemRefId);
        return headers;
    }

    private Map<String, Object> generateHeadersForStandardRefId(String standardId) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(null,null, AuthorizationService.Service.MDS);
        headers.put(Headers.STANDARD_ID, standardId);
        return headers;
    }
    private Map<String, Object> generateHeadersForStandardRefIdOnesearch(String standardId) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(null,null, AuthorizationService.Service.OneSearch);
        headers.put(Headers.STANDARD_ID, standardId);
        return headers;
    }

    private Map<String, Object> generateHeadersForAssessmentIdOneSearch(String assessmentId) {
      Map<String, Object> headers = headersHelper.createBasicHeaders(null,null, AuthorizationService.Service.OneSearch);
      headers.put(Headers.ASSESSMENT_ID, assessmentId);
      return headers;
    }

    public static <T> T getGsonObject(String messageBody , Class<T> classOfT){
        GsonBuilder gsonBuilder=new GsonBuilder();
        gsonBuilder.registerTypeAdapter(Title.class, new Title.TitleJsonDeserializer());
        Gson gson=gsonBuilder.create();
        return gson.fromJson(messageBody , classOfT);
    }
    private static class MdsStandardCacheKey {
        private String standardIds;
        private TestType testType;
        public MdsStandardCacheKey() {

        }
        public MdsStandardCacheKey(String standardIds, TestType testType) {
            this.standardIds = standardIds;
            this.testType = testType;
        }

        public String getStandardIds() {
            return standardIds;
        }

        public void setStandardIds(String standardIds) {
            this.standardIds = standardIds;
        }

        public TestType getTestType() {
            return testType;
        }

        public void setTestType(TestType testType) {
            this.testType = testType;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            MdsStandardCacheKey that = (MdsStandardCacheKey) o;

            if (!standardIds.equals(that.standardIds)) return false;
            return testType == that.testType;
        }

        @Override
        public int hashCode() {
            int result = standardIds.hashCode();
            result = 31 * result + testType.hashCode();
            return result;
        }
    }
}
