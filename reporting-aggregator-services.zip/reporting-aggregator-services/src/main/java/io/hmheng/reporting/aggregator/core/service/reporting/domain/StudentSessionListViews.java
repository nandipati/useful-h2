package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.core.service.reporting.SessionId;

import java.util.List;

/**
 * Created by somashekara on 11/15/16.
 */
public class StudentSessionListViews {

    private List<SessionId> content;
    private int totalPages;
    private int totalElements;
    private int size;
    private int number;
    private int numberOfElements;
    private boolean first;
    private boolean last;
    private boolean sort;

    public StudentSessionListViews(List<SessionId> content, int totalPages, int totalElements, int size, int number, int numberOfElements, boolean first, boolean last, boolean sort) {
        this.content = content;
        this.totalPages = totalPages;
        this.totalElements = totalElements;
        this.size = size;
        this.number = number;
        this.numberOfElements = numberOfElements;
        this.first = first;
        this.last = last;
        this.sort = sort;
    }

    public boolean isSort() {
        return sort;
    }

    public void setSort(boolean sort) {
        this.sort = sort;
    }

    public StudentSessionListViews() {
    }

    public List<SessionId> getContent() {
        return content;
    }

    public void setContent(List<SessionId> content) {
        this.content = content;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {
        this.totalElements = totalElements;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumberOfElements() {
        return numberOfElements;
    }

    public void setNumberOfElements(int numberOfElements) {
        this.numberOfElements = numberOfElements;
    }

    public boolean isFirst() {
        return first;
    }

    public void setFirst(boolean first) {
        this.first = first;
    }

    public boolean isLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }
}

