package io.hmheng.reporting.aggregator.core.service.reporting;

import java.util.List;
import java.util.UUID;

/**
 * Created by suryadevarap on 12/1/17.
 */
public class ReprocessAssignmentsWrapper {
  private List<UUID> assignmentId;

  public List<UUID> getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(List<UUID> assignmentId) {
    this.assignmentId = assignmentId;
  }
}
