package io.hmheng.reporting.aggregator.core.service.scoring;

import com.fasterxml.jackson.core.type.TypeReference;
import io.hmheng.reporting.aggregator.core.service.grading.domain.SessionWrapper;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.EventSessionView;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.FormativeActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoreEventResponseInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoresAssessmentDeadLetter;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoresAssessmentDeadLetterResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Sessions;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StandardSession;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static io.hmheng.reporting.aggregator.core.service.AuthorizationService.Service.Scoring;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.*;
import static io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils.objectMapper;

@Service
public class ScoringServiceImpl implements ScoringService {

    private static final Logger logger = LoggerFactory.getLogger(ScoringServiceImpl.class);

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private HeadersHelper headersHelper;

    private String deadLetterPageSize = "30";

    @Override
    public BenchmarkActivityScoresResponse getBenchmarkActivityScores(UUID activityId) {
        logger.info("{} []", " + getBenchmarkActivityScores(UUID)", activityId);

        BenchmarkActivityScoresResponse benchmarkActivityScoresResponse = null;
        Sessions sessionsCollector = new Sessions();
        sessionsCollector.setContent(new ArrayList<>());
        Sessions sessions;
        int page = 0;
        try {
            do {
                benchmarkActivityScoresResponse = producerTemplate
                    .requestBodyAndHeaders(ScoringRouteBuilder.getBenchmarkActivityScoresEndpoint, "",
                        generateHeadersForScores(activityId, page++, 100), BenchmarkActivityScoresResponse.class);

                sessions = Optional.ofNullable(benchmarkActivityScoresResponse)
                    .map(BenchmarkActivityScoresResponse::getSessions).orElse(null);

                if (sessions != null && (!CollectionUtils.isEmpty(sessions.getContent()))) {
                    logger.info("{} Benchmark scores returned: {}", sessions.getContent().size(), sessions.getContent
                        ().toString());
                    sessionsCollector.getContent().addAll(sessions.getContent());
                } else {
                    logger.info("No Benchmark scores returned!");
                }
            } while (sessions != null && !(sessions.isLast() || CollectionUtils.isEmpty(sessions.getContent())));
            sessionsCollector.setLast(true);
            sessionsCollector.setTotalPages(page-1);
            sessionsCollector.setTotalElements(sessionsCollector.getContent().size());
            benchmarkActivityScoresResponse.setSessions(sessionsCollector);
        } catch (Exception e) {
            logger.warn("Exception from Scoring: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.info("{} []", "-getBenchmarkActivityScores(UUID)", activityId);

        return benchmarkActivityScoresResponse;
    }

    @Override
    public FormativeActivityScoresResponse getFormativeActivityScores(UUID activityId) {
        logger.info("{} {}", " + getFormativeActivityScores(UUID)", activityId);
        FormativeActivityScoresResponse formativeActivityScoresResponse = null;
        Sessions sessionsCollector = new Sessions();
        sessionsCollector.setContent(new ArrayList<>());
        Sessions sessions;
        int page = 0;
        try {
            do {
                formativeActivityScoresResponse = producerTemplate
                    .requestBodyAndHeaders(ScoringRouteBuilder.getFormativeActivityScoresEndpoint, "",
                        generateHeadersForScores(activityId, page++, 100), FormativeActivityScoresResponse.class);
                sessions = Optional.ofNullable(formativeActivityScoresResponse)
                    .map(FormativeActivityScoresResponse::getSessions).orElse(null);
                if (sessions != null && (!CollectionUtils.isEmpty(sessions.getContent()))) {
                    logger.info("{} Formative scores returned: {} {}", sessions.getContent().size(), sessions.getContent
                        ().toString(), activityId);
                    sessionsCollector.getContent().addAll(sessions.getContent());
                } else {
                    logger.info("No Formative scores returned! {}", activityId);
                }
            } while (sessions != null && !(sessions.isLast() || CollectionUtils.isEmpty(sessions.getContent())));
            sessionsCollector.setLast(true);
            sessionsCollector.setTotalPages(page-1);
            sessionsCollector.setTotalElements(sessionsCollector.getContent().size());
            formativeActivityScoresResponse.setSessions(sessionsCollector);
        } catch (Exception e) {
            logger.warn("Exception from Scoring: {} {}", e, activityId);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.info("{} {}", "-getFormativeActivityScores(UUID)", activityId);

        return formativeActivityScoresResponse;
    }

    @Override
    public StudentSessionScores getFormativeStudentSessionScores(UUID activityId , UUID sessionId){
        logger.info("{}", " + getFormativeStudentSessionScores(UUID,UUID)");

        StudentSessionScores studentSessionScoresResponse = null;

        try {

            studentSessionScoresResponse = producerTemplate.requestBodyAndHeaders(
                ScoringRouteBuilder.getFormativeStudentSessionScoresEndpoint,
                "",
                generateHeadersForStudentSessionScores(activityId, sessionId),
                StudentSessionScores.class);
        } catch (Exception e) {
            logger.warn("Exception from Scoring: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }
        logger.info("{} Scores returned: {}", (studentSessionScoresResponse != null)?
            ((studentSessionScoresResponse.getSession() != null)?studentSessionScoresResponse.getSession()
                .toString():"null"):null);

        logger.info("{}", "-getFormativeStudentSessionScores(UUID,UUID)");

        return studentSessionScoresResponse;
    }

    @Override
    public StudentSessionScores getBenchmarkStudentSessionScores(UUID activityId , UUID sessionId){
        logger.info("{}", " + getBenchmarkStudentSessionScores(UUID,UUID)");

        StudentSessionScores studentSessionScoresResponse = null;

        try {

            studentSessionScoresResponse = producerTemplate.requestBodyAndHeaders(
                ScoringRouteBuilder.getBenchmarkStudentSessionScoresEndpoint,
                "",
                generateHeadersForStudentSessionScores(activityId, sessionId),
                StudentSessionScores.class);
        } catch (Exception e) {
            logger.warn("Exception from Scoring: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }
        logger.info("{} Scores returned: {}", (studentSessionScoresResponse != null)?
            ((studentSessionScoresResponse.getSession() != null)?studentSessionScoresResponse.getSession()
                .toString(): "null"):null);

        logger.info("{}", "-getBenchmarkStudentSessionScores(UUID,UUID)");

        return studentSessionScoresResponse;
    }

    @Override
    public ScoreEventResponseInfo postEventDetails(AssignmentEventInfo assignmentEventInfo){
        logger.debug("{}", " + postEventDetails(UUID,UUID,ScoreEventResponseInfo)");

        ScoreEventResponseInfo response = null;

        try{
            response = producerTemplate.requestBodyAndHeaders(
            ScoringRouteBuilder.postEventEndpoint,
            assignmentEventInfo,
            generateHeadersForEventDetails(assignmentEventInfo.getEventRefId(), assignmentEventInfo.getActivityId(),true),
                ScoreEventResponseInfo.class);
        } catch (Exception e){
            logger.warn("Exception from Scoring: {}", e);

            if (isHttpResponseNotFound(e) || isHttpResponseNotCreated(e)) {
                return null;
            }

        }
        return response;
    }

    @Override
    public void postStudentDetails(UUID eventId, List<StudentInfo> studentInfoList){
        logger.debug("{}", " + postStudentDetails(UUID,UUID,ScoreEventResponseInfo)");



        try{
            producerTemplate.requestBodyAndHeaders(
                    ScoringRouteBuilder.postStudentAssignmentEndpoint,
                    studentInfoList,
                    generateHeadersForEventDetails(eventId));
        } catch (Exception e){
            logger.warn("Exception from Scoring: {}", e);

            if (isHttpResponseNotFound(e) || isHttpResponseNotCreated(e)) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public ScoresAssessmentDeadLetterResponse saveDeadLetter(ScoresAssessmentDeadLetter scoresAssessmentDeadLetter) {
        logger.debug("{}", " +saveDeadLetter(PushScoreStatus)");
        ScoresAssessmentDeadLetterResponse response = null;
        try{
            response = producerTemplate.requestBodyAndHeaders(
                ScoringRouteBuilder.postScoresAssessmentDeadLetterEndpoint,
                scoresAssessmentDeadLetter,
                generateHeadersForDeadLetter(),
                ScoresAssessmentDeadLetterResponse.class);
        } catch (Exception e){
            logger.warn("Exception from Scoring: {}", e);
            if (isHttpResponseNotFound(e) || isHttpResponseNotCreated(e)) {
                return null;
            }
        }
        logger.debug("{}", " -saveDeadLetter(PushScoreStatus)");
        return response;
    }

    @Override
    public List<ScoresAssessmentDeadLetter> getScoresAssessmentDeadLetter(List<UUID> messageIdList){
        logger.debug("{}", "-getScoresAssessmentDeadLetter(List<UUID>)");
        List<ScoresAssessmentDeadLetter> response = null;
        try{
            response = producerTemplate.requestBodyAndHeaders(
                ScoringRouteBuilder.postAllScoresAssessmentDeadLetterEndpoint,
                messageIdList,
                generateHeadersForDeadLetter(),
                List.class);
            response = objectMapper().convertValue(response, new TypeReference<List <ScoresAssessmentDeadLetter>>() {
            });
        } catch (Exception e){
            logger.warn("Exception from Scoring: {}", e);
            if (isHttpResponseNotFound(e) || isHttpResponseNotCreated(e)) {
                return null;
            }
        }
        logger.debug("{}", " -getScoresAssessmentDeadLetter(List<UUID>)");
        return response;
    }

    @Override
    public List<ScoresAssessmentDeadLetter> updateScoresAssessmentDeadLetter(List<UUID> messageIdList){
      logger.debug("{}", "-getScoresAssessmentDeadLetter(List<UUID>)");
      List<ScoresAssessmentDeadLetter> response = null;
      try{
        response = producerTemplate.requestBodyAndHeaders(
            ScoringRouteBuilder.postUpdateStatusScoresAssessmentDeadLetterEndpoint,
            messageIdList,
            generateHeadersForDeadLetter(),
            List.class);
        response = objectMapper().convertValue(response, new TypeReference<List <ScoresAssessmentDeadLetter>>() {
        });
      } catch (Exception e){
        logger.warn("Exception from Scoring: {}", e);
        if (isHttpResponseNotFound(e) || isHttpResponseNotCreated(e)) {
          return null;
        }
      }
      logger.debug("{}", " -getScoresAssessmentDeadLetter(List<UUID>)");
      return response;
    }

    @Override
    public List<EventSessionView> findEventBySessionId(List<UUID> sessionIds){
        logger.info("{}", " + findEventBySessionId(UUID)");

        List<EventSessionView> response = null;
        SessionWrapper wrapper = new SessionWrapper();
        wrapper.setSessionIds(sessionIds);

        try {

            response = producerTemplate.requestBodyAndHeaders(
                    ScoringRouteBuilder.postEventBySessionEndpoint,
                    wrapper,
                    generateHeadersForEventBySession(),
                    List.class);
            response = objectMapper().convertValue(response, new TypeReference<List <EventSessionView>>() {
            });
        } catch (Exception e) {
            logger.warn("Exception from Scoring: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }
        logger.debug("{}", " -findEventBySessionId(List<UUID>)");

        return response;
    }

    @Override
    public List<StandardSession> getStudents(List<UUID> sessions) {
        logger.info("{}", " + findBySessionId(UUID)");

        List<StandardSession> response = null;
        SessionWrapper wrapper = new SessionWrapper();
        wrapper.setSessionIds(sessions);

        try {
            response = producerTemplate.requestBodyAndHeaders(
                ScoringRouteBuilder.postBySessionEndpoint,
                wrapper,
                generateHeadersForEventBySession(),
                List.class);
            response = objectMapper().convertValue(response, new TypeReference<List<EventSessionView>>() {
            });
        } catch (Exception e) {
            logger.warn("Exception from Scoring: {}", e);
            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }
        logger.debug("{}", " -findBySessionId(List<UUID>)");

        return response;
    }

    private boolean isHttpResponseNotFound(Exception e) {
        return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
            && ((HttpOperationFailedException) e.getCause()).getStatusCode() == HttpStatus.NOT_FOUND.value();

    }

    private boolean isHttpResponseNotCreated(Exception e) {
        return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
            && ((HttpOperationFailedException) e.getCause()).getStatusCode() != HttpStatus.CREATED.value();

    }

    private Map<String, Object> generateHeadersForEventBySession() {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        return headers;
    }

    private Map<String, Object> generateHeadersForScores(UUID activityId, int page, int size) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        headers.put(ACTIVITY_ID, activityId.toString());
        headers.put(PAGE, String.valueOf(page));
        headers.put(SIZE, String.valueOf(size));
        return headers;
    }

    private Map<String, Object> generateHeadersForStudentSessionScores(UUID activityId, UUID sessionId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        headers.put(ACTIVITY_ID, activityId.toString());
        headers.put(SESSION_REFID,sessionId.toString());
        return headers;
    }


    private Map<String, Object> generateHeadersForEventDetails(UUID eventId, UUID activityId,boolean updateEventGroups) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        headers.put(EVENT_REFID, eventId.toString());
        headers.put(ACTIVITY_ID,activityId.toString());
        headers.put(UPDATEEVENTGROUPS,updateEventGroups);
        return headers;
    }

    private Map<String, Object> generateHeadersForEventDetails(UUID eventId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        headers.put(EVENT_REFID, eventId.toString());
        return headers;
    }

    private Map<String, Object> generateHeadersForDeadLetter() {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        return headers;
    }

    private Map<String, Object> generateHeadersForDeadLetterReprocess(UUID messageId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Scoring);
        headers.put(MESSAGE_ID, messageId.toString());
        return headers;
    }

    @Override
    public String deleteTeacherAssignment(UUID eventRefId) {
      String response = null;
      try {
        response = producerTemplate.requestBodyAndHeaders(ScoringRouteBuilder.deleteTeacherAssignmentEndpoint,
                null, generateHeadersForEventDetails(eventRefId), String.class);
      } catch (Exception e) {
        logger.warn("Exception from Reporting: {}", e);
        if (isHttpResponseNotFound(e)) {
          return null;
        }

      }
      return response;
    }
}
