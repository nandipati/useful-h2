package io.hmheng.reporting.aggregator.core.service.mds.domains;


public class OneSearchItems
{
  private String identifier;

  private String itemPosition;

  private String manuallyScorable;

  public String getIdentifier() {
    return identifier;
  }

  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  public String getItemPosition() {
    return itemPosition;
  }

  public void setItemPosition(String itemPosition) {
    this.itemPosition = itemPosition;
  }

  public String getManuallyScorable() {
    return manuallyScorable;
  }

  public void setManuallyScorable(String manuallyScorable) {
    this.manuallyScorable = manuallyScorable;
  }

  @Override
  public String toString() {
    return "OneSearchItems{" +
        "identifier='" + identifier + '\'' +
        ", itemPosition='" + itemPosition + '\'' +
        ", manuallyScorable='" + manuallyScorable + '\'' +
        '}';
  }

}
