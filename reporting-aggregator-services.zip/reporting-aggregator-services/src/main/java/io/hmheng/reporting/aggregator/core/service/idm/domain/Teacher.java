package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.UUID;

public class Teacher {

  private UUID refId;
  private Name name;

  public Teacher(){}

  public Teacher(UUID refId, Name name) {
    this.refId = refId;
    this.name = name;
  }

  public UUID getRefId() {
    return refId;
  }

  public void setRefId(UUID refId) {
    this.refId = refId;
  }

  public Name getName() {
    return name;
  }

  public void setName(Name name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return "Teacher{" +
        "refId=" + refId +
        ", name='" + name + '\'' +
        '}';
  }

  public static class Name {
    private String firstName;
    private String middleInitial;
    private String lastName;

    public Name(){}

    public Name(String firstName, String middleInitial, String lastName) {
      this.firstName = firstName;
      this.middleInitial = middleInitial;
      this.lastName = lastName;
    }

    public String getFirstName() { return firstName; }

    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getMiddleInitial() { return middleInitial; }

    public void setMiddleInitial(String middleInitial) { this.middleInitial = middleInitial; }

    public String getLastName() { return lastName; }

    public void setLastName(String lastName) { this.lastName = lastName; }
  }



}

