package io.hmheng.reporting.aggregator.core.service.mds.domains;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Created by nandipatim on 3/18/16.
 */
public class Standards {

    @JsonProperty(value = "standard")
    private List<Standard> standard;

    @JsonProperty(value = "abguids")
    private List<Standard.Abguid> abguids;


    public List<Standard> getStandard() {
        return standard;
    }

    public void setStandard(List<Standard> standard) {
        this.standard = standard;
    }

    public List<Standard.Abguid> getAbguids() {
        return abguids;
    }

    public void setAbguids(List<Standard.Abguid> abguids) {
        this.abguids = abguids;
    }
}
