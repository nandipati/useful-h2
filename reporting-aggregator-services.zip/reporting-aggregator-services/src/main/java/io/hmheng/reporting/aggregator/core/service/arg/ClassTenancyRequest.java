package io.hmheng.reporting.aggregator.core.service.arg;

import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import java.util.UUID;

public class ClassTenancyRequest {

    private UUID leaRefId;
    private UUID schoolRefId;
    private UUID studentActivityRefId;
    private UUID studentPersonalRefId;
    private UUID testingEventRefId;
    private UUID reportingActivityId;
    private String contextId;
    private SourceObjectType sourceObjectType;
    private String sourceTopicName;
    private boolean idsEnabledFlag=Boolean.FALSE;
    private UUID sectionId;
    private String platformId;

    public ClassTenancyRequest(UUID leaRefId, UUID schoolRefId, UUID studentActivityRefId, UUID studentPersonalRefId,
                               String contextId) {
        this.leaRefId = leaRefId;
        this.schoolRefId = schoolRefId;
        this.studentActivityRefId = studentActivityRefId;
        this.studentPersonalRefId = studentPersonalRefId;
        this.contextId = contextId;

    }

    public ClassTenancyRequest(UUID leaRefId, UUID schoolRefId, UUID studentActivityRefId, UUID studentPersonalRefId,
        String contextId, String platformId, UUID sectionId) {
        this.leaRefId = leaRefId;
        this.schoolRefId = schoolRefId;
        this.studentActivityRefId = studentActivityRefId;
        this.studentPersonalRefId = studentPersonalRefId;
        this.contextId = contextId;
        this.platformId = platformId;
        this.sectionId = sectionId;
    }

    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    public UUID getStudentActivityRefId() {
        return studentActivityRefId;
    }

    public void setStudentActivityRefId(UUID studentActivityRefId) {
        this.studentActivityRefId = studentActivityRefId;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getTestingEventRefId() {
        return testingEventRefId;
    }

    public void setTestingEventRefId(UUID testingEventRefId) {
        this.testingEventRefId = testingEventRefId;
    }

    public String getContextId() {
        return contextId;
    }

    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getReportingActivityId() {
        return reportingActivityId;
    }

    public void setReportingActivityId(UUID reportingActivityId) {
        this.reportingActivityId = reportingActivityId;
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

    public void setSourceObjectType(SourceObjectType sourceObjectType) {
        this.sourceObjectType = sourceObjectType;
    }

    public String getSourceTopicName() {
        return sourceTopicName;
    }

    public void setSourceTopicName(String sourceTopicName) {
        this.sourceTopicName = sourceTopicName;
    }

    public boolean isIdsEnabledFlag() { return idsEnabledFlag; }

    public void setIdsEnabledFlag(boolean idsEnabledFlag) { this.idsEnabledFlag = idsEnabledFlag; }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

}
