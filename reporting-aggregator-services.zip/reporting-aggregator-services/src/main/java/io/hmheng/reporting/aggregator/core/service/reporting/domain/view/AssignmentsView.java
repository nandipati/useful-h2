package io.hmheng.reporting.aggregator.core.service.reporting.domain.view;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

/**
 * Created by suryadevarap on 11/28/17.
 */
public class AssignmentsView {

  @JsonProperty("assignmentId")
  private List<UUID> assignmentList;

  public List<UUID> getAssignmentList() {
    return assignmentList;
  }

  public void setAssignmentList(List<UUID> assignmentList) {
    this.assignmentList = assignmentList;
  }

}
