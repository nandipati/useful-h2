package io.hmheng.reporting.aggregator.core.service.scoring;

import com.fasterxml.jackson.core.type.TypeReference;

import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchAssessmentItems;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchAssessmentItemsListResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchItems;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.DomainStandard;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ItemDetails;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StandardScores;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StandardSession;
import io.hmheng.reporting.aggregator.utils.ContentSource;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import io.hmheng.reporting.aggregator.core.service.mds.MDSService;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Item;
import io.hmheng.reporting.aggregator.core.service.mds.domains.ItemsExternalRefIdResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OnesearchItemResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Question;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Result;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Standard;
import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardSet;
import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardToItems;
import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardsResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityItemsPerformance;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsPerformance;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScoreInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScoreRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentTotalScoreInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.PerformanceLevel;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsToItemsMapInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.Subscore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemBase;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentTotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoringSource;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import static io.hmheng.reporting.aggregator.core.service.utils.MDSMessageParserHelper.createNoStandard;


/**
 * Created by nandipatim on 3/4/16.
 */
@Component
public class ScoreHelper {

    private static final Logger logger = LoggerFactory.getLogger(ScoreHelper.class);

    @Autowired
    private MDSService mdsService;

    @Autowired
    private ReportingService reportingService;

    @Value("${event.studentAssignmentStandardScores.noStandard}")
    public String noStandard;

    @Value("${event.studentAssignmentStandardScores.bandUpdate}")
    public Boolean bandUpdate;


    public static final String CONSTANT_ITEM= "Item ";
    public static final int ITEM_REF_ID_COUNT = 15;
    public static final int STANDARD_REF_ID_COUNT = 6;
    public static final String ITEM_REF_ID_DELIMITER = " OR externalRefId:";

    static int NO_OF_RETRY = 3;

  public TotalScore convertScoreIntoTotalScore(BenchmarkScore benchmarkScore){

        TotalScore ts = new TotalScore();
        ts.setTotalAbilityEstimate(benchmarkScore.getAbilityEstimate());
        ts.setTotalStandardError(benchmarkScore.getStandardError());
        ts.setTotalAbbr(benchmarkScore.getAbbr());
        ts.setTotalAchievementLevel(benchmarkScore.getAchievementLevel());
        ts.setTotalCompletionCriteria(benchmarkScore.getCompletionCriteria());
        ts.setTotalCompletionCriteriaPercentage(benchmarkScore.getCompletionCriteriaPercentage());
        ts.setTotalIpCeil(benchmarkScore.getIpCeil());
        ts.setTotalIpFloor(benchmarkScore.getIpFloor());
        ts.setTotalLpr(benchmarkScore.getLpr());
        ts.setTotalMaxScore(benchmarkScore.getMaxScore());
        ts.setTotalName(benchmarkScore.getName());
        ts.setTotalNumberAttempted(benchmarkScore.getNumberAttempted());
        ts.setTotalNumberQuestions(benchmarkScore.getNumberQuestions());
        ts.setSkippedQuestions(benchmarkScore.getSkippedQuestions());
        ts.setCompletionCriteriaNotMet(benchmarkScore.getCompletionCriteriaNotMet());
        ts.setInCompleteTestRecord(benchmarkScore.getInCompleteTestRecord());
        ts.setItemsOmitted(benchmarkScore.getItemsOmitted());
        ts.setTotalScaleScore(benchmarkScore.getScaleScore());
        ts.setTotalScore(benchmarkScore.getScore());
        ts.setTotalScoreType(benchmarkScore.getScoreType());
        ts.setTotalSlot(benchmarkScore.getSlot());
        ts.setTotalOrder(benchmarkScore.getOrder());
        ts.setPssLowerLimit(benchmarkScore.getLowerLimitPss());
        ts.setPssUpperLimit(benchmarkScore.getUpperLimitPss());
        ts.setPnprLowerLimit(benchmarkScore.getLowerLimitPnpr());
        ts.setPnprUpperLimit(benchmarkScore.getUpperLimitPnpr());
        ts.setLowerLimitLexile(benchmarkScore.getLowerLimitLexile());
        ts.setUpperLimitLexile(benchmarkScore.getUpperLimitLexile());
        ts.setCollegeReadiness(benchmarkScore.getCollegeReadiness());

        return ts;
    }

    public Subscore convertScoreIntoSubScore(BenchmarkScore benchmarkScore){

        Subscore subscore = new Subscore();
        subscore.setAbilityEstimate(benchmarkScore.getAbilityEstimate());
        subscore.setAbbr(benchmarkScore.getAbbr());
        subscore.setAchievementLevel(benchmarkScore.getAchievementLevel());
        subscore.setCompletionCriteria(benchmarkScore.getCompletionCriteria());
        subscore.setCompletionCriteriaPercentage(benchmarkScore.getCompletionCriteriaPercentage());
        subscore.setIpCeil(benchmarkScore.getIpCeil());
        subscore.setIpFloor(benchmarkScore.getIpFloor());
        subscore.setLpr(benchmarkScore.getLpr());
        subscore.setMaxScore(benchmarkScore.getMaxScore());
        subscore.setName(benchmarkScore.getName());
        subscore.setNumberAttempted(benchmarkScore.getNumberAttempted());
        subscore.setNumberQuestions(benchmarkScore.getNumberQuestions());
        subscore.setScaleScore(benchmarkScore.getScaleScore());
        subscore.setScore(benchmarkScore.getScore());
        subscore.setScoreType(benchmarkScore.getScoreType());
        subscore.setSlot(benchmarkScore.getSlot());
        subscore.setScoreOrder(benchmarkScore.getOrder());

        return subscore;
    }

    public AssignmentTotalScoreInfo getAssignmentTotalScoreInfo(AssignmentTotalScore assignmentTotalScore, TestType testType){
        AssignmentTotalScoreInfo assignmentTotalScoreInfo = new AssignmentTotalScoreInfo();
        assignmentTotalScoreInfo.setSessionId(assignmentTotalScore.getSessionId());
        assignmentTotalScoreInfo.setTotalItems(assignmentTotalScore.getTotalItems());
        assignmentTotalScoreInfo.setTotalItemsCorrect(assignmentTotalScore.getItemsCorrect());
        assignmentTotalScoreInfo.setTotalPointsCorrect(assignmentTotalScore.getPointsCorrect());
        assignmentTotalScoreInfo.setTotalPoints(assignmentTotalScore.getTotalPoints());
        assignmentTotalScoreInfo.setTotalProficiencyScore(assignmentTotalScore.getTotalProficiencyScore());
        PerformanceLevel performanceLevel = PerformanceLevel.getPerformanceLevel(
            assignmentTotalScore.getTotalProficiencyScore(), testType);
        assignmentTotalScoreInfo.setTotalPerformanceLevel(performanceLevel.getName());
        if(bandUpdate){
          if(assignmentTotalScore.getPerformanceBand()!=null){
          assignmentTotalScoreInfo.setBandId(assignmentTotalScore.getPerformanceBand().getBandRefId());
          }
        }else {
          assignmentTotalScoreInfo.setBandId(performanceLevel.getBandId());
        }
        assignmentTotalScoreInfo.setTotalAttainedPoints(assignmentTotalScore.getTotalAttainedPoints());
        if(assignmentTotalScore.getTotalTime() != null) {
            assignmentTotalScoreInfo.setTotalTime(assignmentTotalScore.getTotalTime());
        }
        //TODO: As LEARNOSITY is only source it is hard coded will move the source derived and passed from Scoring
        //TODO: Once we have new source other than lernosity.
        assignmentTotalScoreInfo.setScoringSource(ScoringSource.LEARNOSITY);
        return assignmentTotalScoreInfo;
    }

    public List<AssignmentItemScore> populateItemNamesForScores(
        List<AssignmentItemScore> assignmentItemScores , TestType testType ,
        Map<String , ActivityItemsPerformance> activityItemsPerformanceMap) throws CloneNotSupportedException {

        if(CollectionUtils.isEmpty(assignmentItemScores))
            throw new ApplicationException("Formative Scores cannot be Null or missing for ActivityForScores in Scoring");
        
        List<AssignmentItemScore> assignmentItemScoresCopy = new ArrayList<>();

        for(AssignmentItemScore itemScore : assignmentItemScores){

            String itemName = itemScore.getItemName();
            if(testType.getSourceObjectType().getContentSource() == ContentSource.MDS && itemName != null){

                Integer sequenceInt = getStringSequence(itemName);
                itemScore.setSequenceNumber(sequenceInt);
                itemScore.setItemNumber(sequenceInt);
            } else {

                ActivityItemsPerformance activityItemsPerformance = activityItemsPerformanceMap.get(itemScore.getItemRefId());
                if(activityItemsPerformance != null) {
                    itemScore.setItemName(activityItemsPerformance.getItemName());
                    itemScore.setSequenceNumber(activityItemsPerformance.getSequenceNumber());
                    itemScore.setItemNumber(activityItemsPerformance.getItemNumber());
                }else{
                    Integer sequenceInt = getStringSequence(itemName);
                    itemScore.setSequenceNumber(sequenceInt);
                }
            }
            assignmentItemScoresCopy.add((AssignmentItemScore) itemScore.clone());
        }
        return assignmentItemScoresCopy;
    }

    private Integer getStringSequence(String itemName) {

        Integer sequenceInt = -1;
        int indexOfItem = itemName.toUpperCase().indexOf(CONSTANT_ITEM.trim().toUpperCase());
        try {
            String sequence = itemName.substring(indexOfItem+4).trim();
            sequenceInt = Integer.parseInt(sequence);
        }catch(Exception ex){
            logger.error("Error parsing Sequence Number.");
        }

        return sequenceInt;
    }

    public List<ActivityStandardsPerformance> getStandardsForNonMDSItemsFromReporting(
        List<AssignmentItemScore> assignmentItemScores ,UUID activityId){

        List<ActivityStandardsPerformance> standardsPerformances = reportingService.getStandardsToItemsMapInfo(activityId);


        return standardsPerformances;
    }

    //Calling one Search for Item and Standard Creation.

  @Deprecated
    public ActivityStandardsToItemsMapInfo getStandardsAndItemsForNonMDSSource(String resourceId, TestType testType){
      ActivityStandardsToItemsMapInfo activityStandardsToItemsMapInfo = new ActivityStandardsToItemsMapInfo();
        try {
            if(resourceId == null){
                logger.error("*+*+*+ Resource Id is null +*+*+*");
                throw new ApplicationException("Resource Id should not be null");
            }

            OneSearchAssessmentItemsListResponse itemsListResponse = mdsService.getItemsByAssessmentId(resourceId);

            if(itemsListResponse == null){
                logger.error("*+*+*+ Item Response from Search cannot be null for Resource : {} +*+*+*" , resourceId);
                throw new ApplicationException("Item Response from Search cannot be null for Resource : "+resourceId);
            }

            OneSearchAssessmentItems oneSearchAssessmentItems = null;

                oneSearchAssessmentItems = itemsListResponse.getFirstAssessmentItem();
                if (oneSearchAssessmentItems == null) {
                    logger.error("*+*+*+ OneSearchAssessmentItems from Search cannot be null for Resource : {} +*+*+*", resourceId);
                    throw new ApplicationException("OneSearchAssessmentItems from Search cannot be null for Resource : " + resourceId);
                }
                OneSearchItems[] oneSearchItemsArray = oneSearchAssessmentItems.getOneSearchItems();
                String itemCountString = oneSearchAssessmentItems.getItemCount();

                if (itemCountString != null) {
                    int itemCount = NumberUtils.createInteger(itemCountString);
                    if (itemCount <= 0) {
                        logger.error("*+*+*+ OneSearchAssessmentItems from Search Return Item Count 0 for Resource : {} +*+*+*", resourceId);
                        throw new ApplicationException("OneSearchAssessmentItems from Search Return Item Count 0 for Resource : " + resourceId);
                    }
                }


                Standard noStandard = createNoStandard();

                List<StandardToItems> standardToItemList = new ArrayList<>();
                List<String> notFoundItemsInOneSearch = new ArrayList<>();
                List<ActivityStandardsPerformance> activityStandardsPerformanceList = new ArrayList<>();
                List<ActivityItemsPerformance> activityItemsPerformanceList = new ArrayList<>();
                Map<StandardToItems , List<ActivityItemsPerformance>> itemsListHashMap =
                    new HashMap<StandardToItems,List<ActivityItemsPerformance>>();

                ActivityStandardsPerformance activityStandardsPerformance;
                ActivityItemsPerformance activityItemsPerformance;

                Integer sequenceInt = 0;
                String previousItem = null;
                String previousPosition = null;
                for (OneSearchItems oneSearchItem : oneSearchItemsArray) {
                    String itemPosition = oneSearchItem.getItemPosition();
                    String namePosition = oneSearchItem.getItemPosition();
                  if(itemPosition == null || namePosition == null){
                    itemPosition = "1";
                    namePosition = "1";
                  }
                    if(previousItem != null) {
                        oneSearchItem.setIdentifier(previousItem+"_"+oneSearchItem.getIdentifier());
                        namePosition = previousPosition + "-" + itemPosition;
                        itemPosition = previousPosition;
                    }
                    OnesearchItemResponse itemDetails = mdsService.getItemDetailsByProgramItemRefId(oneSearchItem.getIdentifier());
                   if(itemDetails == null && previousItem == null){
                        notFoundItemsInOneSearch.add(oneSearchItem.getIdentifier()+"_"+"Item"+itemPosition);
                        previousItem = oneSearchItem.getIdentifier();
                        previousPosition = oneSearchItem.getItemPosition();
                        continue;
                    }
                    if(itemDetails == null && previousItem == null ){
                        addStandardsToItems(standardToItemList, null, noStandard);
                        continue;
                    }

                    if (itemDetails == null && previousItem != null) {
                        notFoundItemsInOneSearch.add(oneSearchItem.getIdentifier()+"_"+"Item"+itemPosition);
                    }


                    Item item = null;
                    if(itemDetails != null) {
                        item = itemDetails.getFirstItem();
                    }
                    if (item == null && previousItem == null) {
                        addStandardsToItems(standardToItemList, null, noStandard);
                        continue;
                    }

                    previousItem = null;
                    previousPosition = null;
                    sequenceInt++;

                    Integer itemNumber = -1;

                    try{
                        itemNumber = Integer.parseInt(itemPosition);
                    }catch(Exception ex){
                        logger.error("Error while parsing Item Number " , ex);
                    }


                    String questionType = null;
                    String manuallyScorable = null;
                    String depthOfKnowledge = null;

                    if(item != null) {
                        questionType = item.getFirstQuestion().getInteractivityType();
                        manuallyScorable = item.getManuallyScorable();
                        depthOfKnowledge = item.getDepthOfKnowledge();
                    }
                    else {
                        questionType = Result.QUESTION_TYPE;
                        manuallyScorable = oneSearchItem.getManuallyScorable();
                    }
                    activityItemsPerformance = new ActivityItemsPerformance(oneSearchItem.getIdentifier(), sequenceInt, "ITEM " + namePosition, Result.STANDARD_TYPE_AB, questionType,
                        manuallyScorable , depthOfKnowledge);

                    logger.info("Creating a activityItemsPerformance {}",activityItemsPerformance);

                    activityItemsPerformance.setItemNumber(itemNumber);
                    if ((item != null && ArrayUtils.isEmpty(item.getStandardSet())) || (item == null && activityItemsPerformance != null)) {
                        StandardToItems sti = addStandardsToItemswithDescription(standardToItemList, noStandard, testType);
                        getItemPerformanceList(itemsListHashMap, sti).add(activityItemsPerformance);

                    } else {
                        for (StandardSet ss : item.getStandardSet()) {
                            for (Standard std : ss.getStandard()) {
                                std.setStandardSet(ss);
                                StandardToItems sti = addStandardsToItemswithDescription(standardToItemList, std, testType);
                                getItemPerformanceList(itemsListHashMap, sti).add(activityItemsPerformance);
                            }

                        }
                    }

                    activityItemsPerformanceList.add(activityItemsPerformance);


                }
                int standardSequence = 1;
                for (StandardToItems standard : standardToItemList) {
                    activityStandardsPerformance = getStandardActivityPerformance(standard
                            , standardSequence);
                  if(standard.getStandard().getStandardSet()!=null) {
                    activityStandardsPerformance.setStandardSetName(standard.getStandard().getStandardSet().getName());
                  }else{
                    activityStandardsPerformance.setStandardSetName("NO_STANDARD");
                  }
                    activityStandardsPerformance.setDomainId(null); //will be removed in cleanup
                    activityStandardsPerformance.setItems(itemsListHashMap.get(standard));
                    activityStandardsPerformanceList.add(activityStandardsPerformance);
                    standardSequence++;
                }
                activityStandardsToItemsMapInfo.setStandards(activityStandardsPerformanceList);
                activityStandardsToItemsMapInfo.setTestType(testType);
                activityStandardsToItemsMapInfo.setDomainStandards(null);
                logger.info("ResourceId, {} Not Found Items in OneSearch {} with a total of {}..",resourceId,      notFoundItemsInOneSearch, notFoundItemsInOneSearch.size() );
        } catch (ApplicationException e) {
            logger.error("Error while create Item Performance :",e);
            e.printStackTrace();
        }

        logger.info("final..activityStandardsToItemsMapInfo{}",activityStandardsToItemsMapInfo);
        return activityStandardsToItemsMapInfo;
    }

  public ActivityStandardsToItemsMapInfo getStandardsAndItemsFromScoringQueue(StandardSession standardSessionScores){
    logger.info("standardSessionScores {}" +standardSessionScores);
    ActivityStandardsToItemsMapInfo activityStandardsToItemsMapInfo = new ActivityStandardsToItemsMapInfo();
    AssignmentStudentStandardScoreInfo assignmentStudentStandardScoreInfo = new AssignmentStudentStandardScoreInfo();
    AssignmentStudentStandardScoreRequest assignmentStudentStandardScoreRequest = new AssignmentStudentStandardScoreRequest();
    List<AssignmentStudentStandardScore> assignmentStudentStandardScoreList = new ArrayList<>();
    List<ActivityStandardsPerformance> activityStandardsPerformanceList = new ArrayList<>();
    ActivityStandardsPerformance activityStandardsPerformance;
    AssignmentStudentStandardScore stdScore;


    try {
      if(standardSessionScores.getActivityId() == null){
        logger.error("*+*+*+ Activity Id is null +*+*+*");
        throw new ApplicationException("Activity Id should not be null");
      }

        int standardSequence = 1;

        // standard related info
        for (StandardScores ss : standardSessionScores.getStandards()) {
          activityStandardsPerformance = new ActivityStandardsPerformance();
          stdScore = new AssignmentStudentStandardScore();
          //Scoring sends NO_STANDARD with ID:7f537d60-67fb-41ea-8651-4d75b57be9cf
          if(ss.getStandardId().toString().equals(noStandard)) {
            logger.info("NO_STANDARD");
            activityStandardsPerformance.setStandardId(noStandard);
            activityStandardsPerformance.setStandardDescription(Result.NO_STANDARDS_DESC);
            activityStandardsPerformance.setType(Result.NO_STANDARDS);
          } else {
            activityStandardsPerformance.setStandardId(ss.getStandardId().toString());
            activityStandardsPerformance.setAvailablePoints(ss.getTotalPoints());
            activityStandardsPerformance.setSequenceNumber(String.valueOf(standardSequence));
            activityStandardsPerformance.setType(Result.STANDARD_TYPE_AB);
            standardSequence++;
          }
          //saving activity_standard_scores
          saveStandardScores(ss,activityStandardsPerformance,standardSessionScores,stdScore,
              activityStandardsPerformanceList,assignmentStudentStandardScoreList);
        }
        standardSessionScores.getItemToStandardMap().stream().forEach(itemToStandardMap -> {
          ItemDetails itemDetails = itemToStandardMap.getItemDetails();
          Map<String, List<DomainStandard>> standardSet = itemToStandardMap.getStandardSet();

          // item related info
          ActivityItemsPerformance items = new ActivityItemsPerformance();
          items.setItemRefId(itemDetails.getItemRefId());
          items.setItemName(itemDetails.getItemName());
          String [] position = itemDetails.getItemPosition().split("-");
          if(position.length>0){
            items.setItemNumber(Integer.valueOf(position[0]));
          }
          items.setManuallyScorable(itemDetails.getManuallyScorable());
          items.setSequenceNumber(items.getItemNumber());
          OnesearchItemResponse oneSearchItems = mdsService.getItemDetailsByProgramItemRefId(items.getItemRefId());
          StandardSet[] ss = new StandardSet[0];

          if(oneSearchItems== null) {
             oneSearchItems = retryOneSearch(items,ScoreHelper.NO_OF_RETRY);
          }else{
            Item oneSearchItem = oneSearchItems.getFirstItem();
            Question firstQuestion = oneSearchItem.getFirstQuestion();
            items.setQuestionType(firstQuestion.getInteractivityType());
            items.setDepthOfKnowledge(oneSearchItem.getDepthOfKnowledge());
            if(oneSearchItem.getStandardSet()!=null){
            ss = oneSearchItem.getStandardSet();}
            else {
              ss = noStandardSet();
            }

          }
          // standardSet info
          standardSet.forEach((standardSetKey, standardSetValues) -> standardSetValues.stream()
              .forEach(ssv -> ssv.getStandards().stream().forEach(ssvStd -> {
                Optional<ActivityStandardsPerformance> performanceOptional = activityStandardsPerformanceList.stream()
                    .filter(asp -> asp.getStandardId().equals(ssvStd.getStandardId().toString())).findFirst();
                if (performanceOptional.isPresent()) {
                  ActivityStandardsPerformance standardsPerformance = performanceOptional.get();
                    standardsPerformance.setStandardName(ssvStd.getName());
                    standardsPerformance.setStandardDescription(ssvStd.getDescription());
                    standardsPerformance.setStandardSetName(standardSetKey);
                    standardsPerformance.setDomainId(ssv.getDomainId());
                }
              })));

          List<UUID> std = itemToStandardMap.getStandards();
          for (UUID aStd : std) {
              for (ActivityStandardsPerformance asp : activityStandardsPerformanceList) {
                for (StandardSet sss : ss){
                String name = sss.getName();
                if(name.equals(asp.getStandardSetName())){
                  items.setType(sss.getProvider());
                }
              }

                if (asp.getStandardId().equals(aStd.toString())) {
                  if (asp.getItems() == null) {
                    asp.setItems(new ArrayList<>());
                  }
                  asp.getItems().add(items);
                  break;
                }
              }
          }
        });

        activityStandardsToItemsMapInfo.setStandards(activityStandardsPerformanceList);
        activityStandardsToItemsMapInfo.setDomainStandards(standardSessionScores.getDomains());
        activityStandardsToItemsMapInfo.setTestType(standardSessionScores.getTestType());


    } catch (ApplicationException e) {
      logger.error("Error while creating ActivityStandardsToItemsMapInfo :",e);
      e.printStackTrace();
    }

    assignmentStudentStandardScoreInfo.setSessionId(standardSessionScores.getSessionId());
    assignmentStudentStandardScoreInfo.setTestType(standardSessionScores.getTestType());
    assignmentStudentStandardScoreInfo.setActivityStandardScores(assignmentStudentStandardScoreList);

    assignmentStudentStandardScoreRequest.setAssignmentStudentStandardScoreInfo(assignmentStudentStandardScoreInfo);

    try {
      logger.info("publishing assignment standard scores {}", standardSessionScores.getSessionId());
      reportingService.pusblishAssignmentStandardScores(standardSessionScores.getActivityId()
          , standardSessionScores.getStudentPersonId(), assignmentStudentStandardScoreRequest);
    } catch (Exception e) {
      logger.warn("Exception from Reporting Service: {}", e);
      e.printStackTrace();
    }

    logger.info("final..activityStandardsToItemsMapInfo{}",activityStandardsToItemsMapInfo);
    return activityStandardsToItemsMapInfo;
  }

  private void saveStandardScores(StandardScores ss, ActivityStandardsPerformance activityStandardsPerformance,
      StandardSession standardSessionScores, AssignmentStudentStandardScore stdScore,
      List<ActivityStandardsPerformance> activityStandardsPerformanceList,
      List<AssignmentStudentStandardScore> assignmentStudentStandardScoreList) {

    stdScore.setStandardId(ss.getStandardId().toString());
    stdScore.setSequenceNumber(StringUtils.isEmpty(activityStandardsPerformance.getSequenceNumber()) ?
        "0" :
        activityStandardsPerformance.getSequenceNumber());
    stdScore.setStandardName(activityStandardsPerformance.getStandardName());
    stdScore.setStandardItems(ss.getItemCount());
    stdScore.setStandardPoints(ss.getTotalPoints());
    stdScore.setStandardItemsCorrect(ss.getCorrectItemsCount());
    stdScore.setStandardAttainedPoints(ss.getAttainedPoints());
    stdScore.setStandardItemsCorrectPoints(ss.getCorrectItemsPoints());
    stdScore.setStandardProficiencyScore(ss.getStandardProficiencyScore());
    stdScore.setStandardPerformanceLevel(PerformanceLevel
        .getPerformanceLevel(stdScore.getStandardProficiencyScore(), standardSessionScores.getTestType()));
    if(bandUpdate){
      if(ss.getProficiencyBand()!=null) {
        stdScore.setBandId(ss.getProficiencyBand().getBandRefId()); // consuming Scoring queue band
      }
    }else{
      stdScore.setBandId(stdScore.getStandardPerformanceLevel().getBandId()); //consuming Aggregator band
    }
    assignmentStudentStandardScoreList.add(stdScore);
    activityStandardsPerformanceList.add(activityStandardsPerformance);
  }

  private StandardSet[] noStandardSet() {

    StandardSet stdSet = new StandardSet();
    stdSet.setName("NOT_CONTENT_SOURCE_STANDARDSET.xml");
    return new StandardSet[] { stdSet };
  }

  private OnesearchItemResponse retryOneSearch(ActivityItemsPerformance items, int noOfRetries) {

    OnesearchItemResponse oneSearchItems = null;
    try {
      oneSearchItems = mdsService.getItemDetailsByProgramItemRefId(items.getItemRefId());
    } catch (Exception e){
      logger.error("Error while calling Onesearch  ", e);
      if(noOfRetries <= ScoreHelper.NO_OF_RETRY) {
        noOfRetries++;
        retryOneSearch( items,noOfRetries);
      }
      throw new RuntimeException(e);
    }
    return oneSearchItems;

  }

  private List<ActivityItemsPerformance> getItemPerformanceList(Map<StandardToItems, List<ActivityItemsPerformance>> itemsListHashMap, StandardToItems sti) {
        List<ActivityItemsPerformance> listItemPerf = itemsListHashMap.get(sti);
        if(listItemPerf == null){
            listItemPerf = new ArrayList<>();
            itemsListHashMap.put(sti , listItemPerf);
        }

        return listItemPerf;
    }

    public List<StandardToItems> getStandardsForNonMDSItems(List<AssignmentItemScore> assignmentItemScores) {
        List<StandardToItems> standardToItems=new ArrayList<>();
        Standard noStandard = createNoStandard();
        for (int itemScoreIndex = 0; itemScoreIndex < assignmentItemScores.size(); itemScoreIndex++) {
            AssignmentItemScore assignItemScore = assignmentItemScores.get(itemScoreIndex);
            OnesearchItemResponse itemDetails = mdsService.getItemDetailsByProgramItemRefId(assignItemScore.getItemRefId());
            if(itemDetails==null) {
                logger.error("*+*+*+ Item response for item: " + assignItemScore.getItemRefId() + " is null!!");
                addStandardsToItems(standardToItems, assignItemScore, noStandard);
                assignItemScore.setStandards(Collections.singleton(noStandard));
                continue;
            }

            Item item = itemDetails.getFirstItem();
            if(item==null) {
                logger.error("*+*+*+ Item response for item: " + assignItemScore.getItemRefId() + " is null!!");
                addStandardsToItems(standardToItems, assignItemScore, noStandard);
                assignItemScore.setStandards(Collections.singleton(noStandard));
                continue;
            }
            Question firstQuestion = item.getFirstQuestion();
            assignItemScore.setQuestionType(firstQuestion.getInteractivityType());
            assignItemScore.setDepthOfKnowledge(item.getDepthOfKnowledge());
            assignItemScore.setManuallyScorable(item.getManuallyScorable());
            Set<Standard> itemStandards=new HashSet<>();

            if(item.getStandardSet()==null || item.getStandardSet().length==0) {
                addStandardsToItems(standardToItems, assignItemScore, noStandard);
                assignItemScore.setStandards(Collections.singleton(noStandard));
                continue;

            }
            for(StandardSet ss: item.getStandardSet()) {
                for(Standard std: ss.getStandard()) {
                    itemStandards.add(std);
                    std.setStandardSet(ss);
                    addStandardsToItems(standardToItems, assignItemScore, std);
                }
            }
            assignItemScore.setStandards(itemStandards);

        }
        return standardToItems;
    }

    public Map<String , ActivityItemsPerformance> getItemsMap(List<ActivityStandardsPerformance>  standardsPerformances){

        Map<String , ActivityItemsPerformance> performanceMap = new HashMap<>();

        if(standardsPerformances != null){
            standardsPerformances.stream().forEach(standardsPerformance -> {
                List<ActivityItemsPerformance> itemsPerformances =  standardsPerformance.getItems();
                itemsPerformances.stream().forEach(activityItemsPerformance -> {
                    performanceMap.put(activityItemsPerformance.getItemRefId() , activityItemsPerformance);
                });
            });
        }

        return performanceMap;
    }


    //Added a new method after moving logic for Onsearch to get from Reporting and perform logic.
    public List<AssignmentStudentStandardScore> getStandardsForItems(List<AssignmentItemScore> assignmentItemScores ,
                   List<ActivityStandardsPerformance>  standardsPerformances , TestType testType){

        List<AssignmentStudentStandardScore> activityStandardScores = new ArrayList<>();

        if(!CollectionUtils.isEmpty(standardsPerformances)){

            Map<String , AssignmentItemScore> itemScoreMap = new HashMap<>();

            assignmentItemScores.stream().forEach(assignmentItemScore -> {
                itemScoreMap.put(assignmentItemScore.getItemRefId() , assignmentItemScore);
            });

            standardsPerformances.stream().forEach(standardsPerformance -> {
                List<ActivityItemsPerformance> itemsPerformances =  standardsPerformance.getItems();
                activityStandardScores.add(createAssignmentStudentStandardScore(itemScoreMap,
                    itemsPerformances, standardsPerformance , testType));
            });
        }

        return activityStandardScores;
    }

    //Convert Assignment Scores from Standard Performance.
    private AssignmentStudentStandardScore createAssignmentStudentStandardScore(Map<String , AssignmentItemScore> itemScoreMap ,
             List<ActivityItemsPerformance> itemsPerformances , ActivityStandardsPerformance activityStandardsPerformance ,
             TestType testType){

        List<AssignmentItemScore> itemScores = new ArrayList<>();
        itemsPerformances.stream().forEach(activityItemsPerformance -> {
            AssignmentItemScore itemScore = itemScoreMap.get(activityItemsPerformance.getItemRefId());
            if(itemScore != null) {
                itemScores.add(itemScore);
            }
        });
        AssignmentStudentStandardScore stdScore = new AssignmentStudentStandardScore();
        stdScore.setStandardId(activityStandardsPerformance.getStandardId());
        stdScore.setSequenceNumber(StringUtils.isEmpty(
            activityStandardsPerformance.getSequenceNumber())? "0" : activityStandardsPerformance.getSequenceNumber());
        stdScore.setStandardName(activityStandardsPerformance.getStandardName());
        stdScore.setStandardItems(CollectionUtils.isEmpty(activityStandardsPerformance.getItems()) ? 0
            : activityStandardsPerformance.getItems().size());
        stdScore.setStandardPoints(getStandardPoints(itemScores));
        stdScore.setStandardItemsCorrect(getItemsCorrectCount(itemScores));
        stdScore.setStandardAttainedPoints(getStandardAttainedPoints(itemScores));
        int itemsCorrectPerStandard = getItemsCorrectPoints(itemScores);
        stdScore.setStandardItemsCorrectPoints(itemsCorrectPerStandard);
        stdScore.setStandardProficiencyScore(
            getStandardProficiencyScore(stdScore.getStandardAttainedPoints(),
                stdScore.getStandardPoints()));
        stdScore.setStandardPerformanceLevel(
            PerformanceLevel.getPerformanceLevel(stdScore.getStandardProficiencyScore(), testType));
        stdScore.setBandId(stdScore.getStandardPerformanceLevel().getBandId());
        stdScore.setStandardSet(activityStandardsPerformance.getStandardSet());

        return stdScore;
    }

    private StandardToItems addStandardsToItems(List<StandardToItems> standardToItems, AssignmentItemScore assignItemScore, Standard std) {
        Optional<StandardToItems> existingItem = standardToItems.stream().filter(sti -> sti.getStandard().getGuid().equals(std.getGuid())).findFirst();
        StandardToItems sti=null;
        if(existingItem.isPresent()) {
            sti=existingItem.get();
        } else {
            sti=new StandardToItems(std);
            standardToItems.add(sti);
        }
        sti.getItemScores().add(assignItemScore);

        return sti;
    }

    private StandardToItems addStandardsToItemswithDescription(List<StandardToItems> standardToItemList, Standard std, TestType testType) {
        Optional<StandardToItems> existingItem = standardToItemList.stream().filter(sti -> sti.getStandard().getGuid().equals(std.getGuid())).findFirst();
        StandardToItems sti=null;
        if(!existingItem.isPresent()) {
            if(!Result.NO_STANDARDS.equals(std.getType())) {
              //OneSearch standards call
                StandardsResponse standardsResponse = mdsService.getStandardDetailsByStandardRefId(std.getGuid(), testType);
                std.setDescription(standardsResponse.getStandards().getStandard().get(0).getDescription());
            }
            sti = new StandardToItems(std);
            standardToItemList.add(sti);
        }else{
            sti = existingItem.get();
        }

        return sti;
    }



    public List<StandardToItems> getStandardsForItems(List<AssignmentItemScore> assignmentItemScores, UUID activityId) {

        List<AssignmentItemBase> assignmentItems=reportingService.getCachedObject(activityId.toString(), new TypeReference<ArrayList<AssignmentItemBase>>() {
        });
        if(assignmentItems==null) {
            assignmentItems=new ArrayList<>();
        }
        List<StandardToItems> standardList = new ArrayList<>();

        try {
            List<String> itemRefIdList = new ArrayList<>();
            List<String> itemNoStandardList = new ArrayList<>();
            int itemScoresSize = assignmentItemScores.size();
            for (int itemScoreIndex = 0; itemScoreIndex < assignmentItemScores.size(); itemScoreIndex++) {
                AssignmentItemScore assignItemScore = assignmentItemScores.get(itemScoreIndex);

                AssignmentItemBase cachedResult;
                //look in overall assignment cache
                Optional<AssignmentItemBase> first = assignmentItems.stream().filter(aib -> aib.getItemRefId().equals(assignItemScore.getItemRefId())).findFirst();
                if(first.isPresent()) {
                    cachedResult = first.get();
                } else {
                    //item isn't in the overall cache, we'll check the individual cache
                    cachedResult = reportingService.getCachedObject(assignItemScore.getItemRefId(), new TypeReference<AssignmentItemBase>() {});
                    if(cachedResult!=null) {
                        assignmentItems.add(cachedResult);
                    }
                }
                if(cachedResult!=null) {
                    assignItemScore.setStandards(cachedResult.getStandards());
                    assignItemScore.setBloomTaxonomy(cachedResult.getBloomTaxonomy());
                    assignItemScore.setCognitiveDifficulty(cachedResult.getCognitiveDifficulty());
                    assignItemScore.setDepthOfKnowledge(cachedResult.getDepthOfKnowledge());
                    assignItemScore.setManuallyScorable(cachedResult.getManuallyScorable());
                    assignItemScore.setQuestionType(cachedResult.getQuestionType());
                    setStandardRelation(standardList, assignItemScore);

                } else {
                    //item was not found in either cache (individual or overall)
                    itemRefIdList.add(assignItemScore.getItemRefId());
                    itemNoStandardList.add(assignItemScore.getItemRefId());
                }
                int itemCount = itemRefIdList.size();

                // call MDS service to retrieve multiple items passing multiple item ids
                if (itemCount == ITEM_REF_ID_COUNT || (itemScoreIndex > 0 && itemScoreIndex == itemScoresSize - 1)) {
                    ItemsExternalRefIdResponse itemsExternalRefIdResponse;
                    String itemRefIds = StringUtils.join(itemRefIdList, ITEM_REF_ID_DELIMITER);
                    logger.info("Item IDs to be sent to MDS: {}", itemRefIds);
                    itemsExternalRefIdResponse = mdsService.getItemDetailByItemRefId(itemRefIds, itemCount);

                    if (itemsExternalRefIdResponse != null) {

                        // loop thru the results (multiple items)
                        for (Result result : itemsExternalRefIdResponse.getResults()) {

                            String contentIdentifier = result.getIdentifier();

                            AssignmentItemScore itemScore = processMdsResult(assignmentItemScores, result, contentIdentifier);

                            AssignmentItemBase baseCopy = itemScore.getBaseCopy();
                            reportingService.addToCache(contentIdentifier, baseCopy);
                            assignmentItems.add(baseCopy);
                            //set item to standard mapping after adding to the cache
                            setStandardRelation(standardList, itemScore);

                            itemNoStandardList.remove(contentIdentifier);
                        }

                        for (String itemRefId : itemNoStandardList) {

                            AssignmentItemScore item = assignmentItemScores.stream().filter(ai -> ai.getItemRefId().equals(itemRefId)).findFirst().get();

                            if (item != null) {
                                Result result = new Result();
                                Set<Standard> standards = result.getStandards();
                                if (!CollectionUtils.isEmpty(standards)) {
                                    item.setStandards(standards);
                                    AssignmentItemBase baseCopy = item.getBaseCopy();
                                    reportingService.addToCache(item.getItemRefId(), baseCopy);
                                    assignmentItems.add (baseCopy);
                                    setStandardRelation(standardList, item);
                                }
                            }

                        }
                    }

                    itemRefIdList.clear();
                }
            }
            reportingService.addToCache(activityId.toString(), assignmentItems);
        }
        catch(Exception e) {
            logger.error("Exception getting standards for items:", e);
        }
        return standardList;
    }

    private void setStandardRelation(List<StandardToItems> standardList, AssignmentItemScore itemScore) {
        if(!CollectionUtils.isEmpty(itemScore.getStandards())) {
            for (Standard standard : itemScore.getStandards()) {
                Optional<StandardToItems> standardMatch = standardList.stream().filter(std -> std.getStandard().equals(standard)).findFirst();
                if(standardMatch.isPresent()) {
                    standardMatch.get().addAssignmentItemScores(itemScore);
                } else {
                    StandardToItems standardToItems = new StandardToItems(standard);
                    standardToItems.addAssignmentItemScores(itemScore);
                    standardList.add(standardToItems);
                }
            }
        }
    }

    private AssignmentItemScore processMdsResult(List<AssignmentItemScore> assignmentItemScores, Result result, String contentIdentifier) {
        AssignmentItemScore itemScore = assignmentItemScores.stream().filter(ai -> ai.getItemRefId().equals(contentIdentifier)).findFirst().get();

        if (itemScore != null) {

            String cognitiveDifficulty = result.getCognitiveDifficulty();
            if (cognitiveDifficulty != null) {
                itemScore.setCognitiveDifficulty(cognitiveDifficulty);
            }

            String bloomTaxonomy = result.getBloomTaxonomy();
            if (bloomTaxonomy != null) {
                itemScore.setBloomTaxonomy(bloomTaxonomy);
            }
            String depthOfKnowledge = result.getDepthOfKnowledge();
            if (depthOfKnowledge != null) {
                itemScore.setDepthOfKnowledge(depthOfKnowledge);
            }
            String questionType = result.getQuestionType();
            if (questionType != null) {
                itemScore.setQuestionType(questionType);
            }

            Set<Standard> standards = result.getStandards();
            if (!CollectionUtils.isEmpty(standards)) {
                itemScore.setStandards(standards);
            }
        }
        return itemScore;
    }

    public AssignmentStudentStandardScoreRequest getStandardAssignmentScores(List<StandardToItems> standards
        , UUID sessionId, TestType testType){

        if(standards == null)
            throw new IllegalArgumentException("Standards Can not be Empty..");

        AssignmentStudentStandardScoreRequest assignmentStudentStandardScoreRequest = new AssignmentStudentStandardScoreRequest();

        AssignmentStudentStandardScoreInfo assignmentStudentStandardScoreInfo = new AssignmentStudentStandardScoreInfo();
        assignmentStudentStandardScoreRequest.setAssignmentStudentStandardScoreInfo(assignmentStudentStandardScoreInfo);
        assignmentStudentStandardScoreInfo.setSessionId(sessionId);
        assignmentStudentStandardScoreInfo.setTestType(testType);
        assignmentStudentStandardScoreInfo.setActivityStandardScores(new ArrayList<>());

        int sequence =1;

        for(StandardToItems standard:standards){

            AssignmentStudentStandardScore assignmentStudentStandardScore = calculateStandardScores(standard, sequence, testType);
            assignmentStudentStandardScoreInfo.getActivityStandardScores().add(assignmentStudentStandardScore);
            sequence++;
        }

        return assignmentStudentStandardScoreRequest;
    }

    private AssignmentStudentStandardScore calculateStandardScores(StandardToItems standard , int sequence,
                                                                   TestType testType){

        AssignmentStudentStandardScore score = new AssignmentStudentStandardScore();

        if(standard != null) {
            score.setStandardId(standard.getStandard().getAbguids().getAbguid());
            score.setStandardName(standard.getStandard().getId());
            score.setSequenceNumber(String.valueOf(sequence));
            score.setStandardItems(CollectionUtils.isEmpty(standard.getItemScores()) ? 0 : standard.getItemScores().size());
            score.setStandardPoints(getStandardPoints(standard.getItemScores()));
            score.setStandardItemsCorrect(getItemsCorrectCount(standard.getItemScores()));
            score.setStandardAttainedPoints(getStandardAttainedPoints(standard.getItemScores()));
            score.setStandardSet(standard.getStandard().getStandardSet());
            int itemsCorrectPerStandard = getItemsCorrectPoints(standard.getItemScores());
            score.setStandardItemsCorrectPoints(itemsCorrectPerStandard);
            score.setStandardProficiencyScore(
                getStandardProficiencyScore(score.getStandardAttainedPoints(),
                    score.getStandardPoints()));
            score.setStandardPerformanceLevel(
                PerformanceLevel.getPerformanceLevel(score.getStandardProficiencyScore(), testType));
            score.setBandId(score.getStandardPerformanceLevel().getBandId());
        }


        return score;
    }

    private int getItemsCorrectCount(List<AssignmentItemScore> itemScores){

        int itemsCount = 0;

        if(CollectionUtils.isEmpty(itemScores))
            return itemsCount;

        itemsCount =(int) itemScores.stream()
                .filter(AssignmentItemScore::isItemCorrect).count();

        return itemsCount;
    }

    private int getItemsCorrectPoints(List<AssignmentItemScore> itemScores){

        int itemsCount = 0;

        if(CollectionUtils.isEmpty(itemScores))
            return itemsCount;

        itemsCount = itemScores.stream()
            .filter(AssignmentItemScore::isItemCorrect)
                .mapToInt(AssignmentItemScore::getItemScore).sum();

        return itemsCount;
    }

    private Double getStandardProficiencyScore(int attainedPoints , int standardPoints){
        Double standardProficiency=0.0;

        if(standardPoints>0) {
            standardProficiency = new BigDecimal(attainedPoints).divide(new BigDecimal(standardPoints), 2, BigDecimal.ROUND_HALF_UP).doubleValue();

        }
        return standardProficiency;
    }

    private int getStandardPoints(List<AssignmentItemScore> itemScores){

        int points = 0;

        if(CollectionUtils.isEmpty(itemScores))
            return points;

        points = itemScores.stream().mapToInt(assignmentItemScore ->
                (assignmentItemScore != null && assignmentItemScore.getItemMaxScore() == null) ? 0 : assignmentItemScore.getItemMaxScore()).sum();

        return points;
    }

    private int getStandardAttainedPoints(List<AssignmentItemScore> itemScores){

        int attainedPoints = 0;

        if(CollectionUtils.isEmpty(itemScores))
            return attainedPoints;

        attainedPoints = itemScores.stream().mapToInt(assignmentItemScore ->
                (assignmentItemScore.getItemScore() == null) ? 0 : assignmentItemScore.getItemScore()).sum();

        return attainedPoints;
    }


    public void populateStandardDescription(List<Standard> standards, TestType testType){

        try {
            List<String> standardRefIdList = new ArrayList<String>();
            ArrayList<String> tempIdList= new ArrayList<String>();

            // loop thru the list of standards and groups ids
            for (Standard std : standards) {
                if(!Result.NO_STANDARD_ID.equals(std.getAbguids().getAbguid())) {
                    String abguid = std.getAbguids().getAbguid();
                    logger.info("Standard ID: {}", abguid);
                    tempIdList.add(abguid);
                    if (tempIdList.size() == STANDARD_REF_ID_COUNT || (standards.indexOf(std) == standards.size() - 1)) {
                        String combineIds = StringUtils.join(tempIdList, "%2C");
                        standardRefIdList.add(combineIds);
                        tempIdList.clear();
                    }
                }
            }

            // call MDS service requesting multiple standard ids (in group)
            standardRefIdList.parallelStream().forEach(standard -> {
                String abguid = standard;
                logger.info("Standard IDs to be sent to MDS: {}", abguid);
                StandardsResponse standardService = mdsService.getStandardDetailsByStandardRefId(abguid, testType);
                if (standardService != null && standardService.getStandards() != null) {
                    for (Standard std : standardService.getStandards().getStandard()) {
                        String serviceStandardAbGuid = std.getAbguids().getAbguid();
                        Standard currentStandard = standards.stream().filter(s -> s.getAbguids().getAbguid()
                                .equals(serviceStandardAbGuid))
                                .findFirst().orElse(null);
                        if (currentStandard != null) {
                            currentStandard.setDescription(std.getDescription());
                        }
                        else {
                            logger.info("ABGuid from MDS does not match requested: {}", serviceStandardAbGuid);
                        }
                    }
                } else if (standardService == null) {
                    logger.info("MDS endpoint returns with no standards");
                }
            });
        }
        catch(Exception e) {
            logger.error("Exception populating standard description:", e);
        }
    }

     public ActivityStandardsToItemsMapInfo calculateStandardPerformance(List<StandardToItems> standards , TestType testType){

        if(standards == null)
            throw new IllegalArgumentException("Standards Can not be Empty..");

        ActivityStandardsToItemsMapInfo saveActivityPerformanceInfo = new ActivityStandardsToItemsMapInfo();

        saveActivityPerformanceInfo.setStandards(new ArrayList<>());
        int standardSequence = 1;
        for(StandardToItems standard:standards){
            saveActivityPerformanceInfo.getStandards().add(getStandardActivityPerformance(standard
            ,standardSequence));
            standardSequence++;
        }
         saveActivityPerformanceInfo.setTestType(testType);
        return saveActivityPerformanceInfo;
    }

    private ActivityStandardsPerformance getStandardActivityPerformance(StandardToItems standard , int standardSequence){

        ActivityStandardsPerformance sp = new ActivityStandardsPerformance();

        sp.setStandardId(standard.getStandard().getAbguids().getAbguid());
        sp.setStandardName(standard.getStandard().getId());
        sp.setSequenceNumber(String.valueOf(standardSequence));
        sp.setStandardDescription(standard.getStandard().getDescription());
        sp.setType(standard.getStandard().getType());
        sp.setStandardSet(standard.getStandard().getStandardSet());
        sp.setItems(new ArrayList<>());
        int pointsAvailable = 0;
        for(AssignmentItemScore assignmentItemScore:standard.getItemScores()) {
            sp.getItems().add(
                    createActivityItemsPerformance(assignmentItemScore));
            pointsAvailable = pointsAvailable+assignmentItemScore.getItemMaxScore();
        }
        sp.setAvailablePoints(pointsAvailable);
        return sp;
    }

    private ActivityItemsPerformance createActivityItemsPerformance(AssignmentItemScore assignmentItemScore){

        ActivityItemsPerformance activityItemsPerformance = new ActivityItemsPerformance();
        Integer sequenceNumber = ((assignmentItemScore.getSequenceNumber()) == null) ? Integer.valueOf(-1) :
            assignmentItemScore.getSequenceNumber();
        Integer itemNumber = ((assignmentItemScore.getItemNumber()) == null) ? Integer.valueOf(-1) :
            assignmentItemScore.getItemNumber();
        activityItemsPerformance.setSequenceNumber(sequenceNumber);
        activityItemsPerformance.setItemNumber(itemNumber);
        activityItemsPerformance.setItemName(assignmentItemScore.getItemName());
        activityItemsPerformance.setItemRefId(assignmentItemScore.getItemRefId());
        activityItemsPerformance.setType(Result.STANDARD_TYPE_AB);
        activityItemsPerformance.setAvailablePoints(assignmentItemScore.getItemMaxScore());
        activityItemsPerformance.setCognitiveDifficultyLevel(assignmentItemScore.getCognitiveDifficulty());
        activityItemsPerformance.setBloomsTaxanomyLevel(assignmentItemScore.getBloomTaxonomy());
        activityItemsPerformance.setQuestionType(assignmentItemScore.getQuestionType());
        activityItemsPerformance.setDepthOfKnowledge(assignmentItemScore.getDepthOfKnowledge());
        activityItemsPerformance.setManuallyScorable(assignmentItemScore.getManuallyScorable());
        return activityItemsPerformance;
    }

}
