package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StudentDemographic {
    
    private UUID refId;
    private Demographics demographics;
    private String economicDisadvantage;
    private Disability disability;
    private Name name;
    private LocalId localId;
    private String username;
    private String lasid;


    public UUID getRefId() {
        return refId;
    }
    
    public void setRefId(UUID refId) {
        this.refId = refId;
    }
    
    public Demographics getDemographics() {
        return demographics;
    }

    public void setDemographics(Demographics demographics) {
        this.demographics = demographics;
    }

    public String getEconomicDisadvantage() {
        return economicDisadvantage;
    }

    public void setEconomicDisadvantage(String economicDisadvantage) {
        this.economicDisadvantage = economicDisadvantage;
    }

    public Disability getDisability() {
        return disability;
    }

    public void setDisability(Disability disability) {
        this.disability = disability;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public LocalId getLocalId() {
        return localId;
    }

    public void setLocalId(LocalId localId) {
        this.localId = localId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLasid() {
        return lasid;
    }

    public void setLasid(String lasid) {
        this.lasid = lasid;
    }

    public static class Demographics {
        private EthnicityList ethnicityList;
        private String sexus;
        private String birthDate;
        private String languageProficiency;
		private List<IDMDemographicsAny> anies;
        
        public EthnicityList getEthnicityList() {
            return ethnicityList;
        }
        
        public void setEthnicityList(EthnicityList ethnicityList) {
            this.ethnicityList = ethnicityList;
        }
        
        public String getSexus() {
            return sexus;
        }
        
        public void setSexus(String sexus) {
            this.sexus = sexus;
        }

        public String getBirthDate() {
            return birthDate;
        }

        public void setBirthDate(String birthDate) {
            this.birthDate = birthDate;
        }

        public String getLanguageProficiency() {
            return languageProficiency;
        }

        public void setLanguageProficiency(String languageProficiency) {
            this.languageProficiency = languageProficiency;
        }

		public List<IDMDemographicsAny> getAnies() {
			return anies;
		}

		public void setAnies(List<IDMDemographicsAny> anies) {
			this.anies = anies;
		}
	}
    
    public static class EthnicityList {
        private List<Codable> ethnicities = new ArrayList<>();
        
        public List<Codable> getEthnicities() {
            return ethnicities;
        }
        
        public void setEthnicities(List<Codable> ethnicities) {
            this.ethnicities = ethnicities;
        }
    }
    
    public static class Disability {
        private Codable primaryDisability;
        private Codable ideaenvironment;
        
        public Codable getPrimaryDisability() {
            return primaryDisability;
        }
        
        public void setPrimaryDisability(Codable primaryDisability) {
            this.primaryDisability = primaryDisability;
        }
        
        public Codable getIdeaenvironment() {
            return ideaenvironment;
        }
        
        public void setIdeaenvironment(Codable ideaenvironment) {
            this.ideaenvironment = ideaenvironment;
        }
    }
    
    public static class Codable {
        private String code;
        private String codesetName;
        
        public String getCode() {
            return code;
        }
        
        public void setCode(String code) {
            this.code = code;
        }
        
        public String getCodesetName() {
            return codesetName;
        }
        
        public void setCodesetName(String codesetName) {
            this.codesetName = codesetName;
        }
    }

    public static class Name{
        private NameOfRecord nameOfRecord;

        private String lastName;
        private String firstName;
        private String middleName;

        public NameOfRecord getNameOfRecord() {
            return nameOfRecord;
        }

        public void setNameOfRecord(NameOfRecord nameOfRecord) {
            this.nameOfRecord = nameOfRecord;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getMiddleName() {
            return middleName;
        }

        public void setMiddleName(String middleName) {
            this.middleName = middleName;
        }

        @Override
        public String toString() {
            return "Name{" +
                "nameOfRecord=" + nameOfRecord +
                ", lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                '}';
        }
    }

    public static class NameOfRecord{
        private String familyName;
        private String givenName;

        public String getFamilyName() {
            return familyName;
        }

        public void setFamilyName(String familyName) {
            this.familyName = familyName;
        }

        public String getGivenName() {
            return givenName;
        }

        public void setGivenName(String givenName) {
            this.givenName = givenName;
        }

        @Override
        public String toString() {
            return "NameOfRecord{" +
                "lastName='" + familyName + '\'' +
                ", firstName='" + givenName + '\'' +
                '}';
        }
    }

    public static class LocalId{
        private String idValue;

        public String getIdValue() {
            return idValue;
        }

        public void setIdValue(String idValue) {
            this.idValue = idValue;
        }
    }

	public static class IDMDemographicsAny {
		protected List<String> specialConditions;
		protected List<String> specialServices;
		protected String economicStatus;

		public List<String> getSpecialConditions() {
			return specialConditions;
		}

		public void setSpecialConditions(List<String> specialConditions) {
			this.specialConditions = specialConditions;
		}

		public List<String> getSpecialServices() {
			return specialServices;
		}

		public void setSpecialServices(List<String> specialServices) {
			this.specialServices = specialServices;
		}

		public String getEconomicStatus() {
			return economicStatus;
		}

		public void setEconomicStatus(String economicStatus) {
			this.economicStatus = economicStatus;
		}
	}

    @Override
    public String toString() {
        return "StudentDemographic{" +
            "refId=" + refId +
            ", demographics=" + demographics +
            ", economicDisadvantage='" + economicDisadvantage + '\'' +
            ", disability=" + disability +
            ", name=" + name +
            ", localId=" + localId +
            ", username='" + username + '\'' +
            ", lasid='" + lasid + '\'' +
            '}';
    }
}
