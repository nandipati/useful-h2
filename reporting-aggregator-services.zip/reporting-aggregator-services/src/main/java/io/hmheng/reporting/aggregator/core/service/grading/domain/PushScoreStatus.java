package io.hmheng.reporting.aggregator.core.service.grading.domain;

import org.joda.time.DateTime;

import java.util.UUID;

/**
 * Created by mfeng on 10/18/17.
 */
public class PushScoreStatus {

    private UUID sessionId;
    private String message;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
