package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by suryadevarap on 4/4/18.
 */
public class ItemToStandardMap {

  private String itemRefId;
  private List<UUID> standards;
  private ItemDetails itemDetails;
  private Map<String,List<DomainStandard>> standardSet;

  public String getItemRefId() {
    return itemRefId;
  }

  public void setItemRefId(String itemRefId) {
    this.itemRefId = itemRefId;
  }

  public List<UUID> getStandards() {
    return standards;
  }

  public void setStandards(List<UUID> standards) {
    this.standards = standards;
  }

  public ItemDetails getItemDetails() {
    return itemDetails;
  }

  public void setItemDetails(ItemDetails itemDetails) {
    this.itemDetails = itemDetails;
  }

  public Map<String, List<DomainStandard>> getStandardSet() {
    return standardSet;
  }

  public void setStandardSet(Map<String, List<DomainStandard>> standardSet) {
    this.standardSet = standardSet;
  }
}
