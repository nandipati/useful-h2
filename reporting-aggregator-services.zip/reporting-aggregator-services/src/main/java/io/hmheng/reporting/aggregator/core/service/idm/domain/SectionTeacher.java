package io.hmheng.reporting.aggregator.core.service.idm.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

public class SectionTeacher {

    @JsonProperty("staffPersonRefId")
    private UUID staffPersonalRefId;
    
    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    @Override
    public String toString() {
        return "SectionTeacher{" +
            "staffPersonalRefId=" + staffPersonalRefId +
            '}';
    }
    
}
