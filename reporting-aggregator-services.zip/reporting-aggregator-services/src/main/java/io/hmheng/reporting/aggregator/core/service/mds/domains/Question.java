package io.hmheng.reporting.aggregator.core.service.mds.domains;


public class Question
{
  private String manuallyScorable;

  private String identifier;

  private String interactivityType;

  public String getManuallyScorable ()
  {
    return manuallyScorable;
  }

  public void setManuallyScorable (String manuallyScorable)
  {
    this.manuallyScorable = manuallyScorable;
  }

  public String getIdentifier ()
  {
    return identifier;
  }

  public void setIdentifier (String identifier)
  {
    this.identifier = identifier;
  }

  public String getInteractivityType ()
  {
    return interactivityType;
  }

  public void setInteractivityType (String interactivityType)
  {
    this.interactivityType = interactivityType;
  }

  @Override
  public String toString()
  {
    return "ClassPojo [manuallyScorable = "+manuallyScorable+", identifier = "+identifier+", interactivityType = "+interactivityType+"]";
  }
}
