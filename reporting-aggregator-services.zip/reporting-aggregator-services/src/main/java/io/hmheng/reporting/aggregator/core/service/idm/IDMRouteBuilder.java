package io.hmheng.reporting.aggregator.core.service.idm;

import io.hmheng.reporting.aggregator.core.service.idm.domain.IDMStudentStaffResponse;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SectionRoster;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.List;

import io.hmheng.reporting.aggregator.core.service.idm.domain.Section;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SectionResponse;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentSectionAssociationResponse;
import io.hmheng.reporting.aggregator.core.service.utils.JacksonDataFormatHelper;

import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.CONTEXT_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SCHOOL_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SECTION_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STUDENT_PERSONAL_REFID;
import static org.apache.camel.component.http4.HttpMethods.GET;

@Component
public class IDMRouteBuilder extends RouteBuilder {

  public static final String studentSectionAssociationsRouteId = "idmStudentSectionAssociationsRoute";
  public static final String studentSectionAssociationsIDSRouteId = "idmStudentSectionAssociationsIDSRoute";
  public static final String sectionsForSchoolRouteId = "idmSectionsForSchoolRoute";
  public static final String sectionsForStudentRouteId = "idmSectionsForStudentRoute";
  public static final String sectionsForSchoolIDSRouteId = "sectionsForSchoolIDSRoute";
  public static final String staffPersonsForSchoolRouteId = "idmStaffPersonsForSchoolRoute";
  public static final String teachersForSchoolRouteId = "idmTeachersForSchoolRoute";
  public static final String studentDemographicRouteId = "idmStudentDemographicRoute";
  public static final String studentDemographicIDSRouteId = "idmStudentDemographicIDSRoute";
  public static final String sectionsDetailsRouteId = "idmSectionsDetailsRoute";
  public static final String sectionRosterIDSRouteId = "idmSectionRosterIDSRoute";
  public static final String teachersForStudentIDSRouteId = "teachersForStudentIDSRoute";
  public static final String teachersForStudentIDMRouteId = "teachersForStudentIDMRoute";
  public static final String sectionsForStudentIDSRouteId = "sectionsForStudentIDSRoute";

  public static final String getStudentSectionAssociationsEndpoint = "direct://getStudentSectionAssociations";
  public static final String getStudentSectionAssociationsIDSEndpoint = "direct://getStudentSectionAssociationsIDS";
  public static final String getSectionsForSchoolEndpoint = "direct://getSectionsForSchool";
  public static final String getSectionsForStudentEndpoint = "direct://getSectionsForStudent";
  public static final String getSectionsForSchoolIDSEndpoint = "direct://getSectionsForSchoolIDS";
  public static final String getStaffPersonsForSchoolEndpoint = "direct://getStaffPersonsForSchool";
  public static final String getTeachersForSchoolEndpoint = "direct://getTeachersForSchool";
  public static final String getStudentDemographicEndpoint = "direct://getStudentDemographic";
  public static final String getStudentDemographicIDSEndpoint = "direct://getStudentDemographicIDS";
  public static final String getSectionDetailsEndpoint = "direct://getSectionDetails";
  public static final String getSectionRosterIDSEndpoint = "direct://getSectionRosterIDS";
  public static final String getTeachersForStudentIDSEndpoint = "direct://getTeachersForStudentIDS";
  public static final String getTeachersForStudentIDMEndpoint = "direct://getTeachersForStudentIDM";
  public static final String getSectionsForStudentIDSEndpoint = "direct://getSectionsForStudentIDS";

  @Value("${ids.host.baseUrl}")
  public String idsHost;

  @Value("${idm.host.baseUrl}")
  public String idmHost;

  @Autowired
  private JacksonDataFormatHelper jacksonDataFormatHelper;

  @Override
  public final void configure() throws Exception {
    String getStudentSectionAssociationsPath = String.format("/v3/students/${header.%s}${header.%s}/studentSectionAssociation",
        STUDENT_PERSONAL_REFID, CONTEXT_ID);
    configureEndpoint(
        idmHost,
        getStudentSectionAssociationsEndpoint,
        studentSectionAssociationsRouteId,
        getStudentSectionAssociationsPath,
        StudentSectionAssociationResponse.class);

    String getStudentSectionAssociationsIDSPath = String.format("/v1/students/${header.%s}/sections", STUDENT_PERSONAL_REFID);

    configureEndpoint(
        idsHost,
        getStudentSectionAssociationsIDSEndpoint,
        studentSectionAssociationsIDSRouteId,
        getStudentSectionAssociationsIDSPath,
        List.class);


    String getSectionsForSchoolPath = String.format("/v3/schools/${header.%s}${header.%s}/sections?size=10000",
        SCHOOL_REFID, CONTEXT_ID);

    String getSectionsForSchoolIDSPath = String.format("/v1/schools/${header.%s}/sections", SCHOOL_REFID);
    String idmIdentityHost=idmHost.replace("openid-connect", "identity");
    configureEndpoint(
        idmHost,
        getSectionsForSchoolEndpoint,
        sectionsForSchoolRouteId,
        getSectionsForSchoolPath,
        SectionResponse.class);

    //idm sections for student
    configureEndpoint(idmIdentityHost,
        getSectionsForStudentEndpoint,
        sectionsForStudentRouteId,
        String.format("/v1/students/student/${header.%s}/section${header.%s}",
            STUDENT_PERSONAL_REFID, CONTEXT_ID),
        SectionResponse.class
    );

    configureEndpoint(
        idsHost,
        getSectionsForSchoolIDSEndpoint,
        sectionsForSchoolIDSRouteId,
        getSectionsForSchoolIDSPath,
        List.class);

    String getStaffPersonsForSchoolPath = String.format("/v3/schools/${header.%s}${header.%s}/staffPersons?size=10000",
        SCHOOL_REFID, CONTEXT_ID);

    //idm student teacher endpoint
    configureEndpoint(
        idmIdentityHost,
        getTeachersForStudentIDMEndpoint,
        teachersForStudentIDMRouteId,
        String.format("/v1/students/${header.%s}/staffPersons${header.%s}",
            STUDENT_PERSONAL_REFID, CONTEXT_ID),
        IDMStudentStaffResponse.class);

    configureEndpoint(
        idmHost,
        getStaffPersonsForSchoolEndpoint,
        staffPersonsForSchoolRouteId,
        getStaffPersonsForSchoolPath,
        List.class);

    String getTeachersForSchoolIDSPath = String
        .format("/v1/schools/${header.%s}/teachers", SCHOOL_REFID);

    configureEndpoint(
        idsHost,
        getTeachersForSchoolEndpoint,
        teachersForSchoolRouteId,
        getTeachersForSchoolIDSPath,
        List.class);

    String getStudentDemographicPath = String.format("/v3/students/${header.%s}${header.%s}",
        STUDENT_PERSONAL_REFID, CONTEXT_ID);

    configureEndpoint(
        idmHost,
        getStudentDemographicEndpoint,
        studentDemographicRouteId,
        getStudentDemographicPath,
        StudentDemographic.class);

    String getStudentDemographicIDSPath = String.format("/v1/students/${header.%s}",
        STUDENT_PERSONAL_REFID);

    configureEndpoint(
        idsHost,
        getStudentDemographicIDSEndpoint,
        studentDemographicIDSRouteId,
        getStudentDemographicIDSPath,
        StudentDemographic.class);

    String getSessionDetailsPath = String.format("/v3/sections/${header.%s}${header.%s}",
        SECTION_REFID, CONTEXT_ID);

    configureEndpoint(
        idmHost,
        getSectionDetailsEndpoint,
        sectionsDetailsRouteId,
        getSessionDetailsPath,
        Section.class);

    String getSectionRosterIDSPath = String.format("/v1/sections/${header.%s}/rosters",
        SECTION_REFID);

    configureEndpoint(
        idsHost,
        getSectionRosterIDSEndpoint,
        sectionRosterIDSRouteId,
        getSectionRosterIDSPath,
        SectionRoster.class);

    configureEndpoint(idsHost,
        getTeachersForStudentIDSEndpoint,
        teachersForStudentIDSRouteId,
        String.format("/v1/students/${header.%s}/teachers", STUDENT_PERSONAL_REFID),
        List.class);

    configureEndpoint(idsHost,
        getSectionsForStudentIDSEndpoint,
        sectionsForStudentIDSRouteId,
        String.format("/v1/students/${header.%s}/sections", STUDENT_PERSONAL_REFID),
        List.class);

  }


  private void configureEndpoint(String host, String endpointUri, String endpointId, String url, Class<?> responseClass) {
    configureEndpoint(GET, host, endpointUri, endpointId, url, responseClass);
  }

  private void configureEndpoint(HttpMethods httpMethod, String host, String endpointUri, String endpointId, String url, Class<?> responseClass) {
    from(endpointUri).id(endpointId)
        .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
        .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
        .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
        .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
        .setHeader(CORRELATION_ID, simple("${header." + CORRELATION_ID + "}"))
        .recipientList(simple(host + url))
        .unmarshal(jacksonDataFormatHelper.configureDataFormat(responseClass))
        .end();
  }
}
