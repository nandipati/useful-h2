package io.hmheng.reporting.aggregator.core.service.mds.domains;

import java.util.Arrays;

public class OnesearchItemResponse
{
  private Item[] item;

  public Item[] getItem ()
  {
    return item;
  }

  public void setItem (Item[] item)
  {
    this.item = item;
  }
  public Item getFirstItem() {
    if(item==null || item.length!=1)
      return null;
    return item[0];

  }
  @Override
  public String toString()
  {
    return "ClassPojo [item = "+ Arrays.toString(item)+"]";
  }
}
