package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.time.LocalDateTime;

/**
 * Created by somashekara on 11/14/16.
 */
public class SessionIdList extends StudentSession {

    private LocalDateTime startDate;

    private LocalDateTime endDate;

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }
}
