package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by nandipatim on 3/11/16.
 */
public class AssignmentScoreRequest {

    public AssignmentScoreRequest(AssignmentStudentScoreInfo studentScore) {
        this.studentScore = studentScore;
    }

    @JsonProperty("studentScore")
    private AssignmentStudentScoreInfo studentScore;

    public AssignmentStudentScoreInfo getStudentScore() {
        return studentScore;
    }

    public void setStudentScore(AssignmentStudentScoreInfo studentScore) {
        this.studentScore = studentScore;
    }
}
