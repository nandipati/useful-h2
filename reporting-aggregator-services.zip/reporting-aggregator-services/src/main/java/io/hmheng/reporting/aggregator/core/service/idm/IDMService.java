package io.hmheng.reporting.aggregator.core.service.idm;


import java.util.Set;
import java.util.UUID;

import io.hmheng.reporting.aggregator.core.service.idm.domain.Section;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StaffPerson;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentSectionAssociation;
import io.hmheng.reporting.aggregator.core.service.idm.domain.Teacher;

public interface IDMService {
    
    Set<StudentSectionAssociation> getStudentSectionAssociations(UUID studentPersonalRefId, String contextId, String platformId);

  Set<Section> getSectionsForStudent(UUID studentPersonalRefId, String contextId, String platformId);

  Set<Section> getSectionsForSchool(UUID schoolRefId, String contextId, String platformId);

  Set<Teacher> getTeachersForStudent(UUID studentPersonalRefId, String platformId);

  Set<StaffPerson> getStaffPersonsForStudent(UUID studentPersonalRefId, String contextId);

  Set<StaffPerson> getStaffPersonsForSchool(UUID schoolRefId, String contextId);

    Set<Teacher> getTeachersForSchool(UUID schoolRefId, String platformId);

    StudentDemographic getStudentDemographic(UUID studentPersonalRefId, String contextId, String platformId);

    Section getSectionsDetails(UUID sectionId, String contextId, String platformId);



}
