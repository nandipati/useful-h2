package io.hmheng.reporting.aggregator.core.service.mds.domains;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemScore;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ron on 9/9/2016.
 */
public class StandardToItems {
    private Standard standard;
    private List<AssignmentItemScore> itemScores;

    public StandardToItems(Standard standard) {
        this.standard=standard;
    }
    public Standard getStandard() {
        return standard;
    }

    public void setStandard(Standard standard) {
        this.standard = standard;
    }

    public List<AssignmentItemScore> getItemScores() {
        if(itemScores==null)
            itemScores=new ArrayList<>();
        return itemScores;
    }

    public void setItemScores(List<AssignmentItemScore> itemScores) {
        this.itemScores = itemScores;
    }

    public void addAssignmentItemScores(AssignmentItemScore assignmentItemScore){

        if(CollectionUtils.isEmpty(this.itemScores))
            this.itemScores = new ArrayList<AssignmentItemScore>();

        if(!itemScores.contains(assignmentItemScore))
            this.itemScores.add(assignmentItemScore);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StandardToItems that = (StandardToItems) o;

        return standard.equals(that.standard);

    }

    @Override
    public int hashCode() {
        return standard.hashCode();
    }
}
