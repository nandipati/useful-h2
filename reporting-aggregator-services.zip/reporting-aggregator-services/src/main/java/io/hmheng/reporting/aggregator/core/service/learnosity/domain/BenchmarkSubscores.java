package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Arrays;

/**
 * Created by nandipatim on 11/30/16.
 */
public class BenchmarkSubscores {

  private String id;
  private String title;
  @JsonProperty("num_questions")
  private Integer numQuestions;
  @JsonProperty("num_attempted")
  private Integer numAttempted;
  @JsonProperty("num_unmarked")
  private Integer numUnmarked;
  private Integer score;
  @JsonProperty("max_score")
  private Integer maxScore;
  @JsonProperty("attempted_max_score")
  Integer attemptedMaxScore;
  @JsonProperty("unmarked_max_score")
  private Integer unmarkedMaxScore;
  private Object[] items;
  @JsonProperty("ability_estimate")
  private AbilityEstimate abilityEstimate;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public Integer getNumQuestions() {
    return numQuestions;
  }

  public void setNumQuestions(Integer numQuestions) {
    this.numQuestions = numQuestions;
  }

  public Integer getNumAttempted() {
    return numAttempted;
  }

  public void setNumAttempted(Integer numAttempted) {
    this.numAttempted = numAttempted;
  }

  public Integer getNumUnmarked() {
    return numUnmarked;
  }

  public void setNumUnmarked(Integer numUnmarked) {
    this.numUnmarked = numUnmarked;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public Integer getMaxScore() {
    return maxScore;
  }

  public void setMaxScore(Integer maxScore) {
    this.maxScore = maxScore;
  }

  public Integer getAttemptedMaxScore() {
    return attemptedMaxScore;
  }

  public void setAttemptedMaxScore(Integer attemptedMaxScore) {
    this.attemptedMaxScore = attemptedMaxScore;
  }

  public Integer getUnmarkedMaxScore() {
    return unmarkedMaxScore;
  }

  public void setUnmarkedMaxScore(Integer unmarkedMaxScore) {
    this.unmarkedMaxScore = unmarkedMaxScore;
  }

  public Object[] getItems() {
    return items;
  }

  public void setItems(Object[] items) {
    this.items = items;
  }

  public AbilityEstimate getAbilityEstimate() {
    return abilityEstimate;
  }

  public void setAbilityEstimate(AbilityEstimate abilityEstimate) {
    this.abilityEstimate = abilityEstimate;
  }

  @Override
  public String toString() {
    return "BenchmarkSubscores{" +
        "id='" + id + '\'' +
        ", title='" + title + '\'' +
        ", numQuestions=" + numQuestions +
        ", numAttempted=" + numAttempted +
        ", numUnmarked=" + numUnmarked +
        ", score=" + score +
        ", maxScore=" + maxScore +
        ", attemptedMaxScore=" + attemptedMaxScore +
        ", unmarkedMaxScore=" + unmarkedMaxScore +
        ", items=" + Arrays.toString(items) +
        ", abilityEstimate=" + abilityEstimate +
        '}';
  }
}
