package io.hmheng.reporting.aggregator.core.service.mds;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import io.hmheng.reporting.aggregator.core.service.mds.domains.ItemsExternalRefIdResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OnesearchItemResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardsResponse;
import io.hmheng.reporting.aggregator.core.service.utils.Headers;
import io.hmheng.reporting.aggregator.core.service.utils.JacksonDataFormatHelper;

import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ASSESSMENT_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ITEM_REF_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.PAGE_LENGTH;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STANDARD_ID;

/**
 * Created by nandipatim on 3/15/16.
 */
@Component
public class MDSRouteBuilder extends RouteBuilder {

    public static final String itemDetailsForAssesmentRouteId = "itemDetailsForAssesmentRoute";
    public static final String getItemDetailsForAssesmentEndpoint = "direct://getItemDetailsForAssesment";
    public static final String standardDetailsRouteId = "standardDetailsRoute";
    public static final String getStandardDetailsEndpoint = "direct://getStandardDetails";
    public static final String standardDetailsOnesearchRouteId = "standardDetailsOnesearchRouteId";
    public static final String getStandardDetailsOnesearchEndpoint = "direct://getStandardDetailsOnesearch";
    public static final String itemDetailsFromOnesearch = "itemDetailsfromOnesearchRoute";
    public static final String getItemDetailsFromOnesearchEndpoint = "direct://getItemDetailsFromOnesearch";
    public static final String itemsListDetailsFromOneSearchRouteId = "itemsListDetailsFromOneSearchRoute";
    public static final String getItemsListDetailsFromOneSearchEndpoint = "direct://getItemsListDetailsFromOneSearch";

    @Value("${mds.host.baseUrl}")
    public String mdsHost;

    @Value("${onesearch.host.baseUrl}")
    public String onesearchHost;

    @Value("${spring.profiles.active}")
    private String environment;


    @Autowired
    private JacksonDataFormatHelper jacksonDataFormatHelper;

    @Autowired
    private MessageProcessor messageProcessor;

    @Override
    public final void configure() throws Exception {

        String getItemDetailsForAssesments = String.format("/search/v1/beta/assessments/items?q=externalRefId:${header.%s}&pageLength=${header.%s}",
                ITEM_REF_ID, PAGE_LENGTH);

        configureEndpoint(HttpMethods.GET,
                getItemDetailsForAssesmentEndpoint,
                itemDetailsForAssesmentRouteId,
                getItemDetailsForAssesments,
                ItemsExternalRefIdResponse.class);

        String getStandardDetails = String.format("/metadata/v1/standards/${header.%s}",
                STANDARD_ID);

        configureEndpoint(HttpMethods.GET,
                getStandardDetailsEndpoint,
                standardDetailsRouteId,
                getStandardDetails,
                StandardsResponse.class);

        getStandardDetails = String.format("/api/onesearch/v1/standards/${header.%s}",
            STANDARD_ID);

        String getItemDetailsFromOnesearch=String.format("/api/onesearch/v1/assessments/rubrics?itemId=${header.%s}", ITEM_REF_ID);

        String getItemsListDetailsFromOneSearch=String.format("/api/onesearch/v1/assessments/rubrics?assessmentId=${header.%s}",
            ASSESSMENT_ID);


        //TODO: SERIOUS HACK!! THIS TOKEN EXPIRES ON 10/30 WE NEED TO USE THE TRUSTED API TOKEN BEFORE THEN!!!
        // ONESEARCH NEEDS TO ADD SUPPORT FOR THAT THOUGH!!!
        configureEndpointFixedAuth(HttpMethods.GET,
            getItemDetailsFromOnesearchEndpoint,
            itemDetailsFromOnesearch,
            getItemDetailsFromOnesearch,
            OnesearchItemResponse.class);

        configureEndpointFixedAuth(HttpMethods.GET,
            getStandardDetailsOnesearchEndpoint,
            standardDetailsOnesearchRouteId,
            getStandardDetails,
            StandardsResponse.class);

         configureEndpointFixedAuth(HttpMethods.GET,
             getItemsListDetailsFromOneSearchEndpoint,
             itemsListDetailsFromOneSearchRouteId,
             getItemsListDetailsFromOneSearch,
             OnesearchItemResponse.class);


    }
    private void configureEndpointFixedAuth(HttpMethods httpMethod, String endpointUri, String endpointId, String url, Class<?> responseClass) {
        String AUTH_TOKEN="SIF_HMACSHA256 ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjem92TDJsa1pXNTBhWFI1TG1Gd2FTNW9iV2hqYnk1amIyMGlMQ0poZFdRaU9pSm9kSFJ3T2k4dmQzZDNMbWh0YUdOdkxtTnZiU0lzSW1saGRDSTZNVFV3TURJek1UWXdPU3dpYzNWaUlqb2lZMjQ5UkdselkyOTJaWEpGUkNCVVpXRmphR1Z5TEhWcFpEMWthWE4wTlhOamFEVjBaV0V4TEhWdWFYRjFaVWxrWlc1MGFXWnBaWEk5Tm1ObU9EUXhaakV0TVRBNFlpMDBaR016TFRnMk1qZ3RNR0l5Tmpaa1lUSXlaRFEwTEc4OU9USXdNREExT1Rjc1pHTTlPVEl3TURBMU9UWWlMQ0pvZEhSd09pOHZkM2QzTG1sdGMyZHNiMkpoYkM1dmNtY3ZhVzF6Y0hWeWJDOXNhWE12ZGpFdmRtOWpZV0l2Y0dWeWMyOXVJanBiSWtsdWMzUnlkV04wYjNJaVhTd2laR2x6ZEY5cFpDSTZJak5sWXpNNU9UVTFMVEpsWldVdE5HTmtaUzFpWVRBMUxXSmhNakExT0dGaU9HRXhNaUlzSW5OamFHOXZiRjlwWkNJNkltRmxPRGt6TjJaa0xXSXpZMlF0TkRCbU9TMDVOR1JqTFdVeU5UTmtaR1UwWVRNMk1DSXNJbk5qYUc5dmJGOXlaV1pwWkNJNkltRmxPRGt6TjJaa0xXSXpZMlF0TkRCbU9TMDVOR1JqTFdVeU5UTmtaR1UwWVRNMk1DSXNJbEJzWVhSbWIzSnRTV1FpT2lKSlJGTWlMQ0pqYjI1MFpYaDBTV1FpT2lJaUxDSmthWE4wWDNKbFptbGtJam9pTTJWak16azVOVFV0TW1WbFpTMDBZMlJsTFdKaE1EVXRZbUV5TURVNFlXSTRZVEV5SWl3aWMyTm9iMjlzWDJOaGRHVm5iM0o1SWpvaUlpd2lhblJwSWpvaU4yWXhZalJrTmpndE9XRmxZaTAwWVRSakxXSmtPRFF0WkdRM05qTXlNV0ZtWlRoa0lpd2lZMnhwWlc1MFgybGtJam9pTVRVeVkyVmtOVEF0TVRNMk9TMDBZakU1TFRoaU1qWXRPR1l6WkRWa09XSm1aRFpoTG1odGFHTnZMbU52YlNJc0ltVjRjQ0k2TVRVd09UTTFNRFF3TUgwLlphMlV2ZHc4QmFvT21yMkw1emdlaEFEaHF2YUM0SHJET3hZb25KQlB5Yk06ZGROU3c2TUNxWnBTZUJPQ01BQ010aENndzV5TGpXV3llSHVuSnNZbmNmQT0K";

        if(environment.equals("cert"))
            AUTH_TOKEN="SIF_HMACSHA256 ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjem92TDJsa1pXNTBhWFI1TG1Gd2FTNW9iV2hqYnk1amIyMGlMQ0poZFdRaU9pSm9kSFJ3T2k4dmQzZDNMbWh0YUdOdkxtTnZiU0lzSW1saGRDSTZNVFV3TXpBd05EYzROaXdpYzNWaUlqb2lZMjQ5UkdselkyOTJaWEpGUkNCVVpXRmphR1Z5TEhWcFpEMWthWE4wTlhOamFEVjBaV0V5TEhWdWFYRjFaVWxrWlc1MGFXWnBaWEk5TkdZek5UWTJZMll0TW1ReE5DMDBPVEpoTFRnMk1UVXRPR0ptWW1abU1UVTNNemhpTEc4OU9USXdNREE1TlRNc1pHTTlPVEl3TURBNU5USWlMQ0pvZEhSd09pOHZkM2QzTG1sdGMyZHNiMkpoYkM1dmNtY3ZhVzF6Y0hWeWJDOXNhWE12ZGpFdmRtOWpZV0l2Y0dWeWMyOXVJanBiSWtsdWMzUnlkV04wYjNJaVhTd2laR2x6ZEY5cFpDSTZJbUk1WXpVMVlXUTBMV1poWkRjdE5EbGhOQzFoWlRjeExUWm1ZMlkyWlRKbU9UazBNQ0lzSW5OamFHOXZiRjlwWkNJNklqVmpOVEl3T1RVNUxXTXdNR1l0TkRreU1DMDRZak5sTFRWbFlXUXlaRFJsWlRjM1pTSXNJbk5qYUc5dmJGOXlaV1pwWkNJNklqVmpOVEl3T1RVNUxXTXdNR1l0TkRreU1DMDRZak5sTFRWbFlXUXlaRFJsWlRjM1pTSXNJbEJzWVhSbWIzSnRTV1FpT2lKSlJGTWlMQ0pqYjI1MFpYaDBTV1FpT2lJaUxDSmthWE4wWDNKbFptbGtJam9pWWpsak5UVmhaRFF0Wm1Ga055MDBPV0UwTFdGbE56RXRObVpqWmpabE1tWTVPVFF3SWl3aWMyTm9iMjlzWDJOaGRHVm5iM0o1SWpvaUlpd2lhblJwSWpvaU1HUXpNR1kyWlRRdFl6TTFZUzAwTXpCaUxUazRNMkV0TXpGaVlURTBOakF5WmpSaUlpd2lZMnhwWlc1MFgybGtJam9pTVRVeVkyVmtOVEF0TVRNMk9TMDBZakU1TFRoaU1qWXRPR1l6WkRWa09XSm1aRFpoTG1odGFHTnZMbU52YlNJc0ltVjRjQ0k2TVRVd09UTTFNRFF3TUgwLjIvVlpnMmRKNmFWM0hFdWI1ZGtaZWZmVDBMTzk0MEFWN0J0SlZCTGJnSkU6R2JDNmlhaFA0U2hzK0hETWF6Skh0eWZJZkdaQ3k4bmVYNGFhZm83aHhqTT0K";
        AUTH_TOKEN="SIF_HMACSHA256 VW1Wd2IzSjBhVzVuUVhCdy5TMlMuaG1oY28uY29tOmJSWldNdHZUNXc4dk1qTmxtZGNEZ0ROU2xlZmVEOGJzTUVXckFmaVl6L0U9";
        from(endpointUri).id(endpointId)
            .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
            .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
            .setHeader(AUTHORIZATION, constant(AUTH_TOKEN))
            .setHeader(Headers.CORRELATION_ID, simple("${header." + Headers.CORRELATION_ID + "}"))
            .recipientList(simple(onesearchHost + url))
            .process(messageProcessor)
            .end();
    }

    private void configureEndpoint(HttpMethods httpMethod, String endpointUri, String endpointId, String url, Class<?> responseClass) {
        from(endpointUri).id(endpointId)
           .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
           .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
           .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
           .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
           .setHeader(Headers.CORRELATION_ID, simple("${header." + Headers.CORRELATION_ID + "}"))
           .recipientList(simple(mdsHost + url))
           .process(messageProcessor)
           .end();
    }
}