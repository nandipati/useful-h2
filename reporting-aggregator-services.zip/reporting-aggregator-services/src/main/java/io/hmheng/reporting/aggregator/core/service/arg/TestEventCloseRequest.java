package io.hmheng.reporting.aggregator.core.service.arg;


import java.util.UUID;


public class TestEventCloseRequest {

    private UUID testEventRefId;
    private UUID activityId;

    public TestEventCloseRequest(UUID testEventRefId, UUID activityId){
        this.testEventRefId = testEventRefId;
        this.activityId = activityId;
    }

    public UUID getTestEventRefId() {
        return testEventRefId;
    }

    public void setTestEventRefId(UUID testEventRefId) {
        this.testEventRefId = testEventRefId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }
}
