package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.UUID;

/**
 * Created by nandipatim on 3/4/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentItemScore extends AssignmentItemBase implements Cloneable{

    private UUID sessionId;
    private Integer itemScore;
    private Integer itemMaxScore;
    private Double itemProficiencyScore;
    private ItemResponse itemResponse;
    private Integer time;
    private ItemStatus itemStatus;
    private Boolean manualscoring;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getItemScore() {
        return itemScore;
    }

    public void setItemScore(Integer itemScore) {
        this.itemScore = itemScore;
    }

    public Integer getItemMaxScore() {
        return itemMaxScore;
    }

    public void setItemMaxScore(Integer itemMaxScore) {
        this.itemMaxScore = itemMaxScore;
    }

    public Double getItemProficiencyScore() {
        return itemProficiencyScore;
    }

    public void setItemProficiencyScore(Double itemProficiencyScore) {
        this.itemProficiencyScore = itemProficiencyScore;
    }

    public ItemResponse getItemResponse() {
        return itemResponse;
    }

    public void setItemResponse(ItemResponse itemResponse) {
        this.itemResponse = itemResponse;
    }

    public Boolean isItemCorrect(){
        return (ItemResponse.CORRECT == itemResponse);
    }

    public AssignmentItemScore clone() throws CloneNotSupportedException {
        return (AssignmentItemScore)super.clone();
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public ItemStatus getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(ItemStatus itemStatus) {
        this.itemStatus = itemStatus;
    }

    public Boolean getManualscoring() {
        return manualscoring;
    }

    public void setManualscoring(Boolean manualscoring) {
        this.manualscoring = manualscoring;
    }


    @Override
    public String toString() {
        return "AssignmentItemScore{" +
            "itemRefId='" + getItemRefId() + '\'' +
            ", sessionId=" + sessionId +
            ", itemScore=" + itemScore +
            ", itemMaxScore=" + itemMaxScore +
            ", itemProficiencyScore=" + itemProficiencyScore +
            ", itemResponse=" + itemResponse +
            ", time=" + time +
            ", itemName='" + getItemName() + '\'' +
            ", cognitiveDifficulty='" + getCognitiveDifficulty() + '\'' +
            ", bloomTaxonomy='" + getBloomTaxonomy() + '\'' +
            ", questionType='" + getQuestionType() + '\'' +
            ", depthOfKnowledge='" + getDepthOfKnowledge() + '\'' +
            ", manuallyScorable='" + getManuallyScorable() + '\'' +
            ", itemStatus='" + getItemStatus() + '\'' +
            ", manualScoring='" + getManualscoring() + '\'' +
            '}';
    }
}
