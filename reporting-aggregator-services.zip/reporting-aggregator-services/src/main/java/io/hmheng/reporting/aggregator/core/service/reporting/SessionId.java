package io.hmheng.reporting.aggregator.core.service.reporting;

import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSession;

/**
 * Created by somashekara on 11/28/16.
 */
public class SessionId extends StudentSession {

    private String startDate;
    private String endDate;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
