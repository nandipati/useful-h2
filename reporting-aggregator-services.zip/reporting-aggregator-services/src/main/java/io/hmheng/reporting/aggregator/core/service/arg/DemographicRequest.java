package io.hmheng.reporting.aggregator.core.service.arg;

import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import org.joda.time.DateTime;

import java.util.UUID;

public class DemographicRequest {

    private UUID studentActivityRefId;
    private UUID studentPersonalRefId;
    private UUID eventRefId;
    private UUID activityId;
    private SourceObjectType sourceObjectType;
    private AssignmentStatus status;
    private UUID sectionId;
    private DateTime startDate;
    private DateTime submitDate;
    private String contextId;
    private String platformId;
    /**
     * The published source topic name in the event service queue from where this batch is orchestrated.
     * Can be used as a marker to differentiate between messages being processed within the aggregator.
     */
    private String sourceTopicName;

    public DemographicRequest(){}

    public DemographicRequest(UUID studentActivityRefId, UUID studentPersonalRefId, UUID eventRefId, String contextId,
                              String platformId) {
        this(studentPersonalRefId,contextId, platformId);
        this.studentActivityRefId = studentActivityRefId;
        this.eventRefId = eventRefId;
    }

    public DemographicRequest(UUID studentPersonalRefId, String contextId, String platformId) {
        this.studentPersonalRefId = studentPersonalRefId;
        this.contextId = contextId;
        this.platformId = platformId;
    }

    public DemographicRequest(UUID studentActivityRefId, UUID studentPersonalRefId, UUID eventRefId, UUID activityId,
                              SourceObjectType sourceObjectType, AssignmentStatus assignmentStatus, String contextId,
                              String platformId) {
        this(studentActivityRefId, studentPersonalRefId, eventRefId, contextId, platformId);
        this.activityId = activityId;
        this.sourceObjectType = sourceObjectType;
        this.status = assignmentStatus;
        this.platformId = platformId;
    }

    public UUID getStudentActivityRefId() {
        return studentActivityRefId;
    }

    public void setStudentActivityRefId(UUID studentActivityRefId) {
        this.studentActivityRefId = studentActivityRefId;
    }

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

    public void setSourceObjectType(SourceObjectType sourceObjectType) {
        this.sourceObjectType = sourceObjectType;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(DateTime submitDate) {
        this.submitDate = submitDate;
    }

    public String getContextId() {
        return contextId;
    }

    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

	 public String getSourceTopicName() {
		return sourceTopicName;
	}

	 public void setSourceTopicName(String sourceTopicName) {
		this.sourceTopicName = sourceTopicName;
	}

   public String getPlatformId() {
        return platformId;
   }

   public void setPlatformId(String platformId) {
        this.platformId = platformId;
   }
}