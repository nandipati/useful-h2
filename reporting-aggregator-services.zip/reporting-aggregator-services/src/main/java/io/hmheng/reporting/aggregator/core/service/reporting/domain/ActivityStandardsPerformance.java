package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardSet;

import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 3/17/16.
 */
public class ActivityStandardsPerformance {

    private String standardId;
    private String sequenceNumber;
    private String standardName;
    private String standardDescription;
    private String type;
    private Integer availablePoints;
    private List<ActivityItemsPerformance> items;
    private StandardSet standardSet;
    private String standardSetName;
    private UUID domainId;

    public String getStandardId() {
        return standardId;
    }

    public void setStandardId(String standardId) {
       standardId = standardId.toLowerCase();
      this.standardId = standardId;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getStandardName() {
        return standardName;
    }

    public void setStandardName(String standardName) {
        this.standardName = standardName;
    }

    public String getStandardDescription() {
        return standardDescription;
    }

    public void setStandardDescription(String standardDescription) {
        this.standardDescription = standardDescription;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getAvailablePoints() {
        return availablePoints;
    }

    public void setAvailablePoints(Integer availablePoints) {
        this.availablePoints = availablePoints;
    }

    public List<ActivityItemsPerformance> getItems() {
        return items;
    }

    public void setItems(List<ActivityItemsPerformance> items) {
        this.items = items;
    }

  public StandardSet getStandardSet() {
    return standardSet;
  }

  public void setStandardSet(StandardSet standardSet) {
    this.standardSet = standardSet;
  }

  public String getStandardSetName() {
    return standardSetName;
  }

  public void setStandardSetName(String standardSetName) {
    this.standardSetName = standardSetName;
  }

  public UUID getDomainId() {
    return domainId;
  }

  public void setDomainId(UUID domainId) {
    this.domainId = domainId;
  }
}
