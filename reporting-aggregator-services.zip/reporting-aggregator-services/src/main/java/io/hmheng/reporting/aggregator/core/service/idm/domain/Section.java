package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.List;
import java.util.UUID;
import org.apache.commons.lang.StringUtils;

public class Section {
    
    private UUID refId;
    private String name;
    private SessionScheduleList sessionScheduleList;
    private YearGroup yearGroup;

    public void setGrades(List<String> grades) {
        this.grades = grades;
    }

    private List<String> grades;
    static String ZERO_GRADE="0";

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SessionScheduleList getSessionScheduleList() {
        return sessionScheduleList;
    }

    public void setSessionScheduleList(SessionScheduleList sessionScheduleList) {
        this.sessionScheduleList = sessionScheduleList;
    }

    public YearGroup getYearGroup() {
        return yearGroup;
    }

    public void setYearGroup(YearGroup yearGroup) {
        this.yearGroup = yearGroup;
    }

    public String getGrade(){
        if(grades!=null) {
            return StringUtils.join(grades, ",");
        }
        if(yearGroup != null){
            String grade = yearGroup.getCode();
            if(grade != null){
                if(StringUtils.isNumeric(grade)){
                    grade = StringUtils.leftPad(grade , 2 , "0");
                }else if(StringUtils.contains(grade,ZERO_GRADE)){
                    grade = StringUtils.strip(grade, ZERO_GRADE);
                }
            }
                return grade;
        }

        return "";
    }

    @Override
    public String toString() {
        return "Section{" +
            "refId=" + refId +
            ", name='" + name + '\'' +
            ", sessionScheduleList='" + sessionScheduleList + '\'' +
            ", yearGroup=" + yearGroup +
            '}';
    }

}
