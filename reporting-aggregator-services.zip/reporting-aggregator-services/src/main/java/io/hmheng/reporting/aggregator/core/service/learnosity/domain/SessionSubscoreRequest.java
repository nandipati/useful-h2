package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

/**
 * Created by pabonaj on 10/1/16.
 */
public class SessionSubscoreRequest {

    private List<String> session_id;

    public List<String> getSession_id() {
        return session_id;
    }

    public void setSession_id(List<String> session_id) {
        this.session_id = session_id;
    }

}
