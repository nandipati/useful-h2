package io.hmheng.reporting.aggregator.core.service.mds;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 3/18/16.
 */
@Component
public class MessageProcessor implements Processor{

    public void process(Exchange exchange) throws Exception{

        try {
            String message = exchange.getIn().getBody(String.class);
            exchange.getIn().setBody(message);
        }catch(Exception ex){
            throw new IllegalArgumentException("Exception while processing JsonObject");
        }
    }
}
