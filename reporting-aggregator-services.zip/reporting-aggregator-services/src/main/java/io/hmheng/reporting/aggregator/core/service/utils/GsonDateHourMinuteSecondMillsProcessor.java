package io.hmheng.reporting.aggregator.core.service.utils;

import io.hmheng.reporting.aggregator.utils.JsonDateTimeHelper;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 2/29/16.
 */
@Component
@Qualifier("gsonDateHourMinuteSecondMillsProcessor")
public class GsonDateHourMinuteSecondMillsProcessor implements Processor{

    @Autowired
    private JsonDateTimeHelper jsonDateTimeHelper;

    public void process(Exchange exchange) {
        Object jsonElement = exchange.getIn().getBody();
        exchange.getIn().setBody(jsonDateTimeHelper.toJsonWithHourMinuteSecondMillis(jsonElement));
    }
}
