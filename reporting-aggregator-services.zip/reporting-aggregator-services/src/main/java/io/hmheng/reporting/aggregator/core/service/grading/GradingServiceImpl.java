package io.hmheng.reporting.aggregator.core.service.grading;

import com.fasterxml.jackson.core.type.TypeReference;
import io.hmheng.reporting.aggregator.core.service.grading.domain.*;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

import static io.hmheng.reporting.aggregator.core.service.AuthorizationService.Service.Grading;
import static io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils.objectMapper;

@Service
public class GradingServiceImpl implements GradingService {

    private static final Logger logger = LoggerFactory.getLogger(GradingServiceImpl.class);


    @Autowired
    private HeadersHelper headersHelper;

    @Autowired
    private ProducerTemplate producerTemplate;

    @Value("${grading.host.maxNumberSessions}")
    public String maxNumberSessions;

    @Override
    public List<PushScoreStatus> pushScores(List<UUID> listSessionIds){
        logger.debug("{}", "-pushScores(List<UUID>)");
        List<PushScoreStatus> finalResponse = new ArrayList<PushScoreStatus>();

        List<UUID> tmpList =  new ArrayList<UUID>();
        for (int i=0; i<listSessionIds.size(); i++) {
            tmpList.add(listSessionIds.get(i));
            int maxSessions = Integer.parseInt(maxNumberSessions);
            if (tmpList.size() == maxSessions || i == listSessionIds.size() - 1) {
                try {
                    SessionWrapper wrapper = new SessionWrapper();
                    wrapper.setSessionIds(tmpList);

                    List<PushScoreStatus> partialResponse = producerTemplate.requestBodyAndHeaders(
                            GradingRouteBuilder.postPushScoresEndpoint,
                            wrapper,
                            generateHeadersForPushScores(),
                            List.class);
                    partialResponse = objectMapper().convertValue(partialResponse, new TypeReference<List<PushScoreStatus>>() {
                    });

                    finalResponse.addAll(partialResponse);
                    tmpList.clear();
                } catch (Exception e) {
                    logger.warn("Exception from Grading: {}", e);
                    if (isHttpResponseNotFound(e) || isHttpResponseNotCreated(e)) {
                        return null;
                    }
                }
            }

        }
        logger.debug("{}", " -pushScores(List<UUID>)");

        return finalResponse;
    }

    private boolean isHttpResponseNotFound(Exception e) {
        return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
            && ((HttpOperationFailedException) e.getCause()).getStatusCode() == HttpStatus.NOT_FOUND.value();

    }

    private boolean isHttpResponseNotCreated(Exception e) {
        return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
            && ((HttpOperationFailedException) e.getCause()).getStatusCode() != HttpStatus.CREATED.value();

    }


    private Map<String, Object> generateHeadersForPushScores() {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Grading);
        return headers;
    }


}
