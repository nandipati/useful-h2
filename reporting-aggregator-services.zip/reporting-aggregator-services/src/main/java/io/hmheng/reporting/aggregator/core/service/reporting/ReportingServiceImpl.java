package io.hmheng.reporting.aggregator.core.service.reporting;

import com.google.gson.JsonObject;

import com.fasterxml.jackson.core.type.TypeReference;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsPerformance;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentClassSummaryInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentScoreRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentScoreInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScoreRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkSession;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkSessionResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ClassStudentInformationListRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsToItemsMapInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentDemographicInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSectionInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSession;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSessionIdResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSessionResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventCloseInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TotalScore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkActivity;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkActivitiesResponse;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import io.hmheng.reporting.aggregator.web.domain.assignment.EventDetailsBatch;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObject;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import org.apache.camel.CamelExecutionException;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ACTIVITY_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ASSIGNMENT_EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.BLOB_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.COMPLETED_DATE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.PAGE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SECTION_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SESSION_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SIZE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STARTDATE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STUDENT_PERSONAL_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STUDENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TESTEVENT_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TESTING_EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ENDDATE;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.EVENTSTATUS;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TEST_EVENT_ID;
import static io.hmheng.reporting.aggregator.core.service.AuthorizationService.Service.Reporting;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.UPDATEEVENTGROUPS;
import static io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils.objectMapper;


@Service
public class ReportingServiceImpl implements ReportingService {

    private static final Logger logger = LoggerFactory.getLogger(ReportingServiceImpl.class);

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private HeadersHelper headersHelper;

    @Value("${reporting.host.rescorePageSize}")
    public String rescorePageSize;
    @Override
    public void publishClassInfo(UUID eventRefId, ClassStudentInformationListRequest request) {
        logger.info("{} {} {}", "+publishTestingEventClassInfo(Set)", eventRefId, request);

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postClassInfoEndpoint,
                    request,
                    generateHeadersForClassInfo(eventRefId));

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishTestingEventClassInfo(Set)");
    }

	@Override
	public void publishClassInfoOnStudentUpdate(UUID studentRefId, StudentSectionInformation request) {
		logger.debug("{} {}", "+postClassInfoOnStudentUpdateEndpoint(Set)", request);

		try {
			producerTemplate.requestBodyAndHeaders(
					ReportingRouteBuilder.postClassInfoOnStudentUpdteEndpoint,
					request,
					generateHeadersForUpdateStudentDemographic(studentRefId));

		} catch (Exception e) {
			logger.warn("Exception from Reporting Service: {}", e);
			throw new RuntimeException(e);
		}

		logger.debug("{}", "-postClassInfoOnStudentUpdateEndpoint(Set)");
	}

    @Override
    public void publishStudentDemographicInfo(UUID eventRefId, UUID studentRefId, StudentDemographicInformation demographicInformation) {

        logger.debug("{}", "+publishStudentDemographicInfo");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postStudentDemographicEndpoint,
                    demographicInformation,
                    generateHeadersForStudentDemographic(eventRefId, studentRefId));

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishStudentDemographicInfo");
    }

	@Override
	public boolean checkIfStudentExists(UUID studentRefId) {

		logger.info("{} {}", "+checkIfStudentExists", studentRefId);

		try {
			producerTemplate.requestBodyAndHeaders(
					ReportingRouteBuilder.checkIfStudentExistsEndpoint,
					null,
					generateHeadersForUpdateStudentDemographic(studentRefId));

		} catch (Exception e) {
			logger.warn("Exception from Reporting Service: {}", e);
      return false;
		}

		logger.debug("{} {}", "-checkIfStudentExists", studentRefId);
		return true;
	}

	@Override
	public void updateStudentDemographicInfo(UUID studentRefId, StudentDemographicInformation demographicInformation) {

		logger.debug("{}", "+updateStudentDemographicInfo");

		try {
			producerTemplate.requestBodyAndHeaders(
					ReportingRouteBuilder.updateStudentDemographicEndpoint,
					demographicInformation,
					generateHeadersForUpdateStudentDemographic(studentRefId));

		} catch (Exception e) {
			logger.error("Exception from Reporting Service: {}", e);
			throw new RuntimeException(e);
		}

		logger.debug("{}", "-updateStudentDemographicInfo");
	}


	/**
     * Post to Reporting /v4/test_events/{TESTING_EVENT_REFID}/activities/{ACTIVITY_ID}/benchmarkscores
     * @param testEventRefId
     * @param activityId
     * @param testEventCloseInformationList
     */
    @Override
    public void publishTestEventCloseLprs(UUID testEventRefId, UUID activityId, List<TestEventCloseInformation> testEventCloseInformationList) {

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postActivityScoresEndpoint,
                    testEventCloseInformationList,
                    generateHeadersForActivityScores(testEventRefId, activityId));
        } catch (Exception e){
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishTestEventCloseLprs(Set)");

    }

   /**
    * Post to Reporting Service "/v4/assignments/${header." + ASSIGNMENT_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/assignmentActivity
    * @param request
    */
    @Override
    public void publishAssignmentEventDetails(AssignmentEventInfo request){

        logger.debug("{}", "+publishAssignmentEventDetails(Set)");

      // TODO: Review NULL constraint set in Reporting
      UUID activityId = request.getActivityId();
      request.setActivityId(null);

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postAssignmentEventDetailsEndpoint,
                    request,
                    generateHeadersForAssignmentActivity(request.getEventRefId(), activityId, true));

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishAssignmentEventDetails(Set)");
    }



    @Override
    public void publishBenchmarkStudentScores(UUID activityId , UUID sessionId , UUID studentPersonalRefId , TotalScore score){

        logger.debug("{}", "+publishBenchmarkStudentScores()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postBenchmarkStudentScoreEndpoint,
                    score,
                generateHeadersForActivityStudentSession(activityId, studentPersonalRefId, sessionId));

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishBenchmarkStudentScores()");
    }

    @Override
    public void publishAssignmentStudentScores(UUID activityId , UUID studentPersonalRefId, UUID sessionId
            , AssignmentStudentScoreInfo assignmentStudentScoreInfo , int noOfRetries){

        logger.debug("{}", "+publishAssignmentStudentScores()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postAssignmentStudentScoreEndpoint,
                    new AssignmentScoreRequest(assignmentStudentScoreInfo),
                    generateHeadersForActivityStudentSession(activityId, studentPersonalRefId, sessionId));

        } catch (Exception e) {
          logger.error("studentScoreInfo: {}", assignmentStudentScoreInfo.toString());
          logger.warn("Exception from Reporting Service: {}", e);
          if(noOfRetries <= ReportingService.NO_OF_RETRY) {
            noOfRetries++;
            publishAssignmentStudentScores(activityId, studentPersonalRefId, sessionId, assignmentStudentScoreInfo , noOfRetries);
          }
          throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishAssignmentStudentScores()");
    }

    /**
     * Post to Reporting Service "/v4/test_events/${header." + TESTING_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/benchmarkActivity
     * @param testEventInfo
     */
    public void publishTestEventDetails(TestEventInfo testEventInfo){
        logger.debug("{}", "+publishTestEventDetails()");

      // TODO: Review NULL constraint set in Reporting
      UUID activityId = testEventInfo.getActivityId();
      testEventInfo.setActivityId(null);

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postTestEventDetailsEndpoint,
                    testEventInfo,
                    generateHeadersForActivityScores(testEventInfo.getEventRefId(), activityId));

        } catch (Exception e) {
            logger.warn("Exception for postTestEventDetailsEndpoint for Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishTestEventDetails()");
    }

  /**
   * Post to Reporting Service "/v4/test_events/${header." + TESTING_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/benchmarkActivity
   * @param activityId
   * @param testEventInfo
   */
  public void publishTestEventDetails(UUID activityId ,TestEventInfo testEventInfo){
    logger.debug("{}", "+publishTestEventDetails()");
    try {
      producerTemplate.requestBodyAndHeaders(
          ReportingRouteBuilder.postTestEventDetailsForActivityEndpoint,
          testEventInfo,
          generateHeadersForActivity(activityId));

    } catch (Exception e) {
      logger.warn("Exception for postTestEventDetailsEndpoint for Reporting Service: {}", e);
      throw new RuntimeException(e);
    }

    logger.debug("{}", "-publishTestEventDetails()");
  }
    
    public void publishReopenedTestEventDetails(UUID testEventRefId, TestEventInfo testEventInfo){
        logger.debug("{}", "+publishReopenedTestEventDetails()");
        try {
            Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
            headers.put(TESTING_EVENT_REFID, testEventRefId.toString());            
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.putTestEventDetailsEndpoint,
                    testEventInfo,
                    headers);

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishReopenedTestEventDetails()");
    }
    
    @Override
    public void publishClassSummaryInfo(UUID activityId, AssignmentClassSummaryInfo assignmentClassSummaryInfo) {

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postAssignmentClassSummaryEndpoint,
                    assignmentClassSummaryInfo,
                    generateHeadersForActivity(activityId));
        } catch (Exception e){
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishClassSummaryInfo(Set)");

    }


    public void pusblishAssignmentStandardScores(UUID activityId , UUID studentPersonalRefId
            , AssignmentStudentStandardScoreRequest assignmentStudentStandardScoreInfo){

        logger.debug("{}", "+publishAssignmentStandardScores()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postAssignmentStudentStandardScoreEndpoint,
                    assignmentStudentStandardScoreInfo,
                    generateHeadersForAssignmentActivityStudent(activityId, studentPersonalRefId));

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishAssignmentStandardScores()");
    }

    public void publishAssignmentStandardPerformance(UUID activityId , ActivityStandardsToItemsMapInfo saveActivityPerformanceInfo){
        logger.debug("{}", "+publishAssignmentStandardPerformance()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postAssignmentStandardPerformanceEndpoint,
                    saveActivityPerformanceInfo,
                    generateHeadersForActivity(activityId));

        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishAssignmentStandardPerformance()");


    }
    @Override
    public <T> void addToCache(String id, T thing) {
        logger.debug("{}", "+getCachedObject()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.putCachedObjectEndpoint,
                    thing,
                    generateHeadersForCacheRequest(id));
            logger.debug("{}", "-getCachedObject()");
        } catch (Exception e) {
            logger.warn("Exception from Reporting Service: {}", e);
        }

    }

    @Override
    public <T> T getCachedObjects(String[] ids, TypeReference<T> type) {
        logger.debug("{}", "+getCachedObject()");

        try {
            String cachedData=producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.getCachedObjectsEndpoint,
                    "",
                    generateHeadersForCacheRequest(ids),
                    String.class);
            logger.debug("{}", "-getCachedObject()");
            if(cachedData==null || cachedData.length()==0)
                return null;
            T cached=objectMapper().readValue(cachedData, type);

            return cached;
        } catch (Exception e) {
            if (isHttpResponseNotFound(e)) {
                return null;
            }
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

    }

    @Override
    public <T> T getCachedObject(String id, TypeReference<T> type) {
        logger.debug("{}", "+getCachedObject()");

        try {
            String cachedData=producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.getCachedObjectEndpoint,
                    "",
                    generateHeadersForCacheRequest(id),
                    String.class);
            if(cachedData==null || cachedData.length()==0)
                return null;
            T cached=objectMapper().readValue(cachedData, type);
            logger.debug("{}", "-getCachedObject()");
            return cached;
        } catch (Exception e) {
            if (isHttpResponseNotFound(e)) {
                return null;
            }
            logger.warn("Exception from Reporting Service (caching): {}", e);
            return null;
        }
    }

    private Map<String, Object> generateHeadersForCacheRequest(String blobId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(BLOB_ID, blobId);
        return headers;

    }
    private Map<String, Object> generateHeadersForCacheRequest(String[] blobIds) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(BLOB_ID, String.join(",", blobIds));
        return headers;

    }
    private Map<String, Object> generateHeadersForClassInfo(UUID eventRefId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(EVENT_REFID, eventRefId.toString());
        return headers;
    }
    private Map<String, Object> generateHeadersForTeacherAssignmentDelete(UUID eventRefId) {
      Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
      headers.put(EVENT_REFID, eventRefId.toString());
      return headers;
    }

	private Map<String, Object> generateHeadersForUpdateStudentDemographic(UUID studentRefId) {
		Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
		headers.put(STUDENT_REFID, studentRefId.toString());
		return headers;
	}

    private Map<String, Object> generateHeadersForStudentDemographic(UUID eventRefId, UUID studentRefId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(EVENT_REFID, eventRefId.toString());
        headers.put(STUDENT_REFID, studentRefId.toString());
        return headers;
    }

    private Map<String, Object> generateHeadersForStudentDetails(UUID eventRefId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(EVENT_REFID, eventRefId.toString());

        return headers;
    }

    private Map<String, Object> generateHeadersForActivityScores(UUID testingEventRefId, UUID activityId) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(TESTING_EVENT_REFID, testingEventRefId.toString());
        headers.put(ACTIVITY_ID, activityId.toString());
        return headers;
    }


    private Map<String, Object>  generateHeadersForAssignmentActivity(UUID assignmentEventRefId , UUID activityId,
                                                                      Boolean updateEventGroups){
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(ASSIGNMENT_EVENT_REFID, assignmentEventRefId.toString());
        headers.put(ACTIVITY_ID, activityId.toString());
        headers.put(UPDATEEVENTGROUPS, updateEventGroups);
        return headers;
    }

    private Map<String, Object>  generateHeadersForActivity(UUID activityId){
      Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
      headers.put(ACTIVITY_ID, activityId.toString());
      return headers;
    }

    private Map<String, Object> generateHeadersForActivityStudentSession(UUID activityId,
        UUID studentPersonalRefId, UUID sessionId){
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(ACTIVITY_ID, activityId.toString());
        headers.put(STUDENT_PERSONAL_REFID, studentPersonalRefId.toString());
        headers.put(SESSION_REFID, sessionId.toString());
        return headers;
    }

    private Map<String, Object>  generateHeadersForAssignmentActivityStudent(UUID activityId, UUID studentPersonalRefId){
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(ACTIVITY_ID, activityId.toString());
        headers.put(STUDENT_PERSONAL_REFID, studentPersonalRefId.toString());
        return headers;
    }


    private Map<String, Object>  generateHeadersForAssignmentClassSummary(UUID assignmentEventRefId , UUID sectionID){
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(ASSIGNMENT_EVENT_REFID, assignmentEventRefId.toString());
        headers.put(SECTION_REFID, sectionID.toString());
        return headers;
    }

    private Map<String, Object> generateHeadersForReprocess() {
      Map<String, Object> headers = headersHelper.createBasicHeadersWithOutCorrelation(Reporting);
      return headers;
    }

	/**
	 * Determine if a CamelExecutionException is a HttpOperationFailedException with statusCode 404.
	 */
	private boolean isHttpResponseNotFound(Exception e) {
		return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
				&& ((HttpOperationFailedException) e.getCause()).getStatusCode() == HttpStatus.NOT_FOUND.value();

	}

    @Override
    public List<StudentSession> getStudentSessionByTestEvent(UUID testEventId) {
        logger.debug("{}", " + getStudentSessionByTestEvent(UUID)");

        List<StudentSession> sessionList = new ArrayList<StudentSession>();
        String dataResponse = null;
        int page=0;
        StudentSessionResponse studentSessionResponse = null;
        int pageSize = Integer.parseInt(rescorePageSize);
        try {
            do {
                dataResponse = producerTemplate.requestBodyAndHeaders(
                        ReportingRouteBuilder.getStudentSessionByTestEventIdEndpoint,
                        "",
                        generateHeadersRescoreActivity(testEventId, null, page++, pageSize, null, null, null),

                        String.class);
                if (dataResponse != null && dataResponse.length() > 0) {
                    studentSessionResponse = objectMapper().readValue(dataResponse, new TypeReference<StudentSessionResponse>() {});
                    if (studentSessionResponse != null && !CollectionUtils.isEmpty(studentSessionResponse.getStudentSessions().getContent()))
                        sessionList.addAll(studentSessionResponse.getStudentSessions().getContent());
                }
            } while (dataResponse != null && !studentSessionResponse.getStudentSessions().isLast());
        }catch (Exception e) {
            logger.warn("Exception from Reporting: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.debug("{}", "-getStudentSessionByTestEvent(UUID,UUID)");

        return sessionList;
    }

    @Override
    public List<StudentSession> getStudentSessionByActivity(UUID activityId) {
        logger.debug("{}", " + getStudentSessionByActivity(UUID)");

        List<StudentSession> sessionList = new ArrayList<StudentSession>();
        String dataResponse = null;
        int page=0;
        StudentSessionResponse studentSessionResponse = null;
        int pageSize = Integer.parseInt(rescorePageSize);
        try {
            do {
                dataResponse = producerTemplate.requestBodyAndHeaders(
                        ReportingRouteBuilder.getStudentSessionByActivityIdEndpoint,
                        "",
                        generateHeadersRescoreActivity(null, activityId, page++, pageSize, null,null, null),

                        String.class);

                if (dataResponse !=null && dataResponse.length() > 0) {
                    studentSessionResponse = objectMapper().readValue(dataResponse, new TypeReference<StudentSessionResponse>() {});
                    if (studentSessionResponse != null && !CollectionUtils.isEmpty(studentSessionResponse.getStudentSessions().getContent()))
                        sessionList.addAll(studentSessionResponse.getStudentSessions().getContent());
                }
            } while (dataResponse != null && !studentSessionResponse.getStudentSessions().isLast());
        }catch (Exception e) {
            logger.warn("Exception from Reporting: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.debug("{}", "-getStudentSessionByActivity(UUID,UUID)");

        return sessionList;
    }

    @Override
    public List<SessionId> getAllSessionIds(  LocalDateTime startDate,LocalDateTime endDate) {

        logger.debug("{}", " + getAllSessionIds()");
        List<SessionId> sessionList = new ArrayList<SessionId>();
        String dataResponse = null;
        int page= 0;
        StudentSessionIdResponse studentSessionIdResponse = null;
        int pageSize = Integer.parseInt(rescorePageSize);

        try {
            do {
                dataResponse = producerTemplate.requestBodyAndHeaders(
                        ReportingRouteBuilder.getAllSessionIdsEndpoint,
                        "",
                        generateHeadersRescoreActivity(null, null, page++, pageSize, startDate, null, endDate),

                        String.class);
                if (dataResponse != null && dataResponse.length() > 0) {
                    studentSessionIdResponse = objectMapper().readValue(dataResponse, new TypeReference<StudentSessionIdResponse>() {});
                    if (studentSessionIdResponse != null && !CollectionUtils.isEmpty(studentSessionIdResponse.getStudentSessionListViews().getContent()))
                        sessionList.addAll(studentSessionIdResponse.getStudentSessionListViews().getContent());
                }
            } while (dataResponse != null && !studentSessionIdResponse.getStudentSessionListViews().isLast());
        }catch (Exception e) {
            logger.warn("Exception from Reporting: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.debug("{}", "getAllSessionIds()");

        return sessionList;
    }

    @Override
    public List<BenchmarkSession> getBenchmarkStudentSessionNoScores(LocalDateTime startDate, LocalDateTime endDate) {
        logger.debug("{}", " + getBenchmarkStudentSessionNoScores()");

        List<BenchmarkSession> sessionList = new ArrayList<BenchmarkSession>();
        int page=0;
        String dataResponse = null;
        BenchmarkSessionResponse benchmarkSessionResponse = null;
        int pageSize = Integer.parseInt(rescorePageSize);
        try {
            do {
                dataResponse = producerTemplate.requestBodyAndHeaders(
                        ReportingRouteBuilder.getBenchmarkStudentSessionNoScoresEndpoint,
                        "",
                        generateHeadersRescoreActivity(null, null, page++, pageSize, startDate, endDate, null),
                        String.class);
                if (dataResponse !=null && dataResponse.length() > 0) {
                    benchmarkSessionResponse = objectMapper().readValue(dataResponse, new TypeReference<BenchmarkSessionResponse>() {});
                    if (benchmarkSessionResponse != null && !CollectionUtils.isEmpty(benchmarkSessionResponse.getBenchmarkSessions().getContent()))
                        sessionList.addAll(benchmarkSessionResponse.getBenchmarkSessions().getContent());
                }
            } while (dataResponse != null && !benchmarkSessionResponse.getBenchmarkSessions().isLast());
        }catch (Exception e) {
            logger.warn("Exception from Reporting: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.debug("{}", "-getBenchmarkStudentSessionNoScores(UUID,UUID)");

        return sessionList;
    }

    @Override
    public List<StudentSession> getTestEventSessions(UUID eventRefId, String eventStatus) {
        logger.debug("{}", " + getTestEventSessions()");

        List<StudentSession> sessionList = new ArrayList<StudentSession>();
        int page=0;
        String dataResponse = null;
        StudentSessionResponse studentSessionResponse = null;
        try {
            int pageSize = Integer.parseInt(rescorePageSize);
            do {
                dataResponse = producerTemplate.requestBodyAndHeaders(
                        ReportingRouteBuilder.getTestEventSessionsEndpoint,
                        "",
                        generateHeadersTestEventSessions(eventRefId, eventStatus, page++, pageSize),
                        String.class);
                if (dataResponse !=null && dataResponse.length() > 0) {
                    studentSessionResponse = objectMapper().readValue(dataResponse, new TypeReference<StudentSessionResponse>() {});
                    if (studentSessionResponse != null && !CollectionUtils.isEmpty(studentSessionResponse.getStudentSessions().getContent()))
                        sessionList.addAll(studentSessionResponse.getStudentSessions().getContent());
                }
            } while (dataResponse != null && !studentSessionResponse.getStudentSessions().isLast());
        }catch (Exception e) {
            logger.warn("Exception from Reporting: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.debug("{}", "-getTestEventSessions(UUID,String)");

        return sessionList;
    }

  @Override
  public AssignmentEventInfo getAssignmentForActivity(UUID activityId) {
    logger.debug("{}", " + getAssignmentForActivity(UUID)");

      AssignmentEventInfo assignmentEventInfo = null;

    try{
      String response = producerTemplate.requestBodyAndHeaders(
          ReportingRouteBuilder.getAssignmentEventDetailsEndpoint,
          "",
          generateHeadersForActivity(activityId),
          String.class);
      assignmentEventInfo = objectMapper().readValue(response, new TypeReference<AssignmentEventInfo>() {});
    }catch (Exception e) {

      logger.warn("Exception from Reporting: {}", e);
      if (isHttpResponseNotFound(e)) {
        return null;
      }
    }
    logger.debug("{}", "-getAssignmentForActivity(UUID)");

    return assignmentEventInfo;
  }

    /**
     * Post to Reporting /v4/test_events/{TESTING_EVENT_REFID}/activities/{ACTIVITY_ID}/reopen
     * @param testEventRefId
     * @param activityId
     * @param testEventCloseInformationList
     */
    @Override
    public void publishTestEventActivityReopen(UUID testEventRefId, UUID activityId, List<TestEventCloseInformation> testEventCloseInformationList) {

        logger.debug("{}", " + publishTestEventActivityReopen()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postTestEventActivityReopenEndpoint,
                    testEventCloseInformationList,
                    generateHeadersForActivityScores(testEventRefId, activityId));
        } catch (Exception e){
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-publishTestEventActivityReopen()");
    }

    @Override
    public void postStudentDetails(UUID eventID, List<StudentInfo> studentInfoList) {

        logger.debug("{}", " + postStudentDetails()");

        try {
            producerTemplate.requestBodyAndHeaders(
                    ReportingRouteBuilder.postStudentAssignmentReportingEndpoint,
                    studentInfoList,
                    generateHeadersForStudentDetails(eventID));
        } catch (Exception e){
            logger.warn("Exception from Reporting Service: {}", e);
            throw new RuntimeException(e);
        }

        logger.debug("{}", "-postStudentDetails()");

    }

    private Map<String, Object> generateHeadersRescoreActivity(UUID testEventId, UUID activityId, int page, int size, LocalDateTime startDate,
                                                                LocalDateTime endDate, LocalDateTime completedDate) {

        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);

        if (testEventId != null) {
            headers.put(TESTEVENT_ID, testEventId.toString());
        } else if (activityId != null) {
            headers.put(ACTIVITY_ID, activityId.toString());
        }

        if (completedDate != null && startDate != null) {
            headers.put(COMPLETED_DATE, completedDate.toString());
            headers.put(STARTDATE, startDate.toString());
        }
        else if (startDate != null) {
            headers.put(STARTDATE, startDate.toString());

            if (endDate != null) {
                headers.put(ENDDATE, endDate.toString());
            }
        }

        headers.put(PAGE, String.valueOf(page));
        headers.put(SIZE, String.valueOf(size));
        return headers;
    }

    private Map<String, Object> generateHeadersTestEventSessions(UUID eventRefId, String eventStatus, int page, int size) {

        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(EVENT_REFID, eventRefId.toString());
        headers.put(EVENTSTATUS, eventStatus);
        headers.put(PAGE, String.valueOf(page));
        headers.put(SIZE, String.valueOf(size));
        return headers;
    }

    @Override
    public List<BenchmarkActivity> getTestEventActivities(UUID eventRefId) {
        logger.debug("{}", " + getTestEventActivities()");

        List<BenchmarkActivity> benchmarkActivityList = new ArrayList<BenchmarkActivity>();
        int page=0;
        String dataResponse = null;
        BenchmarkActivitiesResponse benchmarkActivitiesResponse = null;
        try {
            int pageSize = Integer.parseInt(rescorePageSize);
            do {
                dataResponse = producerTemplate.requestBodyAndHeaders(
                        ReportingRouteBuilder.getTestEventActivitiesEndpoint,
                        "",
                        generateHeadersTestEventActivities(eventRefId, page++, pageSize),
                        String.class);
                if (dataResponse !=null && dataResponse.length() > 0) {
                    benchmarkActivitiesResponse = objectMapper().readValue(dataResponse, new TypeReference<BenchmarkActivitiesResponse>() {});
                    if (benchmarkActivitiesResponse != null && !CollectionUtils.isEmpty(benchmarkActivitiesResponse.getBenchmarkActivities().getContent()))
                        benchmarkActivityList.addAll(benchmarkActivitiesResponse.getBenchmarkActivities().getContent());
                }
            } while (dataResponse != null && !benchmarkActivitiesResponse.getBenchmarkActivities().isLast());
        }catch (Exception e) {
            logger.warn("Exception from Reporting: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        logger.debug("{}", "-getTestEventActivities(UUID)");

        return benchmarkActivityList;
    }

    @Override
    public String deleteTeacherAssignment(UUID eventRefId) {
      String resp=null;
      try {
        resp=producerTemplate.requestBodyAndHeaders(ReportingRouteBuilder.deleteTeacherAssignmentEndpoint,
            null, generateHeadersForTeacherAssignmentDelete(eventRefId), String.class);
      } catch(Exception e) {
        logger.warn("Exception from Reporting: {}", e);
        if (isHttpResponseNotFound(e)) {
          return null;
        }

      }
      return resp;
    }

  @Override
  public List<ActivityStandardsPerformance> getStandardsToItemsMapInfo(UUID activityId){

    logger.debug("{}", "+getStandardsToItemsMapInfo");
    String dataResponse = null;
    List<ActivityStandardsPerformance> activityStandardsPerformances = null;
    try {
      dataResponse = producerTemplate.requestBodyAndHeaders(
          ReportingRouteBuilder.getStandardsToItemsMapEndpoint,
          null,
          generateHeadersForActivity(activityId),
          String.class);
      if (dataResponse !=null && dataResponse.length() > 0) {
        activityStandardsPerformances = objectMapper().readValue(dataResponse, new TypeReference<List<ActivityStandardsPerformance>>() {});
      }

    } catch (Exception e) {
      logger.warn("Exception from Reporting: {}", e);
      if (isHttpResponseNotFound(e)) {
        return null;
      }
    }
    logger.debug("{}", "-getStandardsToItemsMapInfo(UUID)");
    return activityStandardsPerformances;
  }

  @Override
  public List<EventDetailsBatch> getAssignmentDetails(List<UUID> eventRefId) {
    String eventDetails = null;
    List<EventDetailsBatch> eventDetailsBatches = new ArrayList<>();
    List<AssignmentEventInfo> assignmentEventInfoList = null;
    ReprocessAssignmentsWrapper wrapper = new ReprocessAssignmentsWrapper();
    wrapper.setAssignmentId(eventRefId);

    try{
      eventDetails = producerTemplate.requestBodyAndHeaders(
          ReportingRouteBuilder.getReprocessAssignmentsEndpoint,
          wrapper,
          generateHeadersForReprocess(),
          String.class
      );
      if(eventDetails!=null && eventDetails.length()>0){

        assignmentEventInfoList = objectMapper().readValue(eventDetails, new  TypeReference<List<AssignmentEventInfo>>(){});

        if(assignmentEventInfoList!=null && assignmentEventInfoList.size()>0) {
          for (AssignmentEventInfo assignmentEventInfo : assignmentEventInfoList ) {
            EventDetailsBatch eventDetailsBatch = new EventDetailsBatch();
              eventDetailsBatch.setRefId(assignmentEventInfo.getAssignmentId());
              eventDetailsBatch.setEventName(assignmentEventInfo.getAssignmentName());
              TestType type = assignmentEventInfo.getTestType();
              eventDetailsBatch.setSourceObjectType(type.getSourceObjectType());
              eventDetailsBatch.setDueDate(assignmentEventInfo.getDueDate());
              eventDetailsBatch.setAvailableDate(assignmentEventInfo.getAvailableDate());
              eventDetailsBatch.setSectionId(assignmentEventInfo.getSectionId());
              eventDetailsBatch.setStatus(AssignmentStatus.NOT_STARTED);

              SourceObject sourceObject = new SourceObject();
              sourceObject.setValue(assignmentEventInfo.getResourceId());
              sourceObject.setSif_RefObject(type.getSourceObjectType());
              sourceObject.setUgenRefId(assignmentEventInfo.getActivityId());
              sourceObject.setName(assignmentEventInfo.getAssessmentName());
              String attribute = String.valueOf(getAttributes(assignmentEventInfo));
              sourceObject.setAttributes(attribute);

              eventDetailsBatch.setSourceObject(sourceObject);
              eventDetailsBatches.add(eventDetailsBatch);
              }
            }
          }

    }catch (Exception e){
      logger.warn("Exception from Reporting: {}", e);
      if (isHttpResponseNotFound(e)) {
        return null;
      }

      }
    return  eventDetailsBatches;
  }

  private JsonObject getAttributes(AssignmentEventInfo assignmentEventInfo) {
    JsonObject obj = new JsonObject();
    String programId = assignmentEventInfo.getProgramId();
    String platformId = assignmentEventInfo.getResourceId();

    obj.addProperty("programId", programId);
    obj.addProperty("hmhId", platformId);

    return obj;

  }

  private Map<String, Object> generateHeadersTestEventActivities(UUID eventRefId, int page, int size) {
        Map<String, Object> headers = headersHelper.createBasicHeadersWithCorrelation(Reporting);
        headers.put(TEST_EVENT_ID, eventRefId.toString());
        headers.put(SIZE, String.valueOf(size));
        headers.put(PAGE, String.valueOf(page));
        return headers;
    }

}

