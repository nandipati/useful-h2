package io.hmheng.reporting.aggregator.core.service.reporting.domain;

/**
 * Created by somashekara on 11/15/16.
 */
public class StudentSessionIdResponse {

    private StudentSessionListViews studentSessionListViews;

    public StudentSessionListViews getStudentSessionListViews() {
        return studentSessionListViews;
    }

    public void setStudentSessionListViews(StudentSessionListViews studentSessionListViews) {
        this.studentSessionListViews = studentSessionListViews;
    }
}
