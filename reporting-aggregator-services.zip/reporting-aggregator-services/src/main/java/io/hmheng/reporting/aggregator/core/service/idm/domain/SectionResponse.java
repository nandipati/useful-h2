package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.List;

public class SectionResponse {

    private List<Section> sections;

    public List<Section> getSections() {
        return sections;
    }

    public void setSections(List<Section> sections) {
        this.sections = sections;
    }
    
    @Override
    public String toString() {
        return "StudentSectionAssociation{" +
            "sections=" + sections +
            '}';
    }
    
}
