package io.hmheng.reporting.aggregator.core.service.utils;

import com.fasterxml.jackson.datatype.joda.JodaModule;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.springframework.stereotype.Component;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;

/**
 * Created by nandipatim on 3/15/16.
 */
@Component
public class JacksonDataFormatHelper {

    public JacksonDataFormat configureDataFormat(Class<?> clazz) {
        JacksonDataFormat dataFormat = new JacksonDataFormat(clazz);
        dataFormat.addModule(new JodaModule());
        dataFormat.disableFeature(FAIL_ON_UNKNOWN_PROPERTIES);

        return dataFormat;
    }
}
