package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 3/17/16.
 */
public class AssignmentStudentStandardScoreInfo {

    private UUID sessionId;

    private TestType testType;

    private List<AssignmentStudentStandardScore> activityStandardScores;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public List<AssignmentStudentStandardScore> getActivityStandardScores() {
        return activityStandardScores;
    }

    public void setActivityStandardScores(List<AssignmentStudentStandardScore> activityStandardScores) {
        this.activityStandardScores = activityStandardScores;
    }

    @Override
    public String toString() {
        return "AssignmentStudentStandardScoreInfo{" +
            "sessionId=" + sessionId +
            ", testType=" + testType +
            ", activityStandardScores=" + activityStandardScores +
            '}' ;
    }
}
