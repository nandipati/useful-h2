package io.hmheng.reporting.aggregator.core.service.mds.domains;

import io.hmheng.reporting.aggregator.core.service.config.DisciplineConfig;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Discipline {

  private String name;
  private String id;
  private DisciplineConfig config;

  public Discipline(String name, DisciplineConfig config) {
    this.name = name;
    this.config = config;
    this.id = lookupId(name);
  }

  public String getName() {
    return name;
  }

  public String getId() {
    return id;
  }

  private String lookupId(String name) {
    String id = config.getMap().getOrDefault(name, null);

    log.info("Discipline '{}', maps to id '{}'", name, id);

    return id;
  }
}
