package io.hmheng.reporting.aggregator.core.service.reporting.domain;

/**
 * Created by akellas on 5/17/16.
 */
public enum TypeQuestion {

    PASSAGE("passage"),
    SHARED_PASSAGE("sharedpassage"),
    RUBRIC("rubric");

    private final String type;

    TypeQuestion(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return this.type;
    }

    public static boolean contains(String name) {
        for (TypeQuestion tq : TypeQuestion.values()) {
            if (tq.type.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }
}

