package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;

public class StudentDemographicInformation {

    private UUID sessionId;
    private String dateOfBirth;
    private String gender;
    private List<String> ethnicityCodes;
    private String eventStatus;
    private String englishProficiencyCode;
    private List<String> specialServiceCodes;
    private String economicStatusCode;
    private String studentRaceCode;
    private List<String> specialConditionCodes;
    private UUID actvityId;
    private TestType testType;
    private String givenName;
    private String familyName;
    private String contextId;
    private String studentLocalId;
    private String studentUserName;
    private UUID sectionId;
    private DateTime dateStarted;
    private DateTime dateCompleted;
    private Integer sessionDuration;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

	public List<String> getEthnicityCodes() {
		return ethnicityCodes;
	}

	public void setEthnicityCodes(List<String> ethnicityCodes) {
		this.ethnicityCodes = ethnicityCodes;
	}

	public List<String> getSpecialServiceCodes() {
		return specialServiceCodes;
	}

	public void setSpecialServiceCodes(List<String> specialServiceCodes) {
		this.specialServiceCodes = specialServiceCodes;
	}

	public List<String> getSpecialConditionCodes() {
		return specialConditionCodes;
	}


	public void setSpecialConditionCodes(List<String> specialConditionCodes) {
		this.specialConditionCodes = specialConditionCodes;
	}

	public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEventStatus() {
        return eventStatus;
    }

    public void setEventStatus(String eventStatus) {
        this.eventStatus = eventStatus;
    }

    public String getEnglishProficiencyCode() {
        return englishProficiencyCode;
    }

    public void setEnglishProficiencyCode(String englishProficiencyCode) {
        this.englishProficiencyCode = englishProficiencyCode;
    }

    public String getEconomicStatusCode() {
        return economicStatusCode;
    }

    public void setEconomicStatusCode(String economicStatusCode) {
        this.economicStatusCode = economicStatusCode;
    }

    public String getStudentRaceCode() {
        return studentRaceCode;
    }

    public void setStudentRaceCode(String studentRaceCode) {
        this.studentRaceCode = studentRaceCode;
    }

    public UUID getActvityId() {
        return actvityId;
    }

    public void setActvityId(UUID actvityId) {
        this.actvityId = actvityId;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getContextId() {
        return contextId;
    }

    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    public String getStudentLocalId() {
        return studentLocalId;
    }

    public void setStudentLocalId(String studentLocalId) {
        this.studentLocalId = studentLocalId;
    }

    public String getStudentUserName() {
        return studentUserName;
    }

    public void setStudentUserName(String studentUserName) {
        this.studentUserName = studentUserName;
    }

    public UUID getSectionId() { return sectionId; }

    public void setSectionId(UUID sectionId) { this.sectionId = sectionId; }

    public DateTime getDateStarted() { return dateStarted; }

    public void setDateStarted(DateTime dateStarted) { this.dateStarted = dateStarted; }

    public DateTime getDateCompleted() { return dateCompleted; }

    public void setDateCompleted(DateTime dateCompleted) { this.dateCompleted = dateCompleted; }

    public Integer getSessionDuration() { return sessionDuration; }

    public void setSessionDuration(Integer sessionDuration) { this.sessionDuration = sessionDuration; }

    @Override
    public String toString() {
        return "StudentDemographicInformation{" +
            "sessionId=" + sessionId +
            ", dateOfBirth='" + dateOfBirth + '\'' +
            ", gender='" + gender + '\'' +
            ", ethnicityCodes=" + ethnicityCodes +
            ", eventStatus='" + eventStatus + '\'' +
            ", englishProficiencyCode='" + englishProficiencyCode + '\'' +
            ", specialServiceCodes=" + specialServiceCodes +
            ", economicStatusCode='" + economicStatusCode + '\'' +
            ", studentRaceCode='" + studentRaceCode + '\'' +
            ", specialConditionCodes=" + specialConditionCodes +
            ", actvityId=" + actvityId +
            ", testType=" + testType +
            ", givenName='" + givenName + '\'' +
            ", familyName='" + familyName + '\'' +
            ", contextId='" + contextId + '\'' +
            ", studentLocalId='" + studentLocalId + '\'' +
            ", studentUserName='" + studentUserName + '\'' +
            ", sectionId=" + sectionId +
            ", dateStarted=" + dateStarted +
            ", dateCompleted=" + dateCompleted +
            ", sessionDuration=" + sessionDuration +
            '}';
    }
}
