package io.hmheng.reporting.aggregator.core.service;


import com.google.common.collect.Lists;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.assignment.AssignmentService;
import io.hmheng.reporting.aggregator.core.service.assignments.domain.StudentAssignmentReport;
import io.hmheng.reporting.aggregator.core.service.assignments.domain.StudentAssignmentsResponse;
import io.hmheng.reporting.aggregator.core.service.domain.Grade;
import io.hmheng.reporting.aggregator.core.service.domain.Organisation;
import io.hmheng.reporting.aggregator.core.service.learnosity.LearnosityService;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.LearnosityServiceResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSession;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Session;
import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.arg.TestEventCloseRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.Subscore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventCloseInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoreHelper;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoringService;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.LprFilter;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Session;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import org.springframework.util.StringUtils;

@Component
public class TestEventCloseServiceImpl implements TestEventCloseService {

    private static final Logger logger = LoggerFactory.getLogger(TestEventCloseServiceImpl.class);

    static int LPR_FLOOR = 1;
    static int LPR_CEILING = 99;

    @Autowired
    private ScoringService scoringService;

    @Autowired
    private ReportingService reportingService;

    @Autowired
    private LearnosityService learnosityService;

    @Autowired
    private ScoreHelper benchmarkScoreHelper;

    @Autowired
    private AssignmentService assignmentService;

    /**
     * Get all scores for Activity from Scoring.
     * Publish these scores to Reporting Service to /v4/test_events/{TESTING_EVENT_REFID}/activities/{ACTIVITY_ID}/benchmarkscores
     *
     * @param request
     */
    @Override
    public void handleTestEventClose(TestEventCloseRequest request) {

        logger.debug("{}", "+handleTestEventClose(TestEventCloseRequest request)");
        LearnosityServiceResponse learnosityServiceResponse ;
        try {
            List<StudentSession> sessionList = reportingService.getTestEventSessions(request.getTestEventRefId(), Constants.EVENTSTATUS_INPROGRESS);

            if (!CollectionUtils.isEmpty(sessionList)) {
                List<String> sessionIdList = new ArrayList<String>();
                if (sessionList != null && sessionList.size() > 0) {
                    for (int i = 0; i < sessionList.size(); i++) {
                        sessionIdList.add(sessionList.get(i).getSessionRefId().toString());
                    }
                }
                logger.debug("handleTestEventClose sending in-progress sessions to Learnosity {}", sessionIdList);
                learnosityServiceResponse = learnosityService.rescoreBySession(sessionIdList, (List)sessionList);
            }

            //call assignmentService for InProgress Students and post the sessionId List to Learnosity

            List<String> inprogressSessionIdlist = new ArrayList<>();

            inprogressSessionIdlist = getInProgressSessionIds(request.getTestEventRefId(), "IN_PROGRESS");

            if(inprogressSessionIdlist !=null  && !inprogressSessionIdlist.isEmpty()){
                logger.debug("handleTestEventClose sending in-progress sessions to Learnosity {}", inprogressSessionIdlist);
                learnosityServiceResponse = learnosityService.rescoreBySession(inprogressSessionIdlist, (List)sessionList);
            }
        }
        catch(Exception e) {
            logger.warn("Exception from handleTestEventClose(): {}", e);
        }

        //get all the scores for an ActivityId from Scoring
        BenchmarkActivityScoresResponse benchmarkActivityScoresResponse = scoringService.
                getBenchmarkActivityScores(request.getActivityId());

        if(benchmarkActivityScoresResponse==null ||
                ObjectUtils.isEmpty(benchmarkActivityScoresResponse.getSessions()) ||
                ObjectUtils.isEmpty(benchmarkActivityScoresResponse.getSessions().getContent())){
            throw new ApplicationException("Benchmark Scores cannot be Null or empty for ActivityForScores: "+request.getActivityId()
                    +" in Scoring");
        }

        Set<BenchmarkScore> resultScores = getBenchmarkScores(benchmarkActivityScoresResponse);

        List<TestEventCloseInformation> testEventCloseInformationList = Lists.newArrayList(convertToReportingScores((resultScores)));

        reportingService.publishTestEventCloseLprs(request.getTestEventRefId(),
                request.getActivityId(), testEventCloseInformationList);

        logger.debug("Scoring TestEventCloseInformation: {}", testEventCloseInformationList);

        logger.debug("{}", "-handleTestEventClose(TestEventCloseRequest request)");
    }

    public Set<BenchmarkScore> getBenchmarkScores(BenchmarkActivityScoresResponse benchmarkActivityScoresResponse) {
        return getBenchmarkScores(benchmarkActivityScoresResponse, false);
    }

    public Set<BenchmarkScore> getBenchmarkScores(BenchmarkActivityScoresResponse benchmarkActivityScoresResponse, boolean reopen) {
        Set<BenchmarkScore> scores = getBenchmarkScoresFromRequest(benchmarkActivityScoresResponse);

        Set<BenchmarkScore> filteredScores = filterScoresForLpsComputation(scores);

        logger.debug("Scoring filtered scores: {}", filteredScores);

        Set<BenchmarkScore> resultScores = new HashSet<>();

        Set<LprFilter> lprFilters = getTheLprFilters(filteredScores);

        logger.debug("Scoring lprFilters: {}", lprFilters);

        lprFilters.forEach(lprFilter -> {
            int frequency = 0;
            int history = 0;
            int count = 0;

            Map<Double, Double> scaleScoreToLprMap = new HashMap<>();

            Set<BenchmarkScore> scoresForCurrentSlot = getAllScoresBySlot(filteredScores, lprFilter.getSlot());
            count = scoresForCurrentSlot.size();

            for (BenchmarkScore currentScore : scoresForCurrentSlot) {
                double currentScaleScore = currentScore.getScaleScore();

                history = getScaleScoreHistory(scoresForCurrentSlot, currentScaleScore);
                frequency = getScaleScoreFrequency(scoresForCurrentSlot, currentScaleScore);

                if (reopen) {
                    scaleScoreToLprMap.put(currentScaleScore, null);
                }
                else {
                    double lpr = getLpr(frequency, history, count);

                    scaleScoreToLprMap.put(currentScaleScore, lpr);
                }
            }

            resultScores.addAll(updateScoresWithLpr(scoresForCurrentSlot, scaleScoreToLprMap, reopen));

        });
        return resultScores;
    }

    private Set<BenchmarkScore> getBenchmarkScoresFromRequest(BenchmarkActivityScoresResponse benchmarkActivityScoresResponse) {
        List<Session> sessions = benchmarkActivityScoresResponse.getSessions().getContent().stream().
            filter(session -> !StringUtils.isEmpty(session.getStatus()) && Constants.STATUS_COMPLETED.equals(session.getStatus().toUpperCase()))
            .collect(Collectors.toList());

      Set<BenchmarkScore> benchmarkScores = new HashSet<>();

      for(Session session :sessions )
      {
        List<BenchmarkScore> bscores = session.getScores();
        if(bscores!=null) {
          for (BenchmarkScore bs : bscores) {
            bs.setSkippedQuestions(session.isSkippedQuestions());
            bs.setInCompleteTestRecord(session.isInCompleteTestRecord());
            bs.setCompletionCriteriaNotMet(session.isCompletionCriteriaNotMet());
            bs.setItemsOmitted(session.isItemsOmitted());
            benchmarkScores.add(bs);
          }
        }
      }
      return benchmarkScores;
    }

    private double getLpr(int frequency, int history, int count) {
        BigDecimal lpr = BigDecimal.valueOf((history + (0.5*frequency))/count);
        BigDecimal percentage = lpr.multiply(BigDecimal.valueOf(100));
        double roundedLPR = Math.round(percentage.doubleValue());
        if (roundedLPR < LPR_FLOOR) {
            roundedLPR = LPR_FLOOR;
        }
        else if (roundedLPR > LPR_CEILING) {
            roundedLPR = LPR_CEILING;
        }
        return roundedLPR;
    }


    private Set<TestEventCloseInformation> convertToReportingScores(Set<BenchmarkScore> benchmarkScore){
        Map<UUID, String> sessionsVisited= new HashMap<>();
        Set<TestEventCloseInformation> testEventCloseInformationList = new HashSet<>();

        for(BenchmarkScore bs: benchmarkScore) {
            if (sessionsVisited.containsKey(bs.getSessionId())) {
                continue;
            }
            sessionsVisited.put(bs.getSessionId(), bs.getSessionId().toString());

            Set<BenchmarkScore> scoresBySession = benchmarkScore.stream().filter(x->x.getSessionId().
                    toString().equals(bs.getSessionId().toString())).collect(Collectors.toSet());

            testEventCloseInformationList.add(
                    convertBenchmarkScoresToTestEventCloseInformation(scoresBySession, bs.getSessionId()));
        }

        return testEventCloseInformationList;
    }

    private int getScaleScoreFrequency(Set<BenchmarkScore> scoresForCurrentSlot, double scaleScore) {
        return (int)scoresForCurrentSlot.stream().filter(x -> x.getScaleScore() == scaleScore).count();
    }

    private int getScaleScoreHistory(Set<BenchmarkScore> scoresForCurrentSlot, double scaleScore) {
        return (int)scoresForCurrentSlot.stream().filter(x -> x.getScaleScore() < scaleScore).count();
    }

    private Set<BenchmarkScore> filterScoresForLpsComputation(Set<BenchmarkScore> scores){
        return scores.stream().filter(sc -> sc.getScoreType().equals("T"))
                .collect(Collectors.toSet());
    }

    private Set<BenchmarkScore> updateScoresWithLpr(Set<BenchmarkScore> initialScores, Map<Double,Double> scaleScoresLprMap, boolean reopen) {
        initialScores.stream().forEach(score -> {
            Double scaleScore = scaleScoresLprMap.get(score.getScaleScore());
            if (reopen) {
                score.setLpr(null);
            } else if (scaleScore != null) {
                score.setLpr(scaleScoresLprMap.get(score.getScaleScore()));
            }});
        return initialScores;
    }

    private Set<BenchmarkScore> getAllScoresBySlot(final Set<BenchmarkScore> benchmarkScores, String slot){
        return benchmarkScores.stream().
                filter(score -> score.getSlot().equals(slot)).collect(Collectors.toSet());
    }

    private Set<LprFilter> getTheLprFilters(final Set<BenchmarkScore> benchmarkScores){
        Set<LprFilter> lprFilters = new HashSet<>();
        lprFilters.addAll(benchmarkScores.stream().map(score ->
                new LprFilter(score.getScoreType(), score.getSlot())).collect(Collectors.toSet()));
        return  lprFilters;
    }

    private TestEventCloseInformation convertBenchmarkScoresToTestEventCloseInformation(Set<BenchmarkScore> benchmarkScores, UUID sessionId){
        TestEventCloseInformation testEventCloseInformation = new TestEventCloseInformation();
        testEventCloseInformation.setSessionId(sessionId);
        BenchmarkScore benchmarkTotalScore = benchmarkScores.stream().
                filter(x->x.getScoreType().equals("T")).collect(Collectors.toList()).get(0);
        List<BenchmarkScore> benchmarkScoreList = benchmarkScores.stream().
                filter(x -> x.getScoreType().equals("S")).collect(Collectors.toList());
        TotalScore totalScore = benchmarkScoreHelper.convertScoreIntoTotalScore(benchmarkTotalScore);
        List<Subscore> subscores = convertScoresIntoSubscores(benchmarkScoreList);
        totalScore.setStudentSubScores(subscores);

        testEventCloseInformation.setTotalScore(totalScore);

        return testEventCloseInformation;

    }

    private List<Subscore> convertScoresIntoSubscores(List<BenchmarkScore> benchmarkScores){
        List<Subscore> subscoreList = new ArrayList<>();

        for (BenchmarkScore benchmarkScore : benchmarkScores) {
            subscoreList.add(benchmarkScoreHelper.convertScoreIntoSubScore(benchmarkScore));
        }

        return subscoreList;
    }

    public void handleTestEventReopenScores(UUID testEventId, UUID activityId) {

        logger.debug("{}", "+handleTestEventReopenScores(UUID testEventId, UUID activityId)");

        //get all the scores for an ActivityId from Scoring
        BenchmarkActivityScoresResponse benchmarkActivityScoresResponse = scoringService.
                getBenchmarkActivityScores(activityId);

        if(benchmarkActivityScoresResponse==null ||
                ObjectUtils.isEmpty(benchmarkActivityScoresResponse.getSessions()) ||
                ObjectUtils.isEmpty(benchmarkActivityScoresResponse.getSessions().getContent())){
            throw new ApplicationException("Benchmark Scores cannot be Null or empty for activity: "+ activityId
                    +" in Scoring");
        }

        Set<BenchmarkScore> resultScores = getBenchmarkScores(benchmarkActivityScoresResponse, true);

        List<TestEventCloseInformation> testEventCloseInformationList = Lists.newArrayList(convertToReportingScores((resultScores)));

        reportingService.publishTestEventActivityReopen(testEventId, activityId, testEventCloseInformationList);

        logger.debug("{}", "-handleTestEventReopenScores(UUID testEventId, UUID activityId)");
    }

    private List<String> getInProgressSessionIds(UUID testEventId, String assignmentStatus) {

        List<String> list = new ArrayList<>();
        StudentAssignmentsResponse studentAssignmentsResponse = assignmentService.getStudentSessionIds(testEventId, assignmentStatus);
        for (Organisation organisation : studentAssignmentsResponse.getOrganisations()) {
            if (CollectionUtils.isEmpty(organisation.getGrades())) {
                continue;
            }
            for (Grade grade : organisation.getGrades()) {
                List<StudentAssignmentReport> studentAssignmentReports = grade.getStudentAssignmentReports();
                if (CollectionUtils.isEmpty(studentAssignmentReports)) {
                    continue;
                }

                for (StudentAssignmentReport assignmentReport : studentAssignmentReports) {
                    if(AssignmentStatus.IN_PROGRESS == assignmentReport.getStatus())
                        list.add(assignmentReport.getStudentActivityRefId().toString());
                }
            }
        }
        return list;
    }
}
