package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by nandipatim on 3/17/16.
 */
public class AssignmentStudentStandardScoreRequest {

    @JsonProperty(value = "studentSessionStandardScores")
    private AssignmentStudentStandardScoreInfo studentSessionStandardScores;

    public AssignmentStudentStandardScoreInfo getAssignmentStudentStandardScoreInfo() {
        return studentSessionStandardScores;
    }

    public void setAssignmentStudentStandardScoreInfo(AssignmentStudentStandardScoreInfo studentSessionStandardScores) {
        this.studentSessionStandardScores = studentSessionStandardScores;
    }
}
