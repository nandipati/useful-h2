package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.ProficiencyBand;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoringSource;
import java.util.UUID;

/**
 * Created by nandipatim on 3/4/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentTotalScoreInfo {

    private UUID sessionId;
    private Integer totalItemsCorrect;
    private Integer totalPointsCorrect;
    private Integer totalPoints;
    private Integer totalItems;
    private String totalPerformanceLevel;
    private Long bandId;
    private Double totalProficiencyScore;
    private Integer totalAttainedPoints;
    private Integer totalTime;
    private ScoringSource scoringSource;
    private ProficiencyBand proficiencyBand;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getTotalItemsCorrect() {
        return totalItemsCorrect;
    }

    public void setTotalItemsCorrect(Integer totalItemsCorrect) {
        this.totalItemsCorrect = totalItemsCorrect;
    }

    public Integer getTotalPointsCorrect() {
        return totalPointsCorrect;
    }

    public void setTotalPointsCorrect(Integer totalPointsCorrect) {
        this.totalPointsCorrect = totalPointsCorrect;
    }

    public Integer getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(Integer totalPoints) {
        this.totalPoints = totalPoints;
    }

    public Integer getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(Integer totalItems) {
        this.totalItems = totalItems;
    }

    public String getTotalPerformanceLevel() {
        return totalPerformanceLevel;
    }

    public void setTotalPerformanceLevel(String totalPerformanceLevel) {
        this.totalPerformanceLevel = totalPerformanceLevel;
    }

    public Double getTotalProficiencyScore() {
        return totalProficiencyScore;
    }

    public void setTotalProficiencyScore(Double totalProficiencyScore) {
        this.totalProficiencyScore = totalProficiencyScore;
    }

    public Integer getTotalAttainedPoints() {
        return totalAttainedPoints;
    }

    public void setTotalAttainedPoints(Integer totalAttainedPoints) {
        this.totalAttainedPoints = totalAttainedPoints;
    }

    public Long getBandId() {
        return bandId;
    }

    public void setBandId(Long bandId) {
        this.bandId = bandId;
    }

    public Integer getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Integer totalTime) {
        this.totalTime = totalTime;
    }

    public ScoringSource getScoringSource() {
        return scoringSource;
    }

    public void setScoringSource(ScoringSource scoringSource) {
        this.scoringSource = scoringSource;
    }

    public ProficiencyBand getProficiencyBand() {
        return proficiencyBand;
    }

    public void setProficiencyBand(ProficiencyBand proficiencyBand) {
        this.proficiencyBand = proficiencyBand;
    }

    @Override
    public String toString() {
        return "AssignmentTotalScoreInfo{" +
            "sessionId=" + sessionId +
            ", totalItemsCorrect=" + totalItemsCorrect +
            ", totalPointsCorrect=" + totalPointsCorrect +
            ", totalPoints=" + totalPoints +
            ", totalItems=" + totalItems +
            ", totalPerformanceLevel='" + totalPerformanceLevel + '\'' +
            ", bandId=" + bandId +
            ", totalProficiencyScore=" + totalProficiencyScore +
            ", totalAttainedPoints=" + totalAttainedPoints +
            ", totalTime=" + totalTime +
            ", scoringSource=" + scoringSource +
            ", proficiencyBand=" + proficiencyBand +
            '}';
    }
}
