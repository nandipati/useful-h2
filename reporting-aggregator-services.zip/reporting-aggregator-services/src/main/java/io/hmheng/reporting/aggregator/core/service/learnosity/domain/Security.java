package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import io.hmheng.reporting.aggregator.core.service.learnosity.LearnosityRouteBuilder;

import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by pabonaj on 10/1/16.
 */
public class Security {

    private String consumer_key;
    private String domain;
    private String consumer_secret;
    private String timestamp;
    private String signature;

    public String getConsumer_key() {
        return consumer_key;
    }

    public void setConsumer_key(String consumer_key) {
        this.consumer_key = consumer_key;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getConsumer_secret() {
        return consumer_secret;
    }

    public void setConsumer_secret(String consumer_secret) {
        this.consumer_secret = consumer_secret;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = createSignature(signature);
    }

    private String createSignature(String requestJson) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmm");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        this.timestamp = sdf.format(new Date());
        String request = String.format("%s_%s_%s_%s_%s", this.consumer_key, this.domain, this.timestamp, this.consumer_secret, requestJson);
        String signature = getSHA256Hash(request).toLowerCase();
        return signature;
    }

    /**
     * Returns a hexadecimal encoded SHA-256 hash for the input String.
     * @param data
     * @return
     */
    private String getSHA256Hash(String data) {
        String result = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes("UTF-8"));
            return DatatypeConverter.printHexBinary(hash);
        }catch(Exception ex) {

        }
        return result;
    }

}
