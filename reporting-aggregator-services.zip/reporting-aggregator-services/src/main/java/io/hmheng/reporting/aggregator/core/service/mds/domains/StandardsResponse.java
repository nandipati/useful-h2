package io.hmheng.reporting.aggregator.core.service.mds.domains;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Created by nandipatim on 3/16/16.
 */
public class StandardsResponse {

    @JsonProperty(value = "standards")
    private Standards standards;

    public Standards getStandards() {
        return standards;
    }

    public void setStandards(Standards standards) {
        this.standards = standards;
    }
}
