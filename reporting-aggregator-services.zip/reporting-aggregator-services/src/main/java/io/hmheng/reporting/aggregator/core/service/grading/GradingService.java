package io.hmheng.reporting.aggregator.core.service.grading;

import java.util.List;
import java.util.UUID;
import io.hmheng.reporting.aggregator.core.service.grading.domain.PushScoreStatus;

public interface GradingService {

    public List<PushScoreStatus> pushScores(List<UUID> listSessionIDs);
}
