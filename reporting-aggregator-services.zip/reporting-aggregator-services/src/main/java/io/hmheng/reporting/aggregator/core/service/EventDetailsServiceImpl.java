package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.arg.EventDetailsRequest;
import io.hmheng.reporting.aggregator.core.service.config.DisciplineConfig;
import io.hmheng.reporting.aggregator.core.service.idm.IDMService;
import io.hmheng.reporting.aggregator.core.service.idm.domain.Section;
import io.hmheng.reporting.aggregator.core.service.mds.MDSService;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Discipline;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchAssessmentItems;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchAssessmentItemsListResponse;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkActivity;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.GroupInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.utils.DisciplineHelper;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoringService;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoreEventResponseInfo;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import io.hmheng.reporting.aggregator.utils.SourceObjectTypeUtil;
import io.hmheng.reporting.aggregator.web.domain.assignment.EventDetailsBatch;
import io.hmheng.reporting.aggregator.web.domain.assignment.Group;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 2/29/16.
 */
@Component
public class EventDetailsServiceImpl implements EventDetailsService{

    private static final Logger logger = LoggerFactory.getLogger(EventDetailsServiceImpl.class);

    @Autowired
    private IDMService idmService;

    @Autowired
    private ReportingService reportingService;

    @Autowired
    private DisciplineHelper disiplineHelper;

    @Autowired
    private ScoringService scoringService;

    @Autowired
    private TestEventCloseService testEventCloseService;

    @Autowired
    private MDSService mdsService;

    @Autowired
    private DisciplineConfig disciplineConfig;

    /**
     * If Event is formative POST to Reportin Service "/v4/assignments/${header." + ASSIGNMENT_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/assignmentActivity
     * If Event is Benchmark POST to Reporting Service "/v4/test_events/${header." + TESTING_EVENT_REFID + "}/activities/${header." + ACTIVITY_ID + "}/benchmarkActivity
     * @param event
     */
    @Override
    public void handleEventDetails(EventDetailsRequest event){
        validateEvent(event);

        if (isFormativeAssessmentOrProductEdEvent(event)) {
            AssignmentEventInfo assignmentEventInfo = constructAssignmentEventInfo(event);
            dispatchAssignmentEventInfo(assignmentEventInfo);
        }
        else if (isBenchmarkAssessmentEvent(event)) {
            TestEventInfo testEventInfo = constructTestEventInfo(event);
            dispatchTestEventInfo(testEventInfo);
        }
        else {
            throw new ApplicationException("Not a Supported Source Type : "+event.getSourceObjectType());
        }
    }

    @Override
    public void handleReopenedEventDetails(EventDetailsRequest event){
        if(event == null){
            throw new ApplicationException("EventDetailsBatch should not be null");
        }
        TestEventInfo testEventInfo = constructTestEventInfo(event);
        reportingService.publishReopenedTestEventDetails(event.getRefId(),testEventInfo);
    }

    @Override
    public void handleReopenedEventScores(EventDetailsBatch eventDetailsBatch) {

        logger.debug("start processing handleReopenedEventScores");

        List<BenchmarkActivity> benchmarkActivityList = reportingService.getTestEventActivities(eventDetailsBatch.getRefId());

        for (BenchmarkActivity benchmarkActivity : benchmarkActivityList) {
            logger.info("processing benchmark activity {}", benchmarkActivity);
            testEventCloseService.handleTestEventReopenScores(eventDetailsBatch.getRefId(), benchmarkActivity.getActivityId());
        }

        logger.debug("end processing handleReopenedEventScores");
    }

    private Section getSessionFromIdm(EventDetailsRequest event){
        UUID sectionId = event.getSectionId();
        logger.info("Section Id: {}", sectionId);
        String contextId = event.getContextId();
        String platformId = event.getPlatformId();
        Section section = null;
        try {
            section = idmService.getSectionsDetails(sectionId, contextId,platformId);
        } catch (Exception e) {
            logger.error("sectionId details not found from IDM {}", sectionId );

            e.printStackTrace();
        }
        logger.info("{}", "-getSessionFromIdm(UUID)" + ((section != null)?section.toString():null));
        logger.debug("{}", "-getSessionFromIdm(UUID)");

        return section;
    }


    private AssignmentEventInfo constructAssignmentEventInfo(EventDetailsRequest event){

        AssignmentEventInfo assignmentEventInfo = new AssignmentEventInfo();

        assignmentEventInfo.setEventRefId(event.getRefId());
        assignmentEventInfo.setActivityId(event.getActivityId());
        assignmentEventInfo.setAssignmentName(event.getEventName());
        assignmentEventInfo.setAssessmentName(event.getAssessmentName());
        assignmentEventInfo.setIsbn(event.getIsbn());
        assignmentEventInfo.setDueDate(event.getDueDate());
        assignmentEventInfo.setAvailableDate(event.getAvailableDate());
        assignmentEventInfo.setSectionId(event.getSectionId());
        assignmentEventInfo.setResourceId(event.getResourceId());
        if(event.getleaRefId() != null) {
            assignmentEventInfo.setleaRefId(event.getleaRefId());
        }
        if(event.getProgramId() != null) {
            assignmentEventInfo.setProgramId(event.getProgramId());
        }
        assignmentEventInfo.setTestType(TestType.getTestTypeForSourceType(event.getSourceObjectType()));
        if(event.getManualScoringRequired() != null) {
            assignmentEventInfo.setManualScoringRequired(event.getManualScoringRequired());
        }
        if(event.getStaffPersonalRefId() != null){
            assignmentEventInfo.setStaffPersonalRefId(event.getStaffPersonalRefId());
        }

        if(CollectionUtils.isNotEmpty(event.getGroups())) {
            List<GroupInfo> groupInfos = new ArrayList<>();
            for(Group group : event.getGroups()) {
                GroupInfo groupInfo = new GroupInfo();
                groupInfo.setGroupId(group.getRefId());
                groupInfo.setParentGroupId(group.getParentGroupRefId());
                groupInfos.add(groupInfo);

            }
            assignmentEventInfo.setEventGroups(groupInfos);
        }

        OneSearchAssessmentItemsListResponse assessment = getAssessment(event);
        OneSearchAssessmentItems[] assessmentItems = getAssessmentItems(assessment);
        String grade = getGrade(event);
        String programName = getProgramName(assessmentItems);
        Discipline discipline = new Discipline(getDisciplineName(assessmentItems), disciplineConfig);

        assignmentEventInfo.setGrade(grade);
        assignmentEventInfo.setProgramName(programName);
        assignmentEventInfo.setDisciplineName(discipline.getName());
        assignmentEventInfo.setDisciplineId(discipline.getId());

        return assignmentEventInfo;
    }

    private TestEventInfo constructTestEventInfo(EventDetailsRequest event){

        TestEventInfo testEventInfo = new TestEventInfo();
        if(event.getDiscipline() != null)
            testEventInfo.setDiscipline(disiplineHelper.getDisciplineForAssignmentDisciplineString(event.getDiscipline()));

        testEventInfo.setEventRefId(event.getRefId());
        testEventInfo.setActivityId(event.getActivityId());
        testEventInfo.setGrade(event.getGrade());
        testEventInfo.setLevel(event.getLevel());
        testEventInfo.setNormDate(event.getNormDate());
        testEventInfo.setStartDate(event.getAvailableDate());
        testEventInfo.setFinishDate(event.getDueDate());
        if(event.getOriginalStartDate() != null){
            testEventInfo.setStartDate(event.getOriginalStartDate());
        }
        if(event.getOriginalFinishDate() != null){
            testEventInfo.setFinishDate(event.getOriginalFinishDate());
        }
        testEventInfo.setProgramName(event.getProgramName());
        testEventInfo.setProduct(event.getProduct());
        testEventInfo.setEventName(event.getEventName());
        testEventInfo.setStatus(event.getEventStatus().name());
        testEventInfo.setIsbn(event.getIsbn());
        if(event.getAssessmentName() != null)
            testEventInfo.setActivityName(event.getAssessmentName());
        if(event.getResourceId() != null)
            testEventInfo.setResourceId(event.getResourceId());
        if(event.getProgramId() != null){
            testEventInfo.setProgramId(event.getProgramId());
        }
        if(event.getleaRefId() != null) {
            testEventInfo.setleaRefId(event.getleaRefId());
        }
        testEventInfo.setTestType(TestType.getTestTypeForSourceType(event.getSourceObjectType()));
        return testEventInfo;
    }

    private void validateEvent(EventDetailsRequest event) {
        if(event == null){
            throw new ApplicationException("EventDetailsBatch should not be null");
        }
    }

    private String getGrade(EventDetailsRequest event) {
        UUID sectionId = event.getSectionId();
        logger.info("Program Id {} for Activity {}", event.getProgramId(), event.getActivityId());

        if(sectionId == null) return null;

        Section section = getSessionFromIdm(event);
        return (section == null) ? null : section.getGrade();
    }

    private OneSearchAssessmentItemsListResponse getAssessment(EventDetailsRequest event) {
        try {
            return mdsService.getItemsByAssessmentId(event.getResourceId());
        } catch (Exception ex) {
            logger.debug("Post to Reporting - No Program Name for , Program Id {} for Activity {}", event.getProgramId(),event.getActivityId());
        }

        return null;
    }

    private OneSearchAssessmentItems[] getAssessmentItems(OneSearchAssessmentItemsListResponse assessment) {
        return (assessment == null || assessment.getOneSearchAssessmentItems() == null)
            ? new OneSearchAssessmentItems[0]
            : assessment.getOneSearchAssessmentItems();
    }

    private String getProgramName(OneSearchAssessmentItems[] assessmentItems) {
        return Arrays.stream(assessmentItems)
                .filter(item -> item.getProgram() != null)
                .findAny()
                .map(item -> item.getProgram())
                .orElse(null);
    }

    private String getDisciplineName(OneSearchAssessmentItems[] assessmentItems) {
        return Arrays.stream(assessmentItems)
                .filter(item -> item.getDiscipline() != null)
                .findAny()
                .map(item -> item.getDiscipline())
                .orElse(null);
    }

    private void dispatchAssignmentEventInfo(AssignmentEventInfo assignmentEventInfo) {
        Boolean success = sendAssignmentEventInfoToScoringService(assignmentEventInfo);
        sendAssignmentEventInfoToReportingService(assignmentEventInfo);

        if (!success) {
            throw new RuntimeException(String.format("Post to Scoring , Program Id : %s, Activity %s",
                    assignmentEventInfo.getProgramId(), assignmentEventInfo.getActivityId()));
        }
    }

    private void dispatchTestEventInfo(TestEventInfo testEventInfo) {
        reportingService.publishTestEventDetails(testEventInfo);
    }

    private boolean sendAssignmentEventInfoToScoringService(AssignmentEventInfo assignmentEventInfo) {
        Boolean success = false;

        try{
            ScoreEventResponseInfo response = scoringService.postEventDetails(assignmentEventInfo);
            success = response != null;
        }catch(Exception ex){
            logger.error("Post to Scoring , Program Id {} for Activity {}",
                    assignmentEventInfo.getProgramId(), assignmentEventInfo.getActivityId());
        }

        return success;
    }

    private void sendAssignmentEventInfoToReportingService(AssignmentEventInfo assignmentEventInfo) {
        reportingService.publishAssignmentEventDetails(assignmentEventInfo);
    }

    private boolean isFormativeAssessmentOrProductEdEvent(EventDetailsRequest event) {
        return SourceObjectTypeUtil.isFormative(event.getSourceObjectType())
                || SourceObjectTypeUtil.isProductType(event.getSourceObjectType());
    }

    private boolean isBenchmarkAssessmentEvent(EventDetailsRequest event) {
        return SourceObjectTypeUtil.isBenchmark(event.getSourceObjectType());
    }
}
