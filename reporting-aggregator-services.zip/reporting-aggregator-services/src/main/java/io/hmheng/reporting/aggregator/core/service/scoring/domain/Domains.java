package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

/**
 * Created by suryadevarap on 4/4/18.
 */
public class Domains {

  private UUID domainId;
  private String description;
  private String name;

  public UUID getDomainId() {
    return domainId;
  }

  public void setDomainId(UUID domainId) {
    this.domainId = domainId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
