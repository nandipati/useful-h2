package io.hmheng.reporting.aggregator.core.service.learnosity.domain;


import java.util.List;

/**
 * Created by pabonaj on 10/7/16.
 */
public class SessionsResponsesResponse {

    private List<SessionResponse> data;

    private Meta meta;

    public List<SessionResponse> getData ()
    {
        return data;
    }

    public void setData (List<SessionResponse> data)
    {
        this.data = data;
    }

    public Meta getMeta ()
    {
        return meta;
    }

    public void setMeta (Meta meta)
    {
        this.meta = meta;
    }

}
