package io.hmheng.reporting.aggregator.core.service.assignment;

import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.assignments.domain.StudentAssignmentsResponse;
import io.hmheng.reporting.aggregator.core.service.clm.domain.District;
import io.hmheng.reporting.aggregator.core.service.clm.domain.School;
import io.hmheng.reporting.aggregator.utils.AttributeHelper;
import io.hmheng.reporting.aggregator.utils.ExchangeUtils;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TESTING_EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ASSIGNMENT_STATUS_HEADER;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;

/**
 * Created by jayachandranj on 2/27/17.
 */
@Component
public class AssignmentRouteBuilder extends RouteBuilder {

    public static final String testEventClosedStudentAssignmentsRouteId = "testEventClosedStudentAssignmentsRoute";

    @Value("${assignments.host.baseUrl}")
    private String assignmentsHost;

    public static final String getTestEventClosedStudentAssignmentsEndpoint = "direct://getTestEventClosedStudentAssignments";



    @Override
    public void configure() throws Exception {

       configureTestEventStudentAssignments(
                getTestEventClosedStudentAssignmentsEndpoint,
                testEventClosedStudentAssignmentsRouteId,
                String.format("/v2/testingEvents/${header.%s}/studentAssignments?status=${header.%s}", TESTING_EVENT_REFID, ASSIGNMENT_STATUS_HEADER),
                StudentAssignmentsResponse.class);
    }



    private void configureTestEventStudentAssignments(String endpointUri, String endpointId, String url, Class<?> responseClass) {
        from(endpointUri).id(endpointId)
                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.GET))
                .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .setHeader(CORRELATION_ID, simple("${header." + CORRELATION_ID + "}"))
                .recipientList(simple(assignmentsHost + url))
                .unmarshal(configureDataFormat(responseClass))
                .end();
    }

    private JacksonDataFormat configureDataFormat(Class<?> clazz) {
        JacksonDataFormat dataFormat = new JacksonDataFormat(clazz);
        dataFormat.disableFeature(FAIL_ON_UNKNOWN_PROPERTIES);
        return dataFormat;
    }

}
