package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

/**
 * Created by suryadevarap on 4/4/18.
 */
public class StandardSession {

  private UUID studentPersonId;
  private UUID sessionId;
  private UUID activityId;
  private TestType testType;
  @JsonProperty(value = "standards")
  private List<StandardScores> standards;
  @JsonProperty(value = "itemToStandardMapping")
  private List<ItemToStandardMap> itemToStandardMap;
  @JsonProperty(value = "domains")
  private Set<Domains> domains;


  public UUID getStudentPersonId() {
    return studentPersonId;
  }

  public void setStudentPersonId(UUID studentPersonId) {
    this.studentPersonId = studentPersonId;
  }

  public UUID getSessionId() {
    return sessionId;
  }

  public void setSessionId(UUID sessionId) {
    this.sessionId = sessionId;
  }

  public UUID getActivityId() {
    return activityId;
  }

  public TestType getTestType() {
    return testType;
  }

  public void setTestType(TestType testType) {
    this.testType = testType;
  }

  public void setActivityId(UUID activityId) {
    this.activityId = activityId;
  }

  public List<StandardScores> getStandards() {
    return standards;
  }

  public void setStandards(List<StandardScores> standards) {
    this.standards = standards;
  }

  public List<ItemToStandardMap> getItemToStandardMap() {
    return itemToStandardMap;
  }

  public void setItemToStandardMap(List<ItemToStandardMap> itemToStandardMap) {
    this.itemToStandardMap = itemToStandardMap;
  }

  public Set<Domains> getDomains() {
    return domains;
  }

  public void setDomains(Set<Domains> domains) {
    this.domains = domains;
  }

  @Override
  public String toString() {
    return "StandardSession{" +
        "studentPersonId=" + studentPersonId +
        ", sessionId=" + sessionId +
        ", activityId=" + activityId +
        ", standards=" + standards +
        ", itemToStandardMap=" + itemToStandardMap +
        ", domains=" + domains +
        '}';
  }
}
