package io.hmheng.reporting.aggregator.core.service.reporting.domain;


import java.util.List;

public class TotalScore {

    private String totalScoreType;
    private String totalSlot;
    private int totalOrder;
    private String totalName;
    private String totalAbbr;
    private Double totalAbilityEstimate;
    private Double totalStandardError;
    private String totalAchievementLevel;
    private Integer totalNumberAttempted;
    private Integer totalNumberQuestions;
    private boolean skippedQuestions;
    private boolean itemsOmitted;
    private boolean completionCriteriaNotMet;
    private boolean inCompleteTestRecord;
    private Integer totalMaxScore;
    private Integer totalScore;
    private Double totalScaleScore;
    private Double totalLpr;
    private Double totalIpFloor;
    private Double totalIpCeil;
    private Double totalCompletionCriteriaPercentage;
    private Boolean totalCompletionCriteria;
    private Double pssLowerLimit;
    private Double pssUpperLimit;
    private Double pnprLowerLimit;
    private Double pnprUpperLimit;
    private String lowerLimitLexile;
    private String upperLimitLexile;
    private String collegeReadiness;

    private List<Subscore> studentSubScores;


    public String getTotalScoreType() {
        return totalScoreType;
    }

    public void setTotalScoreType(String totalScoreType) {
        this.totalScoreType = totalScoreType;
    }

    public String getTotalSlot() {
        return totalSlot;
    }

    public void setTotalSlot(String totalSlot) {
        this.totalSlot = totalSlot;
    }

    public int getTotalOrder() {
        return totalOrder;
    }

    public void setTotalOrder(int totalOrder) {
        this.totalOrder = totalOrder;
    }

    public String getTotalName() {
        return totalName;
    }

    public void setTotalName(String totalName) {
        this.totalName = totalName;
    }

    public String getTotalAbbr() {
        return totalAbbr;
    }

    public void setTotalAbbr(String totalAbbr) {
        this.totalAbbr = totalAbbr;
    }

    public Double getTotalLpr() {
        return totalLpr;
    }

    public void setTotalLpr(Double totalLpr) {
        this.totalLpr = totalLpr;
    }

    public Double getTotalAbilityEstimate() {
        return totalAbilityEstimate;
    }

    public void setTotalAbilityEstimate(Double totalAbilityEstimate) {
        this.totalAbilityEstimate = totalAbilityEstimate;
    }

    public Double getTotalStandardError() {
        return totalStandardError;
    }

    public void setTotalStandardError(Double totalStandardError) {
        this.totalStandardError = totalStandardError;
    }

    public String getTotalAchievementLevel() {
        return totalAchievementLevel;
    }

    public void setTotalAchievementLevel(String totalAchievementLevel) {
        this.totalAchievementLevel = totalAchievementLevel;
    }

    public Integer getTotalNumberAttempted() {
        return totalNumberAttempted;
    }

    public void setTotalNumberAttempted(Integer totalNumberAttempted) {
        this.totalNumberAttempted = totalNumberAttempted;
    }

    public Integer getTotalNumberQuestions() {
        return totalNumberQuestions;
    }

    public void setTotalNumberQuestions(Integer totalNumberQuestions) {
        this.totalNumberQuestions = totalNumberQuestions;
    }

  public boolean isSkippedQuestions() {
    return skippedQuestions;
  }

  public void setSkippedQuestions(boolean skippedQuestions) {
    this.skippedQuestions = skippedQuestions;
  }

  public Integer getTotalMaxScore() {
        return totalMaxScore;
    }

    public void setTotalMaxScore(Integer totalMaxScore) {
        this.totalMaxScore = totalMaxScore;
    }

    public Integer getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(Integer totalScore) {
        this.totalScore = totalScore;
    }

    public Double getTotalScaleScore() {
        return totalScaleScore;
    }

    public void setTotalScaleScore(Double totalScaleScore) {
        this.totalScaleScore = totalScaleScore;
    }

    public Double getTotalIpFloor() {
        return totalIpFloor;
    }

    public void setTotalIpFloor(Double totalIpFloor) {
        this.totalIpFloor = totalIpFloor;
    }

    public Double getTotalIpCeil() {
        return totalIpCeil;
    }

    public void setTotalIpCeil(Double totalIpCeil) {
        this.totalIpCeil = totalIpCeil;
    }

    public Double getTotalCompletionCriteriaPercentage() {
        return totalCompletionCriteriaPercentage;
    }

    public void setTotalCompletionCriteriaPercentage(Double totalCompletionCriteriaPercentage) {
        this.totalCompletionCriteriaPercentage = totalCompletionCriteriaPercentage;
    }

    public Boolean getTotalCompletionCriteria() {
        return totalCompletionCriteria;
    }

    public void setTotalCompletionCriteria(Boolean totalCompletionCriteria) {
        this.totalCompletionCriteria = totalCompletionCriteria;
    }

    public Double getPssLowerLimit() {
        return pssLowerLimit;
    }

    public void setPssLowerLimit(Double pssLowerLimit) {
        this.pssLowerLimit = pssLowerLimit;
    }

    public Double getPssUpperLimit() {
        return pssUpperLimit;
    }

    public void setPssUpperLimit(Double pssUpperLimit) {
        this.pssUpperLimit = pssUpperLimit;
    }

    public Double getPnprLowerLimit() {
        return pnprLowerLimit;
    }

    public void setPnprLowerLimit(Double pnprLowerLimit) {
        this.pnprLowerLimit = pnprLowerLimit;
    }

    public Double getPnprUpperLimit() {
        return pnprUpperLimit;
    }

    public void setPnprUpperLimit(Double pnprUpperLimit) {
        this.pnprUpperLimit = pnprUpperLimit;
    }

    public String getLowerLimitLexile() {
        return lowerLimitLexile;
    }

    public void setLowerLimitLexile(String lowerLimitLexile) {
        this.lowerLimitLexile = lowerLimitLexile;
    }

    public String getUpperLimitLexile() {
        return upperLimitLexile;
    }

    public void setUpperLimitLexile(String upperLimitLexile) {
        this.upperLimitLexile = upperLimitLexile;
    }

    public String getCollegeReadiness() {
        return collegeReadiness;
    }

    public void setCollegeReadiness(String collegeReadiness) {
        this.collegeReadiness = collegeReadiness;
    }

    public List<Subscore> getStudentSubScores() {
        return studentSubScores;
    }

    public void setStudentSubScores(List<Subscore> studentSubScores) {
        this.studentSubScores = studentSubScores;
    }

    public boolean isItemsOmitted() {
        return itemsOmitted;
    }

    public void setItemsOmitted(boolean itemsOmitted) {
        this.itemsOmitted = itemsOmitted;
    }

    public boolean isCompletionCriteriaNotMet() {
        return completionCriteriaNotMet;
    }

    public void setCompletionCriteriaNotMet(boolean completionCriteriaNotMet) {
        this.completionCriteriaNotMet = completionCriteriaNotMet;
    }

    public boolean isInCompleteTestRecord() {
        return inCompleteTestRecord;
    }

    public void setInCompleteTestRecord(boolean inCompleteTestRecord) {
        this.inCompleteTestRecord = inCompleteTestRecord;
    }

    @Override
    public String toString() {
        return "TotalScore{" +
            "totalScoreType='" + totalScoreType + '\'' +
            ", totalSlot='" + totalSlot + '\'' +
            ", totalOrder=" + totalOrder +
            ", totalName='" + totalName + '\'' +
            ", totalAbbr='" + totalAbbr + '\'' +
            ", totalAbilityEstimate=" + totalAbilityEstimate +
            ", totalStandardError=" + totalStandardError +
            ", totalAchievementLevel='" + totalAchievementLevel + '\'' +
            ", totalNumberAttempted=" + totalNumberAttempted +
            ", totalNumberQuestions=" + totalNumberQuestions +
            ", totalMaxScore=" + totalMaxScore +
            ", totalScore=" + totalScore +
            ", totalScaleScore=" + totalScaleScore +
            ", totalLpr=" + totalLpr +
            ", totalIpFloor=" + totalIpFloor +
            ", totalIpCeil=" + totalIpCeil +
            ", totalCompletionCriteriaPercentage=" + totalCompletionCriteriaPercentage +
            ", totalCompletionCriteria=" + totalCompletionCriteria +
            ", pssLowerLimit=" + pssLowerLimit +
            ", pssUpperLimit=" + pssUpperLimit +
            ", pnprLowerLimit=" + pnprLowerLimit +
            ", pnprUpperLimit=" + pnprUpperLimit +
            ", lowerLimitLexile=" + lowerLimitLexile +
            ", upperLimitLexile=" + upperLimitLexile +
            ", collegeReadiness=" + collegeReadiness +
            ", studentSubScores=" + studentSubScores +
            '}';
    }
}
