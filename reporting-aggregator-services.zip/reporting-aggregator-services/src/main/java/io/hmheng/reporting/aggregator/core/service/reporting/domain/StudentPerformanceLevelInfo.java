package io.hmheng.reporting.aggregator.core.service.reporting.domain;

public class StudentPerformanceLevelInfo {

    private Integer studentIncludedCount;
    private Integer advancedStudentCount;
    private Integer proficientStudentCount;
    private Integer basicStudentCount;
    private Integer belowBasicStudentCount;
    private Integer farBelowBasicStudentCount;
    private Double  advancedStudentPercentage;
    private Double  proficientStudentPercentage;
    private Double  basicStudentPercentage;
    private Double  belowBasicStudentPercentage;
    private Double  farBelowBasicStudentPercentage;


    public StudentPerformanceLevelInfo() {
        studentIncludedCount = 0;
        advancedStudentCount = 0;
        proficientStudentCount = 0;
        basicStudentCount = 0;
        belowBasicStudentCount = 0;
        farBelowBasicStudentCount = 0;
        advancedStudentPercentage = 0.0;
        proficientStudentPercentage = 0.0;
        basicStudentPercentage = 0.0;
        belowBasicStudentPercentage = 0.0;
        farBelowBasicStudentPercentage = 0.0;
    }

    public Integer getStudentIncludedCount() {
        return studentIncludedCount;
    }

    public void setStudentIncludedCount(Integer studentIncludedCount) {
        this.studentIncludedCount = studentIncludedCount;
    }

    public void incrementAdvancedStudentCount() {
        advancedStudentCount++;
    }

    public void incrementProficientStudentCount() {
        proficientStudentCount++;
    }

    public void incrementBasicStudentCount() {
        basicStudentCount++;
    }

    public void incrementBelowBasicStudentCount() {
        belowBasicStudentCount++;
    }

    public void incrementFarBelowBasicStudentCount() {
        farBelowBasicStudentCount++;
    }

    public void updateStudentPercentages(Integer studentCount) {
        studentIncludedCount = studentCount;
        if(isValidStudentCount(advancedStudentCount , studentCount)) {
            advancedStudentPercentage = (double) advancedStudentCount / studentCount;
        }
        if(isValidStudentCount(proficientStudentCount, studentCount)) {
            proficientStudentPercentage = (double) proficientStudentCount / studentCount;
        }
        if(isValidStudentCount(basicStudentCount, studentCount)) {
            basicStudentPercentage = (double) basicStudentCount / studentCount;
        }
        if(isValidStudentCount(belowBasicStudentCount , studentCount)) {
            belowBasicStudentPercentage = (double) belowBasicStudentCount / studentCount;
        }
        if(isValidStudentCount(farBelowBasicStudentCount, studentCount)) {
            farBelowBasicStudentPercentage = (double) farBelowBasicStudentCount / studentCount;
        }
    }

    private Boolean isValidStudentCount(Integer performanceLevelStudentCount , Integer studentcount){

        return (performanceLevelStudentCount > 0 && studentcount > 0);
    }

    public Integer getAdvancedStudentCount() {
        return advancedStudentCount;
    }

    public void setAdvancedStudentCount(Integer advancedStudentCount) {
        this.advancedStudentCount = advancedStudentCount;
    }

    public Integer getProficientStudentCount() {
        return proficientStudentCount;
    }

    public void setProficientStudentCount(Integer proficientStudentCount) {
        this.proficientStudentCount = proficientStudentCount;
    }

    public Integer getBasicStudentCount() {
        return basicStudentCount;
    }

    public void setBasicStudentCount(Integer basicStudentCount) {
        this.basicStudentCount = basicStudentCount;
    }

    public Integer getBelowBasicStudentCount() {
        return belowBasicStudentCount;
    }

    public void setBelowBasicStudentCount(Integer belowBasicStudentCount) {
        this.belowBasicStudentCount = belowBasicStudentCount;
    }

    public Integer getFarBelowBasicStudentCount() {
        return farBelowBasicStudentCount;
    }

    public void setFarBelowBasicStudentCount(Integer farBelowBasicStudentCount) {
        this.farBelowBasicStudentCount = farBelowBasicStudentCount;
    }

    public Double getAdvancedStudentPercentage() {
        return advancedStudentPercentage;
    }

    public void setAdvancedStudentPercentage(Double advancedStudentPercentage) {
        this.advancedStudentPercentage = advancedStudentPercentage;
    }

    public Double getProficientStudentPercentage() {
        return proficientStudentPercentage;
    }

    public void setProficientStudentPercentage(Double proficientStudentPercentage) {
        this.proficientStudentPercentage = proficientStudentPercentage;
    }

    public Double getBasicStudentPercentage() {
        return basicStudentPercentage;
    }

    public void setBasicStudentPercentage(Double basicStudentPercentage) {
        this.basicStudentPercentage = basicStudentPercentage;
    }

    public Double getBelowBasicStudentPercentage() {
        return belowBasicStudentPercentage;
    }

    public void setBelowBasicStudentPercentage(Double belowBasicStudentPercentage) {
        this.belowBasicStudentPercentage = belowBasicStudentPercentage;
    }

    public Double getFarBelowBasicStudentPercentage() {
        return farBelowBasicStudentPercentage;
    }

    public void setFarBelowBasicStudentPercentage(Double farBelowBasicStudentPercentage) {
        this.farBelowBasicStudentPercentage = farBelowBasicStudentPercentage;
    }
}
