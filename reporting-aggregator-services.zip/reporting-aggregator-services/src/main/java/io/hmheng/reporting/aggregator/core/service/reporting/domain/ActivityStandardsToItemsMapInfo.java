package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.Domains;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.util.List;
import java.util.Set;

/**
 * Created by nandipatim on 3/17/16.
 */
public class ActivityStandardsToItemsMapInfo {

    private TestType testType;

    private List<ActivityStandardsPerformance> standards;
     private Set<Domains> domainStandards;

    public List<ActivityStandardsPerformance> getStandards() {
        return standards;
    }

    public void setStandards(List<ActivityStandardsPerformance> standards) {
        this.standards = standards;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public Set<Domains> getDomainStandards() {
        return domainStandards;
    }

    public void setDomainStandards(Set<Domains> domainStandards) {
        this.domainStandards = domainStandards;
    }
}
