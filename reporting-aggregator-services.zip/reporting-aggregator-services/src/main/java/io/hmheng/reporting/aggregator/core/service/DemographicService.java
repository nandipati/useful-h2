package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.arg.DemographicRequest;

public interface DemographicService {

    void handleDemographic(DemographicRequest demographicRequest);
}
