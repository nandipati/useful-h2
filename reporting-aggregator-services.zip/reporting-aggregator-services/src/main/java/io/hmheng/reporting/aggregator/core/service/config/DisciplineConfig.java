package io.hmheng.reporting.aggregator.core.service.config;

import org.apache.commons.collections.map.CaseInsensitiveMap;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@ConfigurationProperties("discipline")
public class DisciplineConfig {
  Map<String, String> map = new CaseInsensitiveMap();

  public Map<String, String> getMap() {
    return map;
  }
}