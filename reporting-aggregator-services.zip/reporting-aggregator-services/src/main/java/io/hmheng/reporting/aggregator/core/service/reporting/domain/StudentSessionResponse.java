package io.hmheng.reporting.aggregator.core.service.reporting.domain;

/**
 * Created by pabonaj on 10/11/16.
 */
public class StudentSessionResponse {

    public StudentSessions getStudentSessions() {
        return studentSessions;
    }

    public void setStudentSessions(StudentSessions studentSessions) {
        this.studentSessions = studentSessions;
    }

    private StudentSessions studentSessions;

}