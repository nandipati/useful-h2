package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.UUID;

public class StaffPerson {
    
    private UUID refId;
    private Name name;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }
    
    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "StaffPerson{" +
            "refId=" + refId +
            ", name='" + name + '\'' +
            '}';
    }
    
    public static class Name {
        
        private NameOfRecord nameOfRecord;

        public NameOfRecord getNameOfRecord() {
            return nameOfRecord;
        }

        public void setNameOfRecord(NameOfRecord nameOfRecord) {
            this.nameOfRecord = nameOfRecord;
        }
        
    }
    
    public static class NameOfRecord {
        
        private String familyName;
        private String givenName;
        private String middleName;

        public String getFamilyName() {
            return familyName;
        }

        public void setFamilyName(String familyName) {
            this.familyName = familyName;
        }

        public String getGivenName() {
            return givenName;
        }

        public void setGivenName(String givenName) {
            this.givenName = givenName;
        }

        public String getMiddleName() {
            return middleName;
        }

        public void setMiddleName(String middleName) {
            this.middleName = middleName;
        }
        
    }
    
}
