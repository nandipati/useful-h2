package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.hmheng.reporting.aggregator.utils.JsonCommons;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by mfeng on 10/19/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventSessionView {

    private UUID sessionId;
    private UUID activityId;
    private String eventType;
    @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
    @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
    private LocalDateTime availableDate;
    @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
    @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
    private LocalDateTime dueDate;
    private boolean manualScoringRequired;
    private String resourceId;
    private UUID staffPersonalRefId;
    private String studentPersonRefId;
    private String status;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public LocalDateTime getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(LocalDateTime availableDate) {
        this.availableDate = availableDate;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public boolean isManualScoringRequired() {
        return manualScoringRequired;
    }

    public void setManualScoringRequired(boolean manualScoringRequired) {
        this.manualScoringRequired = manualScoringRequired;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    public String getStudentPersonRefId() {
        return studentPersonRefId;
    }

    public void setStudentPersonRefId(String studentPersonRefId) {
        this.studentPersonRefId = studentPersonRefId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
