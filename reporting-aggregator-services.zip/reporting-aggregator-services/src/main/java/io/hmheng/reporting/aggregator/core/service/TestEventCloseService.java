package io.hmheng.reporting.aggregator.core.service;


import io.hmheng.reporting.aggregator.core.service.arg.TestEventCloseRequest;

import java.util.UUID;

public interface TestEventCloseService {

    void handleTestEventClose(TestEventCloseRequest request);
    void handleTestEventReopenScores(UUID testEventId, UUID activityId);
}
