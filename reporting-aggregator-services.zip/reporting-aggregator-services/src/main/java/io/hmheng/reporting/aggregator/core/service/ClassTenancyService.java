package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.arg.ClassTenancyRequest;

public interface ClassTenancyService {

    void handleClassTenancy(ClassTenancyRequest request);

}
