package io.hmheng.reporting.aggregator.core.service.scoring.domain;

/**
 * Created by nandipatim on 4/7/17.
 */
public enum ScoringSource {
  LEARNOSITY;
}
