package io.hmheng.reporting.aggregator.core.service.mds.domains;

import java.util.List;

/**
 * Created by nandipatim on 3/15/16.
 */
public class ItemsExternalRefIdResponse {

    private List<Result> results;

    private Facets facets;

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

    public Facets getFacets() {
        return facets;
    }

    public void setFacets(Facets facets) {
        this.facets = facets;
    }

    public static class Facets{

        private BloomTaxonomy bloomTaxonomy;

        private CognitiveDifficulty cognitiveDifficulty;

        private QuestionType type;

        private DepthOfKnowledge depthOfKnowledge;

        public BloomTaxonomy getBloomTaxonomy() {
            return bloomTaxonomy;
        }

        public void setBloomTaxonomy(BloomTaxonomy bloomTaxonomy) {
            this.bloomTaxonomy = bloomTaxonomy;
        }

        public CognitiveDifficulty getCognitiveDifficulty() {
            return cognitiveDifficulty;
        }

        public void setCognitiveDifficulty(CognitiveDifficulty cognitiveDifficulty) {
            this.cognitiveDifficulty = cognitiveDifficulty;
        }

        public QuestionType getType() {
            return type;
        }

        public void setType(QuestionType type) {
            this.type = type;
        }

        public DepthOfKnowledge getDepthOfKnowledge() {
          return depthOfKnowledge;
        }

        public void setDepthOfKnowledge(DepthOfKnowledge depthOfKnowledge) {
        this.depthOfKnowledge = depthOfKnowledge;
        }
    }

    public static class CognitiveDifficulty{
        String type;
        List<FacetValues> facetValues;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public List<FacetValues> getFacetValues() {
            return facetValues;
        }

        public void setFacetValues(List<FacetValues> facetValues) {
            this.facetValues = facetValues;
        }
    }
    public static class BloomTaxonomy{
        String type;
        List<FacetValues> facetValues;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public List<FacetValues> getFacetValues() {
            return facetValues;
        }

        public void setFacetValues(List<FacetValues> facetValues) {
            this.facetValues = facetValues;
        }
    }

    public static class QuestionType {
        String type;
        List<FacetValues> facetValues;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public List<FacetValues> getFacetValues() {
            return facetValues;
        }

        public void setFacetValues(List<FacetValues> facetValues) {
            this.facetValues = facetValues;
        }
    }

    public static class DepthOfKnowledge {
      String type;
      List<FacetValues> facetValues;

      public String getType() {
        return type;
      }

      public void setType(String type) {
        this.type = type;
      }

      public List<FacetValues> getFacetValues() {
        return facetValues;
      }

      public void setFacetValues(List<FacetValues> facetValues) {
        this.facetValues = facetValues;
      }
    }

    public static class FacetValues{
        String name;
        Integer count;
        String value;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    @Override
    public String toString() {
        return "{" +
                "results=" + results +
                ", facets=" + facets +
                "}";
    }
}
