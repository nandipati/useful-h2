package io.hmheng.reporting.aggregator.core.service.scoring.domain;


import java.util.List;
import java.util.UUID;

public class BenchmarkActivityScoresResponse {

    private UUID activityId;
    private Sessions sessions;

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public Sessions getSessions() {
        return sessions;
    }

    public void setSessions(Sessions sessions) {
        this.sessions = sessions;
    }

    @Override
    public String toString() {
        return  "BenchmarkActivityScoresResponse [activityId=" + activityId + ", sessions= " + sessions+ "]";
    }
}
