package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.List;

public class StudentSectionAssociationResponse {

    private List<StudentSectionAssociation> studentSectionAssociations;

    public List<StudentSectionAssociation> getStudentSectionAssociations() {
        return studentSectionAssociations;
    }

    public void setStudentSectionAssociations(List<StudentSectionAssociation> studentSectionAssociations) {
        this.studentSectionAssociations = studentSectionAssociations;
    }

    @Override
    public String toString() {
        return "StudentSectionAssociationResponse{" +
            "studentSectionAssociations=" + studentSectionAssociations +
            '}';
    }
    
}
