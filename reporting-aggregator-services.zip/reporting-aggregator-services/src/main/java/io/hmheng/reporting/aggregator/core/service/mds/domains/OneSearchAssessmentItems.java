package io.hmheng.reporting.aggregator.core.service.mds.domains;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Arrays;

public class OneSearchAssessmentItems
{
  private String title;

  private String lastModified;

  private String manuallyScorable;

  private String userId;

  private String ageRange;

  private String itemCount;

  private String discipline;
  @JsonProperty(value = "item")
  private OneSearchItems[] oneSearchItems;

  private String identifier;

  private String program;

  private String poolId;

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getManuallyScorable() {
    return manuallyScorable;
  }

  public void setManuallyScorable(String manuallyScorable) {
    this.manuallyScorable = manuallyScorable;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getAgeRange() {
    return ageRange;
  }

  public void setAgeRange(String ageRange) {
    this.ageRange = ageRange;
  }

  public String getItemCount() {
    return itemCount;
  }

  public void setItemCount(String itemCount) {
    this.itemCount = itemCount;
  }

  public String getDiscipline() {
    return discipline;
  }

  public void setDiscipline(String discipline) {
    this.discipline = discipline;
  }

  public OneSearchItems[] getOneSearchItems() {
    return oneSearchItems;
  }

  public void setOneSearchItems(OneSearchItems[] oneSearchItems) {
    this.oneSearchItems = oneSearchItems;
  }

  public String getIdentifier() {
    return identifier;
  }

  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  public String getProgram() {
    return program;
  }

  public void setProgram(String program) {
    this.program = program;
  }

  public String getPoolId() {
    return poolId;
  }

  public void setPoolId(String poolId) {
    this.poolId = poolId;
  }

  @Override
  public String toString() {
    return "OneSearchAssessmentItems{" +
        "title='" + title + '\'' +
        ", lastModified='" + lastModified + '\'' +
        ", manuallyScorable='" + manuallyScorable + '\'' +
        ", userId='" + userId + '\'' +
        ", ageRange='" + ageRange + '\'' +
        ", itemCount='" + itemCount + '\'' +
        ", discipline='" + discipline + '\'' +
        ", oneSearchItems=" + Arrays.toString(oneSearchItems) +
        ", identifier='" + identifier + '\'' +
        ", program='" + program + '\'' +
        ", poolId='" + poolId + '\'' +
        '}';
  }
}
