package io.hmheng.reporting.aggregator.core.service.reporting.domain;


import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.UUID;

public class StudentInfo {


    private UUID studentPersonalRefId;
    private UUID sessionId;
    private UUID groupId;

    public UUID getStudentPersonalRefId() {
        return studentPersonalRefId;
    }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) {
        this.studentPersonalRefId = studentPersonalRefId;
    }

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public UUID getGroupId() {
        return groupId;
    }

    public void setGroupId(UUID groupId) {
        this.groupId = groupId;
    }
}
