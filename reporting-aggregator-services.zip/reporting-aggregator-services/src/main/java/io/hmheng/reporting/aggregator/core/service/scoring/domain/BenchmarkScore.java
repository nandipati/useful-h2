package io.hmheng.reporting.aggregator.core.service.scoring.domain;


import java.util.UUID;

public class BenchmarkScore {

    private UUID sessionId;
    private String scoreType;
    private String slot;
    private int order;
    private String name;
    private String abbr;
    private Double abilityEstimate;
    private Double standardError;
    private String achievementLevel;
    private Integer numberAttempted;
    private Integer numberQuestions;
    private Boolean skippedQuestions;
    private Integer maxScore;
    private Integer score;
    private Double scaleScore;
    private Double lpr;
    private Double ipFloor;
    private Double ipCeil;
    private Double completionCriteriaPercentage;
    private Boolean completionCriteria;
    private Double lowerLimitPss;
    private Double upperLimitPss;
    private Double lowerLimitPnpr;
    private Double upperLimitPnpr;
    private String lowerLimitLexile;
    private String upperLimitLexile;
    private String collegeReadiness;
    private Boolean itemsOmitted;
    private Boolean completionCriteriaNotMet;
    private Boolean inCompleteTestRecord;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public String getScoreType() {
        return scoreType;
    }

    public void setScoreType(String scoreType) {
        this.scoreType = scoreType;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbr() {
        return abbr;
    }

    public void setAbbr(String abbr) {
        this.abbr = abbr;
    }

    public Double getAbilityEstimate() {
        return abilityEstimate;
    }

    public void setAbilityEstimate(Double abilityEstimate) {
        this.abilityEstimate = abilityEstimate;
    }

    public Double getStandardError() {
        return standardError;
    }

    public void setStandardError(Double standardError) {
        this.standardError = standardError;
    }

    public String getAchievementLevel() {
        return achievementLevel;
    }

    public void setAchievementLevel(String achievementLevel) {
        this.achievementLevel = achievementLevel;
    }

    public Integer getNumberAttempted() {
        return numberAttempted;
    }

    public void setNumberAttempted(Integer numberAttempted) {
        this.numberAttempted = numberAttempted;
    }

    public Integer getNumberQuestions() {
        return numberQuestions;
    }

    public void setNumberQuestions(Integer numberQuestions) {
        this.numberQuestions = numberQuestions;
    }

    public Boolean getSkippedQuestions() {
      return skippedQuestions;
    }

    public void setSkippedQuestions(Boolean skippedQuestions) {
      this.skippedQuestions = skippedQuestions;
    }

  public Integer getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(Integer maxScore) {
        this.maxScore = maxScore;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Double getScaleScore() {
        return scaleScore;
    }

    public void setScaleScore(Double scaleScore) {
        this.scaleScore = scaleScore;
    }

    public Double getLpr() {
        return lpr;
    }

    public void setLpr(Double lpr) {
        this.lpr = lpr;
    }

    public Double getIpFloor() {
        return ipFloor;
    }

    public void setIpFloor(Double ipFloor) {
        this.ipFloor = ipFloor;
    }

    public Double getIpCeil() {
        return ipCeil;
    }

    public void setIpCeil(Double ipCeil) {
        this.ipCeil = ipCeil;
    }

    public Double getCompletionCriteriaPercentage() {
        return completionCriteriaPercentage;
    }

    public void setCompletionCriteriaPercentage(Double completionCriteriaPercentage) {
        this.completionCriteriaPercentage = completionCriteriaPercentage;
    }

    public Boolean getCompletionCriteria() {
        return completionCriteria;
    }

    public void setCompletionCriteria(Boolean completionCriteria) {
        this.completionCriteria = completionCriteria;
    }

    public Double getLowerLimitPss() {
        return lowerLimitPss;
    }

    public void setLowerLimitPss(Double lowerLimitPss) {
        this.lowerLimitPss = lowerLimitPss;
    }

    public Double getUpperLimitPss() {
        return upperLimitPss;
    }

    public void setUpperLimitPss(Double upperLimitPss) {
        this.upperLimitPss = upperLimitPss;
    }

    public Double getLowerLimitPnpr() {
        return lowerLimitPnpr;
    }

    public void setLowerLimitPnpr(Double lowerLimitPnpr) {
        this.lowerLimitPnpr = lowerLimitPnpr;
    }

    public Double getUpperLimitPnpr() {
        return upperLimitPnpr;
    }

    public void setUpperLimitPnpr(Double upperLimitPnpr) {
        this.upperLimitPnpr = upperLimitPnpr;
    }

    public String getLowerLimitLexile() {
        return lowerLimitLexile;
    }

    public void setLowerLimitLexile(String lowerLimitLexile) {
        this.lowerLimitLexile = lowerLimitLexile;
    }

    public String getUpperLimitLexile() {
        return upperLimitLexile;
    }

    public void setUpperLimitLexile(String upperLimitLexile) {
        this.upperLimitLexile = upperLimitLexile;
    }

    public String getCollegeReadiness() {
        return collegeReadiness;
    }

    public void setCollegeReadiness(String collegeReadiness) {
        this.collegeReadiness = collegeReadiness;
    }

    public Boolean getItemsOmitted() {
        return itemsOmitted;
    }

    public void setItemsOmitted(Boolean itemsOmitted) {
        this.itemsOmitted = itemsOmitted;
    }

    public Boolean getCompletionCriteriaNotMet() {
        return completionCriteriaNotMet;
    }

    public void setCompletionCriteriaNotMet(Boolean completionCriteriaNotMet) {
        this.completionCriteriaNotMet = completionCriteriaNotMet;
    }

    public Boolean getInCompleteTestRecord() {
        return inCompleteTestRecord;
    }

    public void setInCompleteTestRecord(Boolean inCompleteTestRecord) {
        this.inCompleteTestRecord = inCompleteTestRecord;
    }

    @Override
    public String toString() {
        return "BenchmarkScore{" +
                "sessionId=" + sessionId +
                ", scoreType='" + scoreType + '\'' +
                ", slot='" + slot + '\'' +
                ", order=" + order +
                ", name='" + name + '\'' +
                ", abbr='" + abbr + '\'' +
                ", abilityEstimate=" + abilityEstimate +
                ", standardError=" + standardError +
                ", achievementLevel='" + achievementLevel + '\'' +
                ", numberAttempted=" + numberAttempted +
                ", numberQuestions=" + numberQuestions +
                ", skippedQuestions=" + skippedQuestions +
                ", maxScore=" + maxScore +
                ", score=" + score +
                ", scaleScore=" + scaleScore +
                ", lpr=" + lpr +
                ", ipFloor=" + ipFloor +
                ", ipCeil=" + ipCeil +
                ", completionCriteriaPercentage=" + completionCriteriaPercentage +
                ", completionCriteria=" + completionCriteria +
                ", lowerLimitPss=" + lowerLimitPss +
                ", upperLimitPss=" + upperLimitPss +
                ", lowerLimitPnpr=" + lowerLimitPnpr +
                ", upperLimitPnpr=" + upperLimitPnpr +
                ", lowerLimitLexile='" + lowerLimitLexile + '\'' +
                ", upperLimitLexile='" + upperLimitLexile + '\'' +
                ", collegeReadiness='" + collegeReadiness + '\'' +
                ", itemsOmitted=" + itemsOmitted +
                ", completionCriteriaNotMet=" + completionCriteriaNotMet +
                ", inCompleteTestRecord=" + inCompleteTestRecord +
                '}';
    }
}
