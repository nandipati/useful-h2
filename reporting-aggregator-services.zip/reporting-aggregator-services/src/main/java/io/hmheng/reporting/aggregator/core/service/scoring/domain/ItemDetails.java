package io.hmheng.reporting.aggregator.core.service.scoring.domain;

/**
 * Created by suryadevarap on 4/4/18.
 */
public class ItemDetails {

  private String itemRefId;

  private String itemName;

  private String itemPosition;

  private String depthOfKnowledge;

  private String manuallyScorable;

  public String getItemRefId() {
    return itemRefId;
  }

  public void setItemRefId(String itemRefId) {
    this.itemRefId = itemRefId;
  }

  public String getItemName() {
    return itemName;
  }

  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  public String getItemPosition() {
    return itemPosition;
  }

  public void setItemPosition(String itemPosition) {
    this.itemPosition = itemPosition;
  }

  public String getDepthOfKnowledge() {
    return depthOfKnowledge;
  }

  public void setDepthOfKnowledge(String depthOfKnowledge) {
    this.depthOfKnowledge = depthOfKnowledge;
  }

  public String getManuallyScorable() {
    return manuallyScorable;
  }

  public void setManuallyScorable(String manuallyScorable) {
    this.manuallyScorable = manuallyScorable;
  }
}
