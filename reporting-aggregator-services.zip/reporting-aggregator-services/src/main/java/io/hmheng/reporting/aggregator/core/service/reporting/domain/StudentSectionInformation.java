package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by Dare Famuyiwa on 30/06/2016.
 */
public class StudentSectionInformation {
	private UUID leaRefId;
	private String leaName;
	private UUID schoolRefId;
	private String schoolName;
	private UUID studentPersonRefId;

	List<EventSectionInfo> sectionList = new ArrayList<>();

	public UUID getLeaRefId() {
		return leaRefId;
	}

	public void setLeaRefId(UUID leaRefId) {
		this.leaRefId = leaRefId;
	}

	public UUID getSchoolRefId() {
		return schoolRefId;
	}

	public void setSchoolRefId(UUID schoolRefId) {
		this.schoolRefId = schoolRefId;
	}

	public UUID getStudentPersonRefId() {
		return studentPersonRefId;
	}

	public void setStudentPersonRefId(UUID studentPersonRefId) {
		this.studentPersonRefId = studentPersonRefId;
	}

	public String getLeaName() {
		return leaName;
	}

	public void setLeaName(String leaName) {
		this.leaName = leaName;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public void addSection(EventSectionInfo sectionInformation){
		sectionList.add(sectionInformation);
	}

	public List<EventSectionInfo> getSectionList() {
		return sectionList;
	}

	public void setSectionList(List<EventSectionInfo> sectionList) {
		this.sectionList = sectionList;
	}

	@Override
	public String toString() {
		return "StudentSectionInformation{" +
				"leaRefId=" + leaRefId +
				", leaName='" + leaName + '\'' +
				", schoolRefId=" + schoolRefId +
				", schoolName='" + schoolName + '\'' +
				", studentPersonRefId=" + studentPersonRefId +
				", sectionList=" + sectionList +
				'}';
	}
}
