package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentTotalScore;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.util.List;

/**
 * Created by nandipatim on 3/5/16.
 */
@JsonRootName("studentScore")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentStudentScoreInfo {

    @JsonProperty("activityItemScores")
    private List<AssignmentItemScore> activityItemScores;

    @JsonProperty("activityTotalScore")
    private AssignmentTotalScoreInfo activityTotalScore;

    private TestType testType;

    public List<AssignmentItemScore> getActivityItemScores() {
        return activityItemScores;
    }

    public void setActivityItemScores(List<AssignmentItemScore> activityItemScores) {
        this.activityItemScores = activityItemScores;
    }

    public AssignmentTotalScoreInfo getActivityTotalScore() {
        return activityTotalScore;
    }

    public void setActivityTotalScore(AssignmentTotalScoreInfo activityTotalScore) {
        this.activityTotalScore = activityTotalScore;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    @Override
    public String toString() {
        return "AssignmentStudentScoreInfo{" +
            "activityItemScores=" + activityItemScores +
            ", activityTotalScore=" + activityTotalScore +
            ", testType=" + testType +
            '}' ;
    }
}
