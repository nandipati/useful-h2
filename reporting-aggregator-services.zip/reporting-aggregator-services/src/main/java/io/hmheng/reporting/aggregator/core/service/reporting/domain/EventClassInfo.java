package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.UUID;

public class EventClassInfo {
    
    private UUID classId;
    private String className;
    private String classGrade;
    private UUID staffPersonRefId;
    private String staffFamilyName;
    private String staffGivenName;
    private String staffMiddleName;

    public UUID getClassId() {
        return classId;
    }

    public void setClassId(UUID classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassGrade() {
        return classGrade;
    }

    public void setClassGrade(String classGrade) {
        this.classGrade = classGrade;
    }
    
    public UUID getStaffPersonRefId() {
        return staffPersonRefId;
    }

    public void setStaffPersonRefId(UUID staffPersonRefId) {
        this.staffPersonRefId = staffPersonRefId;
    }

    public String getStaffFamilyName() {
        return staffFamilyName;
    }

    public void setStaffFamilyName(String staffFamilyName) {
        this.staffFamilyName = staffFamilyName;
    }

    public String getStaffGivenName() {
        return staffGivenName;
    }

    public void setStaffGivenName(String staffGivenName) {
        this.staffGivenName = staffGivenName;
    }

    public String getStaffMiddleName() {
        return staffMiddleName;
    }

    public void setStaffMiddleName(String staffMiddleName) {
        this.staffMiddleName = staffMiddleName;
    }

    @Override
    public String toString() {
        return "TestEventClassInfo{" +
            "classId=" + classId +
            ", className='" + className + '\'' +
            ", classGrade='" + classGrade + '\'' +
            ", staffPersonRefId=" + staffPersonRefId +
            ", staffFamilyName='" + staffFamilyName + '\'' +
            ", staffGivenName='" + staffGivenName + '\'' +
            ", staffMiddleName='" + staffMiddleName + '\'' +
            '}';
    }
    
}