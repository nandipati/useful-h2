package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import java.util.UUID;

/**
 * Created by jayachandranj on 8/28/17.
 */
public class ItemCreationRequest {
    private String resourceId;
    private TestType testType;
    private UUID activityId;

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }
}
