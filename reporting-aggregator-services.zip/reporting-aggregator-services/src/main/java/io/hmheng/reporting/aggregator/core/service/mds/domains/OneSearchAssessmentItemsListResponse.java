package io.hmheng.reporting.aggregator.core.service.mds.domains;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Arrays;

/**
 * Created by jayachandranj on 8/28/17.
 */
public class OneSearchAssessmentItemsListResponse {
    @JsonProperty(value = "assessment")
    private OneSearchAssessmentItems[] oneSearchAssessmentItems;

    public OneSearchAssessmentItems[] getOneSearchAssessmentItems()
    {
        return oneSearchAssessmentItems;
    }

    public void setOneSearchAssessmentItems(OneSearchAssessmentItems[] oneSearchAssessmentItems)
    {
        this.oneSearchAssessmentItems = oneSearchAssessmentItems;
    }
    public OneSearchAssessmentItems getFirstAssessmentItem() {
        if(oneSearchAssessmentItems ==null || oneSearchAssessmentItems.length!=1)
            return null;
        return oneSearchAssessmentItems[0];

    }

    @Override
    public String toString() {
        return "OneSearchAssessmentItemsListResponse{" +
                "oneSearchAssessmentItems=" + Arrays.toString(oneSearchAssessmentItems) +
                '}';
    }
}
