package io.hmheng.reporting.aggregator.core.service.reporting.domain;




public class Subscore {

    private String scoreType;
    private String slot;
    private Integer scoreOrder;
    private String name;
    private String abbr;
    private Double abilityEstimate;
    private Double standardError;
    private String achievementLevel;
    private Integer numberAttempted;
    private Integer numberQuestions;
    private Integer maxScore;
    private Integer score;
    private Double scaleScore;
    private Double lpr;
    private Double ipFloor;
    private Double ipCeil;
    private Double completionCriteriaPercentage;
    private Boolean completionCriteria;


    public String getScoreType() {
        return scoreType;
    }

    public void setScoreType(String scoreType) {
        this.scoreType = scoreType;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

    public Integer getScoreOrder() {
        return scoreOrder;
    }

    public void setScoreOrder(Integer scoreOrder) {
        this.scoreOrder = scoreOrder;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbr() {
        return abbr;
    }

    public void setAbbr(String abbr) {
        this.abbr = abbr;
    }

    public Double getAbilityEstimate() {
        return abilityEstimate;
    }

    public void setAbilityEstimate(Double abilityEstimate) {
        this.abilityEstimate = abilityEstimate;
    }

    public Double getStandardError() {
        return standardError;
    }

    public void setStandardError(Double standardError) {
        this.standardError = standardError;
    }

    public String getAchievementLevel() {
        return achievementLevel;
    }

    public void setAchievementLevel(String achievementLevel) {
        this.achievementLevel = achievementLevel;
    }

    public Integer getNumberAttempted() {
        return numberAttempted;
    }

    public void setNumberAttempted(Integer numberAttempted) {
        this.numberAttempted = numberAttempted;
    }

    public Integer getNumberQuestions() {
        return numberQuestions;
    }

    public void setNumberQuestions(Integer numberQuestions) {
        this.numberQuestions = numberQuestions;
    }

    public Integer getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(Integer maxScore) {
        this.maxScore = maxScore;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Double getScaleScore() {
        return scaleScore;
    }

    public void setScaleScore(Double scaleScore) {
        this.scaleScore = scaleScore;
    }

    public Double getLpr() {
        return lpr;
    }

    public void setLpr(Double lpr) {
        this.lpr = lpr;
    }

    public Double getIpFloor() {
        return ipFloor;
    }

    public void setIpFloor(Double ipFloor) {
        this.ipFloor = ipFloor;
    }

    public Double getIpCeil() {
        return ipCeil;
    }

    public void setIpCeil(Double ipCeil) {
        this.ipCeil = ipCeil;
    }

    public Double getCompletionCriteriaPercentage() {
        return completionCriteriaPercentage;
    }

    public void setCompletionCriteriaPercentage(Double completionCriteriaPercentage) {
        this.completionCriteriaPercentage = completionCriteriaPercentage;
    }

    public Boolean getCompletionCriteria() {
        return completionCriteria;
    }

    public void setCompletionCriteria(Boolean completionCriteria) {
        this.completionCriteria = completionCriteria;
    }

    @Override
    public String toString() {
        return "Subscore{" +
                "scoreType='" + scoreType + '\'' +
                ", slot='" + slot + '\'' +
                ", scoreOrder=" + scoreOrder +
                ", name='" + name + '\'' +
                ", abbr='" + abbr + '\'' +
                ", abilityEstimate=" + abilityEstimate +
                ", standardError=" + standardError +
                ", achievementLevel='" + achievementLevel + '\'' +
                ", numberAttempted=" + numberAttempted +
                ", numberQuestions=" + numberQuestions +
                ", maxScore=" + maxScore +
                ", score=" + score +
                ", scaleScore=" + scaleScore +
                ", lpr=" + lpr +
                ", ipFloor=" + ipFloor +
                ", ipCeil=" + ipCeil +
                ", completionCriteriaPercentage=" + completionCriteriaPercentage +
                ", completionCriteria=" + completionCriteria +
                '}';
    }
}
