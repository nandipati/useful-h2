package io.hmheng.reporting.aggregator.core.service.reporting.domain;


import java.util.UUID;

public class TestEventCloseInformation {

    private UUID sessionId;
    private TotalScore totalScore;

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public TotalScore getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(TotalScore totalScore) {
        this.totalScore = totalScore;
    }

    @Override
    public String toString() {
        return "TestEventCloseInformation{" +
                "sessionId=" + sessionId +
                ", totalScore=" + totalScore +
                '}';
    }
}
