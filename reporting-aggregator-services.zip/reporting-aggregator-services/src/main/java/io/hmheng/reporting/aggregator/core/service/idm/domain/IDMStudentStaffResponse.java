package io.hmheng.reporting.aggregator.core.service.idm.domain;

public class IDMStudentStaffResponse {
  private StaffPerson[] staffPersons;

  public StaffPerson[] getStaffPersons ()
  {
    return staffPersons;
  }

  public void setStaffPersons (StaffPerson[] staffPersons)
  {
    this.staffPersons = staffPersons;
  }

  @Override
  public String toString()
  {
    return "ClassPojo [staffPersons = "+staffPersons+"]";
  }

}
