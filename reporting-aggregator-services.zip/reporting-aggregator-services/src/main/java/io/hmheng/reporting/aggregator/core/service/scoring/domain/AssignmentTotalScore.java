package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.UUID;

/**
 * Created by nandipatim on 3/4/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentTotalScore {

    private UUID sessionId;
    private Integer itemsCorrect;
    private Integer pointsCorrect;
    private Integer totalPoints;
    private Integer totalItems;
    private Integer totalAttainedPoints;
    private Double totalProficiencyScore;
    private Integer totalTime;
    private ProficiencyBand performanceBand;

    public Double getTotalProficiencyScore() {
        return totalProficiencyScore;
    }

    public void setTotalProficiencyScore(Double totalProficiencyScore) {
        this.totalProficiencyScore = totalProficiencyScore;
    }

    public Integer getTotalAttainedPoints() {
        return totalAttainedPoints;
    }

    public void setTotalAttainedPoints(Integer totalAttainedPoints) {
        this.totalAttainedPoints = totalAttainedPoints;
    }

    public Integer getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(Integer totalItems) {
        this.totalItems = totalItems;
    }

    public Integer getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(Integer totalPoints) {
        this.totalPoints = totalPoints;
    }

    public Integer getPointsCorrect() {
        return pointsCorrect;
    }

    public void setPointsCorrect(Integer pointsCorrect) {
        this.pointsCorrect = pointsCorrect;
    }

    public Integer getItemsCorrect() {
        return itemsCorrect;
    }

    public void setItemsCorrect(Integer itemsCorrect) {
        this.itemsCorrect = itemsCorrect;
    }

    public UUID getSessionId() {
        return sessionId;
    }

    public void setSessionId(UUID sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Integer totalTime) {
        this.totalTime = totalTime;
    }

    public ProficiencyBand getPerformanceBand() {
        return performanceBand;
    }

    public void setPerformanceBand(ProficiencyBand performanceBand) {
        this.performanceBand = performanceBand;
    }

    @Override
    public String toString() {
        return "AssignmentTotalScore{" +
            "sessionId=" + sessionId +
            ", itemsCorrect=" + itemsCorrect +
            ", pointsCorrect=" + pointsCorrect +
            ", totalPoints=" + totalPoints +
            ", totalItems=" + totalItems +
            ", totalAttainedPoints=" + totalAttainedPoints +
            ", totalProficiencyScore=" + totalProficiencyScore +
            ", totalTime=" + totalTime +
            ", performanceBand=" + performanceBand +
            '}';
    }
}
