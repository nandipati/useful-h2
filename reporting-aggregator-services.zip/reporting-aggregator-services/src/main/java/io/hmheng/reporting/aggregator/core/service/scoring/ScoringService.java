package io.hmheng.reporting.aggregator.core.service.scoring;

import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.BenchmarkActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.EventSessionView;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.FormativeActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoreEventResponseInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoresAssessmentDeadLetter;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.ScoresAssessmentDeadLetterResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StandardSession;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;

import java.util.List;
import java.util.UUID;

public interface ScoringService {

    BenchmarkActivityScoresResponse getBenchmarkActivityScores(UUID activityId);

    FormativeActivityScoresResponse getFormativeActivityScores(UUID activityId);

    StudentSessionScores getFormativeStudentSessionScores(UUID activityId, UUID sessionId);

    StudentSessionScores getBenchmarkStudentSessionScores(UUID activityId, UUID sessionId);

    ScoreEventResponseInfo postEventDetails(AssignmentEventInfo assignmentEventInfo);

    ScoresAssessmentDeadLetterResponse saveDeadLetter(ScoresAssessmentDeadLetter scoresAssessmentDeadLetterMessage);

    List<ScoresAssessmentDeadLetter> getScoresAssessmentDeadLetter(List<UUID> messageIdList);

    List<ScoresAssessmentDeadLetter> updateScoresAssessmentDeadLetter(List<UUID> messageIdList);

    List<EventSessionView> findEventBySessionId(List<UUID> sessionIds);

    void postStudentDetails(UUID eventID, List<StudentInfo> studentInfoList);

    List<StandardSession> getStudents(List<UUID> sessions);

    String deleteTeacherAssignment(UUID eventRefId);
}
