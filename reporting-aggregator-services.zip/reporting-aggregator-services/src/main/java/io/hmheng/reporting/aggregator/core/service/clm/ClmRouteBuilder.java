package io.hmheng.reporting.aggregator.core.service.clm;

import io.hmheng.reporting.aggregator.core.service.clm.domain.District;
import io.hmheng.reporting.aggregator.core.service.clm.domain.School;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.LEA_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SCHOOL_REFID;
import static org.apache.camel.component.http4.HttpMethods.GET;

@Component
public class ClmRouteBuilder extends RouteBuilder {

    public static final String clmSchoolEndpoint = "direct://clmGetSchool";
    public static final String clmDistrictEndpoint = "direct://clmGetDistrict";

    private static final String clmSchoolRouteId = "clmGetSchoolRouteId";
    private static final String clmDistrictRouteId = "clmGetDistrictRouteId";

    @Value("${clm.host.baseUrl}")
    public String clmHost;

    @Override
    public void configure() throws Exception {

        configureEndpoint(
                clmSchoolEndpoint,
                clmSchoolRouteId,
                String.format("/schools/${header.%s}", SCHOOL_REFID),
                School.class);

        configureEndpoint(
                clmDistrictEndpoint,
                clmDistrictRouteId,
                String.format("/leas/${header.%s}", LEA_REFID),
                District.class);
    }

    private void configureEndpoint(String endpointUri, String endpointId, String url, Class<?> responseClass) {
        from(endpointUri).id(endpointId)
                .setHeader(Exchange.HTTP_METHOD, constant(GET))
                .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_XML))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .setHeader(CORRELATION_ID, simple("${header." + CORRELATION_ID + "}"))
                .recipientList(simple(clmHost + url))
                .unmarshal().jacksonxml(responseClass)
                .end();
    }
}
