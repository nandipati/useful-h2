package io.hmheng.reporting.aggregator.core.service.learnosity;

import io.hmheng.reporting.aggregator.core.service.learnosity.domain.LearnosityServiceResponse;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionsResponsesResponse;

import java.util.List;

/**
 * Created by pabonaj on 9/19/16.
 */
public interface LearnosityService {

    LearnosityServiceResponse rescoreBySession(List<String> sessionList, List<Object> reportingSessionList);

    LearnosityServiceResponse getSessionsResponses(List<String> sessionList, List<SessionsResponsesResponse> sessionsResponsesResponse);

    Object[] getSessionsResponsesData(List<SessionsResponsesResponse> sessionsResponsesResponseList);

    void populateAbilityEstimates(List<SessionsResponsesResponse> sessionsResponsesResponses);
}
