package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.Arrays;

/**
 * Created by nandipatim on 3/9/16.
 */
public enum Discipline {

    M,E;
}
