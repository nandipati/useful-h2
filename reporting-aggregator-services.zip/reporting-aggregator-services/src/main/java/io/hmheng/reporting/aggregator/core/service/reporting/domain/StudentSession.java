package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.UUID;

/**
 * Created by pabonaj on 9/30/16.
 */
public class StudentSession {
    private Long id;
    private UUID activityRefId;
    private UUID sessionRefId;
    private UUID eventRefId;
    private String testType;
    private UUID studentPersonalRefId;

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public UUID getActivityRefId() { return activityRefId; }

    public void setActivityRefId(UUID activityRefId) { this.activityRefId = activityRefId; }

    public UUID getSessionRefId() { return sessionRefId; }

    public void setSessionRefId(UUID sessionRefId) { this.sessionRefId = sessionRefId; }

    public UUID getStudentPersonalRefId() { return studentPersonalRefId; }

    public void setStudentPersonalRefId(UUID studentPersonalRefId) { this.studentPersonalRefId = studentPersonalRefId; }

}
