package io.hmheng.reporting.aggregator.core.service.mds;

import io.hmheng.reporting.aggregator.core.service.mds.domains.ItemsExternalRefIdResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OneSearchAssessmentItemsListResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.OnesearchItemResponse;
import io.hmheng.reporting.aggregator.core.service.mds.domains.StandardsResponse;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

/**
 * Created by nandipatim on 3/16/16.
 */
public interface MDSService {

  OnesearchItemResponse getItemDetailsByProgramItemRefId(String itemRefId);

  OneSearchAssessmentItemsListResponse getItemsByAssessmentId(String assessmentId);

  ItemsExternalRefIdResponse getItemDetailByItemRefId(String itemRefId, int pageLength);

  StandardsResponse getStandardDetailsByStandardRefId(String standardRefId, TestType testType);
}
