package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentInfo;
import io.hmheng.reporting.aggregator.web.domain.assignment.Group;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Created by nandipatim on 2/29/16.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ScoreEventResponseInfo {

    private UUID assignmentId;
    private UUID activityId;
    private String assignmentName;
    private String activityName;
    private String isbn;
    private String grade;
    private UUID sectionId;
    private String assessmentName;
    private LocalDateTime availableDate;
    private LocalDateTime dueDate;
    private String resourceId;
    private String programId;
    private TestType testType;
    private Boolean manualScoringRequired;

    private List<Group> eventGroups;

    public List<Group> getEventGroups() {
        return eventGroups;
    }

    public void setEventGroups(List<Group> eventGroups) {
        this.eventGroups = eventGroups;
    }


    public UUID getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(UUID assignmentId) {
        this.assignmentId = assignmentId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public String getAssignmentName() {
        return assignmentName;
    }

    public void setAssignmentName(String assignmentName) {
        this.assignmentName = assignmentName;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public LocalDateTime getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(LocalDateTime availableDate) {
        this.availableDate = availableDate;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public Boolean getManualScoringRequired() {
        return manualScoringRequired;
    }

    public void setManualScoringRequired(Boolean manualScoringRequired) {
        this.manualScoringRequired = manualScoringRequired;
    }
}
