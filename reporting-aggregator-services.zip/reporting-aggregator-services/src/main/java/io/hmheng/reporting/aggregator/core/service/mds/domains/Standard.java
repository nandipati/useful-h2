package io.hmheng.reporting.aggregator.core.service.mds.domains;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentItemScore;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.util.CollectionUtils;

/**
 * Created by nandipatim on 3/16/16.
 */
public class Standard {

    private String id;
    private String hmhGuid;
    private String description;
    private String type;
    private String gradeFrom;
    private String gradeTo;
    @JsonProperty(value = "abguids")
    private Abguid abguids;
    private String guid;
    private StandardSet standardSet;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHmhGuid() {
        return hmhGuid;
    }

    public void setHmhGuid(String hmhGuid) {
        this.hmhGuid = hmhGuid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGradeFrom() {
        return gradeFrom;
    }

    public void setGradeFrom(String gradeFrom) {
        this.gradeFrom = gradeFrom;
    }

    public String getGradeTo() {
        return gradeTo;
    }

    public void setGradeTo(String gradeTo) {
        this.gradeTo = gradeTo;
    }

    public Abguid getAbguids() {
        if(this.abguids==null) {
            this.abguids = new Abguid();
            this.abguids.setAbguid(guid);
        }
        return abguids;
    }

    public void setAbguids(Abguid abguids) {
        this.abguids = abguids;
    }

    public void setStandardSet(StandardSet standardSet) {
        this.standardSet = standardSet;
    }

    public StandardSet getStandardSet() {
        return StandardSet.getSimpleStandardSet(standardSet);
    }



    public static class Abguid {

        private String abguid;

        public String getAbguid() {
            return abguid;
        }

        public void setAbguid(String abguid) {
            abguid = abguid.toLowerCase();
            this.abguid = abguid;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Abguid abguid1 = (Abguid) o;

            return !(getAbguid() != null ? !getAbguid().equals(abguid1.getAbguid()) : abguid1.getAbguid() != null);

        }

        @Override
        public int hashCode() {
            return getAbguid() != null ? getAbguid().hashCode() : 0;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Standard standard = (Standard) o;

        return !(getAbguids() != null ? !getAbguids().equals(standard.getAbguids()) : standard.getAbguids() != null);

    }

    @Override
    public int hashCode() {
        return getAbguids() != null ? getAbguids().hashCode() : 0;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        if(this.abguids==null) {
            this.abguids = new Abguid();
            this.abguids.setAbguid(guid);
        }
        if(this.hmhGuid==null)
            this.hmhGuid=guid;
        this.guid = guid;
    }
}
