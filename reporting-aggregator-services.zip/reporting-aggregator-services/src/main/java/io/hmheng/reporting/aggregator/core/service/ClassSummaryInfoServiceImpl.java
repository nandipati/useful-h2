package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.reporting.ReportingService;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentClassSummaryInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.PerformanceLevel;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentPerformanceLevelInfo;
import io.hmheng.reporting.aggregator.core.service.scoring.ScoringService;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.AssignmentTotalScore;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.FormativeActivityScoresResponse;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.Session;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;
import io.hmheng.reporting.aggregator.exception.ApplicationException;
import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;
import org.springframework.util.StringUtils;

@Component
public class ClassSummaryInfoServiceImpl implements ClassSummaryInfoService {

  private static final Logger logger = LoggerFactory.getLogger(ClassSummaryInfoServiceImpl.class);

  @Autowired
    private ScoringService scoringService;

    @Autowired
    private ReportingService reportingService;


  @Override
    public void handleClassSummaryInfo(StudentSessionScores request) {

        logger.info("+handleClassSummaryInfo {}",request.getActivityId());

        FormativeActivityScoresResponse formativeActivityScoresResponse = scoringService.
                getFormativeActivityScores(request.getActivityId());

        if(formativeActivityScoresResponse == null || formativeActivityScoresResponse.getSessions() == null)
            throw new ApplicationException("Formative Scores cannot be Null or empty for ActivityForScores: "+request.getActivityId()
                    +" in Scoring");

        logger.info("EventType {} ",request.getEventType());


        AssignmentClassSummaryInfo assignmentClassSummaryInfo = createAssignmentClassSummary(
            formativeActivityScoresResponse.getSessions().getContent() , request.getEventType());


        logger.info("No of Bannds {} Bandids from {} for Activity {} "
         ,assignmentClassSummaryInfo.getPerformanceLevels().size()
         ,assignmentClassSummaryInfo.getBand1Id(),request.getActivityId());

        logger.info("calling publishClassSummaryInfo {}", request.getActivityId());
        reportingService.publishClassSummaryInfo(request.getActivityId(), assignmentClassSummaryInfo);

        logger.info("+handleClassSummaryInfo {}",request.getActivityId());
  }

    private AssignmentClassSummaryInfo createAssignmentClassSummary(List<Session> sessions , TestType testType) {

        int classPointsCorrect = 0;
        int itemsCorrectForClass = 0;
        double classProficiencyAverage = 0;
        double classPointsAverage = 0;
        double correctItemsAverage = 0;
        int itemsCount=0;
        int availablePoints = 0;
        int studentCount = 0;

        StudentPerformanceLevelInfo studentPerformanceLevelInfo = new StudentPerformanceLevelInfo();

        if (!CollectionUtils.isEmpty(sessions)) {

            AssignmentTotalScore assignmentTotalScore;
            PerformanceLevel totalAttainedPerformanceLevel;

            for (Session session : sessions) {
              //TODO: change Status to Enum in Aggregator and Scoring API.
              String status = session.getStatus();
              if(!StringUtils.isEmpty(status)) {
                AssignmentStatus assignmentStatus = AssignmentStatus.fromString(status);
                if(assignmentStatus.isAllowsScores()) {
                  assignmentTotalScore = session.getTotalScore();
                  if (assignmentTotalScore != null) {
                    studentCount++;
                  }
                  classPointsCorrect += Optional.ofNullable(assignmentTotalScore)
                      .map(AssignmentTotalScore::getTotalAttainedPoints).orElse(0);
                  itemsCorrectForClass += Optional.ofNullable(assignmentTotalScore)
                      .map(AssignmentTotalScore::getItemsCorrect).orElse(0);
                  int totalPoints = Optional.ofNullable(assignmentTotalScore)
                      .map(AssignmentTotalScore::getTotalPoints).orElse(0);
                  if (testType == null) {
                    testType = TestType.FORMATIVE;
                  }
                  totalAttainedPerformanceLevel = PerformanceLevel.getPerformanceLevel(
                      Optional.ofNullable(assignmentTotalScore).map(AssignmentTotalScore::getTotalProficiencyScore).orElse(0.0d)
                      , testType);
                  updatePerformanceLevelCount(studentPerformanceLevelInfo, totalAttainedPerformanceLevel);
                }
              }
            }

            assignmentTotalScore = Optional.ofNullable(sessions.get(0))
                        .map(Session::getTotalScore).orElse(null);
            itemsCount = Optional.ofNullable(assignmentTotalScore)
                    .map(AssignmentTotalScore::getTotalItems).orElse(0);
            availablePoints = Optional.ofNullable(assignmentTotalScore)
                    .map(AssignmentTotalScore::getTotalPoints).orElse(0);;

            classPointsAverage = (double) classPointsCorrect / studentCount;

            if (availablePoints > 0) {
                classProficiencyAverage = new BigDecimal(classPointsAverage).divide(new BigDecimal(availablePoints)
                        , 2, BigDecimal.ROUND_HALF_UP).doubleValue();
            }

            correctItemsAverage = (double) itemsCorrectForClass / studentCount;
            studentPerformanceLevelInfo.updateStudentPercentages(studentCount);

        }

        return new AssignmentClassSummaryInfo()
                .withClassProficiencyAverage(classProficiencyAverage)
                .withClassPointsAverage(classPointsAverage)
                .withCorrectItems(correctItemsAverage)
                .withPerformanceLevelInfo(studentPerformanceLevelInfo)
                .withAvailablePoints(availablePoints)
                .withItemsCount(itemsCount)
                .withTestType(testType)
                .withPerformanceBandIdsForLevels(testType);
    }

    private void updatePerformanceLevelCount(StudentPerformanceLevelInfo studentPerformanceLevelInfo,
                                             PerformanceLevel totalAttainedPerformanceLevel) {
        switch(totalAttainedPerformanceLevel){
            case ADVANCED:
                studentPerformanceLevelInfo.incrementAdvancedStudentCount();
                break;
            case PROFICIENT:
                studentPerformanceLevelInfo.incrementProficientStudentCount();
                break;
            case BASIC:
            case MASTERED:
                studentPerformanceLevelInfo.incrementBasicStudentCount();
                break;
            case BELOW_BASIC:
            case PARTIALLY_MASTERED:
                studentPerformanceLevelInfo.incrementBelowBasicStudentCount();
                break;
            case FAR_BELOW_BASIC:
            case NOT_MASTERED:
                studentPerformanceLevelInfo.incrementFarBelowBasicStudentCount();
                break;

        }
    }
}