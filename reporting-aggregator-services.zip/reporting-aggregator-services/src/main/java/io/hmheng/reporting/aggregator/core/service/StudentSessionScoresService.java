package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.StandardSession;
import io.hmheng.reporting.aggregator.core.service.scoring.domain.StudentSessionScores;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by nandipatim on 3/4/16.
 */
public interface StudentSessionScoresService {
    final ExecutorService backgroundExecutor = Executors.newCachedThreadPool();

    void handleStudentSessionScores(StudentSessionScores studentSessionScoresRequest);

    void handleStandardSessionScores(StandardSession standardSessionScores);
}
