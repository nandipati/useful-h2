package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Created by suryadevarap on 4/4/18.
 */
public class DomainStandard {

  private UUID domainId;
  private Set<Standards> standards;

  public UUID getDomainId() {
    return domainId;
  }

  public void setDomainId(UUID domainId) {
    this.domainId = domainId;
  }

  public Set<Standards> getStandards() {
    return standards;
  }

  public void setStandards(Set<Standards> standards) {
    this.standards = standards;
  }
}
