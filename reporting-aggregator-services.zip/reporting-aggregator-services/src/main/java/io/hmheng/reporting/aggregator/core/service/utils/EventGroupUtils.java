package io.hmheng.reporting.aggregator.core.service.utils;

import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentInfo;

import java.util.ArrayList;
import java.util.List;

public class EventGroupUtils {

    public static List<StudentInfo> getStudentListWithoutNullGroups(AssignmentStudentInfo assignmentStudentInfo){
        List<StudentInfo> studentList = new ArrayList<>();
        assignmentStudentInfo.getStudents().forEach(studentInfo -> {
            if(studentInfo.getGroupId() == null){
                studentList.add(studentInfo);
            }
        });

        assignmentStudentInfo.getStudents().removeAll(studentList);

        return assignmentStudentInfo.getStudents();

    }

}
