package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

/**
 * Created by pabonaj on 10/7/16.
 */
public class Meta {

    private String status;
    private String timestamp;
    private String next;
    private int records;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getNext() {
        return next;
    }

    public void setNext(String next) {
        this.next = next;
    }

    public int getRecords() {
        return records;
    }

    public void setRecords(int records) {
        this.records = records;
    }

}
