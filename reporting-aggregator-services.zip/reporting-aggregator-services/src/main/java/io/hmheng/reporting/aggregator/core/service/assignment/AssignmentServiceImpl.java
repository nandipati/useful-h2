package io.hmheng.reporting.aggregator.core.service.assignment;

import io.hmheng.reporting.aggregator.core.service.AuthorizationDetails;
import io.hmheng.reporting.aggregator.core.service.AuthorizationService;
import io.hmheng.reporting.aggregator.core.service.assignments.domain.StudentAssignmentsResponse;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static io.hmheng.reporting.aggregator.core.service.utils.Headers.TESTING_EVENT_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.ASSIGNMENT_STATUS_HEADER;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;
import static io.hmheng.reporting.aggregator.core.service.AuthorizationService.Service.Assignments;

/**
 * Created by jayachandranj on 2/27/17.
 */
@Service
public class AssignmentServiceImpl implements AssignmentService {

    private static final Logger logger = LoggerFactory.getLogger(AssignmentServiceImpl.class);

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private HeadersHelper headersHelper;

    @Override
    public StudentAssignmentsResponse getStudentSessionIds(UUID testEventId, String assignmentStatus){
        StudentAssignmentsResponse studentAssignmentsResponse =null;
        studentAssignmentsResponse = producerTemplate.requestBodyAndHeaders(AssignmentRouteBuilder.getTestEventClosedStudentAssignmentsEndpoint,"",
                generateHeaderForInProgressStudents(testEventId,assignmentStatus),StudentAssignmentsResponse.class);
        return studentAssignmentsResponse;
    }

    private Map<String, Object> generateHeaderForInProgressStudents(UUID testEventId, String assignmentStatus) {
        Map<String, Object> headers = createBasicHeaders();
        headers.put(TESTING_EVENT_REFID, testEventId.toString());
        headers.put(ASSIGNMENT_STATUS_HEADER,assignmentStatus);
        return headers;
    }

    private Map<String, Object> createBasicHeaders() {
        AuthorizationDetails authorizationDetails = authorizationService.createSIFAuthorization(Assignments);
        Map<String, Object> headers = new HashMap<>();

        headers.put(AUTHORIZATION, authorizationDetails.getSifAuthorization().getAuthorization());
        headers.put(AUTH_CURRENT_DATE_TIME, authorizationDetails.getAuthCurrentDateTime());

        return headers;
    }


}
