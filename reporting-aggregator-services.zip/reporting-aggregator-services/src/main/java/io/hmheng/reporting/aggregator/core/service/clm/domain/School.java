package io.hmheng.reporting.aggregator.core.service.clm.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlRootElement;

import java.util.UUID;

@XmlRootElement(name = "school", namespace = "ns3")
@JsonIgnoreProperties(ignoreUnknown = true)
public class School {

    private String schoolName;
    private UUID leaRefId;
    private String orgId;

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public UUID getLeaRefId() {
        return leaRefId;
    }

    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @Override
    public String toString() {
        return "School{" +
            "schoolName='" + schoolName + '\'' +
            ", leaRefId=" + leaRefId +
            ", orgId='" + orgId + '\'' +
            '}';
    }
}
