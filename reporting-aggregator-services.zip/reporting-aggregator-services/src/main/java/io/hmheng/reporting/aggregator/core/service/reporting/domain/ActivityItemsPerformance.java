package io.hmheng.reporting.aggregator.core.service.reporting.domain;

/**
 * Created by nandipatim on 3/17/16.
 */
public class ActivityItemsPerformance {

    private String itemRefId;
    private Integer sequenceNumber;
    private String itemName;
    private String type;
    private Integer availablePoints;
    private String cognitiveDifficultyLevel;
    private String bloomsTaxanomyLevel;
    private String questionType;
    private String depthOfKnowledge;
    private String manuallyScorable;
    private Integer itemNumber;

    public ActivityItemsPerformance() {
    }

    public ActivityItemsPerformance(String itemRefId, Integer sequenceNumber, String itemName, String type, String questionType, String manuallyScorable, String depthOfKnowledge) {
        this.itemRefId = itemRefId;
        this.sequenceNumber = sequenceNumber;
        this.itemName = itemName;
        this.type = type;
        this.questionType = questionType;
        this.manuallyScorable = manuallyScorable;
        this.depthOfKnowledge = depthOfKnowledge;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getAvailablePoints() {
        return availablePoints;
    }

    public void setAvailablePoints(Integer availablePoints) {
        this.availablePoints = availablePoints;
    }

    public String getCognitiveDifficultyLevel() {
        return cognitiveDifficultyLevel;
    }

    public void setCognitiveDifficultyLevel(String cognitiveDifficultyLevel) {
        this.cognitiveDifficultyLevel = cognitiveDifficultyLevel;
    }

    public String getBloomsTaxanomyLevel() {
        return bloomsTaxanomyLevel;
    }

    public void setBloomsTaxanomyLevel(String bloomsTaxanomyLevel) {
        this.bloomsTaxanomyLevel = bloomsTaxanomyLevel;
    }

    public String getQuestionType() {
        return questionType;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public String getDepthOfKnowledge() {
        return depthOfKnowledge;
    }

    public void setDepthOfKnowledge(String depthOfKnowledge) {
        this.depthOfKnowledge = depthOfKnowledge;
    }

    public String getManuallyScorable() {
      return manuallyScorable;
    }

    public void setManuallyScorable(String manuallyScorable) {
      this.manuallyScorable = manuallyScorable;
    }

    public Integer getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(Integer itemNumber) {
        this.itemNumber = itemNumber;
    }

    @Override
    public String toString() {
        return "ActivityItemsPerformance{" +
            "itemRefId='" + itemRefId + '\'' +
            ", sequenceNumber=" + sequenceNumber +
            ", itemName='" + itemName + '\'' +
            ", type='" + type + '\'' +
            ", availablePoints=" + availablePoints +
            ", cognitiveDifficultyLevel='" + cognitiveDifficultyLevel + '\'' +
            ", bloomsTaxanomyLevel='" + bloomsTaxanomyLevel + '\'' +
            ", questionType='" + questionType + '\'' +
            ", depthOfKnowledge='" + depthOfKnowledge + '\'' +
            ", manuallyScorable='" + manuallyScorable + '\'' +
            ", itemNumber=" + itemNumber +
            '}';
    }
}
