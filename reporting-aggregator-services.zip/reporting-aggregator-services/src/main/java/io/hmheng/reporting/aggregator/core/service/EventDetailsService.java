package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.arg.EventDetailsRequest;
import io.hmheng.reporting.aggregator.web.domain.assignment.EventDetailsBatch;

/**
 * Created by nandipatim on 2/29/16.
 */
public interface EventDetailsService {

    void handleEventDetails(EventDetailsRequest event);

    void handleReopenedEventDetails(EventDetailsRequest event);

    void handleReopenedEventScores(EventDetailsBatch eventDetailsBatch);
}
