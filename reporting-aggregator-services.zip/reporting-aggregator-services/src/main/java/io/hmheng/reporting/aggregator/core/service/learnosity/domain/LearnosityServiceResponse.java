package io.hmheng.reporting.aggregator.core.service.learnosity.domain;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonObject;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by pabonaj on 10/7/16.
 */
public class LearnosityServiceResponse {

    private int status;
    private List<Object> jsonLearnosity;
    private List<Object> sessionIds;

    private List<String> otherIgnoredSessions;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<Object> getJsonLearnosity() {
        return jsonLearnosity;
    }

    public void setJsonLearnosity(List<Object> jsonLearnosity) {
        this.jsonLearnosity = jsonLearnosity;
    }

    public List<Object> getSessionIds() {
        return sessionIds;
    }

    public void setSessionIds(List<Object> sessionIds) {
        this.sessionIds = sessionIds;
    }

    public List<String> getOtherIgnoredSessions() {
        return otherIgnoredSessions;
    }

    public void setOtherIgnoredSessions(List<String> otherIgnoredSessions) {
        this.otherIgnoredSessions = otherIgnoredSessions;
    }

    public void appendToOtherIgnoredSessions(List<String> otherIgnoredSessions) {
        if (this.otherIgnoredSessions == null) {
            this.otherIgnoredSessions = new ArrayList<String>();
        }
        this.otherIgnoredSessions.addAll(otherIgnoredSessions);
    }
}
