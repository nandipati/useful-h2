package io.hmheng.reporting.aggregator.core.service.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.hmheng.reporting.aggregator.core.service.mds.domains.Result;
import io.hmheng.reporting.aggregator.core.service.mds.domains.Standard;

/**
 * Created by nandipatim on 3/20/16.
 */
public class MDSMessageParserHelper {

    private static final Logger logger = LoggerFactory.getLogger(MDSMessageParserHelper.class);


    public static void parseItemResponseContent(Set<Standard> standards , JsonObject content) {
        try {
            JsonArray contentArray = content.get("resource")
                    .getAsJsonObject().get(Result.CHILDREN).getAsJsonArray();

            JsonArray listOfValue = contentArray.get(0).getAsJsonObject().get("metadata").getAsJsonObject().get(Result.CHILDREN)
                    .getAsJsonArray();


            for (JsonElement object : listOfValue) {
                JsonElement standardsElement = object.getAsJsonObject().get("curriculumStandardsMetadataSet");
                if (standardsElement != null) {
                    JsonObject standardMetaDataObject = standardsElement.getAsJsonObject();
                    JsonArray standardArray = standardMetaDataObject.get(Result.CHILDREN).getAsJsonArray();
                    for (JsonElement standardObject : standardArray) {
                        JsonObject curriculumStandardsMetadata = standardObject.getAsJsonObject().get("curriculumStandardsMetadata").getAsJsonObject();
                        JsonObject standardAttributes = curriculumStandardsMetadata.getAsJsonObject("_attributes");
                        String typeData = standardAttributes.get("providerId").getAsString();
                        if (typeData != null && Result.STANDARD_TYPE_AB.equals(typeData)) {
                            JsonArray standardsArray = curriculumStandardsMetadata.get(Result.CHILDREN).getAsJsonArray();
                            for (JsonElement standardDataObject : standardsArray) {
                                JsonObject setOfGUIDS = standardDataObject.getAsJsonObject().get("setOfGUIDs").getAsJsonObject();
                                JsonArray guidChildern = setOfGUIDS.get(Result.CHILDREN).getAsJsonArray();
                                for (JsonElement guidChildernObject : guidChildern) {
                                    populateStandards(standards, guidChildernObject);
                                }

                            }
                        }
                    }
                }
            }
        }catch(Exception ex){
            logger.error("Exception Parsing MDS Response :",ex);
        }
    }

    private static void populateStandards(Set<Standard> standards, JsonElement guidChildernObject) {
        Standard standard = new Standard();
        JsonObject labelledGUID = guidChildernObject.getAsJsonObject().getAsJsonObject("labelledGUID");
        JsonArray standardsChilds = labelledGUID.getAsJsonArray(Result.CHILDREN);
        for (JsonElement standardElement : standardsChilds) {
            JsonObject standardLabel = standardElement.getAsJsonObject().getAsJsonObject("label");
            if (standardLabel != null) {
                String label = standardLabel.getAsJsonArray(Result.CHILDREN).get(0).getAsString();
                standard.setId(label);
            }
            JsonObject standardGUID = standardElement.getAsJsonObject().getAsJsonObject("GUID");
            if (standardGUID != null) {
                String guid = standardGUID.getAsJsonArray(Result.CHILDREN).get(0).getAsString();
                Standard.Abguid abguid = new Standard.Abguid();
                abguid.setAbguid(guid);
                standard.setAbguids(abguid);
            }
            standard.setType(Result.STANDARD_TYPE_AB);
        }
        standards.add(standard);
    }

    public static Standard createNoStandard() {
        Standard standard = new Standard();
        Standard.Abguid abguid = new Standard.Abguid();
        abguid.setAbguid(Result.NO_STANDARD_ID);
        standard.setGuid(Result.NO_STANDARD_ID);
        standard.setAbguids(abguid);
        standard.setId(Result.NO_STANDARDS);
        standard.setDescription(Result.NO_STANDARDS_DESC);
        standard.setType(Result.NO_STANDARDS);
        return standard;
    }

    public static String parseItemResponseContentIdentifier(JsonObject content) {
        JsonObject attributes = content.get(Result.RESOURCE)
                .getAsJsonObject().get(Result.ATTRIBUTES).getAsJsonObject();

        return attributes.get("identifier").getAsString();
    }

    private static JsonObject parseItemContent(JsonObject content, String elementName, String subElementName) {
        JsonArray children = content.get(elementName).getAsJsonObject().get(Result.CHILDREN).getAsJsonArray();
        for (JsonElement child : children) {
            JsonObject childElement = child.getAsJsonObject().getAsJsonObject(subElementName);
            if (childElement != null) {
                return child.getAsJsonObject();
            }
        }
        return null;
    }

    private static String parseEducationalDifficulty(JsonObject content, String searchValue) {
        JsonObject resource = parseItemContent(content, Result.RESOURCE, Result.METADATA);
        if (resource != null) {
            JsonObject metadata = parseItemContent(resource, Result.METADATA, Result.LOM);
            if (metadata != null) {
                JsonObject lom = parseItemContent(metadata, Result.LOM, Result.EDUCATIONAL);
                if (lom != null) {
                    JsonArray educational = lom.get(Result.EDUCATIONAL).getAsJsonObject().get(Result.CHILDREN).getAsJsonArray();
                    for (JsonElement itemEducational : educational) {
                        JsonObject difficulty = itemEducational.getAsJsonObject().getAsJsonObject(Result.DIFFICULTY);
                        if (difficulty != null) {
                            JsonArray children = difficulty.get(Result.CHILDREN).getAsJsonArray();
                            if (children != null) {
                                JsonObject child = children.get(0).getAsJsonObject();
                                if (child != null) {
                                    JsonObject source = child.getAsJsonObject(Result.SOURCE);
                                    if (source != null) {
                                        JsonArray sourceChildren = source.getAsJsonObject().get(Result.CHILDREN).getAsJsonArray();
                                        if (sourceChildren != null) {
                                            String sourceChild = sourceChildren.get(0).getAsString();
                                            if (sourceChild != null && sourceChild.equals(searchValue)) {
                                                JsonObject sourceValue = children.get(1).getAsJsonObject();
                                                if (sourceValue != null) {
                                                    JsonObject value = sourceValue.getAsJsonObject(Result.VALUE);
                                                  if (value != null && !StringUtils.isEmpty(value) && value.get
                                                      (Result.CHILDREN)!=null) {
                                                        logger.error("inside child node of Result:: ",value);
                                                        JsonArray valueArray = value.get(Result.CHILDREN).getAsJsonArray();
                                                        if (valueArray != null) {
                                                            return valueArray.get(0).getAsString();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return null;
    }

    public static String parseItemResponseQuestionType(JsonObject content) {
        try {
            String questionTypes = null;
            List<String> types = new ArrayList<>();
            JsonArray children = content.get(Result.RESOURCE).getAsJsonObject().get(Result.CHILDREN).getAsJsonArray();
            for (JsonElement child : children) {
                JsonObject childElement = child.getAsJsonObject().getAsJsonObject(Result.DEPENDENCY);
                if (childElement != null) {
                    JsonObject fields = childElement.get(Result.ATTRIBUTES).getAsJsonObject();
                    types.add(fields.getAsJsonObject().get(Result.TYPE).getAsString());
                }
            }
            if (types.size() > 0) {
                questionTypes = String.join(",", types);
                return questionTypes;
            }
        }catch(Exception ex){
            logger.error("Exception Parsing MDS Response content question type:",ex);
        }
        return null;
    }

    public static String parseItemResponseBloomsTaxonomy(JsonObject content) {
        try {
            String value = parseEducationalDifficulty(content, Result.SOURCE_BLOOM_TAXONOMY);
            if (value != null && value.length() >= Result.LENGTH_BLOOMS_TAXONOMY_TEXT) {
                if (value.substring(0, Result.LENGTH_BLOOMS_TAXONOMY_TEXT).equals(Result.TEXT_BLOOMS_TAXONOMY)) {
                    value = value.substring(Result.LENGTH_BLOOMS_TAXONOMY_TEXT);
                }
            }
            return value;
        }catch(Exception ex){
            logger.error("Exception Parsing MDS Response content blooms taxonomy:",ex);
        }
        return null;
    }

    public static String parseItemResponseCognitiveDifficulty(JsonObject content) {
        try {
            String value = parseEducationalDifficulty(content, Result.SOURCE_COGNITIVE_DIFFICULTY);
            return value;
        }catch(Exception ex){
            logger.error("Exception Parsing MDS Response content cognitive difficulty:",ex);
        }
        return null;
    }

    public static String parseItemResponseDepthOfKnowledge(JsonObject content) {
        try {
            String value = parseEducationalDifficulty(content, Result.SOURCE_DEPTH_OF_KNOWLEDGE);
            return value;
        }catch(Exception ex){
            logger.error("Exception Parsing MDS Response content Depth Of Knowledge:",ex);
        }
        return null;
    }

}
