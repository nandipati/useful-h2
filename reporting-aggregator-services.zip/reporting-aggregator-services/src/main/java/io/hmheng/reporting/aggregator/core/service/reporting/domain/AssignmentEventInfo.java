package io.hmheng.reporting.aggregator.core.service.reporting.domain;


import io.hmheng.reporting.aggregator.core.service.arg.EventDetailsRequest;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import java.util.List;
import java.util.UUID;
import org.joda.time.DateTime;

/**
 * Created by nandipatim on 2/29/16.
 */
public class AssignmentEventInfo {

    private UUID eventRefId;
    private UUID assignmentId;
    private UUID activityId;
    private String assignmentName;
    private String activityName;
    private String isbn;
    private String grade;
    private UUID sectionId;
    private String assessmentName;
    private DateTime availableDate;
    private DateTime dueDate;
    private String resourceId;
    private String programId;
    private String programName;
    private TestType testType;
    private Boolean manualScoringRequired;
    private UUID staffPersonalRefId;
    private UUID leaRefId;
    private String disciplineId;
    private String disciplineName;

    private List<GroupInfo> eventGroups;

    public List<GroupInfo> getEventGroups() {
        return eventGroups;
    }

    public void setEventGroups(List<GroupInfo> eventGroups) {
        this.eventGroups = eventGroups;
    }

    public UUID getleaRefId() {
        return leaRefId;
    }

    public void setleaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(UUID assignmentId) {
        this.assignmentId = assignmentId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public String getAssignmentName() {
        return assignmentName;
    }

    public void setAssignmentName(String assignmentName) {
        this.assignmentName = assignmentName;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public DateTime getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(DateTime availableDate) {
        this.availableDate = availableDate;
    }

    public DateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(DateTime dueDate) {
        this.dueDate = dueDate;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public Boolean getManualScoringRequired() {
        return manualScoringRequired;
    }

    public void setManualScoringRequired(Boolean manualScoringRequired) {
        this.manualScoringRequired = manualScoringRequired;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }

    public String getDisciplineId() {
        return disciplineId;
    }

    public void setDisciplineId(String disciplineId) {
        this.disciplineId = disciplineId;
    }

    public String getDisciplineName() {
        return disciplineName;
    }

    public void setDisciplineName(String disciplineName) {
        this.disciplineName = disciplineName;
    }

    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }
}
