package io.hmheng.reporting.aggregator.core.service.idm.domain;

import io.hmheng.reporting.aggregator.core.service.clm.domain.School;
import java.util.UUID;

public class StudentSectionAssociation {

    private UUID refId;
    private UUID studentRefId;
    private UUID sectionRefId;
    private String grade;
    private School school;

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public UUID getStudentRefId() {
        return studentRefId;
    }

    public void setStudentRefId(UUID studentRefId) {
        this.studentRefId = studentRefId;
    }

    public UUID getSectionRefId() {
        return sectionRefId;
    }

    public void setSectionRefId(UUID sectionRefId) {
        this.sectionRefId = sectionRefId;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    @Override
    public String toString() {
        return "StudentSectionAssociation{" +
            "refId=" + refId +
            ", studentRefId=" + studentRefId +
            ", sectionRefId=" + sectionRefId +
            '}';
    }
    
}
