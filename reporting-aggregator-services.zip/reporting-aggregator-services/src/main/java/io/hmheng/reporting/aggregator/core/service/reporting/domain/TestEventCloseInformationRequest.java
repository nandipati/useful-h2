package io.hmheng.reporting.aggregator.core.service.reporting.domain;


import java.util.List;

public class TestEventCloseInformationRequest {

    List<TestEventCloseInformation> testEventCloseInformationList;

    public List<TestEventCloseInformation> getTestEventCloseInformationList() {
        return testEventCloseInformationList;
    }

    public void setTestEventCloseInformationList(List<TestEventCloseInformation> testEventCloseInformationList) {
        this.testEventCloseInformationList = testEventCloseInformationList;
    }

    @Override
    public String toString() {
        return "TestEventCloseInformationRequest{" +
                "testEventCloseInformationList=" + testEventCloseInformationList +
                '}';
    }
}
