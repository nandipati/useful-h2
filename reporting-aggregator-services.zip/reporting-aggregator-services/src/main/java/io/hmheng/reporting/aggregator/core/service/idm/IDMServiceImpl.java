package io.hmheng.reporting.aggregator.core.service.idm;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;
import com.google.common.collect.Sets;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;

import io.hmheng.reporting.aggregator.core.service.idm.domain.IDMStudentStaffResponse;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import io.hmheng.reporting.aggregator.core.service.AuthorizationService;
import io.hmheng.reporting.aggregator.core.service.clm.domain.School;
import io.hmheng.reporting.aggregator.core.service.idm.domain.IDSSection;
import io.hmheng.reporting.aggregator.core.service.idm.domain.Section;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SectionResponse;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SectionRoster;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SectionTeacher;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SectionTeacherList;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SessionSchedule;
import io.hmheng.reporting.aggregator.core.service.idm.domain.SessionScheduleList;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StaffPerson;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentDemographic;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentSectionAssociation;
import io.hmheng.reporting.aggregator.core.service.idm.domain.StudentSectionAssociationResponse;
import io.hmheng.reporting.aggregator.core.service.idm.domain.Teacher;
import io.hmheng.reporting.aggregator.core.service.idm.domain.YearGroup;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;

import static io.hmheng.reporting.aggregator.core.service.mds.MDSServiceImpl.getGsonObject;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SCHOOL_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.SECTION_REFID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.STUDENT_PERSONAL_REFID;
import static io.hmheng.reporting.aggregator.core.service.AuthorizationService.Service.IDM;


@Service
public class IDMServiceImpl implements IDMService {
    private static final Logger logger = LoggerFactory.getLogger(IDMServiceImpl.class);

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private HeadersHelper headersHelper;

    private long lastCleanup=System.currentTimeMillis();

    private static int timeExpireAfterWrite = 15;
    private static int timeCleanupCheck = 6000;

    private RemovalListener<IDMCacheKey, Set<Section>> removalListenerSection = new RemovalListener<IDMCacheKey, Set<Section>>() {
        public void onRemoval(RemovalNotification<IDMCacheKey, Set<Section>> removal) {
            logger.debug("executing removalListenerSection sectionCache:{}", sectionCache.size());
        }
    };

    private RemovalListener<IDMCacheKey, Section> removalListenerSectionDetails = new RemovalListener<IDMCacheKey, Section>() {
        public void onRemoval(RemovalNotification<IDMCacheKey, Section> removal) {
            logger.debug("executing removalListenerSectionDetails sectionDetailsCache:{}", sectionDetailsCache.size());
        }
    };

    private LoadingCache<IDMCacheKey, Set<Section>> sectionCache= CacheBuilder.newBuilder().expireAfterWrite(timeExpireAfterWrite, TimeUnit.MINUTES).
            softValues().removalListener(removalListenerSection).build(new CacheLoader<IDMCacheKey, Set<Section>>() {
        @Override
        public Set<Section> load(IDMCacheKey idmCacheKey) throws Exception {
            return getSectionsForSchoolNotCached(idmCacheKey.getUuid(), idmCacheKey.getContextId(), idmCacheKey.getPlatformId());
        }
    });

    private LoadingCache<IDMCacheKey, Section> sectionDetailsCache=CacheBuilder.newBuilder().expireAfterWrite(timeExpireAfterWrite, TimeUnit.MINUTES).
            softValues().removalListener(removalListenerSectionDetails).build(new CacheLoader<IDMCacheKey, Section>() {
        @Override
        public Section load(IDMCacheKey idmCacheKey) throws Exception {
            return getSectionsDetailsNoCache(idmCacheKey.getUuid(), idmCacheKey.getContextId(),idmCacheKey.getPlatformId());
        }
    });

    private LoadingCache<IDMCacheKey, Set<Teacher>> teacherCache=CacheBuilder.newBuilder().expireAfterWrite(timeExpireAfterWrite, TimeUnit.MINUTES).
            softValues().build(new CacheLoader<IDMCacheKey, Set<Teacher>>() {
        @Override
        public Set<Teacher> load(IDMCacheKey idmCacheKey) throws Exception {
            return getTeachersForSchoolNotCached(idmCacheKey.getUuid(), idmCacheKey.getPlatformId());
        }
    });
    private void cleanupCaches() {
        logger.debug("{}", "+cleanupCaches()");
        if((System.currentTimeMillis() - lastCleanup) > (timeCleanupCheck)) {
            synchronized (this) {
                //check again in the event another thread calls this before the refresh completes
                if((System.currentTimeMillis() - lastCleanup) > (timeCleanupCheck)) {
                    logger.debug("cleanup sectionCache:{}, sectionDetailsCache:{}", sectionCache.size(), sectionDetailsCache.size());
                    sectionCache.cleanUp();
                    sectionDetailsCache.cleanUp();
                    teacherCache.cleanUp();
                    logger.debug("cleanup sectionCache:{}, sectionDetailsCache:{}", sectionCache.size(), sectionDetailsCache.size());
                    lastCleanup = System.currentTimeMillis();
                }
            }
        }
        logger.debug("{}", "-cleanupCaches()");
    }

    @Override
    public Set<Section> getSectionsForStudent(UUID studentPersonalRefId, String contextId, String platformId) {
        logger.debug("{}", "+getSectionsForStudent(UUID)");

        SectionResponse sectionResponse = null;

        try {
            if (!StringUtils.isEmpty(platformId)) {
                List <IDSSection> schoolSections = producerTemplate.requestBodyAndHeaders(
                    IDMRouteBuilder.getSectionsForStudentIDSEndpoint,
                    "",
                    generateHeadersForStudent(getService(platformId), studentPersonalRefId, null, platformId, true),
                    List.class);
                schoolSections = objectMapper().convertValue(schoolSections, new TypeReference<List <IDSSection>>() {
                });
                if(!CollectionUtils.isEmpty(schoolSections)){
                    sectionResponse = new SectionResponse();
                }
                ArrayList<Section> sections=new ArrayList<>();
                schoolSections.stream().forEach(idsSection -> {
                    try {
                        if(getSectionsDetails(idsSection.getSectionRefId(), contextId, platformId)!=null)
                            sections.add(getSectionsDetails(idsSection.getSectionRefId(), contextId, platformId));
                        else
                            logger.info("The detailed idssection info not found for this section with contextId, platformId-{},{},{}",idsSection.getSectionRefId(), contextId, platformId);
                    } catch (Exception e) {
                        logger.error("The detailed idssection info not found for this section with contextId, platformId-{},{},{}",idsSection.getSectionRefId(), contextId, platformId);
                    }
                });
                sectionResponse.setSections(sections);
            } else {
                sectionResponse = producerTemplate.requestBodyAndHeaders(
                    IDMRouteBuilder.getSectionsForStudentEndpoint,
                    "",
                    generateHeadersForStudent(getService(null), studentPersonalRefId, contextId, null, true),
                    SectionResponse.class);
                if(sectionResponse!=null && !CollectionUtils.isEmpty(sectionResponse.getSections())) {
                    ArrayList<Section> sections=new ArrayList<>();
                    sectionResponse.getSections().stream().forEach(s -> {
                        try {
                            if(getSectionsDetails(s.getRefId(), contextId, platformId)!=null)
                            sections.add(getSectionsDetails(s.getRefId(), contextId, platformId));
                            else
                                logger.info("The detailed section info not found for this section with contextId, platformId-{},{},{}",s.getRefId(), contextId, platformId);
                        } catch (Exception e) {
                            logger.error("The detailed section info not found for this section with contextId, platformId-{},{},{}",s.getRefId(), contextId, platformId);
                        }
                    });
                    sectionResponse.setSections(sections);
                }
            }
        } catch (Exception e) {
            logger.warn("Exception from IDM in getSectionsForStudent: {}", e);

            if (isHttpResponseNotFound(e)) {
                return Sets.newHashSetWithExpectedSize(0);
            }
        }

        Set<Section> sections = null;
        if(sectionResponse!=null)
            sections=Sets.newHashSet(sectionResponse.getSections());
        else
            sections=Sets.newHashSetWithExpectedSize(0);
        logger.info("{} Sections returned: {}", sections.size(), sections.toString());

        logger.debug("{}", "-getSectionsForSchool(UUID)");

        return sections;

    }

    private ArrayList<Section> prepIdsSections(List<IDSSection> schoolSections) {
        ArrayList<Section> sections = new ArrayList<>();
        schoolSections.stream().forEach(origSect -> {
            IDSSection sect=origSect;
            Section section = new Section();
            section.setRefId(sect.getSectionRefId());
            section.setName(sect.getName());
            YearGroup yearGroup = new YearGroup();
            yearGroup.setCode(sect.getDefaultGrade());
            section.setYearGroup(yearGroup);
            if (sect.getTeachers() != null ) {
                ArrayList<SectionTeacher> sectionTeachers = new ArrayList<SectionTeacher>();
                sect.getTeachers().getLeadTeachers().stream().forEach(leadTeachers -> {
                    SectionTeacher sectionTeacher = new SectionTeacher();
                    sectionTeacher.setStaffPersonalRefId(leadTeachers.getRefId());
                    sectionTeachers.add(sectionTeacher);
                });
                sect.getTeachers().getTeamTeachers().stream().forEach(teamTeachers -> {
                    SectionTeacher sectionTeacher = new SectionTeacher();
                    sectionTeacher.setStaffPersonalRefId(teamTeachers.getRefId());
                    sectionTeachers.add(sectionTeacher);
                });
                if (sectionTeachers.size() > 0) {
                    SectionTeacherList sectionTeacherList = new SectionTeacherList();
                    sectionTeacherList.setSectionTeachers(sectionTeachers);
                    SessionSchedule sessionSchedule = new SessionSchedule();
                    sessionSchedule.setSectionTeacherList(sectionTeacherList);
                    ArrayList<SessionSchedule> sessionSchedules = new ArrayList<SessionSchedule>();
                    sessionSchedules.add(sessionSchedule);
                    SessionScheduleList sessionScheduleList = new SessionScheduleList();
                    sessionScheduleList.setSessionSchedules(sessionSchedules);
                    section.setSessionScheduleList(sessionScheduleList);
                }
            }
            sections.add(section);
        });
        return sections;
    }

    @Override
    public Set<Section> getSectionsForSchool(UUID schoolRefId, String contextId, String platformId) {
        try {
            cleanupCaches();
            return sectionCache.get(new IDMCacheKey(schoolRefId, contextId, platformId));
        } catch (ExecutionException e) {
            logger.warn("Exception from IDM: {}", e);
            return Sets.newHashSetWithExpectedSize(0);
        }
    }
    public Set<Section> getSectionsForSchoolNotCached(UUID schoolRefId, String contextId, String platformId) {
        logger.debug("{}", "+getSectionsForSchool(UUID)");

        SectionResponse sectionResponse = null;

        try {
            if (!StringUtils.isEmpty(platformId)) {
                List <IDSSection> schoolSections = producerTemplate.requestBodyAndHeaders(
                        IDMRouteBuilder.getSectionsForSchoolIDSEndpoint,
                        "",
                        generateHeadersForSchool(getService(platformId), schoolRefId, null, platformId, true),
                        List.class);
                schoolSections = objectMapper().convertValue(schoolSections, new TypeReference<List <IDSSection>>() {
                });
                if(!CollectionUtils.isEmpty(schoolSections)){
                    sectionResponse = new SectionResponse();
                }
                ArrayList<Section> sections = prepIdsSections(schoolSections);
                sectionResponse.setSections(sections);
            } else {
                sectionResponse = producerTemplate.requestBodyAndHeaders(
                        IDMRouteBuilder.getSectionsForSchoolEndpoint,
                        "",
                        generateHeadersForSchool(getService(null), schoolRefId, contextId, null, true),
                        SectionResponse.class);
            }
        } catch (Exception e) {
            logger.warn("Exception from IDM: {}", e);

            if (isHttpResponseNotFound(e)) {
                return null;
            }
        }

        Set<Section> sections = Sets.newHashSet(sectionResponse.getSections());
        logger.info("{} Sections returned: {}", sections.size(), sections.toString());

        logger.debug("{}", "-getSectionsForSchool(UUID)");

        return sections;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Set<Teacher> getTeachersForSchool(UUID schoolRefId, String platformId) {
        try {
            return teacherCache.get(new IDMCacheKey(schoolRefId, null, platformId));
        } catch (ExecutionException e) {
            logger.warn("Exception from new IDS: {}", e);

            if (isHttpResponseNotFound(e)) {
                return Sets.newHashSetWithExpectedSize(0);
            }
        }
        return null;
    }

    public Set<Teacher> getTeachersForSchoolNotCached(UUID schoolRefId, String platformId) {
        logger.debug("{}", "+getTeachersForSchool(UUID)");

        List<Teacher> teachersForSchool = null;

        try {
            teachersForSchool = producerTemplate.requestBodyAndHeaders(
                IDMRouteBuilder.getTeachersForSchoolEndpoint,
                "",
                generateHeadersForSchool(getService(platformId),schoolRefId, null , platformId, true),
                List.class);

            teachersForSchool = objectMapper().convertValue(teachersForSchool, new TypeReference<List<Teacher>>() {
            });
        } catch (Exception e) {
            logger.warn("Exception from new IDS: {}", e);
        }

        logger.info("{} Teachers returned: {}", teachersForSchool.size(), teachersForSchool.toString());

        logger.debug("{}", "-getTeachersForSchool(UUID)");
        if(!CollectionUtils.isEmpty(teachersForSchool))
            return Sets.newHashSet(teachersForSchool);
        return null;
    }

    @Override
    public Set<Teacher> getTeachersForStudent(UUID studentPersonalRefId, String platformId) {
        logger.debug("{}", "+getTeachersForStudent(UUID)");

        List<Teacher> teachersForStudent = null;

        try {
            teachersForStudent = producerTemplate.requestBodyAndHeaders(
                IDMRouteBuilder.getTeachersForStudentIDSEndpoint,
                "",
                generateHeadersForStudent(getService(platformId),studentPersonalRefId, null , platformId, true),
                List.class);

            teachersForStudent = objectMapper().convertValue(teachersForStudent, new TypeReference<List<Teacher>>() {
            });
        } catch (Exception e) {
            logger.warn("Exception from new IDS: {}", e);
        }

        logger.info("{} Teachers returned: {}", teachersForStudent.size(), teachersForStudent.toString());

        logger.debug("{}", "-getTeachersForStudent(UUID)");
        if(!CollectionUtils.isEmpty(teachersForStudent))
            return Sets.newHashSet(teachersForStudent);
        return null;
    }

    @Override
    public Set<StaffPerson> getStaffPersonsForStudent(UUID studentPersonalRefId, String contextId) {
        logger.debug("{}", "+getStaffPersonsForSchool(UUID)");

        List<StaffPerson> staffPersons = null;
        try {
            IDMStudentStaffResponse resp = producerTemplate.requestBodyAndHeaders(
                IDMRouteBuilder.getTeachersForStudentIDMEndpoint,
                "",
                generateHeadersForStudent(getService(null),studentPersonalRefId, contextId, null, false),
                IDMStudentStaffResponse.class);
            //IDMStudentStaffResponse resp = getGsonObject(rawResp, IDMStudentStaffResponse.class);
            staffPersons=CollectionUtils.arrayToList(resp.getStaffPersons());
        } catch (Exception e) {
            logger.warn("Exception from IDM: {}", e);

            if (isHttpResponseNotFound(e)) {
                return Sets.newHashSetWithExpectedSize(0);
            }
        }

        logger.info("{} StaffPersons returned: {}", staffPersons.size(), staffPersons.toString());

        logger.debug("{}", "-getStaffPersonsForSchool(UUID)");
        return Sets.newHashSet(staffPersons);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Set<StaffPerson> getStaffPersonsForSchool(UUID schoolRefId, String contextId) {
        logger.debug("{}", "+getStaffPersonsForSchool(UUID)");

        List<StaffPerson> staffPersons = null;

        try {
            staffPersons = producerTemplate.requestBodyAndHeaders(
                IDMRouteBuilder.getStaffPersonsForSchoolEndpoint,
                "",
                generateHeadersForSchool(getService(null),schoolRefId, contextId, null, false),
                List.class);

            staffPersons = objectMapper().convertValue(staffPersons, new TypeReference<List<StaffPerson>>() {
            });
        } catch (Exception e) {
            logger.warn("Exception from IDM: {}", e);

            if (isHttpResponseNotFound(e)) {
                return Sets.newHashSetWithExpectedSize(0);
            }
        }

        logger.info("{} StaffPersons returned: {}", staffPersons.size(), staffPersons.toString());

        logger.debug("{}", "-getStaffPersonsForSchool(UUID)");
        return Sets.newHashSet(staffPersons);
    }

    @Override
    public Set<StudentSectionAssociation> getStudentSectionAssociations(UUID studentPersonalRefId, String contextId, String platformId) {
        logger.debug("{}", "+getStudentSectionAssociations(UUID)");

        StudentSectionAssociationResponse sectionAssociationResponse = null;

        try {
            if(!StringUtils.isEmpty(platformId)) {
                sectionAssociationResponse=new StudentSectionAssociationResponse();
                List<IDSSection> sections = producerTemplate.requestBodyAndHeaders(
                    IDMRouteBuilder.getStudentSectionAssociationsIDSEndpoint,
                    "",
                    generateHeadersForStudent(getService(platformId),studentPersonalRefId, null, platformId, true),
                    List.class);

                sections = objectMapper().convertValue(sections, new TypeReference<List <IDSSection>>() {
                });
                ArrayList<StudentSectionAssociation> studentSectionAssociations = new ArrayList<>();
                sections.stream().forEach(sect -> {
                    StudentSectionAssociation ssa=new StudentSectionAssociation();
                    ssa.setRefId(sect.getSectionRefId());
                    ssa.setStudentRefId(studentPersonalRefId);
                    ssa.setSectionRefId(sect.getSectionRefId());
                    ssa.setGrade(sect.getDefaultGrade());
                    School school = new School();
                    school.setOrgId(sect.getSchool().getOrgId());
                    school.setSchoolName(sect.getSchool().getName());
                    ssa.setSchool(school);
                    studentSectionAssociations.add(ssa);
                });
                sectionAssociationResponse.setStudentSectionAssociations(studentSectionAssociations);
            } else {
                sectionAssociationResponse = producerTemplate.requestBodyAndHeaders(
                        IDMRouteBuilder.getStudentSectionAssociationsEndpoint,
                        "",
                        generateHeadersForStudent(getService(null),studentPersonalRefId, contextId, null, false),
                        StudentSectionAssociationResponse.class);
            }
        } catch (Exception e) {
            logger.warn("Exception from IDM: {}", e);

            if (isHttpResponseNotFound(e)) {
                return Sets.newHashSetWithExpectedSize(0);
            }
        }

        Set<StudentSectionAssociation> studentSectionAssociations = Sets
            .newHashSet(sectionAssociationResponse.getStudentSectionAssociations());
        logger.info("{} StudentSectionAssociations returned: {}", studentSectionAssociations.size(), studentSectionAssociations.toString());

        logger.debug("{}", "-getStudentSectionAssociations(UUID)");

        return studentSectionAssociations;
    }

    @Override
    public StudentDemographic getStudentDemographic(UUID studentPersonalRefId, String contextId, String plaformId) {
        logger.debug("{}", "+getStudentDemographic(UUID)");

        StudentDemographic studentDemographic;

        AuthorizationService.Service service = getService(plaformId);

        try {
            if(AuthorizationService.Service.IDM == service) {
                studentDemographic = producerTemplate.requestBodyAndHeaders(
                    IDMRouteBuilder.getStudentDemographicEndpoint,
                    "",
                    generateHeadersForStudent(getService(plaformId), studentPersonalRefId, contextId, plaformId, false),
                    StudentDemographic.class);
            }else{

                studentDemographic = producerTemplate.requestBodyAndHeaders(
                    IDMRouteBuilder.getStudentDemographicIDSEndpoint,
                    "",
                    generateHeadersForStudent(service , studentPersonalRefId, contextId, plaformId, false),
                    StudentDemographic.class);
            }
        } catch (Exception e) {
            logger.warn("Exception from IDM: {}", e);
            return null;
        }

        logger.debug("{}", "-getStudentDemographic(UUID)");
        return studentDemographic;
    }

    @Override
    public Section getSectionsDetails(UUID sectionId, String contextId, String platformId){
        Section section = null;
        try {
            cleanupCaches();
            section=sectionDetailsCache.get(new IDMCacheKey(sectionId, contextId, platformId));
        } catch (ExecutionException e) {
            logger.warn("Exception from IDM-cached: {}", e);
        }
        return section;
    }
    public Section getSectionsDetailsNoCache(UUID sectionId, String contextId, String platformId){
        logger.debug("{}", "+getSectionsDetails(UUID)");

        Section section = null;

        try {

            if(!StringUtils.isEmpty(platformId)){
              SectionRoster sectionRosters= producerTemplate.requestBodyAndHeaders(
                  IDMRouteBuilder.getSectionRosterIDSEndpoint,
                  "",
                  generateHeadersForSessionDetails(getService(platformId),sectionId, null, platformId),
                  SectionRoster.class);

              section = new Section();
              section.setRefId(sectionRosters.getSectionRefid());
              section.setName(sectionRosters.getName());
                YearGroup yearGroup = new YearGroup();
                yearGroup.setCode(sectionRosters.getDefaultGrade());
              section.setYearGroup(yearGroup);

                if (sectionRosters.getTeachers() != null ) {
                  ArrayList<SectionTeacher> sectionTeachers = new ArrayList<SectionTeacher>();
                  sectionRosters.getTeachers().stream().forEach(teacher -> {
                    SectionTeacher sectionTeacher = new SectionTeacher();
                    sectionTeacher.setStaffPersonalRefId(teacher.getRefId());
                    sectionTeachers.add(sectionTeacher);
                  });
                  if (sectionTeachers.size() > 0) {
                    SectionTeacherList sectionTeacherList = new SectionTeacherList();
                    sectionTeacherList.setSectionTeachers(sectionTeachers);
                    SessionSchedule sessionSchedule = new SessionSchedule();
                    sessionSchedule.setSectionTeacherList(sectionTeacherList);
                    ArrayList<SessionSchedule> sessionSchedules = new ArrayList<SessionSchedule>();
                    sessionSchedules.add(sessionSchedule);
                    SessionScheduleList sessionScheduleList = new SessionScheduleList();
                    sessionScheduleList.setSessionSchedules(sessionSchedules);
                    section.setSessionScheduleList(sessionScheduleList);
                  }
                }
        }

              else{

              section = producerTemplate.requestBodyAndHeaders(
                  IDMRouteBuilder.getSectionDetailsEndpoint,
                  "",
                  generateHeadersForSessionDetails(getService(null),sectionId, contextId, null),
                  Section.class);

                logger.info("In else of getSectionsDetailsNoCache - section-{}",section);
            }
        } catch (Exception e) {
            logger.warn("Exception from IDM: {}", e);
            return null;
        }
        logger.debug("{}", "-getSectionsDetails(UUID)");
        return section;
    }

    /**
     * Determine if a CamelExecutionException is a HttpOperationFailedException with statusCode 404.
     */
    private boolean isHttpResponseNotFound(Exception e) {
        return (e instanceof CamelExecutionException) && (e.getCause() instanceof HttpOperationFailedException)
            && ((HttpOperationFailedException) e.getCause()).getStatusCode() == HttpStatus.NOT_FOUND.value();

    }

    private Map<String, Object> generateHeadersForSchool(AuthorizationService.Service service, UUID schoolRefId,
                                                         String contextId, String platformId, boolean useIds) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(contextId, platformId, service, useIds);
        headers.put(SCHOOL_REFID, schoolRefId.toString());
        return headers;
    }

    private Map<String, Object> generateHeadersForSessionDetails(AuthorizationService.Service service ,UUID sectionId,
                                                                 String contextId , String platformId) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(contextId,platformId, service);
        headers.put(SECTION_REFID, sectionId.toString());
        return headers;
    }

    private Map<String, Object> generateHeadersForStudent(AuthorizationService.Service service , UUID studentPersonalRefId, String contextId, String platformId, boolean useIds) {
        Map<String, Object> headers = headersHelper.createBasicHeaders(contextId, platformId, service, useIds);
        headers.put(STUDENT_PERSONAL_REFID, studentPersonalRefId.toString());
        return headers;
    }
    
    private static ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return mapper;
    }
    class IDMCacheKey {
        private String contextId;
        private UUID uuid;
        private String platformId;

        public IDMCacheKey(UUID uuid, String contextId, String platformId) {
            this.uuid=uuid;
            this.contextId=contextId;
            this.platformId = platformId;
        }
        public IDMCacheKey(UUID uuid, String contextId) {
            this.uuid=uuid;
            this.contextId=contextId;

        }
        public String getContextId() {
            return contextId;
        }

        public UUID getUuid() {
            return uuid;
        }

        public String getPlatformId() {
            return platformId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            IDMCacheKey that = (IDMCacheKey) o;

            if (contextId != null ? !contextId.equals(that.contextId) : that.contextId != null) return false;
            return uuid.equals(that.uuid);

        }

        @Override
        public int hashCode() {
            int result = contextId != null ? contextId.hashCode() : 0;
            result = 31 * result + (uuid != null ? uuid.hashCode() : 0);
            return result;
        }
    }

    private AuthorizationService.Service getService(String plaformId) {

        if(!StringUtils.isEmpty(plaformId)){
            return EnumUtils.getEnum(AuthorizationService.Service.class , plaformId);
        }

        return IDM;
    }
}
