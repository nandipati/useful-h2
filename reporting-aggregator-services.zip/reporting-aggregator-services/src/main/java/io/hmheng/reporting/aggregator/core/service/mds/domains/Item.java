package io.hmheng.reporting.aggregator.core.service.mds.domains;

import java.util.Arrays;

public class Item
{
  private String lastModified;

  private String manuallyScorable;

  private String printable;

  private Title title;

  private String depthOfKnowledge;

  private String program;

  private String manifestId;

  private String userId;

  private String questionCount;

  private String assessmentId;

  private Question[] question;

  private StandardSet[] standardSet;

  private String identifier;

  private String poolId;

  public String getLastModified ()
  {
    return lastModified;
  }

  public void setLastModified (String lastModified)
  {
    this.lastModified = lastModified;
  }

  public String getManuallyScorable ()
  {
    return manuallyScorable;
  }

  public void setManuallyScorable (String manuallyScorable)
  {
    this.manuallyScorable = manuallyScorable;
  }

  public String getPrintable ()
  {
    return printable;
  }

  public void setPrintable (String printable)
  {
    this.printable = printable;
  }

  public Title getTitle ()
  {
    return title;
  }

  public void setTitle (Title title)
  {
    this.title = title;
  }

  public String getDepthOfKnowledge ()
  {
    return depthOfKnowledge;
  }

  public void setDepthOfKnowledge (String depthOfKnowledge)
  {
    this.depthOfKnowledge = depthOfKnowledge;
  }

  public String getProgram ()
  {
    return program;
  }

  public void setProgram (String program)
  {
    this.program = program;
  }

  public String getManifestId ()
  {
    return manifestId;
  }

  public void setManifestId (String manifestId)
  {
    this.manifestId = manifestId;
  }

  public String getUserId ()
  {
    return userId;
  }

  public void setUserId (String userId)
  {
    this.userId = userId;
  }

  public String getQuestionCount ()
  {
    return questionCount;
  }

  public void setQuestionCount (String questionCount)
  {
    this.questionCount = questionCount;
  }

  public String getAssessmentId ()
  {
    return assessmentId;
  }

  public void setAssessmentId (String assessmentId)
  {
    this.assessmentId = assessmentId;
  }

  public Question[] getQuestion ()
  {
    return question;
  }
  public Question getFirstQuestion() {
    if(question!=null && question.length > 0)
      return question[0];
    return null;
  }
  public void setQuestion (Question[] question)
  {
    this.question = question;
  }

  public StandardSet[] getStandardSet ()
  {
    return standardSet;
  }

  public void setStandardSet (StandardSet[] standardSet)
  {
    this.standardSet = standardSet;
  }

  public String getIdentifier ()
  {
    return identifier;
  }

  public void setIdentifier (String identifier)
  {
    this.identifier = identifier;
  }

  public String getPoolId ()
  {
    return poolId;
  }

  public void setPoolId (String poolId)
  {
    this.poolId = poolId;
  }

  @Override
  public String toString()
  {
    return "ClassPojo [lastModified = "+lastModified+", manuallyScorable = "+manuallyScorable+", printable = "
        + ""+printable+", title = "+title+", depthOfKnowledge = "+depthOfKnowledge+", program = "+program+", "
        + "manifestId = "+manifestId+", userId = "+userId+", questionCount = "+questionCount+", assessmentId = "
        + ""+assessmentId+", question = "+Arrays.toString(question)+","
        + " standardSet = "+ Arrays.toString(standardSet)+", identifier = "+identifier+", poolId = "+poolId+"]";
  }

}
