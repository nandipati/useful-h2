package io.hmheng.reporting.aggregator.core.service.reporting.domain;

/**
 * Created by pabonaj on 2/8/17.
 */
public class BenchmarkActivitiesResponse {

    public BenchmarkActivities getBenchmarkActivities() {
        return benchmarkActivities;
    }

    public void setBenchmarkActivities(BenchmarkActivities benchmarkActivities) {
        this.benchmarkActivities = benchmarkActivities;
    }

    private BenchmarkActivities benchmarkActivities;

}