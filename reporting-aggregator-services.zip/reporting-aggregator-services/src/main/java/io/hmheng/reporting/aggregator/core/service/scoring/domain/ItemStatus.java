package io.hmheng.reporting.aggregator.core.service.scoring.domain;

/**
 * Created by pabonaj on 9/1/17.
 */
public enum ItemStatus {

  NOT_STARTED,
  IN_PROGRESS,
  COMPLETED

}
