package io.hmheng.reporting.aggregator.core.service.clm.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "lea", namespace = "ns3")
@JsonIgnoreProperties(ignoreUnknown = true)
public class District {

    public static final String NO_DISTRICT_LEA_NAME = "Independent School";

    public static final District NO_DISTRICT;

    static {
        NO_DISTRICT = new District();
        NO_DISTRICT.setLeaName(NO_DISTRICT_LEA_NAME);
    }

    private String leaName;

    public String getLeaName() {
        return leaName;
    }

    public void setLeaName(String leaName) {
        this.leaName = leaName;
    }

    @Override
    public String toString() {
        return "District [leaName=" + leaName + "]";
    }
}
