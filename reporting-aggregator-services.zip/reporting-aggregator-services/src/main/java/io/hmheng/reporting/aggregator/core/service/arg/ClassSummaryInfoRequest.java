package io.hmheng.reporting.aggregator.core.service.arg;

import java.util.UUID;

public class ClassSummaryInfoRequest {
    private UUID eventId;
    private UUID sectionId;
    private UUID activityId;

    public ClassSummaryInfoRequest(UUID eventId, UUID activityId , UUID sectionId){
        this.eventId = eventId;
        this.activityId = activityId;
        this.sectionId = sectionId;
    }

    public UUID getEventId() {
        return eventId;
    }

    public void setEventId(UUID eventId) {
        this.eventId = eventId;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }
}
