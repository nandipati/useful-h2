package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import java.util.List;
import java.util.UUID;

import io.hmheng.reporting.aggregator.core.service.scoring.domain.DomainStandard;

/**
 * Created by suryadevarap on 4/6/18.
 */
public class ScoringStandardSet {

  private String standardSetName;
  private List<UUID> domainId;

  public String getStandardSetName() {
    return standardSetName;
  }

  public void setStandardSetName(String standardSetName) {
    this.standardSetName = standardSetName;
  }

  public List<UUID> getDomainId() {
    return domainId;
  }

  public void setDomainId(List<UUID> domainId) {
    this.domainId = domainId;
  }
}
