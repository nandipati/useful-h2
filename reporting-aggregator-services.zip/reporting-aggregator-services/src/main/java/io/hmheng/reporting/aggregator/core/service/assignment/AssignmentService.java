package io.hmheng.reporting.aggregator.core.service.assignment;

import io.hmheng.reporting.aggregator.core.service.assignments.domain.StudentAssignmentsResponse;
import java.util.UUID;
/**
 * Created by jayachandranj on 2/27/17.
 */
public interface AssignmentService {

    StudentAssignmentsResponse getStudentSessionIds(UUID testEventId, String assignmentStatus);
}
