package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.List;

public class SessionScheduleList {

    private List<SessionSchedule> sessionSchedules;

    public List<SessionSchedule> getSessionSchedules() {
        return sessionSchedules;
    }

    public void setSessionSchedules(List<SessionSchedule> sessionSchedules) {
        this.sessionSchedules = sessionSchedules;
    }

    @Override
    public String toString() {
        return "SessionScheduleList{" +
            "sessionSchedules=" + sessionSchedules +
            '}';
    }
    
}
