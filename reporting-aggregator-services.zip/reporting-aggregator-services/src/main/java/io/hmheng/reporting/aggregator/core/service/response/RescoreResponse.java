package io.hmheng.reporting.aggregator.core.service.response;


import io.hmheng.reporting.aggregator.core.service.grading.domain.PushScoreStatus;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.LearnosityServiceResponse;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.Meta;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionResponse;
import io.hmheng.reporting.aggregator.core.service.learnosity.domain.SessionsResponsesResponse;

import java.util.List;

/**
 * Created by mfeng on 10/19/17.
 */
public class RescoreResponse {

    LearnosityServiceResponse autoRescoreResponse;

    List<PushScoreStatus> manualRescoreResponse;

    public LearnosityServiceResponse getAutoRescoreResponse() {
        return autoRescoreResponse;
    }

    public void setAutoRescoreResponse(LearnosityServiceResponse autoRescoreResponse) {
        this.autoRescoreResponse = autoRescoreResponse;
    }

    public List<PushScoreStatus> getManualRescoreResponse() {
        return manualRescoreResponse;
    }

    public void setManualRescoreResponse(List<PushScoreStatus> manualRescoreResponse) {
        this.manualRescoreResponse = manualRescoreResponse;
    }
}
