package io.hmheng.reporting.aggregator.core.service.reporting;


import com.fasterxml.jackson.core.type.TypeReference;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsPerformance;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentClassSummaryInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentScoreInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.AssignmentStudentStandardScoreRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkSession;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ClassStudentInformationListRequest;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.ActivityStandardsToItemsMapInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentDemographicInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSectionInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.StudentSession;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventCloseInformation;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TestEventInfo;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.TotalScore;
import io.hmheng.reporting.aggregator.core.service.reporting.domain.BenchmarkActivity;
import io.hmheng.reporting.aggregator.web.domain.assignment.EventDetailsBatch;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public interface ReportingService {

    static int NO_OF_RETRY = 1;


    void publishClassInfo(UUID eventRefId, ClassStudentInformationListRequest request);

	  void publishClassInfoOnStudentUpdate(UUID studentRefId, StudentSectionInformation request);

    void publishStudentDemographicInfo(UUID eventRefId, UUID studentRefId, StudentDemographicInformation demographicInformation);

	  boolean checkIfStudentExists(UUID studentRefId);

	  void updateStudentDemographicInfo(UUID studentRefId, StudentDemographicInformation demographicInformation);

    void publishTestEventCloseLprs(UUID testEventRefId, UUID activityId, List<TestEventCloseInformation> testEventCloseInformationList);

    void publishAssignmentEventDetails(AssignmentEventInfo assignmentEventInfo);

    void publishTestEventDetails(TestEventInfo testEventInfo);

    void publishTestEventDetails(UUID activityId ,TestEventInfo testEventInfo);

    void publishBenchmarkStudentScores(UUID activityId , UUID sessionId , UUID studentPersonalRefId, TotalScore score);

    void publishAssignmentStudentScores(UUID activityId , UUID studentPersonalRefId, UUID sessionId
            , AssignmentStudentScoreInfo assignmentStudentScoreInfo , int noOfRetries);

    void pusblishAssignmentStandardScores(UUID activityId , UUID studentPersonalRefId
            , AssignmentStudentStandardScoreRequest assignmentStudentStandardScoreInfo);

    void publishAssignmentStandardPerformance(UUID activityId , ActivityStandardsToItemsMapInfo saveActivityPerformanceInfo);

    void publishClassSummaryInfo(UUID activityId, AssignmentClassSummaryInfo assignmentClassSummaryInfo);

    void publishReopenedTestEventDetails(UUID refId, TestEventInfo testEventInfo);

    void publishTestEventActivityReopen(UUID testEventRefId, UUID activityId, List<TestEventCloseInformation> testEventCloseInformationList);
    void postStudentDetails(UUID eventID, List<StudentInfo> studentInfoList);



    <T> void addToCache(String id, T thing);

    <T> T getCachedObjects(String[] ids, TypeReference<T> type);

    <T> T getCachedObject(String id, TypeReference<T> type);

    List<StudentSession> getStudentSessionByTestEvent(UUID testEventId);

    List<StudentSession>  getStudentSessionByActivity(UUID activityId);

    List<SessionId> getAllSessionIds(LocalDateTime startDate,LocalDateTime endDate);

    List<BenchmarkSession> getBenchmarkStudentSessionNoScores(LocalDateTime startDate, LocalDateTime endDate);

    List<StudentSession> getTestEventSessions(UUID eventRefId, String eventStatus);

    List<BenchmarkActivity> getTestEventActivities(UUID eventRefId);

    AssignmentEventInfo getAssignmentForActivity(UUID activityId);

    String deleteTeacherAssignment(UUID eventRefId);

    List<ActivityStandardsPerformance> getStandardsToItemsMapInfo(UUID activityId);

    List<EventDetailsBatch> getAssignmentDetails(List<UUID> eventRefId);

}
