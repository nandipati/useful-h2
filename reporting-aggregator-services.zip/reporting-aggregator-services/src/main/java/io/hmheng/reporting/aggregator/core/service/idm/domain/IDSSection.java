package io.hmheng.reporting.aggregator.core.service.idm.domain;

import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by pabonaj on 2/17/17.
 */
public class IDSSection {

    private UUID sectionRefId;
    private String classLocalId;
    private String name;
    private String defaultGrade;
    private List<String> grades;
    private Teachers teachers;
    private IDSSchool school;

    static String ZERO_GRADE = "0";

    public Teachers getTeachers() {
        return teachers;
    }

    public void setTeachers(Teachers teachers) {
        this.teachers = teachers;
    }

    public UUID getSectionRefId() {
        return sectionRefId;
    }

    public void setSectionRefId(UUID sectionRefId) {
        this.sectionRefId = sectionRefId;
    }

    public String getClassLocalId() {
        return classLocalId;
    }

    public void setClassLocalId(String classLocalId) {
        this.classLocalId = classLocalId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDefaultGrade() {
        String grade = defaultGrade;
        if (grade != null) {
            if (StringUtils.isNumeric(grade)) {
                StringUtils.leftPad(grade, 2, ZERO_GRADE);
            }
        }
        return grade;
    }

    public void setDefaultGrade(String defaultGrade) {
        this.defaultGrade = defaultGrade;
    }

    public List<String> getGrades() {
        if (grades != null) {
            List<String> paddedGrades = new ArrayList<>();
            for (String grade: grades) {
                if (StringUtils.isNumeric(grade)) {
                    StringUtils.leftPad(grade, 2, ZERO_GRADE);
                }
                paddedGrades.add(grade);
            }
            return paddedGrades;
        }
        return grades;
    }

    public void setGrades(List<String> grades) {
        this.grades = grades;
    }

    public IDSSchool getSchool() {
        return school;
    }

    public void setSchool(IDSSchool school) {
        this.school = school;
    }

    @Override
    public String toString() {
        return "IDSSection{" +
                "sectionRefId=" + sectionRefId +
                ", classLocalId='" + classLocalId + '\'' +
                ", name='" + name + '\'' +
                ", defaultGrade='" + defaultGrade + '\'' +
                ", grades='" + grades + '\'' +
                ", teachers='" + teachers + '\'' +
                ", school=" + school +
                '}';
    }
}
