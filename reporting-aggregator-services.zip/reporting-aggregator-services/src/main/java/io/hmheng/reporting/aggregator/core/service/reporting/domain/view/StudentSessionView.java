package io.hmheng.reporting.aggregator.core.service.reporting.domain.view;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

/**
 * Created by pabonaj on 10/12/16.
 */
public class StudentSessionView {

    @JsonProperty("session_id")
    private List<UUID> sessionList;

    public List<UUID> getSessionList() {
        return sessionList;
    }

    public void setSessionList(List<UUID> sessionList) {
        this.sessionList = sessionList;
    }

}
