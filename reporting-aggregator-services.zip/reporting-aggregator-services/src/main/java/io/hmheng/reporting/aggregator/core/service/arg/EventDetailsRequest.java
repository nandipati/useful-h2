package io.hmheng.reporting.aggregator.core.service.arg;

import io.hmheng.reporting.aggregator.web.domain.assignment.Group;
import org.joda.time.DateTime;

import java.util.List;
import java.util.UUID;

import io.hmheng.reporting.aggregator.web.domain.assignment.AssignmentStatus;
import io.hmheng.reporting.aggregator.web.domain.assignment.SourceObjectType;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestingEventStatus;

/**
 * Created by nandipatim on 2/29/16.
 */
public class EventDetailsRequest {

    private UUID refId;
    private String eventName;
    private UUID activityId;
    private UUID sectionId;
    private String isbn;
    private String assessmentName;
    private AssignmentStatus status;
    private TestingEventStatus eventStatus;
    private SourceObjectType sourceObjectType;
    private DateTime dueDate;
    private DateTime availableDate;
    private DateTime originalStartDate;
    private DateTime originalFinishDate;
    private String contextId;
    private String discipline;
    private DateTime normDate;
    private String product;
    private String programName;
    private String grade;
    private String level;
    private String resourceId;
    private String platformId;
    private String programId;
    private Boolean manualScoringRequired;
    private UUID staffPersonalRefId;
    private UUID leaRefId;
    private List<Group> groups;


    public EventDetailsRequest(UUID refId , String eventName){
        this.refId = refId;
        this.eventName = eventName;
    }

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }


    public UUID getleaRefId() {
        return leaRefId;
    }

    public void setleaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    public UUID getRefId() {
        return refId;
    }

    public void setRefId(UUID refId) {
        this.refId = refId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public UUID getSectionId() {
        return sectionId;
    }

    public void setSectionId(UUID sectionId) {
        this.sectionId = sectionId;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public AssignmentStatus getStatus() {
        return status;
    }

    public void setStatus(AssignmentStatus status) {
        this.status = status;
    }

    public SourceObjectType getSourceObjectType() {
        return sourceObjectType;
    }

    public void setSourceObjectType(SourceObjectType sourceObjectType) {
        this.sourceObjectType = sourceObjectType;
    }

    public DateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(DateTime dueDate) {
        this.dueDate = dueDate;
    }

    public DateTime getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(DateTime availableDate) {
        this.availableDate = availableDate;
    }

    public String getContextId() {
        return contextId;
    }

    public void setContextId(String contextId) {
        this.contextId = contextId;
    }

    public TestingEventStatus getEventStatus() {
        return eventStatus;
    }

    public void setEventStatus(TestingEventStatus eventStatus) {
        this.eventStatus = eventStatus;
    }

    public String getDiscipline() {
        return discipline;
    }

    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    public DateTime getNormDate() {
        return normDate;
    }

    public void setNormDate(DateTime normDate) {
        this.normDate = normDate;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public DateTime getOriginalStartDate() {
        return originalStartDate;
    }

    public void setOriginalStartDate(DateTime originalStartDate) {
        this.originalStartDate = originalStartDate;
    }

    public DateTime getOriginalFinishDate() {
        return originalFinishDate;
    }

    public void setOriginalFinishDate(DateTime originalFinishDate) {
        this.originalFinishDate = originalFinishDate;
    }

    public String getPlatformId() {
      return platformId;
    }

    public void setPlatformId(String platformId) {
      this.platformId = platformId;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public Boolean getManualScoringRequired() {
        return manualScoringRequired;
    }

    public void setManualScoringRequired(Boolean manualScoringRequired) {
        this.manualScoringRequired = manualScoringRequired;
    }

    public UUID getStaffPersonalRefId() {
        return staffPersonalRefId;
    }

    public void setStaffPersonalRefId(UUID staffPersonalRefId) {
        this.staffPersonalRefId = staffPersonalRefId;
    }
}
