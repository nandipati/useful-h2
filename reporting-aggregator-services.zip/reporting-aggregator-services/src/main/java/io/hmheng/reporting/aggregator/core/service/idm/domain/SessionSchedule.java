package io.hmheng.reporting.aggregator.core.service.idm.domain;

public class SessionSchedule {

    private SectionTeacherList sectionTeacherList;

    public SectionTeacherList getSectionTeacherList() {
        return sectionTeacherList;
    }

    public void setSectionTeacherList(SectionTeacherList sectionTeacherList) {
        this.sectionTeacherList = sectionTeacherList;
    }

    @Override
    public String toString() {
        return "SessionSchedule{" +
            "sectionTeacherList=" + sectionTeacherList +
            '}';
    }
    
}
