package io.hmheng.reporting.aggregator.core.service.learnosity;

import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.core.service.utils.Headers;
import io.hmheng.reporting.aggregator.core.service.mds.MessageProcessor;
import io.hmheng.reporting.aggregator.core.service.mds.domains.ItemsExternalRefIdResponse;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import static io.hmheng.reporting.aggregator.Constants.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTHORIZATION;
import static io.hmheng.reporting.aggregator.core.service.utils.Headers.AUTH_CURRENT_DATE_TIME;

/**
 * Created by pabonaj on 9/19/16.
 */
@Component
public class LearnosityRouteBuilder extends RouteBuilder {

    public static final String jobsSessionsScoresSubscores = "jobsSessionsScoresSubscores";
    public static final String sessionsResponses = "sessionsResponses";

    public static final String postJobsSessionsScoresSubscoresEndpoint = "direct://postJobsSessionsScoresSubscoresEndpoint";
    public static final String postSessionsResponsesEndpoint = "direct://postSessionsResponsesEndpoint";

    @Value("${learnosity.host.baseUrl}")
    public String learnosityHost;

    @Value("${learnosity.host.version}")
    public String version;

    @Autowired
    private MessageProcessor messageProcessor;

    @Override
    public final void configure() throws Exception {

       configurePostEndpoint(
                postJobsSessionsScoresSubscoresEndpoint,
                jobsSessionsScoresSubscores,
                "/" + version + "/jobs/sessions/scores/subscores");

        configurePostEndpoint(
                postSessionsResponsesEndpoint,
                sessionsResponses,
                "/" + version + "/sessions/responses");
    }

    private void configureEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod) {
        configureEndpoint(endpoint, routeId, url, httpMethod, MediaType.APPLICATION_FORM_URLENCODED);
    }

    private void configureEndpoint(String endpoint, String routeId, String url, HttpMethods httpMethod, MediaType mediaType) {
        from(endpoint)
                .id(routeId)
                .setHeader(Exchange.HTTP_METHOD, constant(httpMethod))
                .setHeader(Exchange.CONTENT_TYPE, constant(mediaType))
                .setHeader(AUTHORIZATION, simple("${header." + AUTHORIZATION + "}"))
                .setHeader(AUTH_CURRENT_DATE_TIME, simple("${header." + AUTH_CURRENT_DATE_TIME + "}"))
                .setHeader(CORRELATION_ID, simple("${header." + CORRELATION_ID + "}"))
                .setHeader(Constants.SPAN_ID, simple("${header." + Constants.SPAN_ID + "}"))
                .recipientList(simple(learnosityHost + url))
                .process(messageProcessor)
                .end();
    }

    private void configurePostEndpoint(String endpoint, String routeId, String url) {
        configureEndpoint(endpoint, routeId, url, HttpMethods.POST);
    }

}

