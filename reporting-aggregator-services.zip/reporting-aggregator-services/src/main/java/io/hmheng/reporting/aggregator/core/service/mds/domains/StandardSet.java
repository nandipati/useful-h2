package io.hmheng.reporting.aggregator.core.service.mds.domains;

import java.util.Arrays;

public class StandardSet
{
  private String region;

  private Standard[] standard;

  private String name;

  private String provider;

  public String getRegion ()
  {
    return region;
  }

  public void setRegion (String region)
  {
    this.region = region;
  }

  public Standard[] getStandard ()
  {
    return standard;
  }

  public void setStandard (Standard[] standard)
  {
    this.standard = standard;
  }

  public String getName ()
  {
    return name;
  }

  public void setName (String name)
  {
    this.name = name;
  }

  public String getProvider ()
  {
    return provider;
  }

  public void setProvider (String provider)
  {
    this.provider = provider;
  }

  public static StandardSet getSimpleStandardSet(StandardSet source) {
    if(source==null)
      return null;
    StandardSet ss = new StandardSet();
    ss.setName(source.getName());
    ss.setRegion(source.getRegion());
    ss.setProvider(source.getProvider());
    return ss;
  }
  @Override
  public String toString()
  {
    return "ClassPojo [region = "+region+", standard = "+ Arrays.toString(standard)+", name = "+name+", provider = "
        + ""+provider+"]";
  }
}
