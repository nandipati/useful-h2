package io.hmheng.reporting.aggregator.core.service.idm.domain;

import java.util.List;

public class SectionTeacherList {

    private List<SectionTeacher> sectionTeachers;

    public List<SectionTeacher> getSectionTeachers() {
        return sectionTeachers;
    }
    
    public void setSectionTeachers(List<SectionTeacher> sectionTeachers) {
        this.sectionTeachers = sectionTeachers;
    }

    @Override
    public String toString() {
        return "SectionTeacherList{" +
            "sectionTeachers=" + sectionTeachers +
            '}';
    }
    
}
