package io.hmheng.reporting.aggregator.core.service.clm;

import java.util.UUID;

import io.hmheng.reporting.aggregator.core.service.clm.domain.District;
import io.hmheng.reporting.aggregator.core.service.clm.domain.School;

public interface ClmService {

    School getSchool(UUID schoolRefId);

    District getDistrict(UUID leaRefId);
}
