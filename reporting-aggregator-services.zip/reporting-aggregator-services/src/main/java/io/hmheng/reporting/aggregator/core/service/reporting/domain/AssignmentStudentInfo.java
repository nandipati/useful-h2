package io.hmheng.reporting.aggregator.core.service.reporting.domain;


import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;



@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentStudentInfo {

    private UUID eventRefId;

    private List<StudentInfo> students = new ArrayList<>();

    public List<StudentInfo> getStudents() {
        return students;
    }

    public void setStudents(List<StudentInfo> students) {
        this.students = students;
    }


    public UUID getEventRefId() {
        return eventRefId;
    }

    public void setEventRefId(UUID eventRefId) {
        this.eventRefId = eventRefId;
    }

    @Override
    public String toString() {
        return "AssignmentStudentInfo{" + "eventRefId=" + eventRefId + ", students=" + students + '}';
    }
}
