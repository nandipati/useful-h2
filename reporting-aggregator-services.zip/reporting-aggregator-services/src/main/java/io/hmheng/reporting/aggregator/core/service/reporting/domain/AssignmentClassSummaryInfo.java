package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.util.List;
import org.springframework.util.CollectionUtils;

public class AssignmentClassSummaryInfo {
    private Double classProficiencyAverage;
    private Double classPointsAverage;
    private Double classCorrectItems;
    private Integer studentIncludedCount;
    private Integer advancedStudentsCount;
    private Double advancedStudentsPercentage;
    private Integer proficientStudentsCount;
    private Double proficientStudentsPercentage;
    private Integer basicStudentsCount;
    private Double basicStudentsPercentage;
    private Integer belowBasicStudentsCount;
    private Double belowBasicStudentsPercentage;
    private Integer farBelowBasicStudentsCount;
    private Double farBelowBasicStudentsPercentage;
    private Integer itemsCount;
    private Integer availablePoints;
    private TestType testType;
    private Long band1Id;
    private Long band2Id;
    private Long band3Id;
    private Long band4Id;
    private Long band5Id;
    private List<PerformanceLevel> performanceLevels;

    public Integer getStudentIncludedCount() {
        return studentIncludedCount;
    }

    public void setStudentIncludedCount(Integer studentIncludedCount) {
        this.studentIncludedCount = studentIncludedCount;
    }

    public Integer getAdvancedStudentsCount() {
        return advancedStudentsCount;
    }

    public void setAdvancedStudentsCount(Integer advancedStudentsCount) {
        this.advancedStudentsCount = advancedStudentsCount;
    }

    public Double getAdvancedStudentsPercentage() {
        return advancedStudentsPercentage;
    }

    public void setAdvancedStudentsPercentage(Double advancedStudentsPercentage) {
        this.advancedStudentsPercentage = advancedStudentsPercentage;
    }

    public Integer getProficientStudentsCount() {
        return proficientStudentsCount;
    }

    public void setProficientStudentsCount(Integer proficientStudentsCount) {
        this.proficientStudentsCount = proficientStudentsCount;
    }

    public Double getProficientStudentsPercentage() {
        return proficientStudentsPercentage;
    }

    public void setProficientStudentsPercentage(Double proficientStudentsPercentage) {
        this.proficientStudentsPercentage = proficientStudentsPercentage;
    }

    public Integer getBasicStudentsCount() {
        return basicStudentsCount;
    }

    public void setBasicStudentsCount(Integer basicStudentsCount) {
        this.basicStudentsCount = basicStudentsCount;
    }

    public Double getBasicStudentsPercentage() {
        return basicStudentsPercentage;
    }

    public void setBasicStudentsPercentage(Double basicStudentsPercentage) {
        this.basicStudentsPercentage = basicStudentsPercentage;
    }

    public Integer getBelowBasicStudentsCount() {
        return belowBasicStudentsCount;
    }

    public void setBelowBasicStudentsCount(Integer belowBasicStudentsCount) {
        this.belowBasicStudentsCount = belowBasicStudentsCount;
    }

    public Double getBelowBasicStudentsPercentage() {
        return belowBasicStudentsPercentage;
    }

    public void setBelowBasicStudentsPercentage(Double belowBasicStudentsPercentage) {
        this.belowBasicStudentsPercentage = belowBasicStudentsPercentage;
    }

    public Integer getFarBelowBasicStudentsCount() {
        return farBelowBasicStudentsCount;
    }

    public void setFarBelowBasicStudentsCount(Integer farBelowBasicStudentsCount) {
        this.farBelowBasicStudentsCount = farBelowBasicStudentsCount;
    }

    public Double getFarBelowBasicStudentsPercentage() {
        return farBelowBasicStudentsPercentage;
    }

    public void setFarBelowBasicStudentsPercentage(Double farBelowBasicStudentsPercentage) {
        this.farBelowBasicStudentsPercentage = farBelowBasicStudentsPercentage;
    }

    public Integer getItemsCount() {
        return itemsCount;
    }

    public void setItemsCount(Integer itemsCount) {
        this.itemsCount = itemsCount;
    }

    public Integer getAvailablePoints() {
        return availablePoints;
    }

    public void setAvailablePoints(Integer availablePoints) {
        this.availablePoints = availablePoints;
    }

    public Double getClassProficiencyAverage() {
        return classProficiencyAverage;
    }

    public void setClassProficiencyAverage(Double classProficiencyAverage) {
        this.classProficiencyAverage = classProficiencyAverage;
    }

    public Double getClassPointsAverage() {
        return classPointsAverage;
    }

    public void setClassPointsAverage(Double classPointsAverage) {
        this.classPointsAverage = classPointsAverage;
    }

    public Double getClassCorrectItems() {
        return classCorrectItems;
    }

    public void setClassCorrectItems(Double classCorrectItems) {
        this.classCorrectItems = classCorrectItems;
    }

    public TestType getTestType() {
        return testType;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public Long getBand1Id() {
        return band1Id;
    }

    public Long getBand2Id() {
        return band2Id;
    }

    public Long getBand3Id() {
        return band3Id;
    }

    public Long getBand4Id() {
        return band4Id;
    }

    public Long getBand5Id() {
        return band5Id;
    }

    public List<PerformanceLevel> getPerformanceLevels() {
        return performanceLevels;
    }

    public AssignmentClassSummaryInfo withClassProficiencyAverage(Double classProficiencyAvg) {
        this.classProficiencyAverage = classProficiencyAvg;
        return this;
    }

    public AssignmentClassSummaryInfo withClassPointsAverage(Double classPointsAvg) {
        this.classPointsAverage = classPointsAvg;
        return this;
    }

    public AssignmentClassSummaryInfo withCorrectItems(double correctItems) {
        this.classCorrectItems = correctItems;
        return this;
    }

    public AssignmentClassSummaryInfo withItemsCount(int itemsCount) {
        this.itemsCount = itemsCount;
        return this;
    }

    public AssignmentClassSummaryInfo withAvailablePoints(int availablePoints) {
        this.availablePoints = availablePoints;
        return this;
    }

    public AssignmentClassSummaryInfo withTestType(TestType testType){
        this.testType = testType;
        return this;
    }

    public AssignmentClassSummaryInfo withPerformanceLevelInfo(StudentPerformanceLevelInfo studentPerformanceLevelInfo) {
        this.studentIncludedCount = studentPerformanceLevelInfo.getStudentIncludedCount();
        this.advancedStudentsCount = studentPerformanceLevelInfo.getAdvancedStudentCount();
        this.advancedStudentsPercentage = studentPerformanceLevelInfo.getAdvancedStudentPercentage();
        this.proficientStudentsCount = studentPerformanceLevelInfo.getProficientStudentCount();
        this.proficientStudentsPercentage = studentPerformanceLevelInfo.getProficientStudentPercentage();
        this.basicStudentsCount = studentPerformanceLevelInfo.getBasicStudentCount();
        this.basicStudentsPercentage = studentPerformanceLevelInfo.getBasicStudentPercentage();
        this.belowBasicStudentsCount = studentPerformanceLevelInfo.getBelowBasicStudentCount();
        this.belowBasicStudentsPercentage = studentPerformanceLevelInfo.getBelowBasicStudentPercentage();
        this.farBelowBasicStudentsCount = studentPerformanceLevelInfo.getFarBelowBasicStudentCount();
        this.farBelowBasicStudentsPercentage = studentPerformanceLevelInfo.getFarBelowBasicStudentPercentage();
        return this;
    }

    public AssignmentClassSummaryInfo withPerformanceBandIdsForLevels(TestType testType){

        performanceLevels = PerformanceLevel.getBandsForTestType(testType);

        if(!CollectionUtils.isEmpty(performanceLevels)){
            for (PerformanceLevel performanceLevel : performanceLevels){
                if(performanceLevel.getBandOrder() == 1){
                    this.band1Id = performanceLevel.getBandId();
                }else if(performanceLevel.getBandOrder() == 2){
                    this.band2Id = performanceLevel.getBandId();
                }else if(performanceLevel.getBandOrder() == 3){
                    this.band3Id = performanceLevel.getBandId();
                }else if(performanceLevel.getBandOrder() == 4){
                    this.band4Id = performanceLevel.getBandId();
                }else if(performanceLevel.getBandOrder() == 5){
                    this.band5Id = performanceLevel.getBandId();
                }
            }
        }

        return this;
    }
}
