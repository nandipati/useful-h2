package io.hmheng.reporting.aggregator.core.service.scoring.domain;

/**
 * Created by pabonaj on 5/2/17.
 */
public enum FailureType {

    PROCESS_LOOKUP("PROCESS_LOOKUP"), POST_SCORES("POST_SCORES"), DATA_INTEGRITY("DATA_INTEGRITY"), NONE("NONE");


    private final String type;

    FailureType(String type) {
            this.type = type;
        }

    @Override
    public String toString() {
        return this.type;
    }

    public static boolean contains(String name) {
        for (FailureType t : FailureType.values()) {
            if (t.type.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

}
