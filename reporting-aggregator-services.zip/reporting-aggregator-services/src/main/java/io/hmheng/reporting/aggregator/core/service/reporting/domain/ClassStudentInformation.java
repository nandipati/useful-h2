package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ClassStudentInformation {

    private UUID sessionRefId;
    private UUID activityRefId;
    @JsonProperty("studentPersonRefId")
    private UUID studentPersonRefId;
    @JsonProperty("eventClassViews")
    private List<EventClassInfo> eventClassViews = new ArrayList<>();

    private TestType testType;

    public UUID getSessionRefId() {
        return sessionRefId;
    }

    public void setSessionRefId(UUID sessionId) {
        this.sessionRefId = sessionId;
    }

    public UUID getStudentPersonRefId() {
        return studentPersonRefId;
    }

    public void setStudentPersonRefId(UUID studentPersonRefId) {
        this.studentPersonRefId = studentPersonRefId;
    }

    public List<EventClassInfo> getEventClassViews() {
        return eventClassViews;
    }

    public void setEventClassViews(List<EventClassInfo> testEventClassInfos) {
        this.eventClassViews = testEventClassInfos;
    }
    
    public void addTestEventClassInfo(EventClassInfo testEventClassInfo) {
        eventClassViews.add(testEventClassInfo);
    }

    public UUID getActivityRefId() {
        return activityRefId;
    }

    public void setActivityRefId(UUID activityRefId) {
        this.activityRefId = activityRefId;
    }

    public void setTestType(TestType testType) {
        this.testType = testType;
    }

    public TestType getTestType() {
        return testType;
    }
}
