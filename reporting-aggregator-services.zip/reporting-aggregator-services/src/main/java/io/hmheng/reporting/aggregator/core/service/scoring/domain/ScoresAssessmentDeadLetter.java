package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import org.joda.time.DateTime;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import java.util.UUID;

/**
 * Created by pabonaj on 4/27/17.
 */
public class ScoresAssessmentDeadLetter {

  private String scoresAssessmentDeadletterId;
  private UUID messageId;
  private String failureType;
  private String failureEventType;
  private String exception;
  private String data;
  private Integer status;
  private DateTime failureDate;

  public String getScoresAssessmentDeadletterId() {
    return scoresAssessmentDeadletterId;
  }

  public void setScoresAssessmentDeadletterId(String scoresAssessmentDeadletterId) {
    this.scoresAssessmentDeadletterId = scoresAssessmentDeadletterId;
  }

  public UUID getMessageId() {
    return messageId;
  }

  public void setMessageId(UUID messageId) {
    this.messageId = messageId;
  }

  public String getFailureType() {
        return failureType;
    }

  public void setFailureType(String failureType) {
        this.failureType = failureType;
    }

  public String getFailureEventType() {
        return failureEventType;
    }

  public void setFailureEventType(String failureEventType) {
        this.failureEventType = failureEventType;
    }

  public String getException() {
        return exception;
    }

    public void setException(String exception) {
        this.exception = exception;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public DateTime getFailureDate() {
        return failureDate;
    }

    public void setFailureDate(DateTime failureDate) {
        this.failureDate = failureDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

}
