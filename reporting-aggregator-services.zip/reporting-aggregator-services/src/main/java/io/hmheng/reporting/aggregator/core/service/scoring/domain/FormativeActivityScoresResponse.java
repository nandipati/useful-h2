package io.hmheng.reporting.aggregator.core.service.scoring.domain;

import java.util.UUID;

public class FormativeActivityScoresResponse {
    private UUID activityId;
    private String eventType;
    private String status;
    private Sessions sessions;

    public Sessions getSessions() {
        return sessions;
    }

    public void setSessions(Sessions sessions) {
        this.sessions = sessions;
    }

    public UUID getActivityId() {
        return activityId;
    }

    public void setActivityId(UUID activityId) {
        this.activityId = activityId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
