package io.hmheng.reporting.aggregator.core.service.reporting.domain;

import io.hmheng.reporting.aggregator.web.domain.assignment.ProductType;
import io.hmheng.reporting.aggregator.web.domain.assignment.TestType;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Created by nandipatim on 3/5/16.
 */
public enum PerformanceLevel {


    ADVANCED(80.00,100.00,"Advanced", TestType.FORMATIVE, 5L, 5,ProductType.HMH1),
    PROFICIENT(60.00 , 79.99,"Proficient", TestType.FORMATIVE,6L, 4,ProductType.HMH1),
    BASIC(40.00,59.99,"Basic", TestType.FORMATIVE, 7L, 3,ProductType.HMH1),
    BELOW_BASIC(20.00,39.99,"Below Basic", TestType.FORMATIVE, 8L, 2,ProductType.HMH1),
    FAR_BELOW_BASIC(0.00,19.99,"Far Below Basic", TestType.FORMATIVE, 9L, 1,ProductType.HMH1),
    NOT_MASTERED(0.00,64.99, "Not Mastered", null, 10L, 1,ProductType.ED),
    PARTIALLY_MASTERED(65.00,79.99, "Partially Mastered", null, 11L, 2,ProductType.ED),
    MASTERED(80.00,100.00, "Mastered", null, 12L, 3,ProductType.ED);


    private final Double lowerLimit;
    private final Double upperLimit;
    private final String name;
    private final TestType testType;
    private final Long bandId;
    private final Integer bandOrder;
    private final ProductType productType;

    PerformanceLevel(Double lowerLimit , Double upperLimit , String name, TestType testType, Long bandId,
        Integer bandOrder,ProductType productType){
        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
        this.name = name;
        this.testType = testType;
        this.bandId = bandId;
        this.bandOrder = bandOrder;
        this.productType=productType;

    }

    public Double getLowerLimit() {
        return lowerLimit;
    }

    public Double getUpperLimit() {
        return upperLimit;
    }

    public String getName() {
        return name;
    }

    public TestType getTestType() {
        return testType;
    }

    public Long getBandId() {
        return bandId;
    }

    public Integer getBandOrder() {
        return bandOrder;
    }

    public ProductType getProductType(){
        return productType;
    }

    public static PerformanceLevel getPerformanceLevel(Double proficiencyScore, TestType testType){

        if(testType == null){
            throw new RuntimeException("Test Type is not Valid ");
        }

        return Arrays.stream(PerformanceLevel.values()).filter(v -> (Double.compare(proficiencyScore*100, v.lowerLimit) >= 0)
                && (Double.compare(proficiencyScore*100, v.upperLimit) <= 0) && (v.getProductType().equals(testType.getProductType()))
        ).findFirst().orElseGet(() -> BASIC);
    }

    public static List<PerformanceLevel> getBandsForTestType(TestType testType){

        return Arrays.stream(PerformanceLevel.values()).filter(v -> (v.getTestType() == testType)).collect(Collectors.toList());
    }
}
