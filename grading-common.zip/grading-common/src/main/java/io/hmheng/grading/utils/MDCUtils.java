package io.hmheng.grading.utils;

import java.util.UUID;
import org.slf4j.MDC;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

/**
 * Created by nandipatim on 10/6/17.
 */
public class MDCUtils {

    public static void addPropertiesToMDC(UUID assignmentId , UUID activityId , UUID sessionId, UUID studentId){

        if(assignmentId != null)
            addPropertyToMDC(Constants.ASSIGNMENT_ID_TAG , assignmentId.toString());

        if(activityId != null)
            addPropertyToMDC(Constants.ACTIVITY_ID_TAG , activityId.toString());

        if(sessionId != null) {
            addPropertyToMDC(Constants.SESSION_ID_TAG, sessionId.toString());
            addPropertyToMDC(Constants.CORRELATION_ID , sessionId.toString());
        }
        if(studentId != null)
            addPropertyToMDC(Constants.STUDENT_ID_TAG , studentId.toString());
    }

    public static void addPropertyToMDC(String key , String value){
        if(!StringUtils.isEmpty(key) && !StringUtils.isEmpty(value))
            MDC.put(key , value);
    }

    public static void clean(){
        removePropertyFromMDC(Constants.FULL_REQUEST_STRING);
        removePropertyFromMDC(Constants.ELAPSED_TIMEMILLS);
        removePropertyFromMDC(Constants.ELAPSED_TIMESEC);
        removePropertyFromMDC(Constants.SESSION_ID_TAG);
        removePropertyFromMDC(Constants.ACTIVITY_ID_TAG);
        removePropertyFromMDC(Constants.METHOD_OR_ENDPOINT_TAG);
        removePropertyFromMDC(Constants.ASSIGNMENT_ID_TAG);
        removePropertyFromMDC(Constants.ELAPSED_TIMEMILLS_INGRADING);
        removePropertyFromMDC(Constants.STUDENT_ID_TAG);
        removePropertyFromMDC(Constants.SERVICE_NAME_TAG);
    }

    public static void removePropertyFromMDC(String key){
        if(!StringUtils.isEmpty(key))
            MDC.remove(key);
    }

    public static StopWatch start(){
        StopWatch sw = new StopWatch();
        sw.start();
        return sw;
    }

    public static void stopAddPropertyToMDC(StopWatch stopWatch){
        stopWatch.stop();
        MDCUtils.addPropertyToMDC(Constants.ELAPSED_TIMEMILLS, String.valueOf(stopWatch.getTotalTimeMillis()));
        MDCUtils.addPropertyToMDC(Constants.ELAPSED_TIMESEC, String.valueOf(stopWatch.getTotalTimeSeconds()));

    }

}
