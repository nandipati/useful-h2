package io.hmheng.grading.utils;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Created by jayachandranj on 12/19/17.
 */
public class TimeUtils {

    public static long differenceInTimeMillis(LocalDateTime startTime, LocalDateTime endTime){
        long timeInMills = ChronoUnit.MILLIS.between(startTime,endTime);
        return timeInMills;
    }

    public static long differenceInTimeSecs(LocalDateTime startTime, LocalDateTime endTime){
        long timeInSecs = ChronoUnit.SECONDS.between(startTime,endTime);
        return timeInSecs;
    }


}
