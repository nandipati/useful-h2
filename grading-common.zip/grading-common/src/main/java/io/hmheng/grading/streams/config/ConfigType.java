package io.hmheng.grading.streams.config;

/**
 * Created by nandipatim on 5/31/17.
 */
public enum ConfigType {
  CONSUMER,
  PRODUCER;
}
