package io.hmheng.grading.utils;

/**
 * Created by nandipatim on 5/8/17.
 */
public enum Status {

  NOT_SCORED,
  SCORING_IN_PROGRESS,
  SCORING_COMPLETED;

}
