package io.hmheng.grading.scoring.domain;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by mfeng on 5/24/18.
 */
public enum ClientName {

    GRADING("GRADING"),
    SCORING("SCORING"),
    STUDENT_SESSION_REPROCESS("STUDENT_SESSION_REPROCESS");

    private String clientName;

    ClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getValue() {
        return clientName;
    }

    static Map<String, ClientName> map = new HashMap<>();

    static {
        for (ClientName clientName : ClientName.values()) {
            map.put(clientName.clientName, clientName);
        }
    }

    public static ClientName getByCode(String code) {
        return map.get(code);
    }
}