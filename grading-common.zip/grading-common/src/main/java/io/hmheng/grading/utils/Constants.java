package io.hmheng.grading.utils;

/**
 * Created by srikanthk on 4/24/17.
 */
public interface Constants {
    String VERSION_PARAM_NAME = "VERSION_NBR";
    String HALJSON =  "application/hal+json";
    String SERVICE_NAME_TAG = "service-name";
    String SERVICE_NAME = "grading-api";
    String SERVICE_NAME_GRADING_SERVICES = "grading-data-services";
    String SESSION_ID_TAG = "sessionId";
    String ACTIVITY_ID_TAG = "activityId";
    String ASSIGNMENT_ID_TAG = "assignmentId";
    String STUDENT_ID_TAG = "studentPersonalRefId";
    String METHOD_OR_ENDPOINT_TAG = "METHOD-OR-ENDPOINT";
    String FULL_REQUEST_STRING = "fullRequestString";
    String ELAPSED_TIMEMILLS = "elapsedTimeMillis#";
    String ELAPSED_TIMESEC = "elapsedTimeSeconds#";
    String ELAPSED_TIMEMILLS_INGRADING = "elapsedTimeMillsInGrading#";
    String STAGE = "stage";
    String TIMESPENT_BYTEACHER = "timeSpentByTeacher#";
    String GRADEPENDING_TIME = "timeInGradingPending#";
    String CORRELATION_ID = "CorrelationId";
    String NOT_FOUND = "Not Found";
}
