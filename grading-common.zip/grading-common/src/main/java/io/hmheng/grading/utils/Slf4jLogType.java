package io.hmheng.grading.utils;

/**
 * Created by jayachandranj on 12/5/17.
 */
public enum Slf4jLogType {
    MDC,MARKER;
}
