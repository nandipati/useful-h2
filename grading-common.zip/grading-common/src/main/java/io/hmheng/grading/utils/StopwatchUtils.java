package io.hmheng.grading.utils;

import org.springframework.util.StopWatch;

/**
 * Created by jayachandranj on 12/7/17.
 */
public class StopwatchUtils {

    public static StopWatch start(){
        StopWatch sw = new StopWatch();
        sw.start();
        return sw;
    }

    public static void stop(StopWatch sw) throws IllegalStateException {
        sw.stop();
    }
}
