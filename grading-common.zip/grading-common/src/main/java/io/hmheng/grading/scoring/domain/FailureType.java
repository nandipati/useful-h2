package io.hmheng.grading.scoring.domain;

/** Created by mfeng on 5/24/18. */
public enum FailureType {
  ST_SESSION_REPROCESS("ST_SESSION_REPROCESS"),
  NONE("NONE");

  private final String type;

  FailureType(String type) {
    this.type = type;
  }

  @Override
  public String toString() {
    return this.type;
  }

  public static boolean contains(String name) {
    for (FailureType t : FailureType.values()) {
      if (t.type.equalsIgnoreCase(name)) {
        return true;
      }
    }
    return false;
  }
}
