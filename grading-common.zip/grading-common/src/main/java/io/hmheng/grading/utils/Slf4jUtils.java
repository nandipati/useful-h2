package io.hmheng.grading.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static net.logstash.logback.marker.Markers.append;
import static net.logstash.logback.marker.Markers.appendEntries;

/**
 * Created by jayachandranj on 12/5/17.
 */
public class Slf4jUtils {
    private static  final Logger logger = LoggerFactory.getLogger(Slf4jUtils.class);
    public static void addPropertyToSlf4jLogType(Slf4jLogType logType, String key, Object value) {
        switch (logType) {
            case MARKER:
                if(!ObjectUtils.isEmpty(value))
                logger.info(appendEntries((Map<?, ?>) value), "log message for Marker2");
                break;
            case MDC:
                if (!StringUtils.isEmpty(key) && !StringUtils.isEmpty(value.toString()))
                    MDC.put(key, value.toString());
                break;
            default:
                throw new IllegalArgumentException("LogType not match in addPropertyToSlf4jLogType!!");
        }
    }

    public static void addPropertiesToSlf4jLogType(Slf4jLogType logType, UUID assignmentId, UUID activityId, UUID sessionId, UUID studentId) {

        if(assignmentId != null)
            addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.ASSIGNMENT_ID_TAG , assignmentId.toString());

        if(activityId != null)
            addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.ACTIVITY_ID_TAG , activityId.toString());

        if(sessionId != null)
            addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.SESSION_ID_TAG , sessionId.toString());

        if(studentId != null)
            addPropertyToSlf4jLogType(Slf4jLogType.MDC, Constants.STUDENT_ID_TAG , studentId.toString());

    }

    public static void clean(){

            removePropertyFromMDC(Slf4jLogType.MDC, Constants.FULL_REQUEST_STRING);
            removePropertyFromMDC(Slf4jLogType.MDC, Constants.SESSION_ID_TAG);
            removePropertyFromMDC(Slf4jLogType.MDC, Constants.ACTIVITY_ID_TAG);
            removePropertyFromMDC(Slf4jLogType.MDC, Constants.METHOD_OR_ENDPOINT_TAG);
            removePropertyFromMDC(Slf4jLogType.MDC, Constants.ASSIGNMENT_ID_TAG);
            removePropertyFromMDC(Slf4jLogType.MDC, Constants.STUDENT_ID_TAG);
            removePropertyFromMDC(Slf4jLogType.MDC, Constants.SERVICE_NAME_TAG);


    }

    public static void removePropertyFromMDC(Slf4jLogType logType,String key){

            if (!StringUtils.isEmpty(key))
                MDC.remove(key);

    }

    public static void addTimestampPropertyToSlf4jLogType(StopWatch stopWatch){
        Map<String, Object> contextMap = new HashMap<>();
        addTimestampPropertyToMarker(stopWatch, contextMap);
    }

    public static void addTimestampPropertyToMarker(StopWatch stopWatch, Map<String, Object> contextMap) {
        contextMap.put(Constants.ELAPSED_TIMEMILLS, stopWatch.getTotalTimeMillis());
        contextMap.put(Constants.ELAPSED_TIMESEC, stopWatch.getTotalTimeSeconds());
        addPropertyToSlf4jLogType(Slf4jLogType.MARKER, "timeinslf4j", contextMap);
    }
}
