package io.hmheng.grading.scoring.domain;

/**
 * Created by mfeng on 5/24/18.
 */
public enum DeadLetterStatus {
    NONE(0), REPROCESS_READY(1), REPROCESS_DONE(2);

    private final int deadLetterStatus;

    DeadLetterStatus(int deadLetterStatus) {
        this.deadLetterStatus = deadLetterStatus;
    }

    public int getDeadLetterStatus() {
        return deadLetterStatus;
    }

    public static DeadLetterStatus fromDeadLetterStatus(Integer deadLetterStatus) {

        DeadLetterStatus status = null;
        if (deadLetterStatus == null) {
            throw new IllegalArgumentException("deadLetterStatus can't be null");
        }
        for (DeadLetterStatus statusDeadLetter : DeadLetterStatus.values()) {
            if (statusDeadLetter.deadLetterStatus == deadLetterStatus) {
                status = statusDeadLetter;
            }

        }
        return status;
    }
}
