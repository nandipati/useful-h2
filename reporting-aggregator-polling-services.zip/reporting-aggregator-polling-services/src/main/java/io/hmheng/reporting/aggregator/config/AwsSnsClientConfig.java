package io.hmheng.reporting.aggregator.config;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(AWSConfig.class)
public class AwsSnsClientConfig {

    @Autowired
    private AWSConfig awsConfig;

    @Bean
    public AmazonSNS amazonSNSClient() {
        AmazonSNSClient snsClient = new AmazonSNSClient();
        snsClient.setRegion(Region.getRegion(Regions.fromName(awsConfig.getRegion())));
        return snsClient;
    }
}
