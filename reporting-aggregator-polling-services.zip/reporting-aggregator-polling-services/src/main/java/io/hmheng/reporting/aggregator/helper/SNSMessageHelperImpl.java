package io.hmheng.reporting.aggregator.helper;

import com.google.common.collect.Sets;
import com.google.gson.JsonParser;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sqs.model.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

import io.hmheng.reporting.aggregator.config.SNSConfig;
import io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils;

import static io.hmheng.reporting.aggregator.Constants.CONTEXT_ID;
import static io.hmheng.reporting.aggregator.Constants.CORRELATION_ID;
import static io.hmheng.reporting.aggregator.Constants.MESSAGE;
import static io.hmheng.reporting.aggregator.Constants.RECEIPT_HANDLE;

@Component
public class SNSMessageHelperImpl implements SNSMessageHelper {

    private static Logger logger = LoggerFactory.getLogger(SNSMessageHelperImpl.class);
    
    @Autowired
    private AmazonSNS amazonSnsClient;

    @Override
    public Set<String> publishMessages(SNSConfig config, List<Message> messages) {
        if (messages == null || messages.isEmpty()) {
            return Sets.newHashSet();
        }

        Set<String> receiptHandles = Sets.newHashSetWithExpectedSize(messages.size());

        for (Message message : messages) {
            logger.debug("Message --> {}", message.toString());

            PublishRequest publishRequest = createPublishRequest(message, config);

            try {
                amazonSnsClient.publish(publishRequest);
                logger.debug("{}", Runtime.getRuntime().totalMemory());
                receiptHandles.add(publishRequest.getMessageAttributes().get(RECEIPT_HANDLE).getStringValue());
            } catch (Exception e) {
                logger.error("{}: {}", e.getClass().getCanonicalName(), e);
                throw new RuntimeException(e);
            }
        }

        return receiptHandles;
    }

    private PublishRequest createPublishRequest(Message message, SNSConfig config) {
        // Extract the StudentAssignment Message string from the SNS message wrapper
        String messageToPublish = new JsonParser().parse(message.getBody()).getAsJsonObject().get(MESSAGE).getAsString();

        PublishRequest publishRequest = new PublishRequest(config.getTopicArn(), messageToPublish);

        addReceiptHandle(message, publishRequest);
        addCorrelationId(message.getBody(), publishRequest);
        addContextId(message.getBody(), publishRequest);

        return publishRequest;
    }

    private void addReceiptHandle(Message message, PublishRequest publishRequest) {
        String receiptHandle = message.getReceiptHandle();
        publishRequest.getMessageAttributes().put(RECEIPT_HANDLE, createMessageAttributeValue(receiptHandle));
        logger.info("Receipt Handle added: {}", receiptHandle);
    }

    private void addCorrelationId(String message, PublishRequest publishRequest) {
        String correlationId = CommonMessageUtils.getMessageAttribute(CORRELATION_ID, message, null);

        if (correlationId != null) {
            publishRequest.getMessageAttributes().put(CORRELATION_ID, createMessageAttributeValue(correlationId));
            logger.info("Correlation ID added: {}", correlationId);
        }
    }

    private void addContextId(String message, PublishRequest publishRequest) {
        String contextId = CommonMessageUtils.getMessageAttribute(CONTEXT_ID, message, null);

        if (CommonMessageUtils.isContextIdValid(contextId)) {
            publishRequest.getMessageAttributes().put(CONTEXT_ID, createMessageAttributeValue(contextId));
            logger.info("Context ID added: {}", contextId);

        } else {
            logger.info("Invalid contextId attribute found [contextId={}]", contextId);
        }
    }

    private MessageAttributeValue createMessageAttributeValue(String value) {
        return new MessageAttributeValue()
                .withDataType("String")
                .withStringValue(value);
    }

}
