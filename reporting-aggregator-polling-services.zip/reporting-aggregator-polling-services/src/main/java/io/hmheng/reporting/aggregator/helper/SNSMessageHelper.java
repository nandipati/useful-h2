package io.hmheng.reporting.aggregator.helper;

import com.amazonaws.services.sqs.model.Message;

import java.util.List;
import java.util.Set;

import io.hmheng.reporting.aggregator.config.SNSConfig;

public interface SNSMessageHelper {

    Set<String> publishMessages(SNSConfig config, List<Message> messages);
}
