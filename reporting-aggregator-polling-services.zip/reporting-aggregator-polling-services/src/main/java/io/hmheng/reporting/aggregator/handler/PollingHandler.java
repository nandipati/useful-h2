package io.hmheng.reporting.aggregator.handler;

import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollResponse;

public interface PollingHandler {

    StudentAssignmentPollResponse pollStudentAssignmentCompletedEventsForLocation();

    StudentAssignmentPollResponse pollStudentAssignmentCompletedEventsForDemographic();
}
