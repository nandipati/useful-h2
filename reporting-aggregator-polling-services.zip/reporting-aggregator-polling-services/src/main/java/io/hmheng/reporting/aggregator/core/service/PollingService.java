package io.hmheng.reporting.aggregator.core.service;

import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollRequest;
import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollResponse;

public interface PollingService {
    
    StudentAssignmentPollResponse pollStudentAssignmentCompletedEventForLocation(StudentAssignmentPollRequest request);
    
    StudentAssignmentPollResponse pollStudentAssignmentCompletedEventForDemographic(StudentAssignmentPollRequest request);
}
