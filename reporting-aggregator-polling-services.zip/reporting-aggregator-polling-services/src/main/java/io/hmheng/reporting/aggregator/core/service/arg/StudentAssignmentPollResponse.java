package io.hmheng.reporting.aggregator.core.service.arg;

import java.util.Set;
import java.util.UUID;

public class StudentAssignmentPollResponse {

    private Set<String> receiptHandles;
    private Set<UUID> studentAssignmentRefIds;

    public StudentAssignmentPollResponse(Set<String> receiptHandles, Set<UUID> studentAssignmentRefIds) {
        this.receiptHandles = receiptHandles;
        this.studentAssignmentRefIds = studentAssignmentRefIds;
    }
    
    public Set<String> getReceiptHandles() {
        return receiptHandles;
    }
    
    public Set<UUID> getStudentAssignmentRefIds() {
        return studentAssignmentRefIds;
    }
    
}
