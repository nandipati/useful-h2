package io.hmheng.reporting.aggregator.core.service;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.sqs.model.Message;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.hmheng.reporting.aggregator.Constants;
import io.hmheng.reporting.aggregator.config.EventConfig;
import io.hmheng.reporting.aggregator.config.LambdaConfig;
import io.hmheng.reporting.aggregator.config.SNSConfig;
import io.hmheng.reporting.aggregator.config.SQSConfig;
import io.hmheng.reporting.aggregator.config.SingleEventConfig;
import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollRequest;
import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollResponse;
import io.hmheng.reporting.aggregator.helper.SNSMessageHelper;
import io.hmheng.reporting.aggregator.helper.SQSMessageHelper;
import io.hmheng.reporting.aggregator.web.domain.assignment.StudentAssignment;
import io.hmheng.reporting.aggregator.web.handler.CommonMessageUtils;
import org.joda.time.LocalDateTime;
import org.joda.time.Period;
import org.joda.time.PeriodType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toSet;

@Service
@EnableConfigurationProperties(LambdaConfig.class)
public class PollingServiceImpl implements PollingService {
    
    private static Logger logger = LoggerFactory.getLogger(PollingServiceImpl.class);
    
    @Autowired
    private SQSMessageHelper sqsMessageHelper;
    
    @Autowired
    private SNSMessageHelper snsMessageHelper;
    
    @Autowired
    private EventConfig eventConfig;
    
    @Autowired
    private LambdaConfig lambdaConfig;
    
    @Autowired
    private SecurityService securityService;
    
    @Override
    public StudentAssignmentPollResponse pollStudentAssignmentCompletedEventForLocation(StudentAssignmentPollRequest request) {
        return pollStudentAssignmentCompletedEvent(eventConfig.getLocation());
    }
    
    @Override
    public StudentAssignmentPollResponse pollStudentAssignmentCompletedEventForDemographic(StudentAssignmentPollRequest request) {
        return pollStudentAssignmentCompletedEvent(eventConfig.getDemographic());
    }
    
    private StudentAssignmentPollResponse pollStudentAssignmentCompletedEvent(
        SingleEventConfig studentAssignmentCompletedConfig) {
        SQSConfig sqsConfig = studentAssignmentCompletedConfig.getSqs();
        
        LocalDateTime scheduledStopTime = getScheduledStopTime(lambdaConfig.getScheduleRateSeconds(), lambdaConfig.getScheduleSafetyStop());
        logger.info("Scheduled Stop Time: {}", scheduledStopTime.toString());
        
        boolean queueExhausted = false; // Flag to know when the queue has been exhausted
        AWSCredentials credentials = securityService.getAWSCredentials();
        
        int currentRate = 0; // Number of Continuum messages published in this cycle thus far.
        boolean rateLimitExceeded = false;
        
        Set<String> publishedReceiptHandles = Sets.newHashSet();
        Set<UUID> publishedStudentAssignmentRefIds = Sets.newHashSet();
        
        while (!queueExhausted && !rateLimitExceeded && LocalDateTime.now().isBefore(scheduledStopTime)) {
            // Start reading messages
            List<Message> messages = sqsMessageHelper.readMessages(credentials, sqsConfig);
            
            if (messages.isEmpty()) {
                logger.info("Queue has been exhausted. There are no new messages to handle right now.");
                queueExhausted = true;
                continue;
            }
            
            // Process Continuum messages
            List<Message> continuumMessages = filterContinuumMessages(messages, credentials, sqsConfig);
            
            logger.debug("Polled Continuum Messages: {}", continuumMessages.stream().map(Message::toString));
            
            if (!continuumMessages.isEmpty()) {
                SNSConfig snsConfig = studentAssignmentCompletedConfig.getSns();
                
                // Publish Messages to the Topic
                Set<String> receiptHandles = snsMessageHelper.publishMessages(snsConfig, continuumMessages);
                publishedReceiptHandles.addAll(receiptHandles);
                
                // Get the set of StudentAssignmentRefIds
                publishedStudentAssignmentRefIds
                    .addAll(continuumMessages.stream().map(i -> toStudentAssignment(i).getRefId()).collect(toSet()));
                    
                currentRate += continuumMessages.size();
                rateLimitExceeded = checkRateLimit(currentRate);
            }
        }
        
        return new StudentAssignmentPollResponse(publishedReceiptHandles, publishedStudentAssignmentRefIds);
    }
    
    /**
     * Calculate the scheduled stop time as a percentage of the scheduled end time.
     */
    private LocalDateTime getScheduledStopTime(int seconds, int safetyStop) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime scheduledEnd = now.plusSeconds(seconds);
        
        int diffMillis = Math.round((new Period(now, scheduledEnd, PeriodType.millis()).getMillis() * safetyStop) / 100);
        return now.plusMillis(diffMillis);
    }
    
    private boolean checkRateLimit(int currentRate) {
        int messageRateLimit = lambdaConfig.getMessageRateLimit();
        
        if (messageRateLimit != -1 && currentRate >= messageRateLimit) {
            logger.info("Rate limit Exceeded. {} of {} allowed messages published.", currentRate, messageRateLimit);
            return true;
        }
        
        logger.info("Rate limit checked and not exceeded. {} of {} allowed messages published.", currentRate, messageRateLimit);
        
        return false;
    }
    
    private List<Message> filterContinuumMessages(List<Message> messages, AWSCredentials credentials, SQSConfig sqsConfig) {
        List<Message> continuumMessages = Lists.newArrayListWithExpectedSize(messages.size());
        
        // Filter Continuum Messages
        for (Message message : messages) {
            StudentAssignment studentAssignment = toStudentAssignment(message);
            
            if (studentAssignment!=null && studentAssignment.isBenchmark()) {
                continuumMessages.add(message);
            }
        }
        
        // Delete the non-Continuum messages from the queue
        messages.removeAll(continuumMessages);
        
        if (!messages.isEmpty()) {
            List<String> messageReceiptHandles = messages.stream().map(Message::getReceiptHandle).collect(Collectors.toList());
            sqsMessageHelper.deleteMessages(credentials, messageReceiptHandles, sqsConfig);
        }
        
        return continuumMessages;
    }
    
    private StudentAssignment toStudentAssignment(Message message) {
        JsonObject jsonObject = new JsonParser().parse(message.getBody()).getAsJsonObject();
        return CommonMessageUtils.mapMessageToEntity(jsonObject.get(Constants.MESSAGE).getAsString(), StudentAssignment.class);
    }
    

    
}
