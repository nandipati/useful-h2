package io.hmheng.reporting.aggregator.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.hmheng.reporting.aggregator.core.service.PollingService;
import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollRequest;
import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollResponse;

@Component
public class PollingHandlerImpl implements PollingHandler {

    private static final Logger logger = LoggerFactory.getLogger(PollingHandlerImpl.class);

    @Autowired
    private PollingService pollingService;

    @Override
    public StudentAssignmentPollResponse pollStudentAssignmentCompletedEventsForLocation() {

        logger.debug("{}", "+pollStudentAssignmentCompletedEventsForLocation");

        StudentAssignmentPollResponse response = pollingService
                .pollStudentAssignmentCompletedEventForLocation(new StudentAssignmentPollRequest());

        logger.info("Published StudentAssignmentRefIds: {}", response.getStudentAssignmentRefIds());

        logger.debug("{}", "-pollStudentAssignmentCompletedEventsForLocation");
        return response;
    }

    @Override
    public StudentAssignmentPollResponse pollStudentAssignmentCompletedEventsForDemographic() {
        logger.debug("{}", "+pollStudentAssignmentCompletedEventsForDemographic");

        StudentAssignmentPollResponse response = pollingService
                .pollStudentAssignmentCompletedEventForDemographic(new StudentAssignmentPollRequest());

        logger.info("Published StudentAssignmentRefIds: {}", response.getStudentAssignmentRefIds());

        logger.debug("{}", "-pollStudentAssignmentCompletedEventsForDemographic");
        return response;
    }
}
