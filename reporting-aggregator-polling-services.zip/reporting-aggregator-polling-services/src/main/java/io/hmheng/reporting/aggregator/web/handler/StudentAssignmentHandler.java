package io.hmheng.reporting.aggregator.web.handler;

import com.amazonaws.services.lambda.runtime.Context;

import io.hmheng.reporting.aggregator.Application;
import io.hmheng.reporting.aggregator.core.service.arg.StudentAssignmentPollResponse;
import io.hmheng.reporting.aggregator.handler.PollingHandler;

public class StudentAssignmentHandler {
    
    public StudentAssignmentPollResponse pollStudentAssignmentCompletedEventsForLocation(Context context) {
        Application application = new Application(context);
        PollingHandler pollingHandler = application.getBean(PollingHandler.class);
        return pollingHandler.pollStudentAssignmentCompletedEventsForLocation();
    }
    
    public StudentAssignmentPollResponse pollStudentAssignmentCompletedEventsForDemographic(Context context) {
        Application application = new Application(context);
        PollingHandler pollingHandler = application.getBean(PollingHandler.class);
        return pollingHandler.pollStudentAssignmentCompletedEventsForDemographic();
    }
    
}
