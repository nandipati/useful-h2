package io.hmheng.reporting.aggregator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "lambda")
public class LambdaConfig {

    private int scheduleRateSeconds;
    private int scheduleSafetyStop;
    private int messageRateLimit;

    public int getScheduleRateSeconds() {
        return scheduleRateSeconds;
    }

    public void setScheduleRateSeconds(int scheduleRateSeconds) {
        this.scheduleRateSeconds = scheduleRateSeconds;
    }

    public int getScheduleSafetyStop() {
        return scheduleSafetyStop;
    }

    public void setScheduleSafetyStop(int scheduleSafetyStop) {
        this.scheduleSafetyStop = scheduleSafetyStop;
    }

    public int getMessageRateLimit() {
        return messageRateLimit;
    }

    public void setMessageRateLimit(int messageRateLimit) {
        this.messageRateLimit = messageRateLimit;
    }
    
}
