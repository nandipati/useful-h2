package io.hmheng.reporting.aggregator.core.service.arg;

public class StudentAssignmentPollRequest {

    

}
