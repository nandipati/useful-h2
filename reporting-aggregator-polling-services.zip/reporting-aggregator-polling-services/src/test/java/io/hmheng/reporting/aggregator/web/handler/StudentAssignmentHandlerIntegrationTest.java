package io.hmheng.reporting.aggregator.web.handler;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.amazonaws.services.lambda.runtime.Context;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import io.hmheng.reporting.aggregator.TestContextConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TestContextConfiguration.class)
@TestExecutionListeners(listeners = {
        DependencyInjectionTestExecutionListener.class
})
public class StudentAssignmentHandlerIntegrationTest {

    private static final String DEV_FUNCTION_NAME = "rsnp-dev-ra-ast-student-status-completed";
    private static final String INT_FUNCTION_NAME = "rsnp-int-ra-ast-student-status-completed";
    private static final String CERT_FUNCTION_NAME = "rsnp-cert-ra-ast-student-status-completed";

    @Ignore
    @Test
    public void testPollStudentAssignmentCompletedEventsWhenOk() {
        StudentAssignmentHandler handler = new StudentAssignmentHandler();

        Context context = mock(Context.class);
        when(context.getFunctionName()).thenReturn(INT_FUNCTION_NAME);

        handler.pollStudentAssignmentCompletedEventsForLocation(context);
    }
}
