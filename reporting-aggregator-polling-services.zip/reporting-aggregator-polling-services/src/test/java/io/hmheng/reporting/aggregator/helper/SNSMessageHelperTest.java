package io.hmheng.reporting.aggregator.helper;

import static io.hmheng.reporting.aggregator.Constants.CONTEXT_ID;
import static io.hmheng.reporting.aggregator.Constants.CORRELATION_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sqs.model.Message;

import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.util.ResourceUtils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;

import io.hmheng.reporting.aggregator.config.SNSConfig;

public class SNSMessageHelperTest {

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Mock
    private AmazonSNS amazonSnsClient;

    @InjectMocks
    private SNSMessageHelper snsMessageHelper = new SNSMessageHelperImpl();

    @Test
    public void testPublisMessagesEmptyList() {
        Set<String> result = snsMessageHelper.publishMessages(new SNSConfig(), Collections.emptyList());
        assertThat(result).isNotNull().isEmpty();
    }

    @Test
    public void testPublisMessagesNullList() {
        Set<String> result = snsMessageHelper.publishMessages(new SNSConfig(), null);
        assertThat(result).isNotNull().isEmpty();
    }

    @Test
    public void testPublishMessageWithoutAttributes() throws FileNotFoundException, IOException {
        ArgumentCaptor<PublishRequest> publishedRequest = ArgumentCaptor.forClass(PublishRequest.class);

        Set<String> result = snsMessageHelper.publishMessages(new SNSConfig(), Arrays.asList(createMessageWithoutAttributes()));

        verify(amazonSnsClient).publish(publishedRequest.capture());
        PublishRequest request = publishedRequest.getValue();
        assertThat(request.getMessageAttributes()).doesNotContainKeys(CONTEXT_ID, CORRELATION_ID);

        assertThat(result).isNotEmpty();
    }

    @Test
    public void testPublishWithCorrelationId() throws FileNotFoundException, IOException {
        UUID correlationId = UUID.randomUUID();
        ArgumentCaptor<PublishRequest> publishedRequest = ArgumentCaptor.forClass(PublishRequest.class);

        Set<String> result = snsMessageHelper.publishMessages(new SNSConfig(), Arrays.asList(createMessage(correlationId)));

        verify(amazonSnsClient).publish(publishedRequest.capture());
        PublishRequest request = publishedRequest.getValue();

        assertThat(request.getMessageAttributes())
                .doesNotContainKey(CONTEXT_ID)
                .containsKey(CORRELATION_ID);

        assertThat(request.getMessageAttributes().get(CORRELATION_ID).getStringValue())
                .isEqualTo(correlationId.toString());

        assertThat(result).isNotEmpty();
    }

    @Test
    public void testPublishWithCorrelationIdAndContextId() throws FileNotFoundException, IOException {
        UUID correlationId = UUID.randomUUID();
        String contextId = "hmof";

        ArgumentCaptor<PublishRequest> publishedRequest = ArgumentCaptor.forClass(PublishRequest.class);

        Set<String> result = snsMessageHelper.publishMessages(new SNSConfig(), Arrays.asList(createMessage(correlationId, contextId)));

        verify(amazonSnsClient).publish(publishedRequest.capture());
        PublishRequest request = publishedRequest.getValue();

        assertThat(request.getMessageAttributes()).containsKeys(CORRELATION_ID, CONTEXT_ID);

        assertThat(request.getMessageAttributes().get(CORRELATION_ID).getStringValue())
                .isEqualTo(correlationId.toString());

        assertThat(request.getMessageAttributes().get(CONTEXT_ID).getStringValue())
                .isEqualTo(contextId);

        assertThat(result).isNotEmpty();
    }

    @Test
    public void testPublishInvalidContextId() throws FileNotFoundException, IOException {
        String contextId = "invalid";

        ArgumentCaptor<PublishRequest> publishedRequest = ArgumentCaptor.forClass(PublishRequest.class);

        Set<String> result = snsMessageHelper.publishMessages(new SNSConfig(), Arrays.asList(createMessage(UUID.randomUUID(), contextId)));

        verify(amazonSnsClient).publish(publishedRequest.capture());
        PublishRequest request = publishedRequest.getValue();

        assertThat(request.getMessageAttributes())
                .doesNotContainKey(CONTEXT_ID)
                .containsKey(CORRELATION_ID);

        assertThat(result).isNotEmpty();
    }

    private Message createMessageWithoutAttributes() throws FileNotFoundException, IOException {
        Message message = new Message();
        message.setBody(getMessagePayload("sampleMessageNoAttributes"));
        message.setReceiptHandle(UUID.randomUUID().toString());
        return message;
    }

    private Message createMessage(UUID correlationId) throws FileNotFoundException, IOException {
        Message message = new Message();
        String body = getMessagePayload("sampleMessage");
        message.setBody(body.replace("<correlationIdPlaceholder>", correlationId.toString()));
        message.setReceiptHandle(UUID.randomUUID().toString());
        return message;
    }

    private Message createMessage(UUID correlationId, String contextId) throws FileNotFoundException, IOException {
        Message message = new Message();
        String body = getMessagePayload("sampleMessageWithContextId");
        message.setBody(body
                .replace("<correlationIdPlaceholder>", correlationId.toString())
                .replace("<contextIdPlaceholder>", contextId));
        message.setReceiptHandle(UUID.randomUUID().toString());
        return message;
    }

    private String getMessagePayload(String filename) throws FileNotFoundException, IOException {
        return FileUtils.readFileToString(ResourceUtils.getFile("classpath:" + filename + ".json"));
    }
}
