package io.hmheng.streaming.driver.streams;

import org.junit.Test;

/**
 * Created by fodori on 2/17/17.
 */
public class TestOther {

  @Test
  public void test() {

  }
}
