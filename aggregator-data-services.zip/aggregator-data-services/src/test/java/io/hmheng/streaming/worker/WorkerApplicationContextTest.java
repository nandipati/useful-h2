package io.hmheng.streaming.worker;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

/**
 * Created by fodori on 2/21/17.
 */
public class WorkerApplicationContextTest {

  @Test
  public void test() {
    ApplicationContext applicationContext = WorkerApplicationContext.getContext("test");
  }

}
