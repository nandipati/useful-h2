package io.hmheng.streaming.driver.streams;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({"local","dev"})
@ContextConfiguration(classes = KinesisStreamConfigurations.class)
@EnableConfigurationProperties
@Slf4j
public class StreamsConfigurationTest {

  @Autowired
  private KinesisStreamConfigurations streamConfigurations;

  @Test
  public void test() {
    Assert.assertNotNull(streamConfigurations.getStreamConfigurations());
    Assert.assertFalse(streamConfigurations.getStreamConfigurations().isEmpty());
    for (KinesisStreamConfigurations.KinesisStreamConfiguration streamConfiguration : streamConfigurations
        .getStreamConfigurations()) {
      Assert.assertNotNull(streamConfiguration.getAppName());
      Assert.assertNotNull(streamConfiguration.getStream());
      Assert.assertNotNull(streamConfiguration.getProcessorBeanClass());
      Assert.assertNotNull(streamConfiguration.getMapperBeanClass());
      log.info("{}", streamConfiguration.toString());
    }

  }
}