package io.hmheng.streaming.model;

import org.junit.Test;

import io.hmheng.streaming.driver.streams.KinesisStreamConfigurations;

/**
 * Created by fodori on 2/22/17.
 */
public class KinesisMessageTest {

  @Test
  public void test() {
    new KinesisStreamConfigurations();
  }

}
