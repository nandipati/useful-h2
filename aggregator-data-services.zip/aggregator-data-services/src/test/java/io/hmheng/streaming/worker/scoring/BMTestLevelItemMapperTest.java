package io.hmheng.streaming.worker.scoring;

import com.hmhco.api.scoring.view.save.itemlevel.BenchmarkTestItemLevel;

import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by fodori on 3/31/17.
 */
public class BMTestLevelItemMapperTest {

  @Test
  public void testDeserialization() throws IOException {
    BMTestLevelItemMapper mapper = new BMTestLevelItemMapper();

    InputStream ios = this.getClass().getResourceAsStream("/scoring/test_message1.json");
    byte[] bytes = IOUtils.toByteArray(ios);
    IOUtils.closeQuietly(ios);

    BenchmarkTestItemLevel item = mapper.apply(bytes);


  }

}
