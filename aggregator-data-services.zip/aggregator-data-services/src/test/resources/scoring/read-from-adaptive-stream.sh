#!/bin/bash


if [[ $# -eq 0 ]] ; then
    echo 'Please provide stage parameter: dev, int, cert or prod'
    exit 1
fi

STAGE=$1

ENV_FILE=$(source assume_role.sh $STAGE)
source $ENV_FILE
rm $ENV_FILE

SHARD_ITERATOR=$(aws kinesis get-shard-iterator --shard-id shardId-000000000000 --shard-iterator-type TRIM_HORIZON --stream-name io_hmheng_hmhone_$(echo $STAGE)_assessment_score_itemdata_stream --query 'ShardIterator')

RESPONSE_FILE=$(mktemp "$(echo $TMPDIR)adaptive_response.XXXXXXXXXXX")

aws kinesis get-records --shard-iterator $SHARD_ITERATOR > $RESPONSE_FILE

echo Full Kinesis response: $RESPONSE_FILE

echo Individual parsed responses:

python split_and_decode.py $RESPONSE_FILE

