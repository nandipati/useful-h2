#!/bin/bash



for i in {1..2}
do
  sh test_kinesis_usage_data.sh
done
