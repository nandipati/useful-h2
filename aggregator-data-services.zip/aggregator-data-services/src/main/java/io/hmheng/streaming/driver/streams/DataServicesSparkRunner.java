package io.hmheng.streaming.driver.streams;

import io.hmheng.streaming.model.KafkaMessage;
import io.hmheng.streaming.model.StreamMessage;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.function.Consumer;
import java.util.function.Function;

import io.hmheng.streaming.model.KinesisMessage;
import io.hmheng.streaming.worker.WorkerApplicationContext;
import io.hmheng.streaming.worker.scoring.DeadLetterProcessor;
import org.springframework.util.StringUtils;

/**
 * Created by nandipatim on 1/24/17.
 */

@Component
@Slf4j
public class DataServicesSparkRunner implements Serializable {
  private static final long serialVersionUID = 1L;

  private final StreamingContextFactory streamingContextFactory;

  private final InputStreamFactory<KinesisMessage> inputStreamFactory;

  @Autowired
  private KafkaStreamFactory kafkaStreamFactory;

  private final String[] activeProfiles;

  @Value("${spark.app.steamType}")
  private String steamType;

  @Autowired
  public DataServicesSparkRunner(StreamingContextFactory streamingContextFactory,
                                 InputStreamFactory<KinesisMessage> inputStreamFactory, Environment env) {
    this.streamingContextFactory = streamingContextFactory;
    this.inputStreamFactory = inputStreamFactory;
    this.activeProfiles = env.getActiveProfiles();
  }

  public void execute() throws InterruptedException {

    log.info("Active profiles {} ", Arrays.toString(activeProfiles));

    JavaStreamingContext streamingContext = streamingContextFactory.create();
    //streamingContext.checkpoint(streamingContext.sparkContext().getConf().get(Constants.CHECKPOINT_DIR_KEY));

    if(!StringUtils.isEmpty(steamType)) {
      if (steamType.equalsIgnoreCase("KINESIS")) {
        kinesisStreamConsumer(streamingContext);
      } else if(steamType.equalsIgnoreCase("KAFKA")) {
        Map<String ,JavaDStream<KafkaMessage>> streamResult =kafkaStreamFactory.create(streamingContext);
        final String[] activeProfiles = this.activeProfiles.clone();
        Set<String> eventSet= streamResult.keySet();

        for(String streamSession:eventSet){
          JavaDStream<KafkaMessage> kafkaMessageJavaDStream = streamResult.get(streamSession);
          runKafkaTask(activeProfiles, kafkaMessageJavaDStream);

        }
       } else {
        throw new RuntimeException("Stream Type "+steamType+" not supported.");
      }
    }

    run(streamingContext);
  }

  private void kinesisStreamConsumer(JavaStreamingContext streamingContext) {

    Map<String ,JavaDStream<KinesisMessage>> eventsStreamMap = inputStreamFactory.create(streamingContext);

    final String[] activeProfiles = this.activeProfiles.clone();

    Set<String> eventSet= eventsStreamMap.keySet();

    for(String streamSession:eventSet){
      JavaDStream<KinesisMessage> kinesisMessageJavaDStream = eventsStreamMap.get(streamSession);
      runKinesisTask(activeProfiles, kinesisMessageJavaDStream);
    }
  }

  private void runKinesisTask(String[] activeProfiles, JavaDStream<KinesisMessage> kinesisMessageJavaDStream) {
    if (kinesisMessageJavaDStream != null) {
      kinesisMessageJavaDStream.foreachRDD((rdd, time) -> {

        rdd.foreachPartition(part -> {
          // Create connections / long lived expensive objects objects here.
          // This code already runs on the worker and is kept "alive" between batches, so Spring initialization only
          // takes place once
          if (part != null) {

            ApplicationContext applicationContext = WorkerApplicationContext.getContext(activeProfiles);
            if (applicationContext == null) {
              log.info("eventsStream foreachPartition applicationContext is null");
            }
            part.forEachRemaining(item -> {
              try {
                processStreamData(applicationContext, item);
              } catch (Throwable t) {
                DeadLetterProcessor deadLetterProcessor = applicationContext.getBean(DeadLetterProcessor.class);
                deadLetterProcessor.process(item, t);
              }
            });
          }
        });
      });
    }
  }

  private void runKafkaTask(String[] activeProfiles, JavaDStream<KafkaMessage> kafkaMessageJavaDStream) {
    if (kafkaMessageJavaDStream != null) {
      kafkaMessageJavaDStream.foreachRDD((rdd, time) -> {

        rdd.foreachPartition(part -> {
          // Create connections / long lived expensive objects objects here.
          // This code already runs on the worker and is kept "alive" between batches, so Spring initialization only
          // takes place once
          if (part != null) {

            ApplicationContext applicationContext = WorkerApplicationContext.getContext(activeProfiles);
            if (applicationContext == null) {
              log.info("eventsStream foreachPartition applicationContext is null");
            }
            part.forEachRemaining(item -> {
              try {
                processStreamData(applicationContext, item);
              } catch (Throwable t) {
                DeadLetterProcessor deadLetterProcessor = applicationContext.getBean(DeadLetterProcessor.class);
                deadLetterProcessor.process(item, t);
              }
            });
          }
        });
      });
    }
  }

  private void processStreamData(ApplicationContext applicationContext, StreamMessage item) {

    if(item instanceof KinesisMessage) {
      KinesisMessage kinesisMessage = (KinesisMessage)item;
      logMessage("Processing stream {}, message {}", kinesisMessage.getStream(),
          kinesisMessage.getOriginalMessageWithoutPayload().getSequenceNumber());
    } else if(item instanceof KafkaMessage){
      KafkaMessage kafkaMessage = (KafkaMessage) item;
      logMessage("Processing stream {}, key {}", kafkaMessage.getTopic(),
          kafkaMessage.getOriginalMessageWithoutPayload().key());

    }
    Function<byte[], Object> mapperBean = (Function<byte[], Object>) (applicationContext != null ? applicationContext.getBean(item.getMapperBeanClass()) : null);

    Consumer<Object> processorBean = (Consumer<Object>) (applicationContext != null ? applicationContext.getBean(item.getProcessorBeanClass()) : null);

    Object deserializedBean = (mapperBean != null ? mapperBean.apply(item.getMessagePayload()) : null);

    if(item instanceof KinesisMessage && deserializedBean != null) {
      KinesisMessage kinesisMessage = (KinesisMessage) item;
      log.info("Deserialized object from stream {}, message {}: {}", kinesisMessage.getStream(),
          kinesisMessage.getOriginalMessageWithoutPayload().getSequenceNumber(), deserializedBean);
    } else if(item instanceof KafkaMessage && deserializedBean != null){
      KafkaMessage kafkaMessage = (KafkaMessage) item;
      logMessage("Deserialized object from stream {}, message {}: {}", kafkaMessage.getTopic(),
          kafkaMessage.getOriginalMessageWithoutPayload().key() , deserializedBean);

    }

    if(deserializedBean != null) {
      processorBean.accept(deserializedBean);
    }

    if(item instanceof KinesisMessage && deserializedBean != null) {
      KinesisMessage kinesisMessage = (KinesisMessage) item;
      logMessage("Processed object from stream {}, message {}: {} ", kinesisMessage.getStream(),
          kinesisMessage.getOriginalMessageWithoutPayload().getSequenceNumber(), deserializedBean);
    } else if(item instanceof KafkaMessage && deserializedBean != null){
      KafkaMessage kafkaMessage = (KafkaMessage) item;
      logMessage("Processed object from stream {}, message {}: {}", kafkaMessage.getTopic(),
          kafkaMessage.getOriginalMessageWithoutPayload().key() , deserializedBean);
    }
  }

  private void logMessage(String message , Object... args){
    log.info(message , args);

  }

  protected void run(JavaStreamingContext streamingContext) throws InterruptedException {
    streamingContext.start();
    streamingContext.awaitTermination();

  }
}
