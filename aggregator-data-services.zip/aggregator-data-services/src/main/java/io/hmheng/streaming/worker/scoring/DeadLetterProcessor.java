package io.hmheng.streaming.worker.scoring;

import io.hmheng.streaming.model.KafkaMessage;
import io.hmheng.streaming.model.KinesisMessage;
import java.nio.charset.Charset;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

/**
 * Created by fodori on 2/22/17.
 */
@Slf4j
@Component
public class DeadLetterProcessor {


  public void process(Object o, Throwable t) {
    String s = null;
    if(o instanceof KinesisMessage) {
      KinesisMessage kinessMessage = (KinesisMessage) o;
      s = new String(kinessMessage.getMessagePayload(), Charset.defaultCharset());
    }else if(o instanceof KafkaMessage){
      KafkaMessage kafkaMessage = (KafkaMessage)o;
      s = new String(kafkaMessage.getMessagePayload(),Charset.defaultCharset());
    }
    log.error("DEAD LETTER: {}", s, t);
    //TODO: publish to dead letter queue
  }
}
