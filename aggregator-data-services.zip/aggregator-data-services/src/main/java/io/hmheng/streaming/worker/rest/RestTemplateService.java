package io.hmheng.streaming.worker.rest;

import org.springframework.http.HttpHeaders;

/**
 * Created by nandipatim on 3/23/17.
 */
public interface RestTemplateService {

  void postEntity(String serviceUrl, String uri,Object domainObject  , HttpHeaders httpHeaders);
}
