package io.hmheng.streaming.worker;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import io.hmheng.reporting.aggregator.core.service.AuthorizationService;

/**
 * Created by fodori on 2/21/17.
 */
@Slf4j
@SpringBootApplication(scanBasePackageClasses = { WorkerApplicationContext.class,
    AuthorizationService.class }, exclude = { JmxAutoConfiguration.class})
@EnableConfigurationProperties
public class WorkerApplicationContext {

  private static final Object monitor = new Object();

  private static ConfigurableApplicationContext applicationContext;

  protected static void start(String... profiles) {
    synchronized (monitor) {
      if (applicationContext == null) {
        log.info("Starting Spring context on worker.");
        SpringApplication app = new SpringApplication(WorkerApplicationContext.class);
        app.setAdditionalProfiles(profiles);
        app.setWebEnvironment(false);
        applicationContext = app.run();
        applicationContext.registerShutdownHook();
      }
    }
  }

  public static ApplicationContext getContext(String... profiles) {
    if (applicationContext == null) {
      start(profiles);
    }
    return applicationContext;
  }

}
