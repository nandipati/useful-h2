package io.hmheng.streaming.driver;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ConfigurableApplicationContext;

import io.hmheng.streaming.driver.streams.DataServicesSparkRunner;

/**
 * Created by fodori on 2/22/17.
 */
@SpringBootApplication
@EnableConfigurationProperties
@Slf4j
public class DataServicesDriverApp {

  public static void main(String[] args) {
    ConfigurableApplicationContext applicationContext = SpringApplication.run(DataServicesDriverApp.class, args);
    DataServicesSparkRunner sparkRunner = applicationContext.getBean(DataServicesSparkRunner.class);
    try {
      sparkRunner.execute();
    } catch (InterruptedException e) {
      log.warn("Closing application!", e);
    }
  }
}
