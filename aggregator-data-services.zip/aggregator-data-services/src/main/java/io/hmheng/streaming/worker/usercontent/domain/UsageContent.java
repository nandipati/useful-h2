package io.hmheng.streaming.worker.usercontent.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.hmheng.reporting.aggregator.utils.JsonCommons;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by nandipatim on 3/23/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsageContent {
  private String id;
  private UUID userId;
  private String contentId;
  private UsageContentEventType eventType;
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializerISOFormat.class)
  private LocalDateTime sessionStart;
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializerISOFormat.class)
  private LocalDateTime sessionEnd;
  private Integer sessionDurationSec;
  @JsonProperty("@timestamp")
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializerISOFormat.class)
  private LocalDateTime eventTime;
  private Actor actor;
  private Target target;
  private UsageContentSession session;
  private UsageContext usageContext;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public UUID getUserId() {
    return userId;
  }

  public void setUserId(UUID userId) {
    this.userId = userId;
  }

  public String getContentId() {
    return contentId;
  }

  public void setContentId(String contentId) {
    this.contentId = contentId;
  }

  public UsageContentEventType getEventType() {
    return eventType;
  }

  public void setEventType(UsageContentEventType eventType) {
    this.eventType = eventType;
  }

  public LocalDateTime getSessionStart() {
    return sessionStart;
  }

  public void setSessionStart(LocalDateTime sessionStart) {
    this.sessionStart = sessionStart;
  }

  public LocalDateTime getSessionEnd() {
    return sessionEnd;
  }

  public void setSessionEnd(LocalDateTime sessionEnd) {
    this.sessionEnd = sessionEnd;
  }

  public Integer getSessionDurationSec() {
    return sessionDurationSec;
  }

  public void setSessionDurationSec(Integer sessionDurationSec) {
    this.sessionDurationSec = sessionDurationSec;
  }

  public LocalDateTime getEventTime() {
    return eventTime;
  }

  public void setEventTime(LocalDateTime eventTime) {
    this.eventTime = eventTime;
  }

  public Actor getActor() {
    return actor;
  }

  public void setActor(Actor actor) {
    this.actor = actor;
  }

  public Target getTarget() {
    return target;
  }

  public void setTarget(Target target) {
    this.target = target;
  }

  public UsageContentSession getSession() {
    return session;
  }

  public void setSession(UsageContentSession session) {
    this.session = session;
  }

  public UsageContext getUsageContext() {
    return usageContext;
  }

  public void setUsageContext(UsageContext usageContext) {
    this.usageContext = usageContext;
  }

  @Override
  public String toString() {
    return "UsageContent{" +
        "id='" + id + '\'' +
        ", userId=" + userId +
        ", contentId='" + contentId + '\'' +
        ", eventType=" + eventType +
        ", sessionStart=" + sessionStart +
        ", sessionEnd=" + sessionEnd +
        ", sessionDurationSec=" + sessionDurationSec +
        ", eventTime=" + eventTime +
        ", actor=" + actor +
        ", target=" + target +
        ", session=" + session +
        ", usageContext=" + usageContext +
        '}';
  }
}