package io.hmheng.streaming.worker.reporting;

/**
 * Created by nandipatim on 3/23/17.
 */

import io.hmheng.reporting.aggregator.core.service.AuthorizationService;
import io.hmheng.reporting.aggregator.core.service.utils.HeadersHelper;
import io.hmheng.streaming.worker.reporting.domain.UsageSessionInfo;
import io.hmheng.streaming.worker.rest.RestTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

@Service
public class ReportingServiceImpl implements ReportingService{

  @Autowired
  private RestTemplateService restTemplateService;

  @Autowired
  private HeadersHelper headersHelper;

  @Value("${reporting.host.baseUrl}")
  private String reportingUrl;

  @Override
  public void publishUsageData(UsageSessionInfo usageSessionInfo) {

    HttpHeaders httpHeaders = headersHelper.createHttpHeaders(AuthorizationService.Service.Reporting);

    restTemplateService.postEntity(reportingUrl , "%s/v5/assessments/session", usageSessionInfo, httpHeaders);
  }
}
