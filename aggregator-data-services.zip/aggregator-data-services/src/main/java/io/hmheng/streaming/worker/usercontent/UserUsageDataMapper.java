package io.hmheng.streaming.worker.usercontent;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import io.hmheng.streaming.worker.usercontent.domain.UsageContent;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.function.Function;

/**
 * Created by nandipatim on 3/8/17.
 */
@Slf4j
@Component
public class UserUsageDataMapper implements Function<byte[], UsageContent> {

  private ObjectReader objectReader;

  public UserUsageDataMapper() {
    objectReader = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        .readerFor(UsageContent.class);
  }

  @Override
  public UsageContent apply(byte[] bytes) {
    try {
      log.info("Deserializing message into String from User Content Data services");
      UsageContent usageContent = (UsageContent) objectReader.readValue(bytes);
      return usageContent;
    } catch (IOException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
  }
}
