package io.hmheng.streaming.worker.usercontent.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 3/23/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Actor {
  private UUID userId;
  private String userName;
  private UUID districtRefId;
  private String districtId;
  private List<UserRole> roles;

  public UUID getUserId() {
    return userId;
  }

  public void setUserId(UUID userId) {
    this.userId = userId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public UUID getDistrictRefId() {
    return districtRefId;
  }

  public void setDistrictRefId(UUID districtRefId) {
    this.districtRefId = districtRefId;
  }

  public String getDistrictId() {
    return districtId;
  }

  public void setDistrictId(String districtId) {
    this.districtId = districtId;
  }

  public List<UserRole> getRoles() {
    return roles;
  }

  public void setRoles(List<UserRole> roles) {
    this.roles = roles;
  }

  @Override
  public String toString() {
    return "Actor{" +
        "userId=" + userId +
        ", userName='" + userName + '\'' +
        ", districtRefId=" + districtRefId +
        ", districtId='" + districtId + '\'' +
        ", roles=" + roles +
        '}';
  }
}
