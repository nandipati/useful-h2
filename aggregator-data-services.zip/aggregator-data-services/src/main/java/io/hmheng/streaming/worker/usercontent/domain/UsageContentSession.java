package io.hmheng.streaming.worker.usercontent.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Map;

/**
 * Created by nandipatim on 3/23/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsageContentSession {

  private Map<String,Object> hierarchy;

  public Map<String, Object> getHierarchy() {
    return hierarchy;
  }

  public void setHierarchy(Map<String, Object> hierarchy) {
    this.hierarchy = hierarchy;
  }

  @Override
  public String toString() {
    return "UsageContentSession{" +
        "hierarchy=" + hierarchy +
        '}';
  }
}
