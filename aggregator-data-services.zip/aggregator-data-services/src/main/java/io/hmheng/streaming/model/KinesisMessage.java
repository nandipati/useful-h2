package io.hmheng.streaming.model;

import com.amazonaws.services.kinesis.model.Record;

import java.io.Serializable;

import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Builder;
import lombok.Data;

/**
 * Created by fodori on 2/21/17.
 */
@Data
public class KinesisMessage<T> extends StreamMessage implements Serializable {

  private String stream;

  private Record originalMessageWithoutPayload;

  @Builder
  private KinesisMessage(String appName, byte[] messagePayload, Class<? extends Function<byte[], T>> mapperBeanClass,
                         Class<? extends Consumer<T>> processorBeanClass , String stream , Record originalMessageWithoutPayload){
    super(appName , messagePayload , mapperBeanClass , processorBeanClass);
    this.stream = stream;
    this.originalMessageWithoutPayload = originalMessageWithoutPayload;
  }
}
