package io.hmheng.streaming.driver.streams;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;

import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kinesis.KinesisUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import io.hmheng.streaming.model.KinesisMessage;
import io.hmheng.streaming.model.KinesisRecordMapper;

/**
 * Created by nandipatim on 1/24/17.
 */
@Slf4j
@Component
public class AmazonKinesisStreamFactory implements InputStreamFactory<KinesisMessage>, Serializable {

  private static final long serialVersionUID = 1L;

  @Autowired
  private KinesisStreamConfigurations streamConfigurations;

  public Map<String , JavaDStream<KinesisMessage>> create(JavaStreamingContext streamingContext) {

    Map<String , JavaDStream<KinesisMessage>> dStreamMap = new HashMap<>();

    if(streamConfigurations == null){
      throw new RuntimeException("Stream Configurations cannot be Null");
    }

    try {
      for (KinesisStreamConfigurations.KinesisStreamConfiguration streamConfiguration : streamConfigurations
          .getStreamConfigurations()) {
        List<JavaDStream<KinesisMessage>> dStreamLists = new ArrayList<>();
        log.debug("Creating spark streams for stream {}", streamConfiguration.getStream());
        int numShards = streamConfiguration.describeStream().getStreamDescription().getShards().size();
        log.debug("Found {} shards for {}", numShards, streamConfiguration.getStream());
        dStreamLists.addAll(createStreams(streamingContext, streamConfiguration, new Duration(2000), numShards));
        JavaDStream<KinesisMessage> uStreams = unionStreams(dStreamLists, streamingContext);
        uStreams.repartition(streamConfiguration.getSparkProcessingParallelism());
        dStreamMap.put(streamConfiguration.getRoleSessionName() , uStreams);
      }
    } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
      throw new RuntimeException(e);
    }

    return dStreamMap;
  }

  protected List<JavaDStream<KinesisMessage>> createStreams(JavaStreamingContext jssc,
                                                            KinesisStreamConfigurations.KinesisStreamConfiguration streamConfig, Duration kinesisCheckpointInterval, int numStreams)
      throws ClassNotFoundException, IllegalAccessException, InstantiationException {
    List<JavaDStream<KinesisMessage>> dStreamsList = new ArrayList<>(numStreams);
    for (int i = 0; i < numStreams; i++) {
      dStreamsList.add(createStream(jssc, streamConfig, kinesisCheckpointInterval));
    }
    return dStreamsList;
  }

  protected JavaDStream<KinesisMessage> createStream(JavaStreamingContext jssc,
                                                     KinesisStreamConfigurations.KinesisStreamConfiguration streamConfig, Duration kinesisCheckpointInterval) throws ClassNotFoundException {

    KinesisRecordMapper kinesisRecordMapper = KinesisRecordMapper.builder().stream(streamConfig.getStream())
        .appName(streamConfig.getAppName())
        .mapperBeanClass((Class<Function<byte[], Object>>) Class.forName(streamConfig.getMapperBeanClass()))
        .processorBeanClass((Class<Consumer<Object>>) Class.forName(streamConfig.getProcessorBeanClass())).build();

    JavaDStream<KinesisMessage> stream;
    if (streamConfig.isUseSts()) {
      stream = KinesisUtils
          .createStream(jssc, streamConfig.getAppName(), streamConfig.getStream(),  streamConfig.getKinesisEndpoint(),
              streamConfig.getRegion(), InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval,
              StorageLevel.MEMORY_AND_DISK_2(), kinesisRecordMapper, KinesisMessage.class, null, null,
              streamConfig.getRoleArn(), streamConfig.getRoleSessionName(), null);
    } else {
      stream = KinesisUtils
          .createStream(jssc, streamConfig.getAppName(), streamConfig.getStream(), streamConfig.getKinesisEndpoint(),
              streamConfig.getRegion(), InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval,
              StorageLevel.MEMORY_AND_DISK_2(), kinesisRecordMapper, KinesisMessage.class);
    }

    return stream;
  }

  protected <T> JavaDStream<T> unionStreams(List<JavaDStream<T>> dStreamLists, JavaStreamingContext streamingContext) {

    System.out.println("dStreamLists size "+dStreamLists.size());

    return (dStreamLists.size() > 1) ?
        streamingContext.union(dStreamLists.get(0), dStreamLists.subList(1, dStreamLists.size())) :
        dStreamLists.get(0);
  }

}
