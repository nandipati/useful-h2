package io.hmheng.streaming.driver.streams;

import com.esotericsoftware.kryo.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 5/10/18.
 */
@Data
@Component
@NoArgsConstructor
@ConfigurationProperties("spark.kafka")
@EnableConfigurationProperties
public class KafkaConfigurations extends StreamConfiguration {

  @NotNull
  private String brokers;

  @NotNull
  private String topic;
}
