package io.hmheng.streaming.worker.scoring;

import com.hmhco.api.scoring.view.save.itemlevel.BenchmarkTestItemLevel;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.function.Consumer;

import io.hmheng.reporting.aggregator.core.service.AuthorizationDetails;
import io.hmheng.reporting.aggregator.core.service.AuthorizationService;

/**
 * Created by fodori on 2/22/17.
 */
@Slf4j
@Component
public class BMTestLevelItemProcessor implements Consumer<BenchmarkTestItemLevel> {

  private RestTemplate rest;

  @Value("${scoring.host.baseUrl}")
  private String scoringUrl;

  private AuthorizationService authorizationService;

  @Autowired
  public BMTestLevelItemProcessor(AuthorizationService authorizationService) {
    this.authorizationService = authorizationService;
    rest = new RestTemplate();
  }

  @Override
  public void accept(BenchmarkTestItemLevel bmTestLevelItem) {
    AuthorizationDetails auth = authorizationService
        .createSIFAuthorization(AuthorizationService.Service.Scoring);
    log.info("Processing BenchmarkTestItemLevel: {}", bmTestLevelItem);

    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.AUTHORIZATION, auth.getSifAuthorization().getAuthorization());
    headers.add("authCurrentDateTime", auth.getAuthCurrentDateTime());
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
    HttpEntity<BenchmarkTestItemLevel> http = new HttpEntity<>(bmTestLevelItem, headers);
    ResponseEntity<String> response = rest
        .postForEntity(String.format("%s/v1/benchmark/itemlevel", scoringUrl), http, String.class);
    if (!response.getStatusCode().is2xxSuccessful()) {
      log.error("Unable to process BenchmarkTestItemLevel, server returned {}", response.getStatusCodeValue());
      log.error("Response body: ", response.getBody());
      throw new RuntimeException(String.format("Unable to process BenchmarkTestItemLevel, server returned %d",
          response.getStatusCodeValue()));
    }

  }
}
