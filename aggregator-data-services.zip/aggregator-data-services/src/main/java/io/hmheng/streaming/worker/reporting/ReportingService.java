package io.hmheng.streaming.worker.reporting;

import io.hmheng.streaming.worker.reporting.domain.UsageSessionInfo;

/**
 * Created by nandipatim on 3/23/17.
 */
public interface ReportingService {

  void publishUsageData(UsageSessionInfo usageSessionInfo);
}
