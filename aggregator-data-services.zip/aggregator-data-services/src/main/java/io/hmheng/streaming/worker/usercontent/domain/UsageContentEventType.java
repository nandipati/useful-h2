package io.hmheng.streaming.worker.usercontent.domain;

/**
 * Created by nandipatim on 3/23/17.
 */
public enum UsageContentEventType {
  Session;
}
