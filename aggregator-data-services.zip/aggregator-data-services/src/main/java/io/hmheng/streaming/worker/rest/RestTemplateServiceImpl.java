package io.hmheng.streaming.worker.rest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * Created by nandipatim on 3/23/17.
 */
@Slf4j
@Service
public class RestTemplateServiceImpl implements RestTemplateService{

  private RestTemplate rest;

  @Autowired
  public RestTemplateServiceImpl(){
    rest = new RestTemplate();
  }

  @Override
  public void postEntity(String serviceUrl, String uri, Object domainObject , HttpHeaders httpHeaders) {

    if(domainObject != null) {
      log.info("UsageSessionInfo Data RestTemplateServiceImpl {}",domainObject.toString());
    }

    HttpEntity<Object> httpEntity = new HttpEntity<>(domainObject , httpHeaders);
    String url = String.format(uri, serviceUrl);
    ResponseEntity<String> response = rest.postForEntity(url , httpEntity , String.class);

    if(!response.getStatusCode().is2xxSuccessful()){
      log.error("Unable process for url {} , server returned {}", url , response.getStatusCodeValue());
      log.error("Response body: ", response.getBody());
      throw new RuntimeException("Unable process for url "+url+" , server returned "+
          response.getStatusCodeValue());

    }
  }
}
