package io.hmheng.streaming.worker.usercontent.domain;

/**
 * Created by nandipatim on 3/23/17.
 */
public enum UserRole {
  Learner("ROLE_STUDENT"),
  Instructor("ROLE_TEACHER"),
  SCHOOL_ADMINISTRATOR("ROLE_SCHOOL_ADMINISTRATOR"),
  DISTRICT_ADMINISTRATOR("ROLE_DISTRICT_ADMINISTRATOR"),
  TEACHER("ROLE_TEACHER"),
  STUDENT("ROLE_STUDENT"),
  TRUSTEDAPI("ROLE_TRUSTEDAPI"),
  ROLE_STUDENT("ROLE_STUDENT"),
  ROLE_TEACHER("ROLE_TEACHER"),
  ROLE_SCHOOL_ADMINISTRATOR("ROLE_SCHOOL_ADMINISTRATOR"),
  ROLE_DISTRICT_ADMINISTRATOR("ROLE_DISTRICT_ADMINISTRATOR"),
  ROLE_TRUSTEDAPI("ROLE_TRUSTEDAPI"),
  ROLE_USER("ROLE_STUDENT");

  private final String userRoleName;

  UserRole(String userRole){
    this.userRoleName = userRole;
  }

  public String getUserRoleName() {
    return userRoleName;
  }
}
