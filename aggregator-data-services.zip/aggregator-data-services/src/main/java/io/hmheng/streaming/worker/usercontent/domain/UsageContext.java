package io.hmheng.streaming.worker.usercontent.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.UUID;

/**
 * Created by nandipatim on 3/23/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsageContext {

  private UUID id;
  private UUID assignmentId;
  private String resourceId;
  private String viewType;
  private String programId;
  private String programName;

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public UUID getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(UUID assignmentId) {
    this.assignmentId = assignmentId;
  }

  public String getResourceId() {
    return resourceId;
  }

  public void setResourceId(String resourceId) {
    this.resourceId = resourceId;
  }

  public String getViewType() {
    return viewType;
  }

  public void setViewType(String viewType) {
    this.viewType = viewType;
  }

  public String getProgramId() {
    return programId;
  }

  public void setProgramId(String programId) {
    this.programId = programId;
  }

  public String getProgramName() {
    return programName;
  }

  public void setProgramName(String programName) {
    this.programName = programName;
  }

  @Override
  public String toString() {
    return "UsageContext{" +
        "id=" + id +
        ", assignmentId=" + assignmentId +
        ", resourceId='" + resourceId + '\'' +
        ", viewType='" + viewType + '\'' +
        ", programId='" + programId + '\'' +
        ", programName='" + programName + '\'' +
        '}';
  }
}
