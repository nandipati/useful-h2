package io.hmheng.streaming.worker.reporting.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.hmheng.reporting.aggregator.utils.JsonCommons;
import io.hmheng.streaming.worker.usercontent.domain.Level;
import io.hmheng.streaming.worker.usercontent.domain.UsageContentEventType;
import io.hmheng.streaming.worker.usercontent.domain.UsageContext;
import io.hmheng.streaming.worker.usercontent.domain.UserRole;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 3/24/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsageSessionInfo {

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  private LocalDateTime eventTime;
  private String id;
  private String contentId;
  private UUID userId;
  private String userName;
  private UUID districtRefId;
  private String districtId;
  private List<UserRole> roles;
  private UsageContentEventType eventType;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  private LocalDateTime sessionStart;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  private LocalDateTime sessionEnd;
  private Integer sessionDurationSec;
  private List<Level> hierarchy;
  private UsageContext usageContext;

  public LocalDateTime getEventTime() {
    return eventTime;
  }

  public void setEventTime(LocalDateTime eventTime) {
    this.eventTime = eventTime;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getContentId() {
    return contentId;
  }

  public void setContentId(String contentId) {
    this.contentId = contentId;
  }

  public UUID getUserId() {
    return userId;
  }

  public void setUserId(UUID userId) {
    this.userId = userId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public UUID getDistrictRefId() {
    return districtRefId;
  }

  public void setDistrictRefId(UUID districtRefId) {
    this.districtRefId = districtRefId;
  }

  public String getDistrictId() {
    return districtId;
  }

  public void setDistrictId(String districtId) {
    this.districtId = districtId;
  }

  public List<UserRole> getRoles() {
    return roles;
  }

  public void setRoles(List<UserRole> roles) {
    this.roles = roles;
  }

  public UsageContentEventType getEventType() {
    return eventType;
  }

  public void setEventType(UsageContentEventType eventType) {
    this.eventType = eventType;
  }

  public LocalDateTime getSessionStart() {
    return sessionStart;
  }

  public void setSessionStart(LocalDateTime sessionStart) {
    this.sessionStart = sessionStart;
  }

  public LocalDateTime getSessionEnd() {
    return sessionEnd;
  }

  public void setSessionEnd(LocalDateTime sessionEnd) {
    this.sessionEnd = sessionEnd;
  }

  public Integer getSessionDurationSec() {
    return sessionDurationSec;
  }

  public void setSessionDurationSec(Integer sessionDurationSec) {
    this.sessionDurationSec = sessionDurationSec;
  }

  public List<Level> getHierarchy() {
    return hierarchy;
  }

  public void setHierarchy(List<Level> hierarchy) {
    this.hierarchy = hierarchy;
  }

  public UsageContext getUsageContext() {
    return usageContext;
  }

  public void setUsageContext(UsageContext usageContext) {
    this.usageContext = usageContext;
  }

  @Override
  public String toString() {
    return "UsageSessionInfo{" +
        "eventTime=" + eventTime +
        ", id='" + id + '\'' +
        ", contentId='" + contentId + '\'' +
        ", userId=" + userId +
        ", userName='" + userName + '\'' +
        ", districtRefId=" + districtRefId +
        ", districtId='" + districtId + '\'' +
        ", roles=" + roles +
        ", eventType='" + eventType + '\'' +
        ", sessionStart=" + sessionStart +
        ", sessionEnd=" + sessionEnd +
        ", sessionDurationSec=" + sessionDurationSec +
        ", hierarchy=" + hierarchy +
        ", usageContext=" + usageContext +
        '}';
  }
}
