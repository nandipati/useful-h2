package io.hmheng.streaming.worker.reporting.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * Created by nandipatim on 3/25/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsageAssessmentSessionInfo {

  private List<UsageSessionInfo> assessmentSession;

  public List<UsageSessionInfo> getAssessmentSession() {
    return assessmentSession;
  }

  public void setAssessmentSession(List<UsageSessionInfo> assessmentSession) {
    this.assessmentSession = assessmentSession;
  }

  @Override
  public String toString() {
    return "UsageAssessmentSessionInfo{" +
        "assessmentSession=" + assessmentSession +
        '}';
  }
}
