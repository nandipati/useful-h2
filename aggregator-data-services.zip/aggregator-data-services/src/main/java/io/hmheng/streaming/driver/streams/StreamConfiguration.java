package io.hmheng.streaming.driver.streams;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/**
 * Created by nandipatim on 5/10/18.
 */

@Data
@NoArgsConstructor
public class StreamConfiguration implements Serializable {

  @NonNull
  protected String mapperBeanClass;

  @NonNull
  protected String processorBeanClass;

  @NonNull
  protected String appName;

}
