package io.hmheng.streaming.worker.usercontent;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import io.hmheng.streaming.worker.reporting.ReportingService;
import io.hmheng.streaming.worker.reporting.domain.UsageSessionInfo;
import io.hmheng.streaming.worker.usercontent.domain.Actor;
import io.hmheng.streaming.worker.usercontent.domain.Level;
import io.hmheng.streaming.worker.usercontent.domain.Target;
import io.hmheng.streaming.worker.usercontent.domain.UsageContent;
import io.hmheng.streaming.worker.usercontent.domain.UsageContentSession;
import io.hmheng.streaming.worker.usercontent.domain.UsageContext;
import io.hmheng.streaming.worker.usercontent.domain.UserRole;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.function.Consumer;
import org.springframework.util.CollectionUtils;

/**
 * Created by nandipatim on 3/8/17.
 */
@Slf4j
@Component
public class UserUsageDataProcessor implements Consumer<UsageContent> {

  @Autowired
  private ReportingService reportingService;

  private ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

  @Override
  public void accept(UsageContent userUsageData) {

    log.info("Processing User Usage Data: {}", userUsageData);
    reportingService.publishUsageData(constructUsageReportInfo(userUsageData));

  }

  private UsageSessionInfo constructUsageReportInfo(UsageContent usageContent){

    UsageSessionInfo usageSessionInfo = new UsageSessionInfo();
    BeanUtils.copyProperties(usageContent, usageSessionInfo);
    Target target = usageContent.getTarget();
    if(target != null) {
      UsageContext context = usageSessionInfo.getUsageContext();
      if(context == null) {
        context = new UsageContext();
      }
      context.setViewType(target.getViewType());
      context.setProgramId(target.getProgramId());
      context.setProgramName(target.getProgramName());
    }

    UsageContentSession session = usageContent.getSession();
    if(session != null){
      Map<String,Object> sessionHierarchy = session.getHierarchy();
      if(sessionHierarchy != null) {
        int size = 0 ;
        try{
          size = (Integer)sessionHierarchy.get("size");
        }catch(Exception exs){
          log.error("Processing Error for Siz in Hierarcy: {} for session {}", sessionHierarchy.get("size")
              , usageContent.getId());
        }
        List<Level> hierarchy = new ArrayList<>();
        int loop = 0;
        while (loop < size){
          Object object = sessionHierarchy.get(String.valueOf(loop));
          if(object != null) {
            Level level = getLevelFromObject(object);
            hierarchy.add(level);
          }
          loop++;
        }
        usageSessionInfo.setHierarchy(hierarchy);
      }
    }

    Actor actor = usageContent.getActor();
    if(actor != null){
      usageSessionInfo.setDistrictId(actor.getDistrictId());
      usageSessionInfo.setDistrictRefId(actor.getDistrictRefId());
      List<UserRole> userRoles = actor.getRoles();
      List<UserRole> reportingRole= new ArrayList<>();
      if(!CollectionUtils.isEmpty(userRoles)){
        for (UserRole userRole : userRoles) {
          reportingRole.add(UserRole.valueOf(userRole.getUserRoleName()));
        }
      }
        usageSessionInfo.setRoles(reportingRole);
      usageSessionInfo.setUserName(actor.getUserName());
    }

    return usageSessionInfo;
  }

  private Level getLevelFromObject(Object object){
    return objectMapper.convertValue(object , Level.class);
  }

}
