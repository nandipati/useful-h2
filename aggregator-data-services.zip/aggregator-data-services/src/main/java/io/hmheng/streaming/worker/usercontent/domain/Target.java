package io.hmheng.streaming.worker.usercontent.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.UUID;

/**
 * Created by nandipatim on 3/23/17.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Target {
  private String viewType;
  private String programId;
  private String programName;

  public String getViewType() {
    return viewType;
  }

  public void setViewType(String viewType) {
    this.viewType = viewType;
  }

  public String getProgramId() {
    return programId;
  }

  public void setProgramId(String programId) {
    this.programId = programId;
  }

  public String getProgramName() {
    return programName;
  }

  public void setProgramName(String programName) {
    this.programName = programName;
  }

  @Override
  public String toString() {
    return "Target{" +
        "viewType='" + viewType + '\'' +
        ", programId='" + programId + '\'' +
        ", programName='" + programName + '\'' +
        '}';
  }
}
