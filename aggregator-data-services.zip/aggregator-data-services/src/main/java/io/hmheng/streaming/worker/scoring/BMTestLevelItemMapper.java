package io.hmheng.streaming.worker.scoring;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.hmhco.api.scoring.view.save.itemlevel.BenchmarkTestItemLevel;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.function.Function;

/**
 * Created by fodori on 2/22/17.
 */
@Slf4j
@Component
public class BMTestLevelItemMapper implements Function<byte[], BenchmarkTestItemLevel> {

  private ObjectReader objectReader;

  @Autowired
  public BMTestLevelItemMapper() {
    objectReader = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        .disable(DeserializationFeature.ACCEPT_FLOAT_AS_INT).readerFor(BenchmarkTestItemLevel.class);
  }

  @Override
  public BenchmarkTestItemLevel apply(byte[] bytes) {
    try {
      log.info("Deserializing message into BMTestLevelItem");
      return objectReader.readValue(bytes);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
}
