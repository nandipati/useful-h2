package io.hmheng.streaming.worker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Created by fodori on 2/21/17.
 */
@Component
public class WorkerContext {

  public final static ApplicationContext applicationContext = null;

  @Autowired
  public WorkerContext(ApplicationContext applicationContext) throws Exception {
    setApplicationContext(WorkerContext.class.getField("applicationContext"), applicationContext);
  }

  /**
   * Workaround, so we can keep the application context field final, so it is not easily accessible from the outside.
   */
  private void setApplicationContext(Field field, Object newValue) throws Exception {
    field.setAccessible(true);

    Field modifiersField = Field.class.getDeclaredField("modifiers");
    modifiersField.setAccessible(true);
    modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

    field.set(null, newValue);

    modifiersField.setInt(field, field.getModifiers() | Modifier.FINAL);
    modifiersField.setAccessible(false);
    field.setAccessible(false);
  }

}
