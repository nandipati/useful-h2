package io.hmheng.streaming.model;

import java.io.Serializable;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Created by nandipatim on 5/17/18.
 */
@Data
@Builder
@Slf4j
public class KafkaConsumerRecordMapper<T> implements Serializable {

  private String appName;

  private String topic;

  private byte[] messagePayload;

  private Class<? extends Function<byte[], T>> mapperBeanClass;

  private Class<? extends Consumer<T>> processorBeanClass;

  private ConsumerRecord<String, String> originalMessageWithoutPayload;

  public KafkaMessage call(ConsumerRecord<String, String> record){

    if(record == null || record.value() == null){
      throw new RuntimeException("Record cannot be Null for Topic"+topic);
    }

    if(record != null) {
      String data = record.value();
      log.info(" Records in KinesisRecordMapper {}", data);
    }


    KafkaMessage kafkaMessage = ((KafkaMessage.KafkaMessageBuilder<T>) KafkaMessage.builder()).topic(topic).appName(appName)
        .mapperBeanClass(mapperBeanClass).processorBeanClass(processorBeanClass)
        .messagePayload(record.value().getBytes()).originalMessageWithoutPayload(record).build();

    return kafkaMessage;
  }
}
