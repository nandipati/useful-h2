package io.hmheng.streaming.model;

import com.amazonaws.services.kinesis.model.Record;
import java.io.Serializable;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Builder;
import lombok.Data;
import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Created by nandipatim on 5/17/18.
 */
@Data
public class KafkaMessage<T> extends StreamMessage implements Serializable{

  private String topic;

  private ConsumerRecord<String, String> originalMessageWithoutPayload;

  @Builder
  private KafkaMessage(String appName, byte[] messagePayload, Class<? extends Function<byte[], T>> mapperBeanClass,
                         Class<? extends Consumer<T>> processorBeanClass , String topic , ConsumerRecord<String, String> originalMessageWithoutPayload){
    super(appName , messagePayload , mapperBeanClass , processorBeanClass);
    this.topic = topic;
    this.originalMessageWithoutPayload = originalMessageWithoutPayload;
  }
}
