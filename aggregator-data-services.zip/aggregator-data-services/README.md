##To test scoring item level data:

1. Make sure AWS credentials are set (riverside-non-prod)
2. Run DataServicesDriverApp with the following spring profiles: local,dev
3. command line: sh assume_role.sh
4. command line: source set_env
5. Run test_kinesis_item_level.sh or test_kinesis_item_level_loop.sh
6. After testing, delete set_env!