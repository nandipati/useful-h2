package io.hmheng.grading.streams.grading;


import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.streams.grading.domain.StudentActivitySession;
import io.hmheng.grading.streams.grading.domain.ActivityItemsView;
import io.hmheng.grading.util.enums.TestType;

import java.util.UUID;
import org.springframework.http.ResponseEntity;

/**
 * Created by nandipatim on 5/31/17.
 */
public interface GradingService {
  //Grading method to post scores from lernosity.

  ResponseEntity<String> postToGrading(StudentActivitySession studentActivitySession, UUID sessionId);

  StudentActivitySession convertToGradingStructure(StudentSession studentSession, ActivityItemsView activityItemsView);

  ActivityItemsView getGradingActivity(UUID activityId);

}
