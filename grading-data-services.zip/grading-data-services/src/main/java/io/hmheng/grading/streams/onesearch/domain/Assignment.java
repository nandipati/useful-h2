package io.hmheng.grading.streams.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@JsonRootName("assessment")
public class Assignment {

  private List<Item> item;

}