package io.hmheng.grading.streams.grading.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.core.Relation;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by pabonaj on 6/6/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("question")
@Relation(value = "question", collectionRelation = "questions")
public class Questions extends AbstractRequest {

  @NotNull
  private String questionReference;

  private String rubricReference;

  private String questionType;

  private Boolean automarkable;


  private String errorMessage;

  List<Scores> scores;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Questions questions = (Questions) o;

    return !(questionReference != null ? !questionReference.equals(questions.questionReference) : questions.questionReference != null);

  }

  @Override
  public int hashCode() {
    return questionReference != null ? questionReference.hashCode() : 0;
  }

}