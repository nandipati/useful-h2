package io.hmheng.grading.streams.scoring;

import com.fasterxml.jackson.core.JsonProcessingException;

import org.springframework.http.ResponseEntity;

import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.streams.scoring.domain.Event;
import java.util.UUID;

/** Created by nandipatim on 5/31/17. */
public interface ScoringService {
  // Get Event Object from scoring

  Event getEventForActivityRefid(UUID activityRefId);

  ResponseEntity<String> createDeadLetterForStudentSessionReprocessing(StudentSession studentSession) throws
      JsonProcessingException;
}
