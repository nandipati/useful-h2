package io.hmheng.grading.streams.onesearch.decorator;

/**
 * Created by tallurir on 9/20/17.
 */
public enum ContentService {
    ON_SEARCH
}