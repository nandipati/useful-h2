package io.hmheng.grading.util.enums;

/**
 * Created by nandipatim on 4/4/17.
 */
public enum TestType {
  FORMATIVE(Boolean.FALSE , SourceType.HMHONE), BENCHMARK(Boolean.FALSE , SourceType.HMHONE)
  , PROGRAM(Boolean.TRUE , SourceType.ED) , PERFORMANCE_TASK(Boolean.TRUE , SourceType.ED);

  private final Boolean gradingEligable;
  private final SourceType sourceType;

  TestType(Boolean gradingEligable,SourceType sourceType){
    this.gradingEligable = gradingEligable;
    this.sourceType = sourceType;
  }

  public Boolean isGradingEligable() {
    return gradingEligable;
  }

  public SourceType getSourceType() {
    return sourceType;
  }

  public static Boolean isPerformanceTask(String name){
    if(PERFORMANCE_TASK.name().equals(name)){
      return Boolean.TRUE;
    }
    return Boolean.FALSE;
  }
}
