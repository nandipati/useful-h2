package io.hmheng.grading;

import io.hmheng.grading.streams.onesearch.decorator.OneSearchRubricCallable;
import java.util.function.Function;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Scope;
import org.springframework.web.client.RestTemplate;

/**
 * Created by nandipatim on 5/17/17.
 */
@SpringBootApplication
@ComponentScan("com.hmhco,io.hmheng.grading")
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@EnableConfigurationProperties
public class GradingDataServicesApp {

  public static void main(String[] args) {SpringApplication.run(GradingDataServicesApp.class, args);
  }

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  @Bean
  @Scope(value = "prototype")
  public OneSearchRubricCallable oneSearchRubricCallable(String serviceURI) {
    return new OneSearchRubricCallable(serviceURI);
  }

  @Bean
  public Function<String, OneSearchRubricCallable> oneSearchRubricCallableFactory() {
    return serviceURI -> oneSearchRubricCallable(serviceURI);
  }
}
