package io.hmheng.grading.streams.onesearch.decorator;

import io.hmheng.grading.streams.grading.domain.Questions;
import io.hmheng.grading.streams.grading.domain.Scores;
import io.hmheng.grading.streams.onesearch.domain.Question;
import java.util.List;
import java.util.Map;


/**
 * Created by tallurir on 9/20/17.
 */

public  interface  BasicService {



    public  Request populateRequestInfo();
    public  String getServiceURI();
    public  Class getResponseClass();
    void setParameters(Object... args);
    Map<Questions, List<Scores>> getQuestionsScores(List<Question> questionList);
    List<Question> getItemsForAssesment();
    public int getNoRetries();
}
