package io.hmheng.grading.streams.grading.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;

/**
 * Created by tallurir on 10/10/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("activity")
public class ActivityItemsView {
    @NotNull
    private UUID activityRefId;

    @NotNull
    private UUID teacherAssignmentRefId;

    @NotNull
    private UUID staffPersonalRefId;

    private String activityTemplateId;

    private Integer maxScore;

    private Integer maxTime;

    private Integer numQuestions;

    private String assignmentType;

    private String sourceType;

    private List<Items> items;

    private List<ScoreExtnView> scoresExtn;

    private Boolean isNew = Boolean.FALSE;

}