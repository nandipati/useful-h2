package io.hmheng.grading.streams.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;


@Data
@NoArgsConstructor
@JsonRootName("question")
public class Question  {

  @NotNull
  private String identifier;

  private String interactivityType;

  private boolean manuallyScorable;

  List<Rubric> rubric;

}