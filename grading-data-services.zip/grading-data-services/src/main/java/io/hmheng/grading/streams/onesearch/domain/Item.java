package io.hmheng.grading.streams.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;


@Data
@NoArgsConstructor
@JsonRootName("item")
public class Item {
  @NotNull
  private String identifier;

  private Integer itemPosition;

  private Boolean manuallyScorable;

  private List<Question> question;

}