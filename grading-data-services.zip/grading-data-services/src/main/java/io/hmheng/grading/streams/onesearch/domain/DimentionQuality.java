package io.hmheng.grading.streams.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by tallurir on 9/26/17.
 */

@Data
@NoArgsConstructor
@JsonRootName("dimensionOfQuality")
public class DimentionQuality {

    @JsonIgnore
    @JsonProperty(value = "description")
    private List<String> description;
    private String identifier;
    @JsonIgnore
    @JsonProperty(value = "claim")
    private List<Claim> claim;
    private List<DimensionOutcome> dimensionOutcome;
}
