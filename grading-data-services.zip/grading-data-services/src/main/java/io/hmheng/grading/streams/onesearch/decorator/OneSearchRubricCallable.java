package io.hmheng.grading.streams.onesearch.decorator;


import io.hmheng.grading.authorization.AuthorizationService;
import io.hmheng.grading.authorization.util.HeadersHelper;
import io.hmheng.grading.rest.RestTemplateService;
import io.hmheng.grading.streams.onesearch.domain.OneSearchRubricResponse;
import io.hmheng.grading.utils.Constants;
import io.hmheng.grading.utils.MDCUtils;
import io.hmheng.grading.utils.MethodEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpClientErrorException;

import java.util.concurrent.Callable;

@Slf4j
public class OneSearchRubricCallable implements Callable<OneSearchRubricResponse> {

    @Autowired
    private HeadersHelper headersHelper;

    @Autowired
    private RestTemplateService restTemplateService;

    @Value("${onesearch.host.baseUrl}")
    protected String onesearchUrl;

    private String serviceURI;

    @Autowired
    public OneSearchRubricCallable(String serviceURI){
        this.serviceURI = serviceURI;
    }


    public OneSearchRubricResponse getRubricResponse(int count) throws Exception{

        HttpHeaders httpHeaders = headersHelper.createHttpHeadersWithCorrelation(AuthorizationService.Service.ON_SEARCH);
        Object rubricResponse = null;
        rubricResponse = null;
        StopWatch swOnsearchRebrics = MDCUtils.start();
        MDCUtils.addPropertyToMDC(Constants.METHOD_OR_ENDPOINT_TAG , MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING_ONSEARCH_GET_RUBRICS.name());

        try {
            rubricResponse = restTemplateService.getEntity(onesearchUrl, this.serviceURI ,httpHeaders, OneSearchRubricResponse.class);
            MDCUtils.stopAddPropertyToMDC(swOnsearchRebrics);
            log.info("Student Answer Sheet Processing (Get Rubrics from Onsearch)  Url: {} Took {} secs ", this.serviceURI  , swOnsearchRebrics.getTotalTimeSeconds());


        }catch(Exception ex){
            if(count <= 3) {

                if((ex instanceof HttpClientErrorException) || (ex.getCause() instanceof HttpClientErrorException)) {
                    HttpClientErrorException errorException = (HttpClientErrorException)ex;

                    if( errorException.getStatusCode().is5xxServerError()){
                        count++;
                        getRubricResponse(count);
                    }
                }

            } else {
                throw ex;

            }
        }

        if (rubricResponse != null && rubricResponse instanceof OneSearchRubricResponse) {

            return (OneSearchRubricResponse) rubricResponse;
        }

        return null;
    }



    @Override
    public OneSearchRubricResponse call() throws Exception {
        int count = 1;
        return getRubricResponse(count);
    }
}