package io.hmheng.grading.streams.grading.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.core.Relation;

/**
 * Created by nandipatim on 10/10/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("score-extn")
@Relation(value = "score-extn", collectionRelation = "scoresExtn")
public class ScoreExtnView {

    private String scoreReference;

    private Integer maxScore;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ScoreExtnView that = (ScoreExtnView) o;

        return scoreReference != null ? scoreReference.equals(that.scoreReference) : that.scoreReference == null;
    }

    @Override
    public int hashCode() {
        return scoreReference != null ? scoreReference.hashCode() : 0;
    }
}
