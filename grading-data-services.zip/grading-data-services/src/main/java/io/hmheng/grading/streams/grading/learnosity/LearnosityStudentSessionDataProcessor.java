package io.hmheng.grading.streams.grading.learnosity;

import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.rest.RestTemplateService;
import io.hmheng.grading.streams.grading.GradingService;
import io.hmheng.grading.streams.grading.domain.ActivityItemsView;
import io.hmheng.grading.streams.scoring.ScoringService;
import io.hmheng.grading.streams.scoring.domain.Event;
import io.hmheng.grading.util.enums.TestType;
import io.hmheng.grading.utils.Constants;
import io.hmheng.grading.utils.MDCUtils;
import io.hmheng.grading.utils.MethodEndpoint;
import java.util.UUID;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

/**
 * Created by nandipatim on 3/8/17.
 */
@Slf4j
@Component
public class LearnosityStudentSessionDataProcessor implements Consumer<StudentSession> {

  private String localUrl = "http://localhost:";

  @Autowired
  private RestTemplateService restTemplateService;

  @Autowired
  private Environment environment;


  @Override
  public void accept(StudentSession studentSession) {
    MDCUtils.addPropertyToMDC(Constants.SERVICE_NAME_TAG, Constants.SERVICE_NAME_GRADING_SERVICES);
    String[] profiles = environment.getActiveProfiles();
    if(environment != null &&  profiles != null && profiles.length > 0 ) {
      MDCUtils.addPropertyToMDC(Constants.STAGE, profiles[0]);
    }

    if(studentSession != null) {
      log.info("Processing Student Session Scores from Learnosity start: {}", studentSession);
      String port = environment.getProperty("local.server.port");
      restTemplateService.postEntity(localUrl+port ,"/v1/students/studentAnswerSheet" , studentSession , null);
    }
    MDCUtils.clean();
  }
}
