package io.hmheng.grading.streams.grading;

import com.google.gson.Gson;
import io.hmheng.grading.authorization.AuthorizationService;
import io.hmheng.grading.streams.grading.domain.ActivityItemsView;
import io.hmheng.grading.streams.grading.domain.ScoreExtnView;
import io.hmheng.grading.streams.onesearch.decorator.ContentService;
import io.hmheng.grading.streams.onesearch.decorator.Decorator;
import java.util.HashMap;

import io.hmheng.grading.util.enums.TestType;
import lombok.extern.slf4j.Slf4j;
import io.hmheng.grading.authorization.util.HeadersHelper;
import io.hmheng.grading.learnosity.domain.Item;
import io.hmheng.grading.learnosity.domain.Responses;
import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.rest.RestTemplateService;
import io.hmheng.grading.streams.grading.domain.ActivityItemScore;
import io.hmheng.grading.streams.grading.domain.Items;
import io.hmheng.grading.streams.grading.domain.Questions;
import io.hmheng.grading.streams.grading.domain.Scores;
import io.hmheng.grading.streams.grading.domain.StudentActivitySession;
import io.hmheng.grading.streams.grading.domain.StudentAssignmentStatus;
import io.hmheng.grading.streams.grading.domain.StudentItem;
import io.hmheng.grading.streams.grading.domain.StudentQuestion;
import io.hmheng.grading.streams.grading.domain.StudentScore;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.Map;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;
import org.springframework.util.CollectionUtils;

/**
 * Created by nandipatim on 5/31/17.
 */
@Slf4j
@Service
public class GradingServiceImpl implements GradingService {

  @Autowired
  private RestTemplateService restTemplateService;

  @Autowired
  private HeadersHelper headersHelper;

  @Value("${grading.host.baseUrl}")
  private String gradingUrl;

  @Autowired
  public Decorator decorator;


  //Grading method to post scores from lernosity.
  @Override
  public ResponseEntity<String> postToGrading(StudentActivitySession studentActivitySession, UUID sessionId) {
    String uri = String.format("/v1/activities/%s/init", sessionId);
    HttpHeaders httpHeaders = headersHelper.createHttpHeadersWithCorrelation(AuthorizationService.Service.GRADING);
    return restTemplateService.postEntity(gradingUrl, uri, studentActivitySession, httpHeaders);
  }

  @Override
  public StudentActivitySession convertToGradingStructure(StudentSession studentSession, ActivityItemsView activityItemsView) {
    log.info("Start convertToGradingStructure sessionId {}", studentSession.getSessionId());
    StudentActivitySession studentActivitySession = getActivitySession(studentSession , activityItemsView);
    Map<Questions, List<Scores>>  questionScoresMap = null;
    if(activityItemsView.getIsNew()){
      questionScoresMap = processOneSearch(activityItemsView.getActivityTemplateId());
    }else{
      questionScoresMap = getQuestionScoreMapFromGrading(activityItemsView);
    }

    List<Item> itemList = studentSession.getItems();
    List<Responses> responsesList = studentSession.getResponses();

    if (!CollectionUtils.isEmpty(itemList)) {
      List<Items> gradingItemsList = getItems(itemList, responsesList , questionScoresMap, activityItemsView);
      studentActivitySession.setItems(gradingItemsList);
    }

    if (responsesList != null) {
      List<ActivityItemScore> activityItemScoreList = getActivityItemScore(responsesList , questionScoresMap, activityItemsView);
      studentActivitySession.setActivityItems(activityItemScoreList);
    }

    if (itemList != null && responsesList != null) {
      List<StudentItem> studentItemList = getStudentItem(itemList, responsesList, studentSession.getSessionId(),
        questionScoresMap, activityItemsView);
      studentActivitySession.setStudentItems(studentItemList);
    }

    log.info("After ConvertToGradingStructure StudentActivitySession {}", studentActivitySession);

    return studentActivitySession;
  }

  private List<Item>  getAddonItems(List<Item> itemList, ActivityItemsView activityItemsView) {
    List<Item> addOnItems = new ArrayList<>();
    List<Items>  items = activityItemsView == null? null : activityItemsView.getItems();

    if(items != null) {

      List<String> itemRefs = items.stream().map(i -> i.getItemReference().toUpperCase()).collect(Collectors.toList());
      List<String> itemListRefs = itemList.stream().map(i -> i.getReference().toUpperCase()).collect(Collectors.toList());
      itemListRefs.removeAll(itemRefs);

      if(!itemListRefs.isEmpty()){
        addOnItems= itemList.stream().filter(i -> itemListRefs.contains(i.getReference().toUpperCase())).collect(Collectors.toList());
      }
    } else {
      addOnItems = itemList;
    }
    return addOnItems;
  }


  public Map<Questions, List<Scores>> getQuestionScoreMapFromGrading(ActivityItemsView activityItemsView){

    Map<Questions , List<Scores>> manualQuestionScoreMap = new HashMap<>();

    List<Items> itemsList = activityItemsView.getItems();
    List<ScoreExtnView>  scoreExtnViews = activityItemsView.getScoresExtn();

    if(!CollectionUtils.isEmpty(itemsList)){
      itemsList.stream().forEach(items -> {
        List<Questions> questionsList = items.getQuestions();
        if(!CollectionUtils.isEmpty(questionsList)){
          questionsList.stream().forEach(questions -> {
             if(questions != null){
               List<Scores>  scoresList = questions.getScores();
               manualQuestionScoreMap.put(questions , scoresList);
               if(!CollectionUtils.isEmpty(scoresList)){
                 scoresList.stream().forEach(scores -> {
                   if(scoreExtnViews != null){
                     ScoreExtnView scoreExtnView = new ScoreExtnView();
                     scoreExtnView.setScoreReference(scores.getScoreReference());
                     int scoreExtnViewIndex = scoreExtnViews.indexOf(scoreExtnView);
                     if(scoreExtnViewIndex != -1){
                       scoreExtnView = scoreExtnViews.get(scoreExtnViewIndex);
                       scores.setMaxScore(scoreExtnView.getMaxScore());
                       scores.setWeight(scoreExtnView.getMaxScore());
                     }
                   }

                 });
               }

             }
          });
        }
      });
    }

    return manualQuestionScoreMap;
  }

  @Override
  public ActivityItemsView getGradingActivity(UUID activityId) {
        HttpHeaders httpHeaders = headersHelper.createHttpHeadersWithCorrelation(AuthorizationService.Service.GRADING);
        String uri = String.format("/v1/assignments/%s/activityItems", activityId);
        ActivityItemsView response = (ActivityItemsView) restTemplateService.getEntity(gradingUrl, uri, httpHeaders, ActivityItemsView.class);
        return response;
      }

  private StudentActivitySession getActivitySession(StudentSession studentSession , ActivityItemsView activityItemsView) {
    StudentActivitySession studentActivitySession = new StudentActivitySession();
    studentActivitySession.setSessionRefId(studentSession.getSessionId());
    studentActivitySession.setActivityRefId(studentSession.getActivityId());
    studentActivitySession.setStatus(StudentAssignmentStatus.READY_FOR_SCORING);
    studentActivitySession.setMaxScore(studentSession.getMaxScore());
    studentActivitySession.setNumQuestions(studentSession.getNumQuestions());
    studentActivitySession.setStudentPersonalRefId(studentSession.getUserId());
    studentActivitySession.setNumAttempted(studentSession.getNumAttempted());
    studentActivitySession.setScore(studentSession.getScore());
    studentActivitySession.setSessionDuration(studentSession.getSessionDuration());
    studentActivitySession.setDateStarted(studentSession.getStartDate());
    studentActivitySession.setDateCompleted(studentSession.getCompletedDate());
    studentActivitySession.setUserAgent(studentSession.getMetadata().getUserAgent());
    studentActivitySession.setMaxTime(studentSession.getMetadata().getMaxTime());
    String resourceId = studentSession.getMetadata().getActivityTemplateId();
    if(activityItemsView.getActivityTemplateId() != null) {
      studentActivitySession.setActivityTemplateId(activityItemsView.getActivityTemplateId());
    } else {
      studentActivitySession.setActivityTemplateId(resourceId);
    }
    studentActivitySession.setStaffPersonalRefId(activityItemsView.getStaffPersonalRefId());
    studentActivitySession.setTeacherAssignmentRefId(activityItemsView.getTeacherAssignmentRefId());
    studentActivitySession.setAssignmentType(activityItemsView.getAssignmentType());
    studentActivitySession.setSourceType(activityItemsView.getSourceType());
    return studentActivitySession;
  }

  private List<Items> getItems(List<Item> itemList, List<Responses> responsesList, Map<Questions, List<Scores>>  questionScoresMap, ActivityItemsView activityItemsView) {
    itemList = getAddonItems(itemList,activityItemsView);
    List<Items> gradingItemsList = new ArrayList<Items>();
    for (Item item : itemList) {
      Items gradingItems = new Items();
      gradingItems.setItemReference(item.getReference());
      if (item.getSource() != null) {
        gradingItems.setOrganizationId(item.getSource().getOrganisationId());
        gradingItems.setItemPoolId(item.getSource().getItemPoolId());
      }
      if (item.getScoring() != null) {
        gradingItems.setType(item.getScoring().getType());
      }
      String assignmentType = activityItemsView.getAssignmentType();
      if(TestType.isPerformanceTask(assignmentType)){
        gradingItems.setItemReference(questionScoresMap.entrySet().iterator().next().getKey().getQuestionReference());
        // TODO NEED TO TAKE OFF IF PERFORMANCE MODEL IS CHANGED
      }
      if (responsesList != null) {
        List<Questions> gradingQuestionsList = getQuestions(responsesList, item.getReference() , questionScoresMap, activityItemsView);
        gradingItems.setQuestions(gradingQuestionsList);
      }
      gradingItemsList.add(gradingItems);
    }
    return gradingItemsList;
  }

  protected List<Questions> getQuestions(List<Responses> responsesList, String itemReference , Map<Questions , List<Scores>> questionsListMap, ActivityItemsView activityItemsView) {
    List<Responses> foundResponsesList = responsesList.stream().filter(r -> r.getItemReference().equals(itemReference)).collect(Collectors.toList());
    List<Questions> gradingQuestionsList = new ArrayList<Questions>();
    Set<Questions> questionsSet = questionsListMap != null ? questionsListMap.keySet() : null;
    if (foundResponsesList != null) {
      for (Responses foundResponses : foundResponsesList) {
        Questions questions = new Questions();
        questions.setQuestionReference(foundResponses.getQuestionReference());
        questions.setQuestionType(foundResponses.getQuestionType());
        questions.setAutomarkable(foundResponses.isAutomarkable());
        if (questionsSet != null && !questionsSet.isEmpty()) {
          Optional<Questions> questionsOptional = questionsSet.stream().filter(questions1 -> questions1.getQuestionReference().equals(questions.getQuestionReference())).findAny();
          if (questionsOptional.isPresent()) {
            questions.setErrorMessage(questionsOptional.get().getErrorMessage());
          }
        }
        if(!CollectionUtils.isEmpty(questionsListMap)) {
          String assignmentType = activityItemsView.getAssignmentType();
          if(TestType.isPerformanceTask(assignmentType)){
            Map.Entry<Questions, List<Scores>> entry = questionsListMap.entrySet().iterator().next();
            Questions questions1 = entry.getKey();
            List<Scores> scores = entry.getValue();
            questions1.setScores(scores);
            gradingQuestionsList.add(questions1);
            return gradingQuestionsList;

            //TODO NEED TO CHANGE IT ONCE PERFORMANCE MODEL IS CHANGED
          }
        }
        if(!CollectionUtils.isEmpty(questionsListMap) && questionsListMap.containsKey(questions) && !questions.getAutomarkable()){
          Set<Questions> setQuestions = questionsListMap.keySet();
          if(!CollectionUtils.isEmpty(setQuestions)) {
            setQuestions.forEach(fromOnsearch -> {
              if(questions.equals(fromOnsearch)){
                questions.setRubricReference(fromOnsearch.getRubricReference());
                questions.setAutomarkable(fromOnsearch.getAutomarkable());
              }
            });
          }
          questions.setScores(questionsListMap.get(questions));
        }
        else{
          List<Scores> scoresList = new ArrayList<Scores>();
          Scores scores = new Scores();
          scores.setScoreReference(foundResponses.getQuestionReference());
          scores.setAutomarkable(foundResponses.isAutomarkable());
          //scores.setCorrectResponse();
          scoresList.add(scores);
          questions.setScores(scoresList);
        }

       gradingQuestionsList.add(questions);
      }
    }
    return gradingQuestionsList;
  }

  private List<ActivityItemScore> getActivityItemScore(List<Responses> responsesList , Map<Questions , List<Scores>> questionsListMap, ActivityItemsView activityItemsView) {
    List<ActivityItemScore> activityItemScoreList = new ArrayList<ActivityItemScore>();
    for (Responses resp : responsesList) {
      Questions questions = new Questions();
      questions.setQuestionReference(resp.getQuestionReference());
      if(!CollectionUtils.isEmpty(questionsListMap)) {
        String assignmentType = activityItemsView.getAssignmentType();
        if(TestType.isPerformanceTask(assignmentType)){
          List<Scores> performanceScores = questionsListMap.entrySet().iterator().next().getValue();
          for (Scores scores : performanceScores) {
            ActivityItemScore performanceActivityItemScore = new ActivityItemScore();
            performanceActivityItemScore.setItemReference(questionsListMap.entrySet().iterator().next().getKey().getQuestionReference());
            performanceActivityItemScore.setQuestionReference(questionsListMap.entrySet().iterator().next().getKey().getQuestionReference());
            performanceActivityItemScore.setScoreReference(scores.getScoreReference());
            performanceActivityItemScore.setMaxScore(scores.getMaxScore());
            performanceActivityItemScore.setWeight(scores.getWeight());
            activityItemScoreList.add(performanceActivityItemScore);
          }
          return activityItemScoreList;
          //TODO NEED TO CHANGE WHEN PERFORMANCE MODEL IS CHANGED
        }
      }
      if(!CollectionUtils.isEmpty(questionsListMap) && questionsListMap.containsKey(questions)){
        List<Scores> scoresList = questionsListMap.get(questions);
          if (!CollectionUtils.isEmpty(scoresList)) {
            scoresList.stream().forEach(scores -> {
              ActivityItemScore activityItemScore = new ActivityItemScore();
              activityItemScore.setItemReference(resp.getItemReference());
              activityItemScore.setQuestionReference(resp.getQuestionReference());
              activityItemScore.setMaxScore(scores.getMaxScore());
              activityItemScore.setScoreReference(scores.getScoreReference());
              activityItemScore.setWeight(scores.getMaxScore());
              activityItemScoreList.add(activityItemScore);
            });
          }
      }
      else {
        ActivityItemScore activityItemScore = new ActivityItemScore();
        activityItemScore.setItemReference(resp.getItemReference());
        activityItemScore.setQuestionReference(resp.getQuestionReference());
        activityItemScore.setMaxScore(resp.getMaxScore());
        activityItemScore.setScoreReference(resp.getQuestionReference());
        activityItemScore.setWeight(resp.getMaxScore());
        activityItemScoreList.add(activityItemScore);
        Object apiVersionObj = retrieveValueFromMap(resp.getResponse(), "apiVersion");
        if (apiVersionObj != null) {
          Gson gson = new Gson();
          String version = gson.toJson(apiVersionObj);
          activityItemScore.setVersion(version);
        }
      }
    }

    return activityItemScoreList;
  }

  private List<StudentItem> getStudentItem(List<Item> itemList, List<Responses> responsesList, UUID sessionId ,
    Map<Questions , List<Scores>> questionsListMap, ActivityItemsView activityItemsView) {

    List<StudentItem> studentItemList = new ArrayList<StudentItem>();
    Map<String , StudentItem > itemMap = new HashMap<>();
    for (Responses response : responsesList) {
      StudentItem studentItem = null;
      if(!itemMap.containsKey(response.getItemReference())){
        studentItem = new StudentItem();
        studentItem.setItemReference(response.getItemReference());
        studentItem.setMaxScore(response.getMaxScore());
        String assignmentType = activityItemsView.getAssignmentType();
        if(TestType.isPerformanceTask(assignmentType)){
          studentItem.setItemReference(questionsListMap.entrySet().iterator().next().getKey().getQuestionReference());
        }
        itemMap.put(studentItem.getItemReference() , studentItem);
        studentItemList.add(studentItem);
      } else {
        studentItem = itemMap.get(response.getItemReference());
      }
      Item foundItem = itemList.stream().filter(i -> i.getReference().equals(response.getItemReference())).findAny().orElse(null);
      if (foundItem != null) {
        studentItem.setTime(foundItem.getTime());
        studentItem.setUserFlagged(foundItem.isUserFlagged());
      }
      List<StudentQuestion> studentQuestionList = getStudentQuestion(response, questionsListMap,sessionId, activityItemsView);
      if(CollectionUtils.isEmpty(studentItem.getQuestions())) {
        studentItem.setQuestions(studentQuestionList);
      } else {
        studentItem.getQuestions().addAll(studentQuestionList);
      }
    }
    return studentItemList;
  }

  protected List<StudentQuestion> getStudentQuestion(Responses response, Map<Questions , List<Scores>> questionsListMap , UUID sessionId, ActivityItemsView activityItemsView) {
    List<StudentQuestion> studentQuestionList = new ArrayList<StudentQuestion>();
    StudentQuestion studentQuestion = new StudentQuestion();
    studentQuestion.setQuestionReference(response.getQuestionReference());
    Object actualResponseObj = response.getResponse();
    studentQuestion.setActualResponse(actualResponseObj);
    studentQuestion.setResponseId(response.getResponseId());
    Questions questions =new Questions();
    questions.setQuestionReference(response.getQuestionReference());
    questions.setAutomarkable(response.isAutomarkable());
    if(!CollectionUtils.isEmpty(questionsListMap)) {
      String assignmentType = activityItemsView.getAssignmentType();
      if(TestType.isPerformanceTask(assignmentType)){
        List<StudentScore> studentScoreList = new ArrayList<>();
        Map.Entry<Questions, List<Scores>> entry = questionsListMap.entrySet().iterator().next();
        Questions questions1 = entry.getKey();
        BeanUtils.copyProperties(questions1, studentQuestion);
        List<Scores> scores = entry.getValue();
        scores.stream().forEach(score -> {
          StudentScore studentScore = getStudentScore(sessionId.toString(), score);
          studentScoreList.add(studentScore);
        });
        studentQuestion.setResponses(studentScoreList);
        studentQuestionList.add(studentQuestion);
        return studentQuestionList;

        //TODO NEED TO CHANGE IT ONCE PERFORMANCE MODEL IS CHANGED
      }
    }

    if(!CollectionUtils.isEmpty(questionsListMap) && questionsListMap.containsKey(questions) &&  !questions.getAutomarkable()){
      List<StudentScore> studentScoreList = getStudentManualScore(questionsListMap , sessionId , response.getQuestionReference());
      studentQuestion.setResponses(studentScoreList);
    }
    else{
      List<StudentScore> studentScoreList = getStudentScore(response);
      studentQuestion.setResponses(studentScoreList);
    }
    studentQuestionList.add(studentQuestion);
    return studentQuestionList;

  }

    private List<StudentScore> getStudentManualScore(Map<Questions , List<Scores>> questionsListMap ,UUID sessionId ,
      String questionRef) {

      String studentSessionid = sessionId.toString();
      List<StudentScore> studentScoreList = new ArrayList<StudentScore>();

      if(!CollectionUtils.isEmpty(questionsListMap)) {

        Questions questions = new Questions();
        questions.setQuestionReference(questionRef);
        List<Scores> scoresList =  questionsListMap.get(questions);
            if(!CollectionUtils.isEmpty(scoresList)) {
              scoresList.stream().forEach(score -> {
                StudentScore studentScore = getStudentScore(studentSessionid, score);
                studentScoreList.add(studentScore);
              });
            }
      }
      return studentScoreList;
    }

  private StudentScore getStudentScore(String studentSessionid, Scores score) {
    StudentScore studentScore = new StudentScore();
    BeanUtils.copyProperties(score,studentScore);
    studentScore.setResponseId(String.format("%s_%s",studentSessionid,score.getScoreReference()));
    return studentScore;
  }

  private List<StudentScore> getStudentScore(Responses response) {
    List<StudentScore> studentScoreList = new ArrayList<StudentScore>();
    StudentScore studentScore = new StudentScore();
    studentScore.setResponseId(response.getResponseId().toString());
    studentScore.setScoreReference(response.getQuestionReference());
    studentScore.setAttempted(response.isAttempted());
    if(response.isAutomarkable() && response.getMaxScore() == null) {
      studentScore.setMaxScore(0);
    }else {
      studentScore.setMaxScore(response.getMaxScore());
    }
    if(response.isAutomarkable() && response.getScore() == null){
      studentScore.setScore(0);
    }else {
      studentScore.setScore(response.getScore());
    }
    studentScore.setWeight(response.getMaxScore());
    Object valueObj = response.getResponse();
    studentScore.setValue(valueObj);
    studentScoreList.add(studentScore);
    return studentScoreList;
  }


  public Object retrieveValueFromMap(Object responseObj, String key) {
    Object responseValue = null;
    if(responseObj == null || key == null){
      return null;
    }
    if(responseObj instanceof Map){
      Map responseMap = (Map)responseObj;
      if(responseMap.containsKey(key)){
        responseValue = responseMap.get(key);
      }

    }
    return responseValue;
  }

  private  Map<Questions, List<Scores>> processOneSearch(String resourceId) {

    decorator.setBaseService(ContentService.ON_SEARCH);
    decorator.setParameters(resourceId);
    log.info("setting the parameter"+resourceId);
    return  decorator.getQuestionsScores(1);
  }
}