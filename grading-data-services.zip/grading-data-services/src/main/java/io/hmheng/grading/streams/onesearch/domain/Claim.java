package io.hmheng.grading.streams.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by tallurir on 10/11/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("claim")
@JsonIgnoreProperties(ignoreUnknown = true)

public class Claim {

    @JsonIgnore
    @JsonProperty(value = "description")
    private List<String> description;
    private String type;
    private String identifier;
}
