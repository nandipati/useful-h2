package io.hmheng.grading.streams.onesearch.decorator;


import io.hmheng.grading.streams.grading.domain.Questions;
import io.hmheng.grading.streams.grading.domain.Scores;
import io.hmheng.grading.streams.onesearch.OneSearchServiceImpl;
import io.hmheng.grading.streams.onesearch.domain.Question;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class Decorator {

    @Autowired
    private OneSearchServiceImpl oneSearchService;

    BasicService baseService;

    public Decorator(){

    }

    public void setBaseService(ContentService contentService) {
        this.baseService = contentService != null ? createService(contentService) : null;
    }


    public Map<Questions, List<Scores>> getQuestionsScores(Integer callCount) {

        Map<Questions, List<Scores>> questionsListMap = null;
        if(baseService != null){
            try {
                List<Question> questions = baseService.getItemsForAssesment();
                questionsListMap = baseService.getQuestionsScores(questions);
            } catch(Exception e){

                log.warn(String.format("Decator ContentService failed to process task for %s baseService , retrying!", baseService.getClass().getName()));
                log.warn("Error cause: ", e);


                if(callCount < baseService.getNoRetries()){
                    questionsListMap =   getQuestionsScores(callCount+1);
                }  else {
                    throw e;
                }
            }
        }

        return questionsListMap;
    }

    private BasicService createService(ContentService service) {

        BasicService basicService = null;
        switch (service) {
            case ON_SEARCH:
                basicService = oneSearchService;
                break;
            default:
                basicService = null;
                break;
        }
        return basicService;
    }

    public void setParameters(Object... args) {
        baseService.setParameters(args);
    }


}
