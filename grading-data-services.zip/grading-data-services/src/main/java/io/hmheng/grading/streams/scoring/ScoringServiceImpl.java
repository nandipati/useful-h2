package io.hmheng.grading.streams.scoring;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.hmheng.grading.authorization.AuthorizationService;
import io.hmheng.grading.authorization.util.HeadersHelper;
import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.rest.RestTemplateService;
import io.hmheng.grading.scoring.domain.ClientName;
import io.hmheng.grading.scoring.domain.DeadLetterStatus;
import io.hmheng.grading.scoring.domain.FailureType;
import io.hmheng.grading.scoring.view.save.ScoresAssessmentDeadLetterView;
import io.hmheng.grading.streams.scoring.domain.Event;

import java.time.LocalDateTime;
import java.util.UUID;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/** Created by nandipatim on 5/31/17. */
@Service
public class ScoringServiceImpl implements ScoringService {

  @Autowired private RestTemplateService restTemplateService;

  @Autowired private HeadersHelper headersHelper;

  @Value("${scoring.host.baseUrl}")
  private String scoringUrl;
  // Get Event Object from scoring.

  private ObjectMapper objectMapper = new ObjectMapper();

  @Override
  public Event getEventForActivityRefid(UUID activityRefId) {

    String uri = String.format("/v1/events/%s", activityRefId);
    HttpHeaders httpHeaders =
        headersHelper.createHttpHeadersWithCorrelation(AuthorizationService.Service.SCORING);
    Event event = restTemplateService.getEntity(scoringUrl, uri, httpHeaders, Event.class);

    return event;
  }

  @Override
  public ResponseEntity<String> createDeadLetterForStudentSessionReprocessing(
      StudentSession studentSession) throws JsonProcessingException {

    // increase the reprocessing count so that we can limit number of reprocessing
    studentSession.setReprocessCount(studentSession.getReprocessCount() + 1);
    String jsonStudentSession = objectMapper.writeValueAsString(studentSession);

    String uri = "/v1/deadletter/saveFailedMessage";
    HttpHeaders httpHeaders =
        headersHelper.createHttpHeadersWithCorrelation(AuthorizationService.Service.SCORING);
    ScoresAssessmentDeadLetterView request = new ScoresAssessmentDeadLetterView();

    request.setMessageId(UUID.randomUUID());
    request.setFailureType(FailureType.ST_SESSION_REPROCESS.name());
    request.setFailureEventType(null);
    request.setData(jsonStudentSession);
    request.setException(null);
    request.setClientName(ClientName.STUDENT_SESSION_REPROCESS.getValue());
    request.setStatus(DeadLetterStatus.REPROCESS_READY.ordinal());
    request.setFailureDate(LocalDateTime.now());

    ResponseEntity<String> deadletter =
        restTemplateService.postEntity(scoringUrl, uri, request, httpHeaders);

    return deadletter;
  }
}
