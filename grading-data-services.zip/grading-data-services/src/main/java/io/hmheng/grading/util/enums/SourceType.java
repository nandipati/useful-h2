package io.hmheng.grading.util.enums;

/**
 * Created by nandipatim on 10/30/17.
 */
public enum SourceType {
  ED,HMHONE,NONE;
}
