package io.hmheng.grading.streams.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * Created by tallurir on 9/26/17.
 */

@Data
@NoArgsConstructor
@JsonRootName("dimensionOutcome")
@JsonIgnoreProperties(ignoreUnknown = true)
public class DimensionOutcome {

    private String title;
    private String score;
    private String measure;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;


        DimensionOutcome that = (DimensionOutcome) o;

        return score != null ? score.equals(that.score) : that.score == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (score != null ? score.hashCode() : 0);
        return result;
    }
}
