package io.hmheng.grading.streams.onesearch.domain;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonRootName("rubric")
public class Rubric {
    private String identifier;

    @JsonIgnore
    @JsonProperty(value = "description")
    private List<String> description;
    private List<DimentionQuality> dimensionOfQuality;

}
