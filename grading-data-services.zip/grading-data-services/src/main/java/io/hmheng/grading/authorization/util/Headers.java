package io.hmheng.grading.authorization.util;

public interface Headers {

    String AUTHORIZATION = "Authorization";
    String AUTH_CURRENT_DATE_TIME = "authCurrentDateTime";
    String CORRELATION_ID = "CorrelationId";
}
