package io.hmheng.grading.streams.grading.learnosity;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.streams.grading.GradingService;
import io.hmheng.grading.streams.grading.domain.ActivityItemsView;
import io.hmheng.grading.streams.grading.domain.StudentActivitySession;
import io.hmheng.grading.streams.scoring.ScoringService;
import io.hmheng.grading.streams.scoring.domain.Event;
import io.hmheng.grading.util.enums.TestType;
import io.hmheng.grading.utils.Constants;
import io.hmheng.grading.utils.MDCUtils;
import io.hmheng.grading.utils.MethodEndpoint;

import java.util.UUID;

import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by nandipatim on 12/20/17.
 */
@RestController
@RequestMapping("v1/students")
@Slf4j
public class LearnosityStudentSessionController {

    @Autowired
    private GradingService gradingService;

    @Autowired
    private ScoringService scoringService;

    @Autowired
    private Environment environment;


    @Value("${scoring.noOfRetries}")
    protected String noOfRetries;

    @RequestMapping(value="/studentAnswerSheet", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> postStudentAnswersheet(
            @Valid @RequestBody StudentSession studentSession){

        ResponseEntity<String> responseEntity = null;
        StopWatch sw = MDCUtils.start();
        MDCUtils.addPropertyToMDC(Constants.SERVICE_NAME_TAG, Constants.SERVICE_NAME_GRADING_SERVICES);
        String[] profiles = environment.getActiveProfiles();
        if(environment != null &&  profiles != null && profiles.length > 0 ) {
            MDCUtils.addPropertyToMDC(Constants.STAGE, profiles[0]);
        }
        MDCUtils.addPropertiesToMDC(null , studentSession.getActivityId() , studentSession.getSessionId() ,
                studentSession.getUserId());

        Boolean isGradingRequired = studentSession.getIsGradingRequired();

        if (isGradingRequired == null) {
            isGradingRequired = Boolean.TRUE;
        }

        if(isGradingRequired) {

            UUID activityId = studentSession.getActivityId();
            MDCUtils.addPropertyToMDC(Constants.METHOD_OR_ENDPOINT_TAG , MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING_GRADING_GET_ACTIVITY_ITEMS.name());
            StopWatch swGradingItemsGet = MDCUtils.start();
            ActivityItemsView activityItemsView = null;
            try {
                activityItemsView = gradingService.getGradingActivity(activityId);
            } catch (Exception ex){
              log.error(" Error while pull data from "+MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING_GRADING_GET_ACTIVITY_ITEMS.name() , ex);
            }
            MDCUtils.stopAddPropertyToMDC(swGradingItemsGet);
            log.info("Student Answer Sheet Processing (Get Items From Grading)  sessionId: {} Took {} secs ", studentSession , swGradingItemsGet.getTotalTimeSeconds());
            TestType testType = null;
            if(activityItemsView == null || CollectionUtils.isEmpty(activityItemsView.getItems())){
                StopWatch swScoringAssignmentGet = MDCUtils.start();
                MDCUtils.addPropertyToMDC(Constants.METHOD_OR_ENDPOINT_TAG , MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING_GRADING_GET_ASSIGNMENT.name());

                Event event = null;
                try{
                  event = scoringService.getEventForActivityRefid(activityId);
                } catch (RuntimeException e) {
                  if (e.getMessage() != null && e.getMessage().contains(Constants.NOT_FOUND)
                      && studentSession.getReprocessCount() < getNoRetries()) {
                    try {
                      scoringService.createDeadLetterForStudentSessionReprocessing(studentSession);
                    } catch (JsonProcessingException ex) {
                      log.error(" Error re-processing student session - " + studentSession, ex);
                    }
                  } else {
                    // going to the dead-letter queue
                    throw e;
                  }
                }

                if(event == null) {
                  //stop processing since scoring API has not received matching information, the return in this case
                    // is not important as the caller (in data service)is not examining the result
                  return responseEntity;
                }

                MDCUtils.stopAddPropertyToMDC(swScoringAssignmentGet);
                log.info("Student Answer Sheet Processing (Get Assignment Details From Scoring)  sessionId: {} Took {} secs ", studentSession , swScoringAssignmentGet.getTotalTimeSeconds());
                if (event != null) {
                    activityItemsView = new ActivityItemsView();
                    activityItemsView.setActivityTemplateId(event.getResourceId());
                    activityItemsView.setStaffPersonalRefId(event.getStaffPersonalRefId());
                    activityItemsView.setTeacherAssignmentRefId(event.getEventId());
                    activityItemsView.setIsNew(Boolean.TRUE);
                    isGradingRequired = event.isManualScoringRequired();
                    testType = event.getTestType();
                    activityItemsView.setAssignmentType(testType.name());
                    activityItemsView.setSourceType(testType.getSourceType().name());

                    if(testType != null && testType.isGradingEligable() && isGradingRequired){
                        isGradingRequired = Boolean.TRUE;
                    }else{
                        isGradingRequired = Boolean.FALSE;
                    }
                }
            }else{
                activityItemsView.setIsNew(Boolean.FALSE);
                isGradingRequired = Boolean.TRUE;
            }

            if (isGradingRequired) {
                MDCUtils.addPropertyToMDC(Constants.METHOD_OR_ENDPOINT_TAG , MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING_POST_GRADING.name());
                StopWatch swGradingPostInit = MDCUtils.start();
                StudentActivitySession studentActivitySession = gradingService.convertToGradingStructure(studentSession, activityItemsView);
                responseEntity = gradingService.postToGrading(studentActivitySession , studentSession.getSessionId());
                MDCUtils.stopAddPropertyToMDC(swGradingPostInit);
                log.info("Student Answer Sheet Processing (Post to Grading)  sessionId: {} Took {} secs ", studentSession.getSessionId() , swGradingPostInit.getTotalTimeSeconds());
            }
        }
        MDCUtils.addPropertyToMDC(Constants.METHOD_OR_ENDPOINT_TAG , MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING.name());
        MDCUtils.stopAddPropertyToMDC(sw);
        log.info("Processing Student Session Scores from Learnosity Completed sessionId: {} Took {} secs", studentSession.getSessionId(),
                sw.getTotalTimeSeconds());

        return responseEntity;
    }

    private int getNoRetries() {
        return StringUtils.isNotEmpty(noOfRetries) &&  StringUtils.isNumeric(noOfRetries) ? Integer.parseInt
            (noOfRetries):3;
    }

}
