package io.hmheng.grading.streams.onesearch;

import io.hmheng.grading.authorization.AuthorizationService;
import io.hmheng.grading.authorization.util.HeadersHelper;
import io.hmheng.grading.rest.RestTemplateService;
import io.hmheng.grading.streams.grading.domain.Questions;
import io.hmheng.grading.streams.grading.domain.Scores;
import io.hmheng.grading.streams.onesearch.decorator.BasicService;
import io.hmheng.grading.streams.onesearch.decorator.ContentService;
import io.hmheng.grading.streams.onesearch.decorator.OneSearchRubricCallable;
import io.hmheng.grading.streams.onesearch.decorator.Request;
import io.hmheng.grading.streams.onesearch.domain.DimensionOutcome;
import io.hmheng.grading.streams.onesearch.domain.OneSearchResponse;
import io.hmheng.grading.streams.onesearch.domain.OneSearchRubricResponse;
import io.hmheng.grading.streams.onesearch.domain.Question;
import io.hmheng.grading.streams.onesearch.domain.Rubric;
import io.hmheng.grading.utils.Constants;
import io.hmheng.grading.utils.MDCUtils;
import io.hmheng.grading.utils.MethodEndpoint;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Created by tallurir on 10/11/17.
 */
@Slf4j
@Service
public class OneSearchServiceImpl implements BasicService {


    private static final Logger logger = LoggerFactory.getLogger(OneSearchServiceImpl.class);

    protected String parameter;

    @Autowired
    private HeadersHelper headersHelper;

    @Autowired
    private RestTemplateService restTemplateService;

    @Value("${onesearch.host.baseUrl}")
    protected String onesearchUrl;

    @Value("${onesearch.noOfRetries}")
    protected String noOfRetries;

    @Autowired
    private Function<String, OneSearchRubricCallable> oneSearchRubricCallableFactory;

    @Override
    public Request populateRequestInfo() {
        Request request = new Request();
        request.setServiceURI(getServiceURI());
        request.setServiceAuth(AuthorizationService.Service.ON_SEARCH);
        request.setServiceURL(onesearchUrl);
        request.setDomainObject(null);
        request.setResponseClass(getResponseClass());
        return request;
    }
    @Override
    public void setParameters(Object... args) {
        this.parameter =(String) args[0];
    }

    @Override
    public String getServiceURI() {

        return String.format("/api/onesearch/v1/assessments/rubrics?assessmentId=%s&view=toc",parameter != null ? parameter.toString() : null);

    }

    @Override
    public Class getResponseClass() {
        return OneSearchResponse.class;
    }

    @Override
    public int getNoRetries() {
        return StringUtils.isNotEmpty(noOfRetries) &&  StringUtils.isNumeric(noOfRetries) ? Integer.parseInt(noOfRetries):1;
    }



    public List<Question> processAssementData(OneSearchResponse oneSearchResponse) {


        List<Question> questList = new ArrayList<>();
        if (oneSearchResponse != null && !oneSearchResponse.getAssessment().isEmpty()) {

            oneSearchResponse.getAssessment().forEach(assignment -> {
                assignment.getItem().forEach(item -> {

                    if (item.getQuestion() != null && !item.getQuestion().isEmpty()) {
                        item.getQuestion().forEach(question -> {


                            questList.add(question);


                        });
                    }
                });
            });
        }

        return questList;
    }


    public Map<Questions,List<Scores>> processQuestionRubricsData(List<Question> questionList, List<OneSearchRubricResponse> oneSearchRubricResponses) {

        Map<String,List<Scores>> rubricScoreMap= new HashMap<>();
        Map<Questions,List<Scores>> questionScoreMap= new HashMap<>();

        if(oneSearchRubricResponses != null  &&  !oneSearchRubricResponses.isEmpty()) {

            oneSearchRubricResponses.forEach(oneSearchRubricResponse -> {
                if(oneSearchRubricResponse != null  &&  !oneSearchRubricResponse.getRubric().isEmpty()) {

                    oneSearchRubricResponse.getRubric().forEach( rubric1 -> {
                        List<Scores> scores = new ArrayList<>();

                        if (rubric1 != null && rubric1.getDimensionOfQuality() != null) {
                            Map<String,String> claimMap= new HashMap<>();
                            rubric1.getDimensionOfQuality().forEach(dimentionQuality -> {
                                if(dimentionQuality != null && dimentionQuality.getClaim() != null && !dimentionQuality.getClaim().isEmpty() ) {
                                    dimentionQuality.getClaim().forEach( claim -> {
                                        claimMap.put(claim.getIdentifier(),claim.getType());
                                    });
                                }
                                if (dimentionQuality != null && dimentionQuality.getDimensionOutcome() != null) {

                                  List<Integer> scoreList = new ArrayList<>();
                                    dimentionQuality.getDimensionOutcome().forEach(dimensionOutcome -> {
                                      try {
                                          String scoreString = dimensionOutcome.getScore();

                                          if(dimensionOutcome != null && StringUtils.isNotEmpty(scoreString)) {
                                              Integer score = Integer.parseInt(scoreString);
                                              scoreList.add(score);
                                          }
                                      }catch(Exception e){
                                          e.printStackTrace();
                                        }

                                    });

                                        Scores score = new Scores();
                                    try {
                                        Integer maxScore = Collections.max(scoreList);
                                        DimensionOutcome dimensionOutcome = new DimensionOutcome();
                                        dimensionOutcome.setScore(Integer.toString(maxScore));
                                        Integer index = dimentionQuality.getDimensionOutcome().indexOf(dimensionOutcome);
                                        DimensionOutcome reqDimensionOutCome = null;
                                        if(index != -1){
                                            reqDimensionOutCome =  dimentionQuality.getDimensionOutcome().get(index);
                                        }

                                        score.setTitle(reqDimensionOutCome != null ? reqDimensionOutCome.getTitle():null);
                                        score.setDescription(dimentionQuality.getDescription() != null && !dimentionQuality.getDescription().isEmpty() ? dimentionQuality.getDescription().get(0):null);
                                        score.setScoreReference(dimentionQuality.getIdentifier());
                                        score.setMaxScore(maxScore);
                                        score.setWeight(maxScore);
                                        }catch (Exception ex){
                                            score.setErrorMessage(String.format(ContentService.ON_SEARCH+":Invalid Max Score :%s",dimentionQuality.getIdentifier()));
                                        }
                                        score.setType(claimMap.get(score.getScoreReference()));
                                        scores.add(score);


                                }
                                else if(dimentionQuality != null && dimentionQuality.getDimensionOutcome() == null && dimentionQuality.getIdentifier() != null){
                                    Scores score = new Scores();
                                    score.setScoreReference(dimentionQuality.getIdentifier());
                                    score.setMaxScore(0);
                                    score.setErrorMessage(String.format(ContentService.ON_SEARCH+":Invalid Max Score :%s", dimentionQuality.getIdentifier()));
                                    scores.add(score);
                                }
                            });
                        }
                        rubricScoreMap.put(rubric1.getIdentifier(),scores);
                    });
                }});

        }

        if(questionList != null && !questionList.isEmpty()) {
            questionList.forEach(question -> {
                StringBuilder rubricNotFound =new StringBuilder();
                Questions questions = new Questions();
                questions.setAutomarkable(!question.isManuallyScorable());
                questions.setQuestionReference(question.getIdentifier());
                questions.setQuestionType(question.getInteractivityType());
                List<Scores> scoresList = new ArrayList<>();
                question.getRubric().forEach(rubric -> {
                    if(rubricScoreMap.containsKey(rubric.getIdentifier())) {
                        List<Scores> scoresListFromRubrics = rubricScoreMap.get(rubric.getIdentifier());
                        if(!CollectionUtils.isEmpty(scoresListFromRubrics)) {
                           scoresListFromRubrics.stream().forEach(scores -> {
                               if(scores != null){
                                   scores.setAutomarkable(questions.getAutomarkable());
                               }
                           });
                            scoresList.addAll(scoresListFromRubrics);
                        }
                        else{
                            rubricNotFound.append(rubric.getIdentifier()+",") ;
                        }
                    } else {
                        rubricNotFound.append(rubric.getIdentifier()+",") ;
                    }

                });
                if(!CollectionUtils.isEmpty(question.getRubric())) {
                    Rubric rubric = question.getRubric().get(0);
                    questions.setRubricReference(rubric.getIdentifier());
                }

                if(StringUtils.isNotEmpty(rubricNotFound.toString())) {
                    questions.setErrorMessage(String.format(ContentService.ON_SEARCH+":Data Not found for rubrics:%s", rubricNotFound));
                }
                questionScoreMap.put(questions,scoresList);

            });
        }


        return questionScoreMap;
    }

    public Map<Questions, List<Scores>> getQuestionsScores(List<Question> questionList) {
        List<OneSearchRubricResponse> oneSearchRubricResponses = new ArrayList<>();
        Map<Questions, List<Scores>> questionScoreMap = null;

        if(CollectionUtils.isEmpty(questionList)) {
            questionList = getItemsForAssesment();
        }

        if (!CollectionUtils.isEmpty(questionList)) {
            try {

                oneSearchRubricResponses = processRubricParallelProcess(questionList);
            }catch (Exception ex){
                isHttpResponseNotFound(ex);
            }
            questionScoreMap = processQuestionRubricsData(questionList, oneSearchRubricResponses);
        }

        return questionScoreMap;
    }

    public  List<Question> getItemsForAssesment() {

        List<Question> questionList = null;

        Request request = populateRequestInfo();
        request.setServiceURI(getServiceURI());
        logger.info("calling onesearch Get Items endpoint--->"+onesearchUrl+request.getServiceURI());
        Object response = null;
        MDCUtils.addPropertyToMDC(Constants.METHOD_OR_ENDPOINT_TAG , MethodEndpoint.STUDENT_ANSWER_SHEET_PROCESSING_ONSEARCH_GET_ITEMS.name());
        StopWatch swOnsearchGetItems = MDCUtils.start();

        HttpHeaders httpHeaders = headersHelper.createHttpHeadersWithCorrelation(request.getServiceAuth());

        response =  restTemplateService.getEntity(request.getServiceURL(), request.getServiceURI(), httpHeaders, request.getResponseClass());

        MDCUtils.stopAddPropertyToMDC(swOnsearchGetItems);
        log.info("Student Answer Sheet Processing (Get Items Detaisl from OnSearch) Url:{} Took {} secs ", request.getServiceURL()
                ,swOnsearchGetItems.getTotalTimeSeconds());


        if (response != null && response instanceof OneSearchResponse) {
            questionList = processAssementData((OneSearchResponse) response);
        }

        return questionList;
    }


    protected  List<OneSearchRubricResponse>  processRubricParallelProcess(List<Question> questionList) throws Exception{
        List<OneSearchRubricResponse> oneSearchRubricResponses = new ArrayList<>();
        Set<String> rubricSet = new HashSet<String>();
        questionList.forEach(question -> {

            if (question.getRubric() != null && !question.getRubric().isEmpty()) {

                question.getRubric().forEach(rubric -> {
                    rubricSet.add(rubric.getIdentifier());

                });
            }
        });

        ExecutorService executorService = Executors.newSingleThreadExecutor();

        List<OneSearchRubricCallable> callables = new ArrayList<>();

        rubricSet.forEach(rubric->{
            String serviceURI = String.format("/api/onesearch/v1/assessments/rubrics?rubricId=%s", rubric != null ? rubric : null);

            callables.add(oneSearchRubricCallableFactory.apply(serviceURI));
        });


        List<Future<OneSearchRubricResponse>> futures = executorService.invokeAll(callables);

        for(Future<OneSearchRubricResponse> future : futures){

            oneSearchRubricResponses.add(future.get());

        }

        executorService.shutdown();

        return oneSearchRubricResponses;

    }


    private boolean isHttpResponseNotFound(Exception e) {
        logger.info("Error while Accessing Rubric from OneSearch {}", e);
        if((e instanceof HttpClientErrorException) || (e.getCause() instanceof HttpClientErrorException)) {
            HttpClientErrorException errorException = (HttpClientErrorException)e;
            if(errorException.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT || errorException.getStatusCode() ==
                HttpStatus.BAD_GATEWAY || errorException.getStatusCode() == HttpStatus.BANDWIDTH_LIMIT_EXCEEDED){
                throw  errorException;
            };
        }
        return Boolean.TRUE;
    }

}
