package io.hmheng.grading.streams.onesearch.decorator;

import io.hmheng.grading.authorization.AuthorizationService;
import java.io.Serializable;


public class Request implements Serializable{

    String serviceURL;
    String serviceURI;
    AuthorizationService.Service serviceAuth;
    Class responseClass;
    Object domainObject;

    public String getServiceURL() {
        return serviceURL;
    }

    public void setServiceURL(String serviceURL) {
        this.serviceURL = serviceURL;
    }

    public String getServiceURI() {
        return serviceURI;
    }

    public void setServiceURI(String serviceURI) {
        this.serviceURI = serviceURI;
    }

    public AuthorizationService.Service getServiceAuth() {
        return serviceAuth;
    }

    public void setServiceAuth(AuthorizationService.Service serviceAuth) {
        this.serviceAuth = serviceAuth;
    }

    public Class getResponseClass() {
        return responseClass;
    }

    public void setResponseClass(Class responseClass) {
        this.responseClass = responseClass;
    }

    public Object getDomainObject() {
        return domainObject;
    }

    public void setDomainObject(Object domainObject) {
        this.domainObject = domainObject;
    }
}
