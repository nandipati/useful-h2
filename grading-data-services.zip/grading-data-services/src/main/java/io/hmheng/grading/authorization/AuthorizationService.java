package io.hmheng.grading.authorization;

public interface AuthorizationService {

    enum Service {
        SCORING,
        GRADING,
        ON_SEARCH
    }
    
    AuthorizationDetails createSIFAuthorization(Service service);

}


