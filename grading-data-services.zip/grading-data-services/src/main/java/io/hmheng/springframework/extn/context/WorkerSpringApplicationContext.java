package io.hmheng.springframework.extn.context;

import io.hmheng.grading.authorization.AuthorizationService;
import io.hmheng.grading.streams.onesearch.decorator.OneSearchRubricCallable;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Scope;
import org.springframework.web.client.RestTemplate;

@Slf4j
@SpringBootApplication(scanBasePackageClasses = { WorkerSpringApplicationContext.class,
    AuthorizationService.class }
    ,exclude = {DataSourceAutoConfiguration.class,
    DataSourceTransactionManagerAutoConfiguration.class,HibernateJpaAutoConfiguration.class , JmxAutoConfiguration.class})
@EnableConfigurationProperties
@ComponentScan("io.hmheng.grading.streams.grading, io.hmheng.grading.streams.scoring , io.hmheng.grading.rest " +
    ", io.hmheng.grading.authorization, io.hmheng.grading.config, resources ,  io.hmheng.grading.learnosity " +
    ", io.hmheng.grading.streams.kinesis, io.hmheng.grading.streams.config, io.hmheng.grading.streams.onesearch " +
    ", com.hmhco.api.tracing")
public class WorkerSpringApplicationContext {

  private static final Object monitor = new Object();

  private static ConfigurableApplicationContext applicationContext;

  protected static void start(String... profiles) {
    synchronized (monitor) {
      if (applicationContext == null) {
        log.info("Starting Spring context on worker.");
        SpringApplication app = new SpringApplication(WorkerSpringApplicationContext.class);
        app.setAdditionalProfiles(profiles);
        //app.setWebEnvironment(false);
        applicationContext = app.run();
        applicationContext.registerShutdownHook();
      }
    }
  }

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  @Bean
  public Function<String, OneSearchRubricCallable> oneSearchRubricCallableFactory() {
    return serviceURI -> oneSearchRubricCallable(serviceURI);
  }

  @Bean
  @Scope(value = "prototype")
  public OneSearchRubricCallable oneSearchRubricCallable(String serviceURI) {
    return new OneSearchRubricCallable(serviceURI);
  }

  public static ApplicationContext getContext(String... profiles) {
    if (applicationContext == null) {
      start(profiles);
    }
    return applicationContext;
  }

}
