package io.hmheng.grading.performance;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.kinesis.producer.KinesisProducerConfiguration;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;
import io.hmheng.grading.streams.config.ConfigType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.io.Serializable;

/**
 * Created by nandipatim on 5/17/17.
 */
@Data
@NoArgsConstructor
public class TestStreamConfiguration implements Serializable{

  private String env = "int";

  @NonNull
  private String appName = env + ".hmhone-score-learnosity-application";

  @NonNull
  private String stream = "io_hmheng_hmhone_" + env + "_assessment_score_stream";

  @NonNull
  private String region = "us-east-1";

  @NonNull
  private String kinesisEndpoint = "https://kinesis.us-east-1.amazonaws.com";

  private boolean useSts = true;

  private String roleArn = "arn:aws:iam::711638685743:role/io.hmheng.hmhone." + env + ".score.kinesis.crossaccount";

  private String roleSessionName = "consumeAssesmentScores";

  private Integer sparkProcessingParallelism = 3;

  public AmazonKinesis kinesisClient() {
    AmazonKinesisClientBuilder builder = AmazonKinesisClientBuilder.standard().withRegion(region);
    if (useSts) {
      builder = builder.withCredentials(new STSAssumeRoleSessionCredentialsProvider.Builder(roleArn, roleSessionName)
          .withStsClient(AWSSecurityTokenServiceClientBuilder.standard().withCredentials(new
              DefaultAWSCredentialsProviderChain()).withRegion(region).build()).build());
    }

    return builder.build();
  }

  public DescribeStreamResult describeStream() {
    return kinesisClient().describeStream(getStream());
  }

  public ConfigType getConfigType(){
    return ConfigType.PRODUCER;
  }

  public AWSCredentialsProvider getAWSCredentialsProvider(){

    if (useSts) {
      return new STSAssumeRoleSessionCredentialsProvider.Builder(roleArn, roleSessionName)
          .withStsClient(AWSSecurityTokenServiceClientBuilder.standard().withCredentials(new
          DefaultAWSCredentialsProviderChain()).withRegion(region).build()).build();
    }

    return new DefaultAWSCredentialsProviderChain();
  }

  public KinesisProducerConfiguration getKinesisProducerConfiguration(){

    KinesisProducerConfiguration config = new KinesisProducerConfiguration();
    config.setRegion(region);
    config.setCredentialsProvider(getAWSCredentialsProvider());
    config.setMaxConnections(1);
    config.setRequestTimeout(60000);
    config.setRecordMaxBufferedTime(15000);

    return config;
  }
}
