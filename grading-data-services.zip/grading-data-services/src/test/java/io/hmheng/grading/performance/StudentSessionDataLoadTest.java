package io.hmheng.grading.performance;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.streams.grading.domain.ActivityItemsView;
import io.hmheng.grading.streams.grading.domain.StudentActivitySession;
import io.hmheng.grading.streams.kinesis.model.KinesisPutRecordResult;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;



public class StudentSessionDataLoadTest {

	private StudentLoadTestHelper helper = new StudentLoadTestHelper();

	private ObjectMapper objectMapper = new ObjectMapper();

	@Rule
	public MockitoRule mockitoRule = MockitoJUnit.rule();

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

		//Don't fail if additional fields in incoming JSON, just ignore
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		//Don't fail on incoming JSON missing fields
		objectMapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
		objectMapper.findAndRegisterModules();
	}


	public void sendSmallRecordToAggregator()
	{

		while(true) {

			for (int i = 1; i < 12; i++) {
				try {
					long start = new Date().getTime();

					Resource resource = new ClassPathResource("loadTest/smallSessionList" + i + ".json");
					String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
					StudentSessionView sessions = objectMapper.readValue(jsonString, new TypeReference<StudentSessionView>() { });

					Object result = helper.postEntityToReport("http://aggregator-processor.int.br.hmheng.io", "/v1/rescore/responses/sessions?eventType=PROGRAM", sessions);

					long end = new Date().getTime();
					System.out.println("Small List <" + i + "> took " + (end-start)/1000 + " secs");

					//Thread.sleep(10000);

				} catch (Exception e) {
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Big List <" + i + "> has problem");
					e.printStackTrace();
					try {
						//Thread.sleep(60000);
					}
					catch (Exception ex)
					{}
				}
			}

		}

	}
	
	public void sendBigRecordToAggregator()
	{

		while(true) {

			for (int i = 1; i < 4; i++) {
				try {
					long start = new Date().getTime();

					Resource resource = new ClassPathResource("loadTest/bigSessionList" + i + ".json");
					String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
					StudentSessionView sessions = objectMapper.readValue(jsonString, new TypeReference<StudentSessionView>() { });

					Object result = helper.postEntityToReport("http://aggregator-processor.int.br.hmheng.io", "/v1/rescore/responses/sessions?eventType=PROGRAM", sessions);

					long end = new Date().getTime();
					System.out.println("Small List <" + i + "> took " + (end-start)/1000 + " secs");

					//Thread.sleep(10000);

				} catch (Exception e) {
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Big List <" + i + "> has problem");
					e.printStackTrace();
					try {
						//Thread.sleep(60000);
					}
					catch (Exception ex)
					{}
				}
			}

		}

	}

	//@Test
	public void sendMissingActivityRecordToKenisis()
	{

		while(true) {
			try {
				Resource resource = new ClassPathResource("loadTest/StudentSession-reprocess.json");
				String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
				StudentSession session = objectMapper.readValue(jsonString, new TypeReference<StudentSession>() {
				});
				System.out.println(session.getSessionId());


				String json = objectMapper.writeValueAsString(session);
				byte[] studentSessionBytes = json.getBytes();

				ByteBuffer byteBuffer = ByteBuffer.wrap(studentSessionBytes);

				TestSimpleKinesisDataStreamGenerator generator = new TestSimpleKinesisDataStreamGenerator();

				Map<String, KinesisPutRecordResult> result = generator.pushKinesisMessage(new TestStreamConfiguration(), byteBuffer);
				System.out.println("Result : " + result);

			} catch (Exception e) {
				System.out.println("Failed to push to Kinesis stream - " + e.getMessage());
				e.printStackTrace();
			}
		}

	}

	//@Test
	public void sendRecordToKenisis()
	{

		while(true) {
			int change = helper.getRandomNumberInRange(1, 50);
			for (int i = 1; i < 2; i++) {
				try {
					Resource resource = new ClassPathResource("loadTest/LoadTest-LearnosityStudentSession" + i + ".json");
					String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
					StudentSession session = objectMapper.readValue(jsonString, new TypeReference<StudentSession>() {
					});
					System.out.println(session.getSessionId());

					// change something
					session.setCompletedDate(LocalDateTime.now());
					session.setStartDate(LocalDateTime.now());
					session.setNumAttempted(session.getNumAttempted() == null ? change : session.getNumAttempted() + change);

					if (session.getItems() != null) {
						session.getItems().forEach(item -> {
							item.getScoring().setMaxScore(item.getScoring().getMaxScore() == null ? 0 : item.getScoring().getMaxScore() + change);
							item.getScoring().setScore(item.getScoring().getScore() == null ? 0 : item.getScoring().getScore() + change / 2);
						});
					}

					if (session.getResponses() != null) {
						session.getResponses().forEach(res -> {
							res.setMaxScore(res.getMaxScore() == null ? 0 : res.getMaxScore() + change);
							res.setScore(res.getScore() == null ? 0 : res.getScore() + change / 2);
						});
					}

					if (session.getSubscores() != null) {
						session.getSubscores().forEach(score -> {
							score.setMaxScore(score.getMaxScore() == null ? 0 : score.getMaxScore() + change);
							score.setScore(score.getScore() == null ? 0 : score.getScore() + change / 2);
							score.setNumAttempted(score.getNumAttempted() == null ? 0 : score.getNumAttempted() + change / 2);
							score.setNumQuestions(score.getNumQuestions() == null ? 0 : score.getNumQuestions() + change / 2);
						});
					}

					String json = objectMapper.writeValueAsString(session);
					byte[] studentSessionBytes = json.getBytes();

					ByteBuffer byteBuffer = ByteBuffer.wrap(studentSessionBytes);

					TestSimpleKinesisDataStreamGenerator generator = new TestSimpleKinesisDataStreamGenerator();

					Map<String, KinesisPutRecordResult> result = generator.pushKinesisMessage(new TestStreamConfiguration(), byteBuffer);
					System.out.println("Result : " + result);

				} catch (Exception e) {
					System.out.println("Failed to push to Kinesis stream - " + e.getMessage());
					e.printStackTrace();
				}
			}
		}

	}

	public void loadTest() {

		while (true) {
			int change = helper.getRandomNumberInRange(1, 50);
			System.out.println("\n\n\nNew random number is <" + change + ">\n\n\n\n");
			long start = new Date().getTime();

			for (int i = 1; i < 41; i++) {
				try {
					Resource resource = new ClassPathResource("loadTest/LoadTest-LearnosityStudentSession" + i + ".json");
					String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
					StudentSession session = objectMapper.readValue(jsonString, new TypeReference<StudentSession>() {
					});
					System.out.println(session.getSessionId());

					// change something
					session.setCompletedDate(LocalDateTime.now());
					session.setStartDate(LocalDateTime.now());
					session.setNumAttempted(session.getNumAttempted() == null ? change : session.getNumAttempted() + change);

					if(session.getItems() != null){
						session.getItems().forEach(item->{
							if(item.getSource()!= null)
							{
								String original = item.getSource().getItemPoolId();
								item.getSource().setItemPoolId(original + "###"+ change);
							}
							item.getScoring().setMaxScore(item.getScoring().getMaxScore() == null ? 0 : item.getScoring().getMaxScore() + change);
							item.getScoring().setScore(item.getScoring().getScore() == null ? 0 : item.getScoring().getScore() + change/2);
						});
					}

					if(session.getResponses() != null){
						session.getResponses().forEach(res->{
							res.setMaxScore(res.getMaxScore() == null ? 0 : res.getMaxScore() + change);
							res.setScore(res.getScore() == null ? 0 : res.getScore() + change/2);
						});
					}

					if(session.getSubscores() != null) {
						session.getSubscores().forEach(score -> {
							score.setMaxScore(score.getMaxScore() == null ? 0 : score.getMaxScore() + change);
							score.setScore(score.getScore() == null ? 0 : score.getScore() + change / 2);
							score.setNumAttempted(score.getNumAttempted() == null ? 0 : score.getNumAttempted() + change / 2);
							score.setNumQuestions(score.getNumQuestions() == null ? 0 : score.getNumQuestions() + change / 2);
						});
					}


					Object result = helper.postEntity("http://localhost:9085", "/v1/activities/loadTest", session, helper.getHeaders());

					System.out.println("Data Set <" + i + "> passed");

				} catch (Exception e) {
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Data Set <" + i + "> has problem");
					e.printStackTrace();
				}
			}

			long end = new Date().getTime();
			System.out.println("\n\n\n\nLast batch passed with " + (end-start)/1000 + " secs");


		}
	}

	public void testInit()
	{
		while (true) {
			int change = helper.getRandomNumberInRange(1, 50);
			System.out.println("\n\n\nNew random number is <" + change + ">\n\n\n\n");
			long start = new Date().getTime();

			for (int i = 1; i < 41; i++) {
				try {
					Resource resource = new ClassPathResource("loadTest/LoadTest-LearnosityStudentSession" + i + ".json");
					String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
					StudentSession session = objectMapper.readValue(jsonString, new TypeReference<StudentSession>() {
					});
					System.out.println(session.getSessionId());

					// change something
					session.setCompletedDate(LocalDateTime.now());
					session.setStartDate(LocalDateTime.now());
					session.setNumAttempted(session.getNumAttempted() == null ? change : session.getNumAttempted() + change);

					if (session.getItems() != null) {
						session.getItems().forEach(item -> {
							if (item.getSource() != null) {
								String original = item.getSource().getItemPoolId();
								item.getSource().setItemPoolId(original + "###" + change);
							}
							item.getScoring().setMaxScore(item.getScoring().getMaxScore() == null ? 0 : item.getScoring().getMaxScore() + change);
							item.getScoring().setScore(item.getScoring().getScore() == null ? 0 : item.getScoring().getScore() + change / 2);
						});
					}

					if (session.getResponses() != null) {
						session.getResponses().forEach(res -> {
							res.setMaxScore(res.getMaxScore() == null ? 0 : res.getMaxScore() + change);
							res.setScore(res.getScore() == null ? 0 : res.getScore() + change / 2);
						});
					}

					if (session.getSubscores() != null) {
						session.getSubscores().forEach(score -> {
							score.setMaxScore(score.getMaxScore() == null ? 0 : score.getMaxScore() + change);
							score.setScore(score.getScore() == null ? 0 : score.getScore() + change / 2);
							score.setNumAttempted(score.getNumAttempted() == null ? 0 : score.getNumAttempted() + change / 2);
							score.setNumQuestions(score.getNumQuestions() == null ? 0 : score.getNumQuestions() + change / 2);
						});
					}


					ActivityItemsView activityItemsView = helper.getGradingActivity(session.getActivityId());
					StudentActivitySession studentActivitySession = helper.convertToGradingStructure(session, activityItemsView);
					String activitySessionString = objectMapper.writeValueAsString(studentActivitySession);

					ResponseEntity<String> response = helper.postToGrading(studentActivitySession, session.getSessionId());


					System.out.println("Response : " + response.getStatusCode());
				} catch (Exception e) {
					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Data Set <" + i + "> has problem");
					e.printStackTrace();
				}
			}

			long end = new Date().getTime();
			System.out.println("\n\n\n\nLast batch passed with " + (end - start) / 1000 + " secs");
		}
	}

	public void testInitWithOneStudentSession()
	{
		try
		{
			Resource resource = new ClassPathResource("loadTest/testStudentSession.json");
			String jsonString = new BufferedReader(new InputStreamReader(resource.getInputStream())).readLine();
			StudentSession session = objectMapper.readValue(jsonString, new TypeReference<StudentSession>() {
			});
			System.out.println(session.getSessionId());

			ActivityItemsView activityItemsView = helper.getGradingActivity(session.getActivityId());
			StudentActivitySession studentActivitySession = helper.convertToGradingStructure(session, activityItemsView);
			String activitySessionString = objectMapper.writeValueAsString(studentActivitySession);

			ResponseEntity<String> response = helper.postToGrading(studentActivitySession, session.getSessionId());


			System.out.println("Response : " + response.getStatusCode());
		} catch (Exception e) {
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!StudentSession has problem : " + e.getMessage());
			e.printStackTrace();
		}
	}

}
