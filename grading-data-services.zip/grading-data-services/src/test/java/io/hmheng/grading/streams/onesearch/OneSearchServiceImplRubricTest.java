package io.hmheng.grading.streams.onesearch;


import io.hmheng.grading.authorization.util.HeadersHelper;
import io.hmheng.grading.rest.RestTemplateService;
import io.hmheng.grading.streams.onesearch.domain.DimensionOutcome;
import io.hmheng.grading.streams.onesearch.domain.DimentionQuality;
import io.hmheng.grading.streams.onesearch.domain.OneSearchRubricResponse;
import io.hmheng.grading.streams.onesearch.domain.Question;
import io.hmheng.grading.streams.onesearch.domain.Rubric;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.http.HttpHeaders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class OneSearchServiceImplRubricTest {

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @InjectMocks
    private OneSearchServiceImpl oneSearchService = new OneSearchServiceImpl();

    @Mock
    private HeadersHelper headersHelper;

    @Mock
    private RestTemplateService restTemplateService;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(headersHelper.createHttpHeadersWithCorrelation(any())).thenReturn(new HttpHeaders());
        when(restTemplateService.getEntity(any(),any(),any(),any())).thenReturn(getOneSearchRubricResponse());

    }

    private OneSearchRubricResponse getOneSearchRubricResponse() {
        DimensionOutcome dimensionOutcome = new DimensionOutcome();
        dimensionOutcome.setTitle("test");
        dimensionOutcome.setScore("10");

        List dimensionOutcomes = new ArrayList<DimensionOutcome>();
        dimensionOutcomes.add(dimensionOutcome);

        DimentionQuality dimentionQuality = new DimentionQuality();
        dimentionQuality.setDimensionOutcome(dimensionOutcomes);

        List dimentionQualities = new ArrayList<DimentionQuality>();
        dimentionQualities.add(dimentionQuality);

        Rubric rubric1 = new Rubric();
        rubric1.setDimensionOfQuality(dimentionQualities);
        rubric1.setIdentifier("test_rubric1");

        Rubric rubric2 = new Rubric();
        rubric2.setDimensionOfQuality(null);
        rubric2.setIdentifier("test_rubric2");


        List rubrics = new ArrayList<Rubric>();
        rubrics.add(rubric1);
        rubrics.add(rubric2);


        OneSearchRubricResponse response = new OneSearchRubricResponse();
        response.setRubric(rubrics);

        return response;
    }

    private List getQuestionList(){
        Rubric rubric = new Rubric();
        rubric.setDimensionOfQuality(null);
        rubric.setIdentifier("test_rubric1");

        Rubric rubric2 = new Rubric();
        rubric2.setDimensionOfQuality(null);
        rubric2.setIdentifier("test_rubric2");

        List rubrics = new ArrayList<Rubric>();
        rubrics.add(rubric);
        rubrics.add(rubric2);
        Question question = new Question();
        question.setIdentifier("test");
        question.setManuallyScorable(true);
        question.setRubric(rubrics);

        List questions = new ArrayList<Question>();
        questions.add(question);
        return questions;
    }

    @Test
    public void processParellelCalls(){
        try {
            List<OneSearchRubricResponse> rubricResponseList = oneSearchService.processRubricParallelProcess(getQuestionList());
            Assert.assertNotNull(rubricResponseList);
            Assert.assertTrue(rubricResponseList.size() == 2);
        } catch (Exception e) {}

    }

}