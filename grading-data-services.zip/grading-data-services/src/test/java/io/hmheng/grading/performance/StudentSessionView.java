package io.hmheng.grading.performance;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

public class StudentSessionView {

    @JsonProperty("session_id")
    private List<UUID> sessionList;

    public List<UUID> getSessionList() {
        return sessionList;
    }

    public void setSessionList(List<UUID> sessionList) {
        this.sessionList = sessionList;
    }

}