package io.hmheng.grading.streams.grading;

import io.hmheng.grading.authorization.util.HeadersHelper;

import io.hmheng.grading.learnosity.domain.Item;
import io.hmheng.grading.learnosity.domain.Metadata;
import io.hmheng.grading.learnosity.domain.Responses;
import io.hmheng.grading.learnosity.domain.StudentSession;
import io.hmheng.grading.rest.RestTemplateService;


import io.hmheng.grading.streams.grading.domain.ActivityItemsView;
import io.hmheng.grading.streams.grading.domain.Items;
import io.hmheng.grading.streams.grading.domain.StudentActivitySession;
import io.hmheng.grading.streams.grading.domain.StudentQuestion;
import io.hmheng.grading.streams.grading.domain.Questions;
import io.hmheng.grading.streams.grading.domain.Scores;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;


public class GradingServiceImplTest {

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    private GradingServiceImpl gradingService = new GradingServiceImpl();

    @Mock
    private HeadersHelper headersHelper;

    @Mock
    private RestTemplateService restTemplateService;

    UUID sessionId = null;

    @Before
    public void setUp() {
        sessionId = UUID.randomUUID();

    }

    private StudentSession getStudentSession() {

        List<Item> items = new ArrayList<>();
        Item item = new Item();
        item.setReference("test");
        items.add(item);

        Item item2 = new Item();
        item2.setReference("test1");
        items.add(item2);

        StudentSession studentSession = new StudentSession();
        studentSession.setUserId(sessionId);
        studentSession.setSessionId(sessionId);
        studentSession.setActivityId(sessionId);
        studentSession.setStatus("false");
        studentSession.setIsGradingRequired(Boolean.FALSE);
        studentSession.setNumAttempted(1);


        studentSession.setItems(items);
        studentSession.setMaxScore(1);

        studentSession.setNumQuestions(2);

        Metadata metadata = new Metadata();
        metadata.setUserAgent("test");
        metadata.setMaxTime(10);
        metadata.setActivityTemplateId(sessionId.toString());
        studentSession.setMetadata(metadata);

        return studentSession;
    }

    private ActivityItemsView getActivityItemsView() {

        List<Items> items = new ArrayList<>();

        Items items1 = new Items();
        items1.setItemReference("test");


        items.add(items1);


        ActivityItemsView activityItemsView = new ActivityItemsView();
        activityItemsView.setIsNew(false);
        activityItemsView.setItems(items);
        activityItemsView.setAssignmentType("program");

        return activityItemsView;
    }


    @Test
    public void testconvertToGradingStructureWithAddonItems() {
        StudentActivitySession studentActivitySession = gradingService.convertToGradingStructure(getStudentSession(), getActivityItemsView());
        List<Items> items = studentActivitySession.getItems();
        Assert.assertNotNull(studentActivitySession);
        Assert.assertNotNull(items);
        Assert.assertTrue(items.size() == 1);
        Assert.assertEquals(items.get(0).getItemReference(), "test1");


    }

    @Test
    public void testconvertToGradingStructureWithOutAddonItems() {

        List<Items> items = new ArrayList<>();

        Items items1 = new Items();
        items1.setItemReference("test");
        items.add(items1);
        Items items2 = new Items();
        items2.setItemReference("test1");

        items.add(items2);

        ActivityItemsView activityItemsView = getActivityItemsView();
        activityItemsView.setItems(items);
        StudentSession studentSession = getStudentSession();

        StudentActivitySession studentActivitySession = gradingService.convertToGradingStructure(studentSession, activityItemsView);
        items = studentActivitySession.getItems();
        Assert.assertNotNull(studentActivitySession);
        Assert.assertTrue(items.size() == 0);


    }


    @Test
    public void testconvertToGradingStructureWithOutAtivityItems() {


        ActivityItemsView activityItemsView = getActivityItemsView();
        activityItemsView.setItems(null);
        StudentSession studentSession = getStudentSession();

        StudentActivitySession studentActivitySession = gradingService.convertToGradingStructure(studentSession, activityItemsView);
        List<Items> items = studentActivitySession.getItems();
        Assert.assertNotNull(studentActivitySession);
        Assert.assertNotNull(items);
        Assert.assertTrue(items.size() == studentSession.getItems().size());
    }

    @Test
    public void testconvertTostudentQuestionWithOnlyAutomarkable(){
        List<StudentQuestion> studentQuestions = new ArrayList<>();

        Responses response = getResponses(true);
        studentQuestions = gradingService.getStudentQuestion(response, getQuestionsListMap(true), UUID.randomUUID(), getActivityItemsView());
        Assert.assertNotNull(studentQuestions);
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getMaxScore()==1);
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getScore() == response.getScore());
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getAttempted() == response.isAttempted());

    }

    @Test
    public void testconvertTostudentQuestionWithOutAutomarkable(){
        List<StudentQuestion> studentQuestions = new ArrayList<>();

        Responses response = getResponses(false);
        studentQuestions = gradingService.getStudentQuestion(response, getQuestionsListMap(false), UUID.randomUUID(), getActivityItemsView());
        Assert.assertNotNull(studentQuestions);
        Assert.assertNotNull(studentQuestions.get(0).getResponses());
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getMaxScore() == getScores().getMaxScore());
        Assert.assertTrue(getScores().getScoreReference().equals(studentQuestions.get(0).getResponses().get(0).getScoreReference()));
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getScore() == null);
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getAttempted() == null);


    }

    @Test
    public void testconvertTostudentQuestionWithNonExistingQuestion(){
        List<StudentQuestion> studentQuestions = new ArrayList<>();

        Responses response = getResponses(true);
        response.setQuestionReference("test2");
        studentQuestions = gradingService.getStudentQuestion(response, getQuestionsListMap(true), UUID.randomUUID(), getActivityItemsView());
        Assert.assertNotNull(studentQuestions);
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getMaxScore()==1);
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getScore() == response.getScore());
        Assert.assertTrue(studentQuestions.get(0).getResponses().get(0).getAttempted() == response.isAttempted());
        Assert.assertTrue(response.getQuestionReference().equals(studentQuestions.get(0).getResponses().get(0).getScoreReference()));

    }

    @Test
    public void testconvertToQuestionWithOnlyAutomarkable(){
        List<Questions> Questions = new ArrayList<>();

        Responses response = getResponses(true);
        Map<Questions, List<Scores>> map = getQuestionsListMap(true);
        Set<Questions> questions =  map.keySet();
        questions.forEach(s->{s.setQuestionReference("test");
            s.setErrorMessage("error_testing");});
        Questions = gradingService.getQuestions(getResponseList(true), "test", map, getActivityItemsView());
        Assert.assertNotNull(Questions);
        Assert.assertEquals(Questions.get(0).getErrorMessage(), "error_testing");
        Assert.assertEquals(Questions.get(0).getQuestionReference(), "test");
        Assert.assertTrue(Questions.get(0).getAutomarkable().equals(true));
        Assert.assertTrue(Questions.get(0).getScores().size() == 1);
        Assert.assertTrue(Questions.get(0).getScores().get(0).isAutomarkable());
        Assert.assertEquals(Questions.get(0).getScores().get(0).getScoreReference(), "test");
    }

    @Test
    public void testconvertToQuestionWithOutOnlyAutomarkable(){
        List<Questions> questions = new ArrayList<>();

        Responses response = getResponses(false);
        Map<Questions, List<Scores>> map = getQuestionsListMap(false);

        List<Responses> responsesList = getResponseList(false);
        Responses responses2 = new Responses();
        responses2.setItemReference("786543290");
        responses2.setQuestionReference("786543290");
        responses2.setAutomarkable(false);
        responses2.setResponseId("test");
        responses2.setScore(15);
        responses2.setMaxScore(15);
        responsesList.add(responses2);

        questions = gradingService.getQuestions(responsesList, "786543290", map, getActivityItemsView());
        Assert.assertNotNull(questions);
        Assert.assertNull(questions.get(0).getErrorMessage());
        Assert.assertEquals(questions.get(0).getQuestionReference(), "786543290");
        Assert.assertTrue(questions.get(0).getAutomarkable().equals(false));
       Assert.assertTrue(questions.get(0).getScores().size() == 1);
        Assert.assertFalse(questions.get(0).getScores().get(0).isAutomarkable());
        Assert.assertEquals(questions.get(0).getScores().get(0).getScoreReference(), "SCORE_TESTING");
        Assert.assertEquals(questions.get(0).getScores().get(0).getTitle(), "testing");
        Assert.assertTrue(questions.get(0).getScores().get(0).getMaxScore() == 1);
        Assert.assertTrue(questions.get(0).getScores().get(0).getWeight() == 1);
    }

    @Test
    public void testconvertToQuestionWithNonExistingQuestion(){
        List<Questions> questions = new ArrayList<>();

        List<Responses> responses = getResponseList(true);
        questions = gradingService.getQuestions(responses, "test",getQuestionsListMap(true) , getActivityItemsView());
        Assert.assertNotNull(questions);
        Assert.assertTrue(questions.get(0).getScores().size()==1);
        Assert.assertEquals(questions.get(0).getScores().get(0).getScoreReference(), "test");


    }


    private Responses getResponses(boolean automarkable) {
        Responses responses = new Responses();
        responses.setItemReference("786543290");
        responses.setQuestionReference("786543290");
        responses.setAutomarkable(automarkable);
        responses.setResponseId("test");
        responses.setScore(1);
        responses.setMaxScore(1);
        return responses;
    }

    private List<Responses> getResponseList(boolean automarkable){
        List<Responses> responsesList = new ArrayList<>();
        Responses responses = new Responses();
        responses.setItemReference("test");
        responses.setQuestionReference("test");
        responses.setAutomarkable(automarkable);
        responses.setResponseId("test");
        responses.setScore(10);
        responses.setMaxScore(10);

        Responses responses2 = new Responses();
        responses2.setItemReference("test1");
        responses2.setQuestionReference("test1");
        responses2.setAutomarkable(automarkable);
        responses2.setResponseId("test");
        responses2.setScore(15);
        responses2.setMaxScore(15);
        responsesList.add(responses);
        responsesList.add(responses2);
        return responsesList;
    }

    private Map<Questions , List<Scores>> getQuestionsListMap(boolean automarkable) {


        Map<Questions , List<Scores>> result = new HashMap<>();

        List<Scores> scoresList = new ArrayList<>();
        scoresList.add(getScores());

        Questions questions= new Questions();
        questions.setQuestionReference("786543290");
        questions.setAutomarkable(automarkable);

        result.put(questions,scoresList);

        return result;


    }

    private Scores  getScores() {
        Scores scores = new Scores();

        scores.setMaxScore(1);
        scores.setScoreReference("SCORE_TESTING");
        scores.setAutomarkable(false);
        scores.setWeight(1);
        scores.setDescription("testing");
        scores.setTitle("testing");

        return scores;
    }
}
