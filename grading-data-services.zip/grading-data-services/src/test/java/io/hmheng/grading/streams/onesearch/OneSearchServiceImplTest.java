package io.hmheng.grading.streams.onesearch;


import io.hmheng.grading.authorization.util.HeadersHelper;
import io.hmheng.grading.rest.RestTemplateService;

import io.hmheng.grading.streams.grading.domain.Questions;
import io.hmheng.grading.streams.grading.domain.Scores;
import io.hmheng.grading.streams.onesearch.decorator.Request;
import io.hmheng.grading.streams.onesearch.domain.Assignment;
import io.hmheng.grading.streams.onesearch.domain.DimensionOutcome;
import io.hmheng.grading.streams.onesearch.domain.DimentionQuality;
import io.hmheng.grading.streams.onesearch.domain.Item;
import io.hmheng.grading.streams.onesearch.domain.OneSearchResponse;
import io.hmheng.grading.streams.onesearch.domain.OneSearchRubricResponse;
import io.hmheng.grading.streams.onesearch.domain.Question;
import io.hmheng.grading.streams.onesearch.domain.Rubric;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.http.HttpHeaders;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;





/**
 * Created by tallurir on 10/20/17.
 */
public class OneSearchServiceImplTest {

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    private OneSearchServiceImpl oneSearchService = new OneSearchServiceImpl();

    @Mock
    private HeadersHelper headersHelper;

    @Mock
    private RestTemplateService restTemplateService;


    @Before
    public void setUp() {
        when(headersHelper.createHttpHeadersWithCorrelation(any())).thenReturn(new HttpHeaders());
        when(restTemplateService.getEntity(any(),any(),any(),any())).thenReturn(getOneSearchResponse());

    }

    private <T> T getOneSearchResponse() {

        DimensionOutcome dimensionOutcome = new DimensionOutcome();
        dimensionOutcome.setTitle("test");
        dimensionOutcome.setScore("10");

        List dimensionOutcomes = new ArrayList<DimensionOutcome>();
        dimensionOutcomes.add(dimensionOutcome);

        DimentionQuality dimentionQuality = new DimentionQuality();
        dimentionQuality.setDimensionOutcome(dimensionOutcomes);

        List dimentionQualities = new ArrayList<DimentionQuality>();
        dimentionQualities.add(dimentionQuality);

        Rubric rubric = new Rubric();
        rubric.setDimensionOfQuality(dimentionQualities);
        rubric.setIdentifier("test_rubric");

        List rubrics = new ArrayList<Rubric>();
        rubrics.add(rubric);

        Question question = new Question();
        question.setIdentifier("test");
        question.setManuallyScorable(true);
        question.setRubric(rubrics);

        List questions = new ArrayList<Question>();
        questions.add(question);

        Item item = new Item();
        item.setQuestion(questions);

        List items = new ArrayList<Item>();
        items.add(item);

        Assignment assignment = new Assignment();
        assignment.setItem(items);

        List assignments = new ArrayList<Assignment>();
        assignments.add(assignment);


        OneSearchResponse response = new OneSearchResponse();
        response.setAssessment(assignments);

        return (T) response;
    }

    private List getOneSearchRubricResponse() {
        DimensionOutcome dimensionOutcome = new DimensionOutcome();
        dimensionOutcome.setTitle("test");
        dimensionOutcome.setScore("10");

        List dimensionOutcomes = new ArrayList<DimensionOutcome>();
        dimensionOutcomes.add(dimensionOutcome);

        DimentionQuality dimentionQuality = new DimentionQuality();
        dimentionQuality.setDimensionOutcome(dimensionOutcomes);

        List dimentionQualities = new ArrayList<DimentionQuality>();
        dimentionQualities.add(dimentionQuality);

        Rubric rubric = new Rubric();
        rubric.setDimensionOfQuality(dimentionQualities);
        rubric.setIdentifier("test_rubric");

        List rubrics = new ArrayList<Rubric>();
        rubrics.add(rubric);


        OneSearchRubricResponse response = new OneSearchRubricResponse();
        response.setRubric(rubrics);

        List oneSearchRubricResponses = new ArrayList<OneSearchRubricResponse>();
        oneSearchRubricResponses.add(response);
        return oneSearchRubricResponses;
    }

    private String getOneSearchUrl(){
        return "http://cds-onesearch.int.br.hmheng.io";
    }

    @Test
    public void testSetParameters() {
        oneSearchService.setParameters("test_assementId");
        Assert.assertNotNull(oneSearchService.parameter);
        Assert.assertEquals("test_assementId",oneSearchService.parameter);

    }


    @Test
    public void populateRequestInfoTest() {
        oneSearchService.setParameters("test_assementId");
        Request request = oneSearchService.populateRequestInfo();
        Assert.assertNotNull(request);
        Assert.assertTrue(request.getServiceURI().contains("test_assementId"));
    }


    @Test
    public void processAssementDataTest() {
        oneSearchService.setParameters("test_assementId");
        List<Question> questions = oneSearchService.processAssementData(null);
        Assert.assertNotNull(questions);
        Assert.assertTrue(questions.isEmpty());
    }

    @Test
    public void processAssementDataWithResponseTest() {
        oneSearchService.setParameters("test_assementId");
        List<Question> questions = oneSearchService.processAssementData(getOneSearchResponse());
        Assert.assertNotNull(questions);
        Assert.assertTrue(questions.size()==1);
    }

    @Test
    public void processQuestionRubricsDataTest() {
        oneSearchService.setParameters("test_assementId");
        Map<Questions,List<Scores>> questionScoreMap = oneSearchService.processQuestionRubricsData(null,null);
        Assert.assertNotNull(questionScoreMap);
        Assert.assertTrue(questionScoreMap.isEmpty());
    }


    @Test
    public void processQuestionRubricsWithResponseDataTest() {
        oneSearchService.setParameters("test_assementId");
        List<Question> questions = oneSearchService.processAssementData(getOneSearchResponse());

        Map<Questions,List<Scores>> questionScoreMap = oneSearchService.processQuestionRubricsData(questions,getOneSearchRubricResponse());
        Assert.assertNotNull(questionScoreMap);
        Assert.assertTrue(questionScoreMap.size() == 1);
    }

}
